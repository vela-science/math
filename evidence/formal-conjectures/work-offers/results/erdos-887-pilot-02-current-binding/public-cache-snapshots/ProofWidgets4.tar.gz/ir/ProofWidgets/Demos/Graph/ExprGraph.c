// Lean compiler output
// Module: ProofWidgets.Demos.Graph.ExprGraph
// Imports: Init ProofWidgets.Component.GraphDisplay ProofWidgets.Component.HtmlDisplay Lean.Util.FoldConsts
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* l_Lean_Expr_const___override(lean_object*, lean_object*);
static lean_object* l_exprGraphCmd___closed__9;
static lean_object* l_elabExprGraphCmd___lam__2___closed__0;
static lean_object* l_elabExprGraphCmd___lam__1___closed__22;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___closed__0;
static lean_object* l_exprGraphCmd___closed__6;
lean_object* l_Lean_Widget_ppExprTagged(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__2;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___lam__0(lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12_spec__12___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_ProofWidgets_InteractiveCode;
lean_object* l_instBEqOfDecidableEq___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_ConstantInfo_type(lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__25;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10;
static lean_object* l_elabExprGraphCmd___lam__1___closed__13;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25;
uint64_t lean_uint64_mix_hash(uint64_t, uint64_t);
size_t lean_uint64_to_usize(uint64_t);
lean_object* l_Lean_findDocString_x3f(lean_object*, lean_object*, uint8_t, lean_object*);
lean_object* l_Lean_Name_toString(lean_object*, uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8___redArg(lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14;
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9;
uint8_t lean_usize_dec_eq(size_t, size_t);
LEAN_EXPORT uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___redArg(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33;
lean_object* l_Lean_ConstantInfo_getUsedConstantsAsSet(lean_object*);
static lean_object* l_elabExprGraphCmd___closed__2;
static lean_object* l_foo___closed__2;
lean_object* lean_mk_array(lean_object*, lean_object*);
static lean_object* l_exprGraphCmd___closed__0;
static lean_object* l_elabExprGraphCmd___lam__1___closed__18;
lean_object* lean_array_fset(lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(lean_object*, lean_object*, lean_object*);
static double l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34;
lean_object* l_Lean_Environment_find_x3f(lean_object*, lean_object*, uint8_t);
static lean_object* l_elabExprGraphCmd___lam__1___closed__12;
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__27;
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___redArg(lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
uint64_t lean_string_hash(lean_object*);
static lean_object* l_foo___closed__1;
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__15;
lean_object* l_Lean_stringToMessageData(lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36;
static lean_object* l_elabExprGraphCmd___lam__1___closed__11;
static lean_object* l_elabExprGraphCmd___lam__1___closed__5;
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
LEAN_EXPORT lean_object* l_foo___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12_spec__12(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__7;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16;
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5___boxed(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5(lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
static lean_object* l_exprGraphCmd___closed__10;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2(lean_object*, uint8_t, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6(lean_object*, size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
extern lean_object* l_ProofWidgets_MarkdownDisplay;
lean_object* lean_nat_to_int(lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13;
lean_object* l_Lean_MessageData_ofSyntax(lean_object*);
LEAN_EXPORT uint8_t l_elabExprGraphCmd___lam__0(lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27;
static lean_object* l_exprGraphCmd___closed__7;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11;
LEAN_EXPORT lean_object* l_a;
double lean_float_of_nat(lean_object*);
lean_object* lean_st_ref_get(lean_object*, lean_object*);
extern lean_object* l_ProofWidgets_HtmlDisplayPanel;
lean_object* l_Lean_PrettyPrinter_Delaborator_delab(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__8;
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Elab_realizeGlobalConstNoOverloadWithInfo(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__24;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2(lean_object*, uint8_t, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_foo___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_exprGraphCmd___closed__3;
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__1(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic___hyg_49_(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32;
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_exprGraphCmd;
static lean_object* l_elabExprGraphCmd___lam__1___closed__14;
static lean_object* l_elabExprGraphCmd___lam__1___closed__17;
LEAN_EXPORT lean_object* l_b;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_exprGraphCmd___closed__1;
lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps____x40_ProofWidgets_Component_Basic___hyg_924_(lean_object*);
LEAN_EXPORT uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7(lean_object*, lean_object*, lean_object*);
double l_Float_ofScientific(lean_object*, uint8_t, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__6;
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8;
lean_object* lean_array_fget(lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__26;
lean_object* l_Lean_Widget_savePanelWidgetInfo(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_instBEqProd___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_length(lean_object*);
lean_object* l_Lean_Meta_mkFreshLevelMVarsFor(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__19;
static lean_object* l_elabExprGraphCmd___lam__1___closed__9;
lean_object* l_String_hash___boxed(lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_GraphDisplay_instRpcEncodableProps_enc____x40_ProofWidgets_Component_GraphDisplay___hyg_4052_(lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__21;
static lean_object* l_elabExprGraphCmd___lam__1___closed__1;
static lean_object* l_elabExprGraphCmd___lam__1___closed__4;
static lean_object* l_elabExprGraphCmd___lam__1___closed__10;
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t l_Lean_NameSet_contains(lean_object*, lean_object*);
extern lean_object* l_ProofWidgets_GraphDisplay;
uint64_t lean_uint64_xor(uint64_t, uint64_t);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(lean_object*, uint8_t, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19;
lean_object* l_Lean_RBTree_toArray___at___Lean_mkModuleData_spec__2(lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* l_Nat_nextPowerOfTwo(lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8_spec__8___redArg(lean_object*, lean_object*);
size_t lean_usize_sub(size_t, size_t);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8_spec__8(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0;
lean_object* l_Lean_throwError___at_____private_Lean_Elab_Command_0__Lean_Elab_Command_elabCommandUsing_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__16;
size_t lean_usize_add(size_t, size_t);
static lean_object* l_exprGraphCmd___closed__2;
static lean_object* l_exprGraphCmd___closed__8;
static lean_object* l_elabExprGraphCmd___lam__1___closed__23;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18;
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_array_size(lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5;
lean_object* l_instHashableProd___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l_foo(lean_object*);
static lean_object* l_elabExprGraphCmd___closed__1;
lean_object* l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__0___boxed(lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31;
lean_object* l_Lean_Elab_Command_runTermElabM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12;
LEAN_EXPORT lean_object* l_elabExprGraphCmd(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* lean_int_ediv(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__28;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26;
static lean_object* l_exprGraphCmd___closed__4;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15;
static lean_object* l_elabExprGraphCmd___lam__1___closed__0;
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__2(lean_object*, lean_object*, lean_object*);
static lean_object* l_elabExprGraphCmd___closed__3;
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
static lean_object* l_elabExprGraphCmd___lam__1___closed__20;
static lean_object* l_exprGraphCmd___closed__5;
lean_object* l_instDecidableEqString___boxed(lean_object*, lean_object*);
size_t lean_usize_land(size_t, size_t);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29;
LEAN_EXPORT lean_object* l_elabExprGraphCmd___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24;
static lean_object* _init_l_exprGraphCmd___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("exprGraphCmd", 12, 12);
return x_1;
}
}
static lean_object* _init_l_exprGraphCmd___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("andthen", 7, 7);
return x_1;
}
}
static lean_object* _init_l_exprGraphCmd___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__2;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("#expr_graph", 11, 11);
return x_1;
}
}
static lean_object* _init_l_exprGraphCmd___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__4;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ident", 5, 5);
return x_1;
}
}
static lean_object* _init_l_exprGraphCmd___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__6;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_exprGraphCmd___closed__7;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_exprGraphCmd___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_exprGraphCmd___closed__8;
x_2 = l_exprGraphCmd___closed__5;
x_3 = l_exprGraphCmd___closed__3;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_exprGraphCmd___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_exprGraphCmd___closed__9;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_exprGraphCmd___closed__1;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_exprGraphCmd() {
_start:
{
lean_object* x_1; 
x_1 = l_exprGraphCmd___closed__10;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; uint64_t x_7; lean_object* x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_string_hash(x_6);
x_8 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic___hyg_49_), 2, 1);
lean_closure_set(x_8, 0, x_2);
lean_inc(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_8);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_7);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps____x40_ProofWidgets_Component_Basic___hyg_924_(x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___lam__0), 2, 1);
lean_closure_set(x_7, 0, x_2);
x_8 = lean_string_hash(x_6);
lean_inc(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_7);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_8);
return x_9;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delab), 7, 0);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("g", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ellipse", 7, 7);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("fill", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("var(--vscode-editor-background)", 31, 31);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("stroke", 6, 6);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("var(--vscode-editorHoverWidget-border)", 38, 38);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("rx", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ry", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("10", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("text", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("x", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("-", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("y", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("5", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("className", 9, 9);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("font-code", 9, 9);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static double _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34() {
_start:
{
lean_object* x_1; double x_2; 
x_1 = lean_unsigned_to_nat(20u);
x_2 = lean_float_of_nat(x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("span", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" : ", 3, 3);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("div", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, size_t x_5, size_t x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
lean_object* x_13; lean_object* x_14; uint8_t x_19; 
x_19 = lean_usize_dec_lt(x_6, x_5);
if (x_19 == 0)
{
lean_object* x_20; 
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_3);
lean_dec(x_1);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_7);
lean_ctor_set(x_20, 1, x_12);
return x_20;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; uint8_t x_26; lean_object* x_27; 
x_21 = lean_ctor_get(x_7, 0);
lean_inc(x_21);
x_22 = lean_ctor_get(x_7, 1);
lean_inc(x_22);
if (lean_is_exclusive(x_7)) {
 lean_ctor_release(x_7, 0);
 lean_ctor_release(x_7, 1);
 x_23 = x_7;
} else {
 lean_dec_ref(x_7);
 x_23 = lean_box(0);
}
x_24 = lean_array_uget(x_4, x_6);
x_25 = lean_box(0);
x_26 = lean_unbox(x_25);
lean_inc(x_24);
lean_inc(x_1);
x_27 = l_Lean_Environment_find_x3f(x_1, x_24, x_26);
if (lean_obj_tag(x_27) == 0)
{
lean_object* x_28; 
lean_dec(x_24);
if (lean_is_scalar(x_23)) {
 x_28 = lean_alloc_ctor(0, 2, 0);
} else {
 x_28 = x_23;
}
lean_ctor_set(x_28, 0, x_21);
lean_ctor_set(x_28, 1, x_22);
x_13 = x_28;
x_14 = x_12;
goto block_18;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_29 = lean_ctor_get(x_27, 0);
lean_inc(x_29);
if (lean_is_exclusive(x_27)) {
 lean_ctor_release(x_27, 0);
 x_30 = x_27;
} else {
 lean_dec_ref(x_27);
 x_30 = lean_box(0);
}
lean_inc(x_24);
lean_inc(x_1);
x_31 = l_Lean_findDocString_x3f(x_1, x_24, x_2, x_12);
x_32 = lean_ctor_get(x_31, 0);
lean_inc(x_32);
x_33 = lean_ctor_get(x_31, 1);
lean_inc(x_33);
if (lean_is_exclusive(x_31)) {
 lean_ctor_release(x_31, 0);
 lean_ctor_release(x_31, 1);
 x_34 = x_31;
} else {
 lean_dec_ref(x_31);
 x_34 = lean_box(0);
}
x_35 = l_Lean_ConstantInfo_type(x_29);
x_36 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0;
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
x_37 = l_Lean_Widget_ppExprTagged(x_35, x_36, x_8, x_9, x_10, x_11, x_33);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
x_40 = l_Lean_Meta_mkFreshLevelMVarsFor(x_29, x_8, x_9, x_10, x_11, x_39);
lean_dec(x_29);
x_41 = lean_ctor_get(x_40, 0);
lean_inc(x_41);
x_42 = lean_ctor_get(x_40, 1);
lean_inc(x_42);
if (lean_is_exclusive(x_40)) {
 lean_ctor_release(x_40, 0);
 lean_ctor_release(x_40, 1);
 x_43 = x_40;
} else {
 lean_dec_ref(x_40);
 x_43 = lean_box(0);
}
lean_inc(x_24);
x_44 = l_Lean_Expr_const___override(x_24, x_41);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
x_45 = l_Lean_Widget_ppExprTagged(x_44, x_36, x_8, x_9, x_10, x_11, x_42);
if (lean_obj_tag(x_45) == 0)
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; uint8_t x_141; 
x_46 = lean_ctor_get(x_45, 0);
lean_inc(x_46);
x_47 = lean_ctor_get(x_45, 1);
lean_inc(x_47);
lean_dec(x_45);
lean_inc(x_3);
x_48 = l_Lean_Name_toString(x_24, x_2, x_3);
x_57 = lean_string_length(x_48);
x_58 = lean_unsigned_to_nat(3u);
x_59 = lean_nat_mul(x_57, x_58);
lean_dec(x_57);
x_141 = lean_nat_dec_le(x_21, x_59);
if (x_141 == 0)
{
x_60 = x_21;
goto block_140;
}
else
{
lean_dec(x_21);
lean_inc(x_59);
x_60 = x_59;
goto block_140;
}
block_56:
{
lean_object* x_53; lean_object* x_54; lean_object* x_55; 
x_53 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_53, 0, x_48);
lean_ctor_set(x_53, 1, x_49);
lean_ctor_set(x_53, 2, x_50);
lean_ctor_set(x_53, 3, x_52);
x_54 = lean_array_push(x_22, x_53);
if (lean_is_scalar(x_23)) {
 x_55 = lean_alloc_ctor(0, 2, 0);
} else {
 x_55 = x_23;
}
lean_ctor_set(x_55, 0, x_51);
lean_ctor_set(x_55, 1, x_54);
x_13 = x_55;
x_14 = x_47;
goto block_18;
}
block_140:
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; double x_99; double x_100; lean_object* x_101; 
x_61 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1;
x_62 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2;
x_63 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3;
x_64 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12;
x_65 = lean_unsigned_to_nat(2u);
x_66 = lean_nat_mul(x_59, x_65);
x_67 = l_Lean_JsonNumber_fromNat(x_66);
x_68 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_68, 0, x_67);
if (lean_is_scalar(x_43)) {
 x_69 = lean_alloc_ctor(0, 2, 0);
} else {
 x_69 = x_43;
}
lean_ctor_set(x_69, 0, x_64);
lean_ctor_set(x_69, 1, x_68);
x_70 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16;
x_71 = lean_unsigned_to_nat(4u);
x_72 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_73 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19;
x_74 = lean_array_push(x_73, x_69);
x_75 = lean_array_push(x_74, x_70);
x_76 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_76, 0, x_63);
lean_ctor_set(x_76, 1, x_75);
lean_ctor_set(x_76, 2, x_62);
x_77 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20;
x_78 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21;
x_79 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22;
lean_inc(x_59);
x_80 = l_Nat_reprFast(x_59);
x_81 = lean_string_append(x_79, x_80);
lean_dec(x_80);
x_82 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_82, 0, x_81);
if (lean_is_scalar(x_34)) {
 x_83 = lean_alloc_ctor(0, 2, 0);
} else {
 x_83 = x_34;
}
lean_ctor_set(x_83, 0, x_78);
lean_ctor_set(x_83, 1, x_82);
x_84 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26;
x_85 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30;
x_86 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31;
x_87 = lean_array_push(x_86, x_83);
x_88 = lean_array_push(x_87, x_84);
x_89 = lean_array_push(x_88, x_85);
lean_inc(x_48);
x_90 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_90, 0, x_48);
x_91 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32;
x_92 = lean_array_push(x_91, x_90);
x_93 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_93, 0, x_77);
lean_ctor_set(x_93, 1, x_89);
lean_ctor_set(x_93, 2, x_92);
x_94 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33;
x_95 = lean_array_push(x_94, x_76);
x_96 = lean_array_push(x_95, x_93);
x_97 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_97, 0, x_61);
lean_ctor_set(x_97, 1, x_62);
lean_ctor_set(x_97, 2, x_96);
x_98 = lean_nat_mul(x_59, x_71);
lean_dec(x_59);
x_99 = lean_float_of_nat(x_98);
x_100 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34;
x_101 = lean_alloc_ctor(1, 0, 16);
lean_ctor_set_float(x_101, 0, x_99);
lean_ctor_set_float(x_101, 8, x_100);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; 
x_102 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35;
x_103 = l_ProofWidgets_InteractiveCode;
x_104 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_103, x_46, x_62);
x_105 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_106 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_103, x_38, x_62);
x_107 = lean_array_push(x_86, x_104);
x_108 = lean_array_push(x_107, x_105);
x_109 = lean_array_push(x_108, x_106);
x_110 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_110, 0, x_102);
lean_ctor_set(x_110, 1, x_62);
lean_ctor_set(x_110, 2, x_109);
if (lean_is_scalar(x_30)) {
 x_111 = lean_alloc_ctor(1, 1, 0);
} else {
 x_111 = x_30;
}
lean_ctor_set(x_111, 0, x_110);
x_49 = x_97;
x_50 = x_101;
x_51 = x_60;
x_52 = x_111;
goto block_56;
}
else
{
uint8_t x_112; 
lean_dec(x_30);
x_112 = !lean_is_exclusive(x_32);
if (x_112 == 0)
{
lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; 
x_113 = lean_ctor_get(x_32, 0);
x_114 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
x_115 = l_ProofWidgets_InteractiveCode;
x_116 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_115, x_46, x_62);
x_117 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_118 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_115, x_38, x_62);
x_119 = l_ProofWidgets_MarkdownDisplay;
x_120 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_119, x_113, x_62);
x_121 = lean_array_push(x_72, x_116);
x_122 = lean_array_push(x_121, x_117);
x_123 = lean_array_push(x_122, x_118);
x_124 = lean_array_push(x_123, x_120);
x_125 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_125, 0, x_114);
lean_ctor_set(x_125, 1, x_62);
lean_ctor_set(x_125, 2, x_124);
lean_ctor_set(x_32, 0, x_125);
x_49 = x_97;
x_50 = x_101;
x_51 = x_60;
x_52 = x_32;
goto block_56;
}
else
{
lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; 
x_126 = lean_ctor_get(x_32, 0);
lean_inc(x_126);
lean_dec(x_32);
x_127 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
x_128 = l_ProofWidgets_InteractiveCode;
x_129 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_128, x_46, x_62);
x_130 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_131 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_128, x_38, x_62);
x_132 = l_ProofWidgets_MarkdownDisplay;
x_133 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_132, x_126, x_62);
x_134 = lean_array_push(x_72, x_129);
x_135 = lean_array_push(x_134, x_130);
x_136 = lean_array_push(x_135, x_131);
x_137 = lean_array_push(x_136, x_133);
x_138 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_138, 0, x_127);
lean_ctor_set(x_138, 1, x_62);
lean_ctor_set(x_138, 2, x_137);
x_139 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_139, 0, x_138);
x_49 = x_97;
x_50 = x_101;
x_51 = x_60;
x_52 = x_139;
goto block_56;
}
}
}
}
else
{
uint8_t x_142; 
lean_dec(x_43);
lean_dec(x_38);
lean_dec(x_34);
lean_dec(x_32);
lean_dec(x_30);
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_21);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_3);
lean_dec(x_1);
x_142 = !lean_is_exclusive(x_45);
if (x_142 == 0)
{
return x_45;
}
else
{
lean_object* x_143; lean_object* x_144; lean_object* x_145; 
x_143 = lean_ctor_get(x_45, 0);
x_144 = lean_ctor_get(x_45, 1);
lean_inc(x_144);
lean_inc(x_143);
lean_dec(x_45);
x_145 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_145, 0, x_143);
lean_ctor_set(x_145, 1, x_144);
return x_145;
}
}
}
else
{
uint8_t x_146; 
lean_dec(x_34);
lean_dec(x_32);
lean_dec(x_30);
lean_dec(x_29);
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_21);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_3);
lean_dec(x_1);
x_146 = !lean_is_exclusive(x_37);
if (x_146 == 0)
{
return x_37;
}
else
{
lean_object* x_147; lean_object* x_148; lean_object* x_149; 
x_147 = lean_ctor_get(x_37, 0);
x_148 = lean_ctor_get(x_37, 1);
lean_inc(x_148);
lean_inc(x_147);
lean_dec(x_37);
x_149 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_149, 0, x_147);
lean_ctor_set(x_149, 1, x_148);
return x_149;
}
}
}
}
block_18:
{
size_t x_15; size_t x_16; 
x_15 = 1;
x_16 = lean_usize_add(x_6, x_15);
x_6 = x_16;
x_7 = x_13;
x_12 = x_14;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, size_t x_5, size_t x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; 
x_15 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_10, x_11, x_12, x_13, x_14);
return x_15;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, size_t x_5, size_t x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; lean_object* x_16; uint8_t x_21; 
x_21 = lean_usize_dec_lt(x_6, x_5);
if (x_21 == 0)
{
lean_object* x_22; 
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_3);
lean_dec(x_1);
x_22 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_22, 0, x_7);
lean_ctor_set(x_22, 1, x_14);
return x_22;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; uint8_t x_28; lean_object* x_29; 
x_23 = lean_ctor_get(x_7, 0);
lean_inc(x_23);
x_24 = lean_ctor_get(x_7, 1);
lean_inc(x_24);
if (lean_is_exclusive(x_7)) {
 lean_ctor_release(x_7, 0);
 lean_ctor_release(x_7, 1);
 x_25 = x_7;
} else {
 lean_dec_ref(x_7);
 x_25 = lean_box(0);
}
x_26 = lean_array_uget(x_4, x_6);
x_27 = lean_box(0);
x_28 = lean_unbox(x_27);
lean_inc(x_26);
lean_inc(x_1);
x_29 = l_Lean_Environment_find_x3f(x_1, x_26, x_28);
if (lean_obj_tag(x_29) == 0)
{
lean_object* x_30; 
lean_dec(x_26);
if (lean_is_scalar(x_25)) {
 x_30 = lean_alloc_ctor(0, 2, 0);
} else {
 x_30 = x_25;
}
lean_ctor_set(x_30, 0, x_23);
lean_ctor_set(x_30, 1, x_24);
x_15 = x_30;
x_16 = x_14;
goto block_20;
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_31 = lean_ctor_get(x_29, 0);
lean_inc(x_31);
if (lean_is_exclusive(x_29)) {
 lean_ctor_release(x_29, 0);
 x_32 = x_29;
} else {
 lean_dec_ref(x_29);
 x_32 = lean_box(0);
}
lean_inc(x_26);
lean_inc(x_1);
x_33 = l_Lean_findDocString_x3f(x_1, x_26, x_2, x_14);
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_33, 1);
lean_inc(x_35);
if (lean_is_exclusive(x_33)) {
 lean_ctor_release(x_33, 0);
 lean_ctor_release(x_33, 1);
 x_36 = x_33;
} else {
 lean_dec_ref(x_33);
 x_36 = lean_box(0);
}
x_37 = l_Lean_ConstantInfo_type(x_31);
x_38 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0;
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
x_39 = l_Lean_Widget_ppExprTagged(x_37, x_38, x_10, x_11, x_12, x_13, x_35);
if (lean_obj_tag(x_39) == 0)
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; 
x_40 = lean_ctor_get(x_39, 0);
lean_inc(x_40);
x_41 = lean_ctor_get(x_39, 1);
lean_inc(x_41);
lean_dec(x_39);
x_42 = l_Lean_Meta_mkFreshLevelMVarsFor(x_31, x_10, x_11, x_12, x_13, x_41);
lean_dec(x_31);
x_43 = lean_ctor_get(x_42, 0);
lean_inc(x_43);
x_44 = lean_ctor_get(x_42, 1);
lean_inc(x_44);
if (lean_is_exclusive(x_42)) {
 lean_ctor_release(x_42, 0);
 lean_ctor_release(x_42, 1);
 x_45 = x_42;
} else {
 lean_dec_ref(x_42);
 x_45 = lean_box(0);
}
lean_inc(x_26);
x_46 = l_Lean_Expr_const___override(x_26, x_43);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
x_47 = l_Lean_Widget_ppExprTagged(x_46, x_38, x_10, x_11, x_12, x_13, x_44);
if (lean_obj_tag(x_47) == 0)
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; uint8_t x_143; 
x_48 = lean_ctor_get(x_47, 0);
lean_inc(x_48);
x_49 = lean_ctor_get(x_47, 1);
lean_inc(x_49);
lean_dec(x_47);
lean_inc(x_3);
x_50 = l_Lean_Name_toString(x_26, x_2, x_3);
x_59 = lean_string_length(x_50);
x_60 = lean_unsigned_to_nat(3u);
x_61 = lean_nat_mul(x_59, x_60);
lean_dec(x_59);
x_143 = lean_nat_dec_le(x_23, x_61);
if (x_143 == 0)
{
x_62 = x_23;
goto block_142;
}
else
{
lean_dec(x_23);
lean_inc(x_61);
x_62 = x_61;
goto block_142;
}
block_58:
{
lean_object* x_55; lean_object* x_56; lean_object* x_57; 
x_55 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_55, 0, x_50);
lean_ctor_set(x_55, 1, x_52);
lean_ctor_set(x_55, 2, x_53);
lean_ctor_set(x_55, 3, x_54);
x_56 = lean_array_push(x_24, x_55);
if (lean_is_scalar(x_25)) {
 x_57 = lean_alloc_ctor(0, 2, 0);
} else {
 x_57 = x_25;
}
lean_ctor_set(x_57, 0, x_51);
lean_ctor_set(x_57, 1, x_56);
x_15 = x_57;
x_16 = x_49;
goto block_20;
}
block_142:
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; double x_101; double x_102; lean_object* x_103; 
x_63 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1;
x_64 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2;
x_65 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3;
x_66 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12;
x_67 = lean_unsigned_to_nat(2u);
x_68 = lean_nat_mul(x_61, x_67);
x_69 = l_Lean_JsonNumber_fromNat(x_68);
x_70 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_70, 0, x_69);
if (lean_is_scalar(x_45)) {
 x_71 = lean_alloc_ctor(0, 2, 0);
} else {
 x_71 = x_45;
}
lean_ctor_set(x_71, 0, x_66);
lean_ctor_set(x_71, 1, x_70);
x_72 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16;
x_73 = lean_unsigned_to_nat(4u);
x_74 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_75 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19;
x_76 = lean_array_push(x_75, x_71);
x_77 = lean_array_push(x_76, x_72);
x_78 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_78, 0, x_65);
lean_ctor_set(x_78, 1, x_77);
lean_ctor_set(x_78, 2, x_64);
x_79 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20;
x_80 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21;
x_81 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22;
lean_inc(x_61);
x_82 = l_Nat_reprFast(x_61);
x_83 = lean_string_append(x_81, x_82);
lean_dec(x_82);
x_84 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_84, 0, x_83);
if (lean_is_scalar(x_36)) {
 x_85 = lean_alloc_ctor(0, 2, 0);
} else {
 x_85 = x_36;
}
lean_ctor_set(x_85, 0, x_80);
lean_ctor_set(x_85, 1, x_84);
x_86 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26;
x_87 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30;
x_88 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31;
x_89 = lean_array_push(x_88, x_85);
x_90 = lean_array_push(x_89, x_86);
x_91 = lean_array_push(x_90, x_87);
lean_inc(x_50);
x_92 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_92, 0, x_50);
x_93 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32;
x_94 = lean_array_push(x_93, x_92);
x_95 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_95, 0, x_79);
lean_ctor_set(x_95, 1, x_91);
lean_ctor_set(x_95, 2, x_94);
x_96 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33;
x_97 = lean_array_push(x_96, x_78);
x_98 = lean_array_push(x_97, x_95);
x_99 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_99, 0, x_63);
lean_ctor_set(x_99, 1, x_64);
lean_ctor_set(x_99, 2, x_98);
x_100 = lean_nat_mul(x_61, x_73);
lean_dec(x_61);
x_101 = lean_float_of_nat(x_100);
x_102 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34;
x_103 = lean_alloc_ctor(1, 0, 16);
lean_ctor_set_float(x_103, 0, x_101);
lean_ctor_set_float(x_103, 8, x_102);
if (lean_obj_tag(x_34) == 0)
{
lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; 
x_104 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35;
x_105 = l_ProofWidgets_InteractiveCode;
x_106 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_105, x_48, x_64);
x_107 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_108 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_105, x_40, x_64);
x_109 = lean_array_push(x_88, x_106);
x_110 = lean_array_push(x_109, x_107);
x_111 = lean_array_push(x_110, x_108);
x_112 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_112, 0, x_104);
lean_ctor_set(x_112, 1, x_64);
lean_ctor_set(x_112, 2, x_111);
if (lean_is_scalar(x_32)) {
 x_113 = lean_alloc_ctor(1, 1, 0);
} else {
 x_113 = x_32;
}
lean_ctor_set(x_113, 0, x_112);
x_51 = x_62;
x_52 = x_99;
x_53 = x_103;
x_54 = x_113;
goto block_58;
}
else
{
uint8_t x_114; 
lean_dec(x_32);
x_114 = !lean_is_exclusive(x_34);
if (x_114 == 0)
{
lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; 
x_115 = lean_ctor_get(x_34, 0);
x_116 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
x_117 = l_ProofWidgets_InteractiveCode;
x_118 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_117, x_48, x_64);
x_119 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_120 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_117, x_40, x_64);
x_121 = l_ProofWidgets_MarkdownDisplay;
x_122 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_121, x_115, x_64);
x_123 = lean_array_push(x_74, x_118);
x_124 = lean_array_push(x_123, x_119);
x_125 = lean_array_push(x_124, x_120);
x_126 = lean_array_push(x_125, x_122);
x_127 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_127, 0, x_116);
lean_ctor_set(x_127, 1, x_64);
lean_ctor_set(x_127, 2, x_126);
lean_ctor_set(x_34, 0, x_127);
x_51 = x_62;
x_52 = x_99;
x_53 = x_103;
x_54 = x_34;
goto block_58;
}
else
{
lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; lean_object* x_140; lean_object* x_141; 
x_128 = lean_ctor_get(x_34, 0);
lean_inc(x_128);
lean_dec(x_34);
x_129 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38;
x_130 = l_ProofWidgets_InteractiveCode;
x_131 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_130, x_48, x_64);
x_132 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37;
x_133 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_130, x_40, x_64);
x_134 = l_ProofWidgets_MarkdownDisplay;
x_135 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_134, x_128, x_64);
x_136 = lean_array_push(x_74, x_131);
x_137 = lean_array_push(x_136, x_132);
x_138 = lean_array_push(x_137, x_133);
x_139 = lean_array_push(x_138, x_135);
x_140 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_140, 0, x_129);
lean_ctor_set(x_140, 1, x_64);
lean_ctor_set(x_140, 2, x_139);
x_141 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_141, 0, x_140);
x_51 = x_62;
x_52 = x_99;
x_53 = x_103;
x_54 = x_141;
goto block_58;
}
}
}
}
else
{
uint8_t x_144; 
lean_dec(x_45);
lean_dec(x_40);
lean_dec(x_36);
lean_dec(x_34);
lean_dec(x_32);
lean_dec(x_26);
lean_dec(x_25);
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_3);
lean_dec(x_1);
x_144 = !lean_is_exclusive(x_47);
if (x_144 == 0)
{
return x_47;
}
else
{
lean_object* x_145; lean_object* x_146; lean_object* x_147; 
x_145 = lean_ctor_get(x_47, 0);
x_146 = lean_ctor_get(x_47, 1);
lean_inc(x_146);
lean_inc(x_145);
lean_dec(x_47);
x_147 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_147, 0, x_145);
lean_ctor_set(x_147, 1, x_146);
return x_147;
}
}
}
else
{
uint8_t x_148; 
lean_dec(x_36);
lean_dec(x_34);
lean_dec(x_32);
lean_dec(x_31);
lean_dec(x_26);
lean_dec(x_25);
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_3);
lean_dec(x_1);
x_148 = !lean_is_exclusive(x_39);
if (x_148 == 0)
{
return x_39;
}
else
{
lean_object* x_149; lean_object* x_150; lean_object* x_151; 
x_149 = lean_ctor_get(x_39, 0);
x_150 = lean_ctor_get(x_39, 1);
lean_inc(x_150);
lean_inc(x_149);
lean_dec(x_39);
x_151 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_151, 0, x_149);
lean_ctor_set(x_151, 1, x_150);
return x_151;
}
}
}
}
block_20:
{
size_t x_17; size_t x_18; lean_object* x_19; 
x_17 = 1;
x_18 = lean_usize_add(x_6, x_17);
x_19 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(x_1, x_2, x_3, x_4, x_5, x_18, x_15, x_10, x_11, x_12, x_13, x_16);
return x_19;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; uint64_t x_7; lean_object* x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_string_hash(x_6);
x_8 = lean_alloc_closure((void*)(l_ProofWidgets_GraphDisplay_instRpcEncodableProps_enc____x40_ProofWidgets_Component_GraphDisplay___hyg_4052_), 2, 1);
lean_closure_set(x_8, 0, x_2);
lean_inc(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_8);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_7);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
return x_1;
}
else
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_3 = lean_ctor_get(x_2, 0);
x_4 = lean_ctor_get(x_2, 2);
x_5 = lean_ctor_get(x_3, 0);
x_6 = lean_ctor_get(x_3, 1);
x_7 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2;
x_8 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
x_9 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_6);
lean_ctor_set(x_9, 2, x_7);
lean_ctor_set(x_9, 3, x_8);
lean_ctor_set(x_9, 4, x_8);
x_10 = lean_array_push(x_1, x_9);
x_1 = x_10;
x_2 = x_4;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_eq(x_2, x_3);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; size_t x_8; size_t x_9; 
x_6 = lean_array_uget(x_1, x_2);
x_7 = l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5(x_4, x_6);
lean_dec(x_6);
x_8 = 1;
x_9 = lean_usize_add(x_2, x_8);
x_2 = x_9;
x_4 = x_7;
goto _start;
}
else
{
return x_4;
}
}
}
LEAN_EXPORT uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
lean_object* x_3; uint8_t x_4; 
x_3 = lean_box(0);
x_4 = lean_unbox(x_3);
return x_4;
}
else
{
lean_object* x_5; lean_object* x_6; uint8_t x_7; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_5 = lean_ctor_get(x_2, 0);
x_6 = lean_ctor_get(x_2, 2);
x_10 = lean_ctor_get(x_5, 0);
x_11 = lean_ctor_get(x_5, 1);
x_12 = lean_ctor_get(x_1, 0);
x_13 = lean_ctor_get(x_1, 1);
x_14 = lean_string_dec_eq(x_10, x_12);
if (x_14 == 0)
{
x_7 = x_14;
goto block_9;
}
else
{
uint8_t x_15; 
x_15 = lean_string_dec_eq(x_11, x_13);
x_7 = x_15;
goto block_9;
}
block_9:
{
if (x_7 == 0)
{
x_2 = x_6;
goto _start;
}
else
{
return x_7;
}
}
}
}
}
LEAN_EXPORT uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___redArg(x_2, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8_spec__8___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
return x_1;
}
else
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; uint64_t x_9; uint64_t x_10; uint64_t x_11; uint64_t x_12; uint64_t x_13; uint64_t x_14; uint64_t x_15; uint64_t x_16; uint64_t x_17; size_t x_18; size_t x_19; size_t x_20; size_t x_21; size_t x_22; lean_object* x_23; lean_object* x_24; 
x_4 = lean_ctor_get(x_2, 0);
x_5 = lean_ctor_get(x_2, 2);
x_6 = lean_ctor_get(x_4, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_4, 1);
lean_inc(x_7);
x_8 = lean_array_get_size(x_1);
x_9 = lean_string_hash(x_6);
lean_dec(x_6);
x_10 = lean_string_hash(x_7);
lean_dec(x_7);
x_11 = lean_uint64_mix_hash(x_9, x_10);
x_12 = 32;
x_13 = lean_uint64_shift_right(x_11, x_12);
x_14 = lean_uint64_xor(x_11, x_13);
x_15 = 16;
x_16 = lean_uint64_shift_right(x_14, x_15);
x_17 = lean_uint64_xor(x_14, x_16);
x_18 = lean_uint64_to_usize(x_17);
x_19 = lean_usize_of_nat(x_8);
lean_dec(x_8);
x_20 = 1;
x_21 = lean_usize_sub(x_19, x_20);
x_22 = lean_usize_land(x_18, x_21);
x_23 = lean_array_uget(x_1, x_22);
lean_ctor_set(x_2, 2, x_23);
x_24 = lean_array_uset(x_1, x_22, x_2);
x_1 = x_24;
x_2 = x_5;
goto _start;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; uint64_t x_32; uint64_t x_33; uint64_t x_34; uint64_t x_35; uint64_t x_36; uint64_t x_37; uint64_t x_38; uint64_t x_39; uint64_t x_40; size_t x_41; size_t x_42; size_t x_43; size_t x_44; size_t x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_26 = lean_ctor_get(x_2, 0);
x_27 = lean_ctor_get(x_2, 1);
x_28 = lean_ctor_get(x_2, 2);
lean_inc(x_28);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_2);
x_29 = lean_ctor_get(x_26, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_26, 1);
lean_inc(x_30);
x_31 = lean_array_get_size(x_1);
x_32 = lean_string_hash(x_29);
lean_dec(x_29);
x_33 = lean_string_hash(x_30);
lean_dec(x_30);
x_34 = lean_uint64_mix_hash(x_32, x_33);
x_35 = 32;
x_36 = lean_uint64_shift_right(x_34, x_35);
x_37 = lean_uint64_xor(x_34, x_36);
x_38 = 16;
x_39 = lean_uint64_shift_right(x_37, x_38);
x_40 = lean_uint64_xor(x_37, x_39);
x_41 = lean_uint64_to_usize(x_40);
x_42 = lean_usize_of_nat(x_31);
lean_dec(x_31);
x_43 = 1;
x_44 = lean_usize_sub(x_42, x_43);
x_45 = lean_usize_land(x_41, x_44);
x_46 = lean_array_uget(x_1, x_45);
x_47 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_47, 0, x_26);
lean_ctor_set(x_47, 1, x_27);
lean_ctor_set(x_47, 2, x_46);
x_48 = lean_array_uset(x_1, x_45, x_47);
x_1 = x_48;
x_2 = x_28;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8_spec__8(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Std_DHashMap_Internal_AssocList_foldlM___at___Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8_spec__8___redArg(x_2, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; uint8_t x_5; 
x_4 = lean_array_get_size(x_2);
x_5 = lean_nat_dec_lt(x_1, x_4);
lean_dec(x_4);
if (x_5 == 0)
{
lean_dec(x_2);
lean_dec(x_1);
return x_3;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_6 = lean_array_fget(x_2, x_1);
x_7 = lean_box(0);
x_8 = lean_array_fset(x_2, x_1, x_7);
x_9 = l_Std_DHashMap_Internal_AssocList_foldlM___at___Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8_spec__8___redArg(x_3, x_6);
x_10 = lean_unsigned_to_nat(1u);
x_11 = lean_nat_add(x_1, x_10);
lean_dec(x_1);
x_1 = x_11;
x_2 = x_8;
x_3 = x_9;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8___redArg(x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8___redArg(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = lean_array_get_size(x_1);
x_3 = lean_unsigned_to_nat(2u);
x_4 = lean_nat_mul(x_2, x_3);
lean_dec(x_2);
x_5 = lean_unsigned_to_nat(0u);
x_6 = lean_box(0);
x_7 = lean_mk_array(x_4, x_6);
x_8 = l_Std_DHashMap_Internal_Raw_u2080_expand_go___at___Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8_spec__8___redArg(x_5, x_1, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8___redArg(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___redArg(lean_object* x_1, lean_object* x_2, uint8_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
if (lean_obj_tag(x_5) == 0)
{
lean_object* x_8; lean_object* x_9; 
lean_dec(x_4);
lean_dec(x_2);
lean_dec(x_1);
x_8 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_8, 0, x_6);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_8);
lean_ctor_set(x_9, 1, x_7);
return x_9;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; lean_object* x_25; 
x_10 = lean_ctor_get(x_5, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_5, 1);
lean_inc(x_11);
x_12 = lean_ctor_get(x_5, 3);
lean_inc(x_12);
lean_dec(x_5);
lean_inc(x_4);
lean_inc(x_2);
lean_inc(x_1);
x_19 = l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___redArg(x_1, x_2, x_3, x_4, x_10, x_6, x_7);
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
x_21 = lean_ctor_get(x_19, 1);
lean_inc(x_21);
x_22 = lean_ctor_get(x_20, 0);
lean_inc(x_22);
lean_dec(x_20);
x_23 = lean_box(0);
x_24 = lean_unbox(x_23);
lean_inc(x_11);
lean_inc(x_1);
x_25 = l_Lean_Environment_find_x3f(x_1, x_11, x_24);
if (lean_obj_tag(x_25) == 0)
{
lean_dec(x_22);
lean_dec(x_21);
lean_dec(x_11);
x_13 = x_19;
goto block_18;
}
else
{
lean_object* x_26; lean_object* x_27; uint8_t x_28; 
x_26 = lean_ctor_get(x_25, 0);
lean_inc(x_26);
lean_dec(x_25);
x_27 = l_Lean_ConstantInfo_getUsedConstantsAsSet(x_26);
x_28 = l_Lean_NameSet_contains(x_27, x_2);
lean_dec(x_27);
if (x_28 == 0)
{
lean_dec(x_22);
lean_dec(x_21);
lean_dec(x_11);
x_13 = x_19;
goto block_18;
}
else
{
uint8_t x_29; 
x_29 = !lean_is_exclusive(x_19);
if (x_29 == 0)
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; uint64_t x_37; uint64_t x_38; uint64_t x_39; uint64_t x_40; uint64_t x_41; uint64_t x_42; uint64_t x_43; uint64_t x_44; uint64_t x_45; size_t x_46; size_t x_47; size_t x_48; size_t x_49; size_t x_50; lean_object* x_51; uint8_t x_52; 
x_30 = lean_ctor_get(x_19, 1);
lean_dec(x_30);
x_31 = lean_ctor_get(x_19, 0);
lean_dec(x_31);
x_32 = lean_ctor_get(x_22, 0);
lean_inc(x_32);
x_33 = lean_ctor_get(x_22, 1);
lean_inc(x_33);
lean_inc(x_4);
lean_inc(x_2);
x_34 = l_Lean_Name_toString(x_2, x_3, x_4);
lean_inc(x_4);
x_35 = l_Lean_Name_toString(x_11, x_3, x_4);
lean_inc(x_35);
lean_inc(x_34);
lean_ctor_set(x_19, 1, x_35);
lean_ctor_set(x_19, 0, x_34);
x_36 = lean_array_get_size(x_33);
x_37 = lean_string_hash(x_34);
lean_dec(x_34);
x_38 = lean_string_hash(x_35);
lean_dec(x_35);
x_39 = lean_uint64_mix_hash(x_37, x_38);
x_40 = 32;
x_41 = lean_uint64_shift_right(x_39, x_40);
x_42 = lean_uint64_xor(x_39, x_41);
x_43 = 16;
x_44 = lean_uint64_shift_right(x_42, x_43);
x_45 = lean_uint64_xor(x_42, x_44);
x_46 = lean_uint64_to_usize(x_45);
x_47 = lean_usize_of_nat(x_36);
lean_dec(x_36);
x_48 = 1;
x_49 = lean_usize_sub(x_47, x_48);
x_50 = lean_usize_land(x_46, x_49);
x_51 = lean_array_uget(x_33, x_50);
x_52 = l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___redArg(x_19, x_51);
if (x_52 == 0)
{
uint8_t x_53; 
x_53 = !lean_is_exclusive(x_22);
if (x_53 == 0)
{
lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; uint8_t x_66; 
x_54 = lean_ctor_get(x_22, 1);
lean_dec(x_54);
x_55 = lean_ctor_get(x_22, 0);
lean_dec(x_55);
x_56 = lean_box(0);
x_57 = lean_unsigned_to_nat(1u);
x_58 = lean_nat_add(x_32, x_57);
lean_dec(x_32);
x_59 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_59, 0, x_19);
lean_ctor_set(x_59, 1, x_56);
lean_ctor_set(x_59, 2, x_51);
x_60 = lean_array_uset(x_33, x_50, x_59);
x_61 = lean_unsigned_to_nat(4u);
x_62 = lean_nat_mul(x_58, x_61);
x_63 = lean_unsigned_to_nat(3u);
x_64 = lean_nat_div(x_62, x_63);
lean_dec(x_62);
x_65 = lean_array_get_size(x_60);
x_66 = lean_nat_dec_le(x_64, x_65);
lean_dec(x_65);
lean_dec(x_64);
if (x_66 == 0)
{
lean_object* x_67; 
x_67 = l_Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8___redArg(x_60);
lean_ctor_set(x_22, 1, x_67);
lean_ctor_set(x_22, 0, x_58);
x_5 = x_12;
x_6 = x_22;
x_7 = x_21;
goto _start;
}
else
{
lean_ctor_set(x_22, 1, x_60);
lean_ctor_set(x_22, 0, x_58);
x_5 = x_12;
x_6 = x_22;
x_7 = x_21;
goto _start;
}
}
else
{
lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; uint8_t x_80; 
lean_dec(x_22);
x_70 = lean_box(0);
x_71 = lean_unsigned_to_nat(1u);
x_72 = lean_nat_add(x_32, x_71);
lean_dec(x_32);
x_73 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_73, 0, x_19);
lean_ctor_set(x_73, 1, x_70);
lean_ctor_set(x_73, 2, x_51);
x_74 = lean_array_uset(x_33, x_50, x_73);
x_75 = lean_unsigned_to_nat(4u);
x_76 = lean_nat_mul(x_72, x_75);
x_77 = lean_unsigned_to_nat(3u);
x_78 = lean_nat_div(x_76, x_77);
lean_dec(x_76);
x_79 = lean_array_get_size(x_74);
x_80 = lean_nat_dec_le(x_78, x_79);
lean_dec(x_79);
lean_dec(x_78);
if (x_80 == 0)
{
lean_object* x_81; lean_object* x_82; 
x_81 = l_Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8___redArg(x_74);
x_82 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_82, 0, x_72);
lean_ctor_set(x_82, 1, x_81);
x_5 = x_12;
x_6 = x_82;
x_7 = x_21;
goto _start;
}
else
{
lean_object* x_84; 
x_84 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_84, 0, x_72);
lean_ctor_set(x_84, 1, x_74);
x_5 = x_12;
x_6 = x_84;
x_7 = x_21;
goto _start;
}
}
}
else
{
lean_dec(x_51);
lean_dec(x_19);
lean_dec(x_33);
lean_dec(x_32);
x_5 = x_12;
x_6 = x_22;
x_7 = x_21;
goto _start;
}
}
else
{
lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; uint64_t x_93; uint64_t x_94; uint64_t x_95; uint64_t x_96; uint64_t x_97; uint64_t x_98; uint64_t x_99; uint64_t x_100; uint64_t x_101; size_t x_102; size_t x_103; size_t x_104; size_t x_105; size_t x_106; lean_object* x_107; uint8_t x_108; 
lean_dec(x_19);
x_87 = lean_ctor_get(x_22, 0);
lean_inc(x_87);
x_88 = lean_ctor_get(x_22, 1);
lean_inc(x_88);
lean_inc(x_4);
lean_inc(x_2);
x_89 = l_Lean_Name_toString(x_2, x_3, x_4);
lean_inc(x_4);
x_90 = l_Lean_Name_toString(x_11, x_3, x_4);
lean_inc(x_90);
lean_inc(x_89);
x_91 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_91, 0, x_89);
lean_ctor_set(x_91, 1, x_90);
x_92 = lean_array_get_size(x_88);
x_93 = lean_string_hash(x_89);
lean_dec(x_89);
x_94 = lean_string_hash(x_90);
lean_dec(x_90);
x_95 = lean_uint64_mix_hash(x_93, x_94);
x_96 = 32;
x_97 = lean_uint64_shift_right(x_95, x_96);
x_98 = lean_uint64_xor(x_95, x_97);
x_99 = 16;
x_100 = lean_uint64_shift_right(x_98, x_99);
x_101 = lean_uint64_xor(x_98, x_100);
x_102 = lean_uint64_to_usize(x_101);
x_103 = lean_usize_of_nat(x_92);
lean_dec(x_92);
x_104 = 1;
x_105 = lean_usize_sub(x_103, x_104);
x_106 = lean_usize_land(x_102, x_105);
x_107 = lean_array_uget(x_88, x_106);
x_108 = l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___redArg(x_91, x_107);
if (x_108 == 0)
{
lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; uint8_t x_120; 
if (lean_is_exclusive(x_22)) {
 lean_ctor_release(x_22, 0);
 lean_ctor_release(x_22, 1);
 x_109 = x_22;
} else {
 lean_dec_ref(x_22);
 x_109 = lean_box(0);
}
x_110 = lean_box(0);
x_111 = lean_unsigned_to_nat(1u);
x_112 = lean_nat_add(x_87, x_111);
lean_dec(x_87);
x_113 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_113, 0, x_91);
lean_ctor_set(x_113, 1, x_110);
lean_ctor_set(x_113, 2, x_107);
x_114 = lean_array_uset(x_88, x_106, x_113);
x_115 = lean_unsigned_to_nat(4u);
x_116 = lean_nat_mul(x_112, x_115);
x_117 = lean_unsigned_to_nat(3u);
x_118 = lean_nat_div(x_116, x_117);
lean_dec(x_116);
x_119 = lean_array_get_size(x_114);
x_120 = lean_nat_dec_le(x_118, x_119);
lean_dec(x_119);
lean_dec(x_118);
if (x_120 == 0)
{
lean_object* x_121; lean_object* x_122; 
x_121 = l_Std_DHashMap_Internal_Raw_u2080_expand___at___elabExprGraphCmd_spec__8___redArg(x_114);
if (lean_is_scalar(x_109)) {
 x_122 = lean_alloc_ctor(0, 2, 0);
} else {
 x_122 = x_109;
}
lean_ctor_set(x_122, 0, x_112);
lean_ctor_set(x_122, 1, x_121);
x_5 = x_12;
x_6 = x_122;
x_7 = x_21;
goto _start;
}
else
{
lean_object* x_124; 
if (lean_is_scalar(x_109)) {
 x_124 = lean_alloc_ctor(0, 2, 0);
} else {
 x_124 = x_109;
}
lean_ctor_set(x_124, 0, x_112);
lean_ctor_set(x_124, 1, x_114);
x_5 = x_12;
x_6 = x_124;
x_7 = x_21;
goto _start;
}
}
else
{
lean_dec(x_107);
lean_dec(x_91);
lean_dec(x_88);
lean_dec(x_87);
x_5 = x_12;
x_6 = x_22;
x_7 = x_21;
goto _start;
}
}
}
}
block_18:
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_14 = lean_ctor_get(x_13, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_13, 1);
lean_inc(x_15);
lean_dec(x_13);
x_16 = lean_ctor_get(x_14, 0);
lean_inc(x_16);
lean_dec(x_14);
x_5 = x_12;
x_6 = x_16;
x_7 = x_15;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, uint8_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
lean_object* x_16; 
x_16 = l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___redArg(x_3, x_4, x_5, x_6, x_7, x_8, x_15);
return x_16;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12_spec__12(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, uint8_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_16; lean_object* x_17; 
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_1);
x_16 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_16, 0, x_8);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_15);
return x_17;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_18 = lean_ctor_get(x_7, 0);
lean_inc(x_18);
x_19 = lean_ctor_get(x_7, 1);
lean_inc(x_19);
x_20 = lean_ctor_get(x_7, 3);
lean_inc(x_20);
lean_dec(x_7);
lean_inc(x_6);
lean_inc(x_4);
lean_inc(x_1);
x_21 = l_Lean_RBNode_forIn_visit___at___Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12_spec__12(x_1, x_2, x_3, x_4, x_5, x_6, x_18, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_22 = lean_ctor_get(x_21, 0);
lean_inc(x_22);
x_23 = lean_ctor_get(x_21, 1);
lean_inc(x_23);
lean_dec(x_21);
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec(x_22);
lean_inc(x_1);
lean_inc(x_6);
lean_inc(x_4);
x_25 = l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___redArg(x_4, x_19, x_5, x_6, x_1, x_24, x_23);
x_26 = lean_ctor_get(x_25, 0);
lean_inc(x_26);
x_27 = lean_ctor_get(x_25, 1);
lean_inc(x_27);
lean_dec(x_25);
x_28 = lean_ctor_get(x_26, 0);
lean_inc(x_28);
lean_dec(x_26);
x_7 = x_20;
x_8 = x_28;
x_15 = x_27;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12(lean_object* x_1, lean_object* x_2, lean_object* x_3, uint8_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_16; lean_object* x_17; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_3);
x_16 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_16, 0, x_8);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_15);
return x_17;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_18 = lean_ctor_get(x_7, 0);
lean_inc(x_18);
x_19 = lean_ctor_get(x_7, 1);
lean_inc(x_19);
x_20 = lean_ctor_get(x_7, 3);
lean_inc(x_20);
lean_dec(x_7);
lean_inc(x_5);
lean_inc(x_3);
lean_inc(x_6);
x_21 = l_Lean_RBNode_forIn_visit___at___Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12_spec__12(x_6, x_1, x_2, x_3, x_4, x_5, x_18, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_22 = lean_ctor_get(x_21, 0);
lean_inc(x_22);
x_23 = lean_ctor_get(x_21, 1);
lean_inc(x_23);
lean_dec(x_21);
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec(x_22);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_3);
x_25 = l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___redArg(x_3, x_19, x_4, x_5, x_6, x_24, x_23);
x_26 = lean_ctor_get(x_25, 0);
lean_inc(x_26);
x_27 = lean_ctor_get(x_25, 1);
lean_inc(x_27);
lean_dec(x_25);
x_28 = lean_ctor_get(x_26, 0);
lean_inc(x_28);
lean_dec(x_26);
x_29 = l_Lean_RBNode_forIn_visit___at___Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12_spec__12(x_6, x_1, x_2, x_3, x_4, x_5, x_20, x_28, x_9, x_10, x_11, x_12, x_13, x_14, x_27);
return x_29;
}
}
}
LEAN_EXPORT uint8_t l_elabExprGraphCmd___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = lean_box(0);
x_3 = lean_unbox(x_2);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__2___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("html", 4, 4);
return x_1;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; uint8_t x_5; 
x_4 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(x_1, x_3);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_ctor_get(x_4, 1);
x_8 = l_elabExprGraphCmd___lam__2___closed__0;
lean_ctor_set(x_4, 1, x_6);
lean_ctor_set(x_4, 0, x_8);
x_9 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_9, 0, x_4);
lean_ctor_set(x_9, 1, x_2);
x_10 = l_Lean_Json_mkObj(x_9);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_12 = lean_ctor_get(x_4, 0);
x_13 = lean_ctor_get(x_4, 1);
lean_inc(x_13);
lean_inc(x_12);
lean_dec(x_4);
x_14 = l_elabExprGraphCmd___lam__2___closed__0;
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_14);
lean_ctor_set(x_15, 1, x_12);
x_16 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_2);
x_17 = l_Lean_Json_mkObj(x_16);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_13);
return x_18;
}
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("var(--vscode-editor-foreground)", 31, 31);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__0;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__1;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__1;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("strokeWidth", 11, 11);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = l_Lean_JsonNumber_fromNat(x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__5;
x_2 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__6;
x_2 = l_elabExprGraphCmd___lam__1___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("markerEnd", 9, 9);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("url(#arrow)", 11, 11);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__9;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__10;
x_2 = l_elabExprGraphCmd___lam__1___closed__8;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__2;
x_2 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__3;
x_2 = l_elabExprGraphCmd___lam__1___closed__12;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__7;
x_2 = l_elabExprGraphCmd___lam__1___closed__13;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__11;
x_2 = l_elabExprGraphCmd___lam__1___closed__14;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__16() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("internal error", 14, 14);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__16;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_alloc_closure((void*)(l_instDecidableEqString___boxed), 2, 0);
x_2 = lean_alloc_closure((void*)(l_instBEqOfDecidableEq___redArg___lam__0___boxed), 3, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__18;
x_2 = lean_alloc_closure((void*)(l_instBEqProd___redArg___lam__0___boxed), 4, 2);
lean_closure_set(x_2, 0, x_1);
lean_closure_set(x_2, 1, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__20() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_String_hash___boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__20;
x_2 = lean_alloc_closure((void*)(l_instHashableProd___redArg___lam__0___boxed), 3, 2);
lean_closure_set(x_2, 0, x_1);
lean_closure_set(x_2, 1, x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_unsigned_to_nat(8u);
x_3 = lean_nat_mul(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = l_elabExprGraphCmd___lam__1___closed__22;
x_3 = lean_nat_div(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__24() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___lam__1___closed__23;
x_2 = l_Nat_nextPowerOfTwo(x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_elabExprGraphCmd___lam__1___closed__24;
x_3 = lean_mk_array(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__25;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__27() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___lam__1___closed__28() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_elabExprGraphCmd___lam__1___closed__27;
x_2 = lean_unsigned_to_nat(10u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__1(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; lean_object* x_138; 
x_134 = lean_st_ref_get(x_12, x_13);
x_135 = lean_ctor_get(x_134, 0);
lean_inc(x_135);
x_136 = lean_ctor_get(x_134, 1);
lean_inc(x_136);
lean_dec(x_134);
x_137 = lean_box(0);
lean_inc(x_12);
lean_inc(x_11);
x_138 = l_Lean_Elab_realizeGlobalConstNoOverloadWithInfo(x_1, x_137, x_11, x_12, x_136);
if (lean_obj_tag(x_138) == 0)
{
lean_object* x_139; lean_object* x_140; lean_object* x_141; lean_object* x_142; uint8_t x_143; lean_object* x_144; 
x_139 = lean_ctor_get(x_138, 0);
lean_inc(x_139);
x_140 = lean_ctor_get(x_138, 1);
lean_inc(x_140);
lean_dec(x_138);
x_141 = lean_ctor_get(x_135, 0);
lean_inc(x_141);
lean_dec(x_135);
x_142 = lean_box(0);
x_143 = lean_unbox(x_142);
lean_inc(x_141);
x_144 = l_Lean_Environment_find_x3f(x_141, x_139, x_143);
if (lean_obj_tag(x_144) == 0)
{
lean_object* x_145; lean_object* x_146; 
lean_dec(x_141);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
x_145 = l_elabExprGraphCmd___lam__1___closed__17;
x_146 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_145, x_7, x_8, x_9, x_10, x_11, x_12, x_140);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
return x_146;
}
else
{
lean_object* x_147; lean_object* x_148; lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_179; 
x_147 = lean_ctor_get(x_144, 0);
lean_inc(x_147);
lean_dec(x_144);
x_148 = l_Lean_ConstantInfo_getUsedConstantsAsSet(x_147);
x_149 = l_elabExprGraphCmd___lam__1___closed__19;
x_150 = l_elabExprGraphCmd___lam__1___closed__21;
x_151 = lean_unsigned_to_nat(0u);
x_152 = l_elabExprGraphCmd___lam__1___closed__26;
lean_inc_n(x_148, 2);
lean_inc(x_141);
x_153 = l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12(x_149, x_150, x_141, x_2, x_3, x_148, x_148, x_152, x_7, x_8, x_9, x_10, x_11, x_12, x_140);
x_154 = lean_ctor_get(x_153, 0);
lean_inc(x_154);
x_155 = lean_ctor_get(x_153, 1);
lean_inc(x_155);
lean_dec(x_153);
x_179 = lean_ctor_get(x_154, 0);
lean_inc(x_179);
lean_dec(x_154);
x_156 = x_179;
goto block_178;
block_178:
{
lean_object* x_157; lean_object* x_158; lean_object* x_159; size_t x_160; size_t x_161; lean_object* x_162; 
x_157 = l_elabExprGraphCmd___lam__1___closed__27;
x_158 = l_Lean_RBTree_toArray___at___Lean_mkModuleData_spec__2(x_148);
x_159 = l_elabExprGraphCmd___lam__1___closed__28;
x_160 = lean_array_size(x_158);
x_161 = 0;
lean_inc(x_12);
lean_inc(x_11);
x_162 = l_Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2(x_141, x_2, x_5, x_158, x_160, x_161, x_159, x_7, x_8, x_9, x_10, x_11, x_12, x_155);
lean_dec(x_7);
lean_dec(x_158);
if (lean_obj_tag(x_162) == 0)
{
lean_object* x_163; lean_object* x_164; lean_object* x_165; lean_object* x_166; lean_object* x_167; lean_object* x_168; lean_object* x_169; uint8_t x_170; 
x_163 = lean_ctor_get(x_162, 0);
lean_inc(x_163);
x_164 = lean_ctor_get(x_162, 1);
lean_inc(x_164);
lean_dec(x_162);
x_165 = lean_ctor_get(x_163, 0);
lean_inc(x_165);
x_166 = lean_ctor_get(x_163, 1);
lean_inc(x_166);
lean_dec(x_163);
x_167 = lean_ctor_get(x_156, 1);
lean_inc(x_167);
lean_dec(x_156);
x_168 = l_ProofWidgets_GraphDisplay;
x_169 = lean_array_get_size(x_167);
x_170 = lean_nat_dec_lt(x_151, x_169);
if (x_170 == 0)
{
lean_dec(x_169);
lean_dec(x_167);
x_14 = x_166;
x_15 = x_164;
x_16 = x_168;
x_17 = x_151;
x_18 = x_165;
x_19 = x_157;
goto block_133;
}
else
{
uint8_t x_171; 
x_171 = lean_nat_dec_le(x_169, x_169);
if (x_171 == 0)
{
lean_dec(x_169);
lean_dec(x_167);
x_14 = x_166;
x_15 = x_164;
x_16 = x_168;
x_17 = x_151;
x_18 = x_165;
x_19 = x_157;
goto block_133;
}
else
{
size_t x_172; lean_object* x_173; 
x_172 = lean_usize_of_nat(x_169);
lean_dec(x_169);
x_173 = l_Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6(x_167, x_161, x_172, x_157);
lean_dec(x_167);
x_14 = x_166;
x_15 = x_164;
x_16 = x_168;
x_17 = x_151;
x_18 = x_165;
x_19 = x_173;
goto block_133;
}
}
}
else
{
uint8_t x_174; 
lean_dec(x_156);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_4);
x_174 = !lean_is_exclusive(x_162);
if (x_174 == 0)
{
return x_162;
}
else
{
lean_object* x_175; lean_object* x_176; lean_object* x_177; 
x_175 = lean_ctor_get(x_162, 0);
x_176 = lean_ctor_get(x_162, 1);
lean_inc(x_176);
lean_inc(x_175);
lean_dec(x_162);
x_177 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_177, 0, x_175);
lean_ctor_set(x_177, 1, x_176);
return x_177;
}
}
}
}
}
else
{
uint8_t x_180; 
lean_dec(x_135);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_7);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
x_180 = !lean_is_exclusive(x_138);
if (x_180 == 0)
{
return x_138;
}
else
{
lean_object* x_181; lean_object* x_182; lean_object* x_183; 
x_181 = lean_ctor_get(x_138, 0);
x_182 = lean_ctor_get(x_138, 1);
lean_inc(x_182);
lean_inc(x_181);
lean_dec(x_138);
x_183 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_183, 0, x_181);
lean_ctor_set(x_183, 1, x_182);
return x_183;
}
}
block_133:
{
lean_object* x_20; uint8_t x_21; 
x_20 = l_ProofWidgets_HtmlDisplayPanel;
x_21 = !lean_is_exclusive(x_20);
if (x_21 == 0)
{
lean_object* x_22; lean_object* x_23; uint8_t x_24; 
x_22 = lean_ctor_get(x_20, 0);
x_23 = lean_ctor_get(x_20, 1);
lean_dec(x_23);
x_24 = !lean_is_exclusive(x_22);
if (x_24 == 0)
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; double x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; double x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; double x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; uint64_t x_58; lean_object* x_59; 
x_25 = lean_ctor_get(x_22, 0);
x_26 = lean_ctor_get(x_22, 1);
lean_dec(x_26);
x_27 = lean_unsigned_to_nat(2u);
x_28 = lean_box(0);
x_29 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_30 = l_elabExprGraphCmd___lam__1___closed__15;
x_31 = lean_nat_mul(x_18, x_27);
x_32 = lean_float_of_nat(x_31);
x_33 = lean_box_float(x_32);
x_34 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_34, 0, x_33);
x_35 = lean_box(0);
x_36 = lean_box(0);
x_37 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_37, 0, x_34);
lean_ctor_set(x_37, 1, x_35);
lean_ctor_set(x_37, 2, x_36);
x_38 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_38, 0, x_37);
x_39 = lean_float_of_nat(x_18);
x_40 = lean_box_float(x_39);
x_41 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_41, 0, x_40);
x_42 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_42, 0, x_41);
lean_ctor_set(x_42, 1, x_35);
lean_ctor_set(x_42, 2, x_36);
x_43 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_43, 0, x_42);
x_44 = lean_unsigned_to_nat(5u);
x_45 = l_Float_ofScientific(x_44, x_2, x_27);
x_46 = lean_box_float(x_45);
x_47 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_47, 0, x_46);
lean_inc(x_47);
lean_ctor_set(x_22, 1, x_47);
lean_ctor_set(x_22, 0, x_35);
x_48 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_48, 0, x_22);
lean_ctor_set(x_20, 1, x_47);
lean_ctor_set(x_20, 0, x_35);
x_49 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_49, 0, x_20);
x_50 = lean_array_push(x_29, x_38);
x_51 = lean_array_push(x_50, x_43);
x_52 = lean_array_push(x_51, x_48);
x_53 = lean_array_push(x_52, x_49);
x_54 = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(x_54, 0, x_14);
lean_ctor_set(x_54, 1, x_19);
lean_ctor_set(x_54, 2, x_30);
lean_ctor_set(x_54, 3, x_53);
lean_ctor_set_uint8(x_54, sizeof(void*)*4, x_2);
x_55 = lean_mk_empty_array_with_capacity(x_17);
x_56 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(x_16, x_54, x_55);
lean_dec(x_16);
x_57 = lean_alloc_closure((void*)(l_elabExprGraphCmd___lam__2), 3, 2);
lean_closure_set(x_57, 0, x_56);
lean_closure_set(x_57, 1, x_28);
x_58 = lean_string_hash(x_25);
lean_dec(x_25);
x_59 = l_Lean_Widget_savePanelWidgetInfo(x_58, x_57, x_4, x_11, x_12, x_15);
lean_dec(x_12);
lean_dec(x_11);
return x_59;
}
else
{
lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; double x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; double x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; double x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; uint64_t x_93; lean_object* x_94; 
x_60 = lean_ctor_get(x_22, 0);
lean_inc(x_60);
lean_dec(x_22);
x_61 = lean_unsigned_to_nat(2u);
x_62 = lean_box(0);
x_63 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_64 = l_elabExprGraphCmd___lam__1___closed__15;
x_65 = lean_nat_mul(x_18, x_61);
x_66 = lean_float_of_nat(x_65);
x_67 = lean_box_float(x_66);
x_68 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_68, 0, x_67);
x_69 = lean_box(0);
x_70 = lean_box(0);
x_71 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_71, 0, x_68);
lean_ctor_set(x_71, 1, x_69);
lean_ctor_set(x_71, 2, x_70);
x_72 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_72, 0, x_71);
x_73 = lean_float_of_nat(x_18);
x_74 = lean_box_float(x_73);
x_75 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_75, 0, x_74);
x_76 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_76, 0, x_75);
lean_ctor_set(x_76, 1, x_69);
lean_ctor_set(x_76, 2, x_70);
x_77 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_77, 0, x_76);
x_78 = lean_unsigned_to_nat(5u);
x_79 = l_Float_ofScientific(x_78, x_2, x_61);
x_80 = lean_box_float(x_79);
x_81 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_81, 0, x_80);
lean_inc(x_81);
x_82 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_82, 0, x_69);
lean_ctor_set(x_82, 1, x_81);
x_83 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_83, 0, x_82);
lean_ctor_set(x_20, 1, x_81);
lean_ctor_set(x_20, 0, x_69);
x_84 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_84, 0, x_20);
x_85 = lean_array_push(x_63, x_72);
x_86 = lean_array_push(x_85, x_77);
x_87 = lean_array_push(x_86, x_83);
x_88 = lean_array_push(x_87, x_84);
x_89 = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(x_89, 0, x_14);
lean_ctor_set(x_89, 1, x_19);
lean_ctor_set(x_89, 2, x_64);
lean_ctor_set(x_89, 3, x_88);
lean_ctor_set_uint8(x_89, sizeof(void*)*4, x_2);
x_90 = lean_mk_empty_array_with_capacity(x_17);
x_91 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(x_16, x_89, x_90);
lean_dec(x_16);
x_92 = lean_alloc_closure((void*)(l_elabExprGraphCmd___lam__2), 3, 2);
lean_closure_set(x_92, 0, x_91);
lean_closure_set(x_92, 1, x_62);
x_93 = lean_string_hash(x_60);
lean_dec(x_60);
x_94 = l_Lean_Widget_savePanelWidgetInfo(x_93, x_92, x_4, x_11, x_12, x_15);
lean_dec(x_12);
lean_dec(x_11);
return x_94;
}
}
else
{
lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; double x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; double x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; double x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; uint64_t x_131; lean_object* x_132; 
x_95 = lean_ctor_get(x_20, 0);
lean_inc(x_95);
lean_dec(x_20);
x_96 = lean_ctor_get(x_95, 0);
lean_inc(x_96);
if (lean_is_exclusive(x_95)) {
 lean_ctor_release(x_95, 0);
 lean_ctor_release(x_95, 1);
 x_97 = x_95;
} else {
 lean_dec_ref(x_95);
 x_97 = lean_box(0);
}
x_98 = lean_unsigned_to_nat(2u);
x_99 = lean_box(0);
x_100 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17;
x_101 = l_elabExprGraphCmd___lam__1___closed__15;
x_102 = lean_nat_mul(x_18, x_98);
x_103 = lean_float_of_nat(x_102);
x_104 = lean_box_float(x_103);
x_105 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_105, 0, x_104);
x_106 = lean_box(0);
x_107 = lean_box(0);
x_108 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_108, 0, x_105);
lean_ctor_set(x_108, 1, x_106);
lean_ctor_set(x_108, 2, x_107);
x_109 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_109, 0, x_108);
x_110 = lean_float_of_nat(x_18);
x_111 = lean_box_float(x_110);
x_112 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_112, 0, x_111);
x_113 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_113, 0, x_112);
lean_ctor_set(x_113, 1, x_106);
lean_ctor_set(x_113, 2, x_107);
x_114 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_114, 0, x_113);
x_115 = lean_unsigned_to_nat(5u);
x_116 = l_Float_ofScientific(x_115, x_2, x_98);
x_117 = lean_box_float(x_116);
x_118 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_118, 0, x_117);
lean_inc(x_118);
if (lean_is_scalar(x_97)) {
 x_119 = lean_alloc_ctor(0, 2, 0);
} else {
 x_119 = x_97;
}
lean_ctor_set(x_119, 0, x_106);
lean_ctor_set(x_119, 1, x_118);
x_120 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_120, 0, x_119);
x_121 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_121, 0, x_106);
lean_ctor_set(x_121, 1, x_118);
x_122 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_122, 0, x_121);
x_123 = lean_array_push(x_100, x_109);
x_124 = lean_array_push(x_123, x_114);
x_125 = lean_array_push(x_124, x_120);
x_126 = lean_array_push(x_125, x_122);
x_127 = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(x_127, 0, x_14);
lean_ctor_set(x_127, 1, x_19);
lean_ctor_set(x_127, 2, x_101);
lean_ctor_set(x_127, 3, x_126);
lean_ctor_set_uint8(x_127, sizeof(void*)*4, x_2);
x_128 = lean_mk_empty_array_with_capacity(x_17);
x_129 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(x_16, x_127, x_128);
lean_dec(x_16);
x_130 = lean_alloc_closure((void*)(l_elabExprGraphCmd___lam__2), 3, 2);
lean_closure_set(x_130, 0, x_129);
lean_closure_set(x_130, 1, x_99);
x_131 = lean_string_hash(x_96);
lean_dec(x_96);
x_132 = l_Lean_Widget_savePanelWidgetInfo(x_131, x_130, x_4, x_11, x_12, x_15);
lean_dec(x_12);
lean_dec(x_11);
return x_132;
}
}
}
}
static lean_object* _init_l_elabExprGraphCmd___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Unexpected syntax ", 18, 18);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___closed__0;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_elabExprGraphCmd___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("", 0, 0);
return x_1;
}
}
static lean_object* _init_l_elabExprGraphCmd___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_elabExprGraphCmd___closed__2;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; uint8_t x_6; 
x_5 = l_exprGraphCmd___closed__1;
lean_inc(x_1);
x_6 = l_Lean_Syntax_isOfKind(x_1, x_5);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_7 = l_elabExprGraphCmd___closed__1;
x_8 = l_Lean_MessageData_ofSyntax(x_1);
x_9 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = l_elabExprGraphCmd___closed__3;
x_11 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_11, 0, x_9);
lean_ctor_set(x_11, 1, x_10);
x_12 = l_Lean_throwError___at_____private_Lean_Elab_Command_0__Lean_Elab_Command_elabCommandUsing_spec__0___redArg(x_11, x_2, x_3, x_4);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_13 = lean_unsigned_to_nat(1u);
x_14 = l_Lean_Syntax_getArg(x_1, x_13);
x_15 = l_exprGraphCmd___closed__7;
lean_inc(x_14);
x_16 = l_Lean_Syntax_isOfKind(x_14, x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
lean_dec(x_14);
x_17 = l_elabExprGraphCmd___closed__1;
x_18 = l_Lean_MessageData_ofSyntax(x_1);
x_19 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_19, 0, x_17);
lean_ctor_set(x_19, 1, x_18);
x_20 = l_elabExprGraphCmd___closed__3;
x_21 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_21, 0, x_19);
lean_ctor_set(x_21, 1, x_20);
x_22 = l_Lean_throwError___at_____private_Lean_Elab_Command_0__Lean_Elab_Command_elabCommandUsing_spec__0___redArg(x_21, x_2, x_3, x_4);
return x_22;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_23 = lean_alloc_closure((void*)(l_elabExprGraphCmd___lam__0___boxed), 1, 0);
x_24 = lean_box(x_16);
lean_inc(x_23);
x_25 = lean_alloc_closure((void*)(l_elabExprGraphCmd___lam__1___boxed), 13, 5);
lean_closure_set(x_25, 0, x_14);
lean_closure_set(x_25, 1, x_24);
lean_closure_set(x_25, 2, x_23);
lean_closure_set(x_25, 3, x_1);
lean_closure_set(x_25, 4, x_23);
x_26 = l_Lean_Elab_Command_runTermElabM___redArg(x_25, x_2, x_3, x_4);
lean_dec(x_2);
return x_26;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__0(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__1(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
uint8_t x_13; size_t x_14; size_t x_15; lean_object* x_16; 
x_13 = lean_unbox(x_2);
lean_dec(x_2);
x_14 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_15 = lean_unbox_usize(x_6);
lean_dec(x_6);
x_16 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg(x_1, x_13, x_3, x_4, x_14, x_15, x_7, x_8, x_9, x_10, x_11, x_12);
lean_dec(x_4);
return x_16;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
uint8_t x_15; size_t x_16; size_t x_17; lean_object* x_18; 
x_15 = lean_unbox(x_2);
lean_dec(x_2);
x_16 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_17 = lean_unbox_usize(x_6);
lean_dec(x_6);
x_18 = l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2(x_1, x_15, x_3, x_4, x_16, x_17, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_4);
return x_18;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
uint8_t x_15; size_t x_16; size_t x_17; lean_object* x_18; 
x_15 = lean_unbox(x_2);
lean_dec(x_2);
x_16 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_17 = lean_unbox_usize(x_6);
lean_dec(x_6);
x_18 = l_Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2(x_1, x_15, x_3, x_4, x_16, x_17, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_4);
return x_18;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___elabExprGraphCmd_spec__4(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Std_DHashMap_Internal_AssocList_foldlM___at___elabExprGraphCmd_spec__5(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_7 = l_Array_foldlMUnsafe_fold___at___elabExprGraphCmd_spec__6(x_1, x_5, x_6, x_4);
lean_dec(x_1);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___redArg___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; lean_object* x_4; 
x_3 = l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___redArg(x_1, x_2);
lean_dec(x_2);
lean_dec(x_1);
x_4 = lean_box(x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; lean_object* x_5; 
x_4 = l_Std_DHashMap_Internal_AssocList_contains___at___elabExprGraphCmd_spec__7(x_1, x_2, x_3);
lean_dec(x_3);
lean_dec(x_2);
x_5 = lean_box(x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint8_t x_8; lean_object* x_9; 
x_8 = lean_unbox(x_3);
lean_dec(x_3);
x_9 = l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___redArg(x_1, x_2, x_8, x_4, x_5, x_6, x_7);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
uint8_t x_16; lean_object* x_17; 
x_16 = lean_unbox(x_5);
lean_dec(x_5);
x_17 = l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__11(x_1, x_2, x_3, x_4, x_16, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_2);
lean_dec(x_1);
return x_17;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12_spec__12___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
uint8_t x_16; lean_object* x_17; 
x_16 = lean_unbox(x_5);
lean_dec(x_5);
x_17 = l_Lean_RBNode_forIn_visit___at___Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12_spec__12(x_1, x_2, x_3, x_4, x_16, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_3);
lean_dec(x_2);
return x_17;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
uint8_t x_16; lean_object* x_17; 
x_16 = lean_unbox(x_4);
lean_dec(x_4);
x_17 = l_Lean_RBNode_forIn_visit___at___elabExprGraphCmd_spec__12(x_1, x_2, x_3, x_16, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_2);
lean_dec(x_1);
return x_17;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__0___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_elabExprGraphCmd___lam__0(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
uint8_t x_14; lean_object* x_15; 
x_14 = lean_unbox(x_2);
lean_dec(x_2);
x_15 = l_elabExprGraphCmd___lam__1(x_1, x_14, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13);
lean_dec(x_8);
lean_dec(x_6);
return x_15;
}
}
LEAN_EXPORT lean_object* l_elabExprGraphCmd___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_elabExprGraphCmd(x_1, x_2, x_3, x_4);
lean_dec(x_3);
return x_5;
}
}
static lean_object* _init_l_a() {
_start:
{
lean_object* x_1; 
x_1 = lean_unsigned_to_nat(0u);
return x_1;
}
}
static lean_object* _init_l_b() {
_start:
{
lean_object* x_1; 
x_1 = lean_unsigned_to_nat(1u);
return x_1;
}
}
static lean_object* _init_l_foo___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_foo___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_foo___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_foo___closed__1;
x_2 = l_foo___closed__0;
x_3 = lean_int_ediv(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_foo(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_2 = lean_unsigned_to_nat(1u);
x_3 = lean_nat_mul(x_2, x_1);
x_4 = l_foo___closed__2;
x_5 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_foo___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_foo(x_1);
lean_dec(x_1);
return x_2;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_GraphDisplay(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_HtmlDisplay(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Util_FoldConsts(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_Graph_ExprGraph(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_GraphDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_HtmlDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Util_FoldConsts(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_exprGraphCmd___closed__0 = _init_l_exprGraphCmd___closed__0();
lean_mark_persistent(l_exprGraphCmd___closed__0);
l_exprGraphCmd___closed__1 = _init_l_exprGraphCmd___closed__1();
lean_mark_persistent(l_exprGraphCmd___closed__1);
l_exprGraphCmd___closed__2 = _init_l_exprGraphCmd___closed__2();
lean_mark_persistent(l_exprGraphCmd___closed__2);
l_exprGraphCmd___closed__3 = _init_l_exprGraphCmd___closed__3();
lean_mark_persistent(l_exprGraphCmd___closed__3);
l_exprGraphCmd___closed__4 = _init_l_exprGraphCmd___closed__4();
lean_mark_persistent(l_exprGraphCmd___closed__4);
l_exprGraphCmd___closed__5 = _init_l_exprGraphCmd___closed__5();
lean_mark_persistent(l_exprGraphCmd___closed__5);
l_exprGraphCmd___closed__6 = _init_l_exprGraphCmd___closed__6();
lean_mark_persistent(l_exprGraphCmd___closed__6);
l_exprGraphCmd___closed__7 = _init_l_exprGraphCmd___closed__7();
lean_mark_persistent(l_exprGraphCmd___closed__7);
l_exprGraphCmd___closed__8 = _init_l_exprGraphCmd___closed__8();
lean_mark_persistent(l_exprGraphCmd___closed__8);
l_exprGraphCmd___closed__9 = _init_l_exprGraphCmd___closed__9();
lean_mark_persistent(l_exprGraphCmd___closed__9);
l_exprGraphCmd___closed__10 = _init_l_exprGraphCmd___closed__10();
lean_mark_persistent(l_exprGraphCmd___closed__10);
l_exprGraphCmd = _init_l_exprGraphCmd();
lean_mark_persistent(l_exprGraphCmd);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__0);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__1);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__2);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__3);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__4);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__5);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__6);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__7);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__8);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__9);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__10);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__11);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__12);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__13);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__14);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__15);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__16);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__17);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__18);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__19);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__20);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__21);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__22);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__23);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__24);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__25);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__26);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__27);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__28);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__29);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__30);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__31);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__32);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__33);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__34();
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__35);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__36);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__37);
l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38 = _init_l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___Array_forIn_x27Unsafe_loop___at___elabExprGraphCmd_spec__2_spec__2___redArg___closed__38);
l_elabExprGraphCmd___lam__2___closed__0 = _init_l_elabExprGraphCmd___lam__2___closed__0();
lean_mark_persistent(l_elabExprGraphCmd___lam__2___closed__0);
l_elabExprGraphCmd___lam__1___closed__0 = _init_l_elabExprGraphCmd___lam__1___closed__0();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__0);
l_elabExprGraphCmd___lam__1___closed__1 = _init_l_elabExprGraphCmd___lam__1___closed__1();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__1);
l_elabExprGraphCmd___lam__1___closed__2 = _init_l_elabExprGraphCmd___lam__1___closed__2();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__2);
l_elabExprGraphCmd___lam__1___closed__3 = _init_l_elabExprGraphCmd___lam__1___closed__3();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__3);
l_elabExprGraphCmd___lam__1___closed__4 = _init_l_elabExprGraphCmd___lam__1___closed__4();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__4);
l_elabExprGraphCmd___lam__1___closed__5 = _init_l_elabExprGraphCmd___lam__1___closed__5();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__5);
l_elabExprGraphCmd___lam__1___closed__6 = _init_l_elabExprGraphCmd___lam__1___closed__6();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__6);
l_elabExprGraphCmd___lam__1___closed__7 = _init_l_elabExprGraphCmd___lam__1___closed__7();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__7);
l_elabExprGraphCmd___lam__1___closed__8 = _init_l_elabExprGraphCmd___lam__1___closed__8();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__8);
l_elabExprGraphCmd___lam__1___closed__9 = _init_l_elabExprGraphCmd___lam__1___closed__9();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__9);
l_elabExprGraphCmd___lam__1___closed__10 = _init_l_elabExprGraphCmd___lam__1___closed__10();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__10);
l_elabExprGraphCmd___lam__1___closed__11 = _init_l_elabExprGraphCmd___lam__1___closed__11();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__11);
l_elabExprGraphCmd___lam__1___closed__12 = _init_l_elabExprGraphCmd___lam__1___closed__12();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__12);
l_elabExprGraphCmd___lam__1___closed__13 = _init_l_elabExprGraphCmd___lam__1___closed__13();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__13);
l_elabExprGraphCmd___lam__1___closed__14 = _init_l_elabExprGraphCmd___lam__1___closed__14();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__14);
l_elabExprGraphCmd___lam__1___closed__15 = _init_l_elabExprGraphCmd___lam__1___closed__15();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__15);
l_elabExprGraphCmd___lam__1___closed__16 = _init_l_elabExprGraphCmd___lam__1___closed__16();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__16);
l_elabExprGraphCmd___lam__1___closed__17 = _init_l_elabExprGraphCmd___lam__1___closed__17();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__17);
l_elabExprGraphCmd___lam__1___closed__18 = _init_l_elabExprGraphCmd___lam__1___closed__18();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__18);
l_elabExprGraphCmd___lam__1___closed__19 = _init_l_elabExprGraphCmd___lam__1___closed__19();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__19);
l_elabExprGraphCmd___lam__1___closed__20 = _init_l_elabExprGraphCmd___lam__1___closed__20();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__20);
l_elabExprGraphCmd___lam__1___closed__21 = _init_l_elabExprGraphCmd___lam__1___closed__21();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__21);
l_elabExprGraphCmd___lam__1___closed__22 = _init_l_elabExprGraphCmd___lam__1___closed__22();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__22);
l_elabExprGraphCmd___lam__1___closed__23 = _init_l_elabExprGraphCmd___lam__1___closed__23();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__23);
l_elabExprGraphCmd___lam__1___closed__24 = _init_l_elabExprGraphCmd___lam__1___closed__24();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__24);
l_elabExprGraphCmd___lam__1___closed__25 = _init_l_elabExprGraphCmd___lam__1___closed__25();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__25);
l_elabExprGraphCmd___lam__1___closed__26 = _init_l_elabExprGraphCmd___lam__1___closed__26();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__26);
l_elabExprGraphCmd___lam__1___closed__27 = _init_l_elabExprGraphCmd___lam__1___closed__27();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__27);
l_elabExprGraphCmd___lam__1___closed__28 = _init_l_elabExprGraphCmd___lam__1___closed__28();
lean_mark_persistent(l_elabExprGraphCmd___lam__1___closed__28);
l_elabExprGraphCmd___closed__0 = _init_l_elabExprGraphCmd___closed__0();
lean_mark_persistent(l_elabExprGraphCmd___closed__0);
l_elabExprGraphCmd___closed__1 = _init_l_elabExprGraphCmd___closed__1();
lean_mark_persistent(l_elabExprGraphCmd___closed__1);
l_elabExprGraphCmd___closed__2 = _init_l_elabExprGraphCmd___closed__2();
lean_mark_persistent(l_elabExprGraphCmd___closed__2);
l_elabExprGraphCmd___closed__3 = _init_l_elabExprGraphCmd___closed__3();
lean_mark_persistent(l_elabExprGraphCmd___closed__3);
l_a = _init_l_a();
lean_mark_persistent(l_a);
l_b = _init_l_b();
lean_mark_persistent(l_b);
l_foo___closed__0 = _init_l_foo___closed__0();
lean_mark_persistent(l_foo___closed__0);
l_foo___closed__1 = _init_l_foo___closed__1();
lean_mark_persistent(l_foo___closed__1);
l_foo___closed__2 = _init_l_foo___closed__2();
lean_mark_persistent(l_foo___closed__2);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
