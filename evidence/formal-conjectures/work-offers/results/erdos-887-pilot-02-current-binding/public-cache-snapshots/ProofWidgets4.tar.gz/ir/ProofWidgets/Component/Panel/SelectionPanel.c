// Lean compiler output
// Module: ProofWidgets.Component.Panel.SelectionPanel
// Imports: Init Lean.Meta.ExprLens ProofWidgets.Component.Panel.Basic ProofWidgets.Presentation.Expr
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468_(lean_object*, lean_object*);
lean_object* l_Prod_toJson___at___ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5__spec__0(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_Lean_Meta_withLetDecl___at_____private_Lean_Elab_PreDefinition_MkInhabitant_0__Lean_Elab_withInhabitedInstances_go_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Prod_fromJson_x3f___at___ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5__spec__0(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_goalsLocationsToExprs___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200_(lean_object*, lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__3;
static lean_object* l_ProofWidgets_goalsLocationsToExprs___closed__0;
lean_object* l_Lean_Name_toString(lean_object*, uint8_t, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__0;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg(lean_object*, size_t, size_t, lean_object*, lean_object*);
lean_object* l___private_Lean_SubExpr_0__Lean_SubExpr_fromJsonGoalsLocation____x40_Lean_SubExpr___hyg_1840_(lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__2;
static lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__1;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_(lean_object*);
uint64_t lean_string_hash(lean_object*);
lean_object* l_Lean_stringToMessageData(lean_object*);
lean_object* l_Lean_Expr_mvar___override(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_;
static lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__0;
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__4;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_590_(lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(lean_object*);
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_;
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__0(lean_object*);
static lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__2;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_SelectionPanel___closed__4;
lean_object* lean_st_ref_take(lean_object*, lean_object*);
static uint64_t l_ProofWidgets_SelectionPanel___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_goalsLocationsToExprs(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_SelectionPanel___closed__3;
static lean_object* l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__0;
lean_object* l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(lean_object*);
lean_object* l_Lean_FVarId_getValue_x3f___redArg(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_MVarId_withContext___at_____private_Lean_Meta_SynthInstance_0__Lean_Meta_synthPendingImp_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_SubExpr_Pos_toArray(lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_MessageData_ofFormat(lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*);
lean_object* lean_st_ref_get(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__0;
lean_object* lean_array_to_list(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__0;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__1;
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_SelectionPanel___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_goalsLocationsToExprs___boxed__const__1;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
extern lean_object* l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__5;
lean_object* l___private_Lean_SubExpr_0__Lean_SubExpr_toJsonGoalsLocation____x40_Lean_SubExpr___hyg_1946_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_SelectionPanel___closed__2___boxed__const__1;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__1___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__2;
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__0;
static lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__2;
static lean_object* l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__2;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468_(lean_object*, lean_object*);
lean_object* l_Lean_MessageData_ofExpr(lean_object*);
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_;
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__5;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__1;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_(lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__1;
static lean_object* l_ProofWidgets_SelectionPanel___closed__2;
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__2;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0_spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
static lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__0;
lean_object* l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__3;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_goalsLocationsToExprs___lam__0(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__6;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_;
lean_object* l_ProofWidgets_ExprWithCtx_save___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_SelectionPanel;
lean_object* l_Lean_Server_WithRpcRef_mk___redArg(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__4;
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4(lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__7;
lean_object* l_Array_append___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams;
lean_object* lean_expr_instantiate_rev(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200_(lean_object*, lean_object*);
lean_object* l_Lean_Meta_withLocalDecl___at___Lean_Meta_withLocalDeclD___at_____private_Lean_Meta_Constructions_BRecOn_0__Lean_buildBelowMinorPremise_go_spec__0_spec__0___redArg(lean_object*, uint8_t, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* l_Lean_RBNode_find___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget___hyg_204__spec__0___redArg(lean_object*, uint64_t);
static lean_object* l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__3;
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* l_Lean_Expr_fvar___override(lean_object*);
size_t lean_array_size(lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
static lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__3;
static lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__2;
lean_object* lean_string_append(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0(lean_object*, lean_object*);
lean_object* lean_infer_type(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_Lean_Widget_instImpl____x40_Lean_Widget_Basic___hyg_51_;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__4;
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
lean_object* l_Lean_Elab_ContextInfo_runMetaM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__3;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_ExprWithCtx_save(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__1;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0(lean_object*, size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped;
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_array_push(x_1, x_4);
x_11 = lean_apply_7(x_2, x_10, x_3, x_5, x_6, x_7, x_8, x_9);
return x_11;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_array_push(x_1, x_4);
x_11 = lean_apply_7(x_2, x_10, x_3, x_5, x_6, x_7, x_8, x_9);
return x_11;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Invalid coordinate ", 19, 19);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__0;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" for ", 5, 5);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__2;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("", 0, 0);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__4;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Internal: Types should be handled by viewAux", 44, 44);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__6;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_25; lean_object* x_26; lean_object* x_27; uint8_t x_28; lean_object* x_35; uint8_t x_36; 
x_35 = lean_unsigned_to_nat(3u);
x_36 = lean_nat_dec_eq(x_3, x_35);
if (x_36 == 0)
{
lean_object* x_37; uint8_t x_38; 
x_37 = lean_unsigned_to_nat(0u);
x_38 = lean_nat_dec_eq(x_3, x_37);
if (x_38 == 0)
{
lean_object* x_39; uint8_t x_40; 
x_39 = lean_unsigned_to_nat(1u);
x_40 = lean_nat_dec_eq(x_3, x_39);
if (x_40 == 0)
{
lean_object* x_41; uint8_t x_42; 
x_41 = lean_unsigned_to_nat(2u);
x_42 = lean_nat_dec_eq(x_3, x_41);
if (x_42 == 0)
{
if (lean_obj_tag(x_4) == 10)
{
lean_object* x_43; 
x_43 = lean_ctor_get(x_4, 1);
lean_inc(x_43);
lean_dec(x_4);
x_4 = x_43;
goto _start;
}
else
{
lean_dec(x_2);
lean_dec(x_1);
x_10 = x_3;
x_11 = x_4;
goto block_24;
}
}
else
{
lean_dec(x_3);
switch (lean_obj_tag(x_4)) {
case 8:
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; uint8_t x_53; lean_object* x_54; 
x_45 = lean_ctor_get(x_4, 0);
lean_inc(x_45);
x_46 = lean_ctor_get(x_4, 1);
lean_inc(x_46);
x_47 = lean_ctor_get(x_4, 2);
lean_inc(x_47);
x_48 = lean_ctor_get(x_4, 3);
lean_inc(x_48);
lean_dec(x_4);
lean_inc(x_2);
x_49 = lean_alloc_closure((void*)(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___lam__0), 9, 3);
lean_closure_set(x_49, 0, x_2);
lean_closure_set(x_49, 1, x_1);
lean_closure_set(x_49, 2, x_48);
x_50 = lean_expr_instantiate_rev(x_46, x_2);
lean_dec(x_46);
x_51 = lean_expr_instantiate_rev(x_47, x_2);
lean_dec(x_2);
lean_dec(x_47);
x_52 = lean_box(0);
x_53 = lean_unbox(x_52);
x_54 = l_Lean_Meta_withLetDecl___at_____private_Lean_Elab_PreDefinition_MkInhabitant_0__Lean_Elab_withInhabitedInstances_go_spec__0___redArg(x_45, x_50, x_51, x_49, x_40, x_53, x_5, x_6, x_7, x_8, x_9);
return x_54;
}
case 10:
{
lean_object* x_55; 
x_55 = lean_ctor_get(x_4, 1);
lean_inc(x_55);
lean_dec(x_4);
x_3 = x_41;
x_4 = x_55;
goto _start;
}
default: 
{
lean_dec(x_2);
lean_dec(x_1);
x_10 = x_41;
x_11 = x_4;
goto block_24;
}
}
}
}
else
{
lean_dec(x_3);
switch (lean_obj_tag(x_4)) {
case 5:
{
lean_object* x_57; lean_object* x_58; 
x_57 = lean_ctor_get(x_4, 1);
lean_inc(x_57);
lean_dec(x_4);
x_58 = lean_apply_7(x_1, x_2, x_57, x_5, x_6, x_7, x_8, x_9);
return x_58;
}
case 6:
{
lean_object* x_59; lean_object* x_60; lean_object* x_61; uint8_t x_62; 
x_59 = lean_ctor_get(x_4, 0);
lean_inc(x_59);
x_60 = lean_ctor_get(x_4, 1);
lean_inc(x_60);
x_61 = lean_ctor_get(x_4, 2);
lean_inc(x_61);
x_62 = lean_ctor_get_uint8(x_4, sizeof(void*)*3 + 8);
lean_dec(x_4);
x_25 = x_59;
x_26 = x_60;
x_27 = x_61;
x_28 = x_62;
goto block_34;
}
case 7:
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; uint8_t x_66; 
x_63 = lean_ctor_get(x_4, 0);
lean_inc(x_63);
x_64 = lean_ctor_get(x_4, 1);
lean_inc(x_64);
x_65 = lean_ctor_get(x_4, 2);
lean_inc(x_65);
x_66 = lean_ctor_get_uint8(x_4, sizeof(void*)*3 + 8);
lean_dec(x_4);
x_25 = x_63;
x_26 = x_64;
x_27 = x_65;
x_28 = x_66;
goto block_34;
}
case 8:
{
lean_object* x_67; lean_object* x_68; 
x_67 = lean_ctor_get(x_4, 2);
lean_inc(x_67);
lean_dec(x_4);
x_68 = lean_apply_7(x_1, x_2, x_67, x_5, x_6, x_7, x_8, x_9);
return x_68;
}
case 10:
{
lean_object* x_69; 
x_69 = lean_ctor_get(x_4, 1);
lean_inc(x_69);
lean_dec(x_4);
x_3 = x_39;
x_4 = x_69;
goto _start;
}
default: 
{
lean_dec(x_2);
lean_dec(x_1);
x_10 = x_39;
x_11 = x_4;
goto block_24;
}
}
}
}
else
{
lean_dec(x_3);
switch (lean_obj_tag(x_4)) {
case 5:
{
lean_object* x_71; lean_object* x_72; 
x_71 = lean_ctor_get(x_4, 0);
lean_inc(x_71);
lean_dec(x_4);
x_72 = lean_apply_7(x_1, x_2, x_71, x_5, x_6, x_7, x_8, x_9);
return x_72;
}
case 6:
{
lean_object* x_73; lean_object* x_74; 
x_73 = lean_ctor_get(x_4, 1);
lean_inc(x_73);
lean_dec(x_4);
x_74 = lean_apply_7(x_1, x_2, x_73, x_5, x_6, x_7, x_8, x_9);
return x_74;
}
case 7:
{
lean_object* x_75; lean_object* x_76; 
x_75 = lean_ctor_get(x_4, 1);
lean_inc(x_75);
lean_dec(x_4);
x_76 = lean_apply_7(x_1, x_2, x_75, x_5, x_6, x_7, x_8, x_9);
return x_76;
}
case 8:
{
lean_object* x_77; lean_object* x_78; 
x_77 = lean_ctor_get(x_4, 1);
lean_inc(x_77);
lean_dec(x_4);
x_78 = lean_apply_7(x_1, x_2, x_77, x_5, x_6, x_7, x_8, x_9);
return x_78;
}
case 10:
{
lean_object* x_79; 
x_79 = lean_ctor_get(x_4, 1);
lean_inc(x_79);
lean_dec(x_4);
x_3 = x_37;
x_4 = x_79;
goto _start;
}
case 11:
{
lean_object* x_81; lean_object* x_82; 
x_81 = lean_ctor_get(x_4, 2);
lean_inc(x_81);
lean_dec(x_4);
x_82 = lean_apply_7(x_1, x_2, x_81, x_5, x_6, x_7, x_8, x_9);
return x_82;
}
default: 
{
lean_dec(x_2);
lean_dec(x_1);
x_10 = x_37;
x_11 = x_4;
goto block_24;
}
}
}
}
else
{
lean_object* x_83; lean_object* x_84; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_83 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__7;
x_84 = l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(x_83, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
return x_84;
}
block_24:
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_12 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__1;
x_13 = l_Nat_reprFast(x_10);
x_14 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_14, 0, x_13);
x_15 = l_Lean_MessageData_ofFormat(x_14);
x_16 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_16, 0, x_12);
lean_ctor_set(x_16, 1, x_15);
x_17 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__3;
x_18 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_18, 0, x_16);
lean_ctor_set(x_18, 1, x_17);
x_19 = l_Lean_MessageData_ofExpr(x_11);
x_20 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_20, 0, x_18);
lean_ctor_set(x_20, 1, x_19);
x_21 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__5;
x_22 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_22, 0, x_20);
lean_ctor_set(x_22, 1, x_21);
x_23 = l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(x_22, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
return x_23;
}
block_34:
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; uint8_t x_32; lean_object* x_33; 
lean_inc(x_2);
x_29 = lean_alloc_closure((void*)(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___lam__1), 9, 3);
lean_closure_set(x_29, 0, x_2);
lean_closure_set(x_29, 1, x_1);
lean_closure_set(x_29, 2, x_27);
x_30 = lean_expr_instantiate_rev(x_26, x_2);
lean_dec(x_2);
lean_dec(x_26);
x_31 = lean_box(0);
x_32 = lean_unbox(x_31);
x_33 = l_Lean_Meta_withLocalDecl___at___Lean_Meta_withLocalDeclD___at_____private_Lean_Meta_Constructions_BRecOn_0__Lean_buildBelowMinorPremise_go_spec__0_spec__0___redArg(x_25, x_28, x_30, x_29, x_32, x_5, x_6, x_7, x_8, x_9);
return x_33;
}
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
return x_11;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg(x_1, x_3, x_2, x_4, x_5, x_6, x_7, x_8, x_9);
return x_10;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; 
x_10 = l_Array_append___redArg(x_1, x_3);
x_11 = lean_apply_7(x_2, x_10, x_4, x_5, x_6, x_7, x_8, x_9);
return x_11;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_expr_instantiate_rev(x_4, x_2);
lean_dec(x_4);
x_11 = lean_apply_7(x_1, x_2, x_10, x_5, x_6, x_7, x_8, x_9);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_12 = lean_ctor_get(x_3, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_3, 1);
lean_inc(x_13);
lean_dec(x_3);
x_14 = lean_unsigned_to_nat(3u);
x_15 = lean_nat_dec_eq(x_12, x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_alloc_closure((void*)(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___lam__0), 9, 2);
lean_closure_set(x_16, 0, x_1);
lean_closure_set(x_16, 1, x_13);
x_17 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg(x_16, x_2, x_12, x_4, x_5, x_6, x_7, x_8, x_9);
return x_17;
}
else
{
lean_object* x_18; lean_object* x_19; 
lean_dec(x_12);
x_18 = lean_expr_instantiate_rev(x_4, x_2);
lean_dec(x_4);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
x_19 = lean_infer_type(x_18, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
x_21 = lean_ctor_get(x_19, 1);
lean_inc(x_21);
lean_dec(x_19);
x_22 = lean_alloc_closure((void*)(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___lam__1___boxed), 9, 2);
lean_closure_set(x_22, 0, x_2);
lean_closure_set(x_22, 1, x_1);
x_23 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___closed__0;
x_1 = x_22;
x_2 = x_23;
x_3 = x_13;
x_4 = x_20;
x_9 = x_21;
goto _start;
}
else
{
uint8_t x_25; 
lean_dec(x_13);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
lean_dec(x_1);
x_25 = !lean_is_exclusive(x_19);
if (x_25 == 0)
{
return x_19;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_19, 0);
x_27 = lean_ctor_get(x_19, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_19);
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_26);
lean_ctor_set(x_28, 1, x_27);
return x_28;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_9 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___closed__0;
x_10 = l_Lean_SubExpr_Pos_toArray(x_2);
x_11 = lean_array_to_list(x_10);
x_12 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg(x_1, x_9, x_11, x_3, x_4, x_5, x_6, x_7, x_8);
return x_12;
}
}
LEAN_EXPORT lean_object* l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_ProofWidgets_ExprWithCtx_save(x_2, x_3, x_4, x_5, x_6, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
x_9 = lean_infer_type(x_1, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___redArg(x_2, x_3, x_10, x_4, x_5, x_6, x_7, x_11);
return x_12;
}
else
{
uint8_t x_13; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
x_13 = !lean_is_exclusive(x_9);
if (x_13 == 0)
{
return x_9;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_14 = lean_ctor_get(x_9, 0);
x_15 = lean_ctor_get(x_9, 1);
lean_inc(x_15);
lean_inc(x_14);
lean_dec(x_9);
x_16 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_16, 0, x_14);
lean_ctor_set(x_16, 1, x_15);
return x_16;
}
}
}
}
static lean_object* _init_l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("fvar ", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__0;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" is not a let-binding", 21, 21);
return x_1;
}
}
static lean_object* _init_l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__2;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
lean_inc(x_5);
lean_inc(x_1);
x_10 = l_Lean_FVarId_getValue_x3f___redArg(x_1, x_2, x_5, x_7, x_8, x_9);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; 
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
if (lean_obj_tag(x_11) == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
lean_dec(x_3);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__1;
x_14 = l_Lean_Expr_fvar___override(x_1);
x_15 = l_Lean_MessageData_ofExpr(x_14);
x_16 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_16, 0, x_13);
lean_ctor_set(x_16, 1, x_15);
x_17 = l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__3;
x_18 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_18, 0, x_16);
lean_ctor_set(x_18, 1, x_17);
x_19 = l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(x_18, x_5, x_6, x_7, x_8, x_12);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; 
lean_dec(x_1);
x_20 = lean_ctor_get(x_10, 1);
lean_inc(x_20);
lean_dec(x_10);
x_21 = lean_ctor_get(x_11, 0);
lean_inc(x_21);
lean_dec(x_11);
x_22 = l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___redArg(x_3, x_4, x_21, x_5, x_6, x_7, x_8, x_20);
return x_22;
}
}
else
{
uint8_t x_23; 
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_3);
lean_dec(x_1);
x_23 = !lean_is_exclusive(x_10);
if (x_23 == 0)
{
return x_10;
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_24 = lean_ctor_get(x_10, 0);
x_25 = lean_ctor_get(x_10, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_10);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_24);
lean_ctor_set(x_26, 1, x_25);
return x_26;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = lean_ctor_get(x_1, 1);
lean_inc(x_7);
switch (lean_obj_tag(x_7)) {
case 0:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
lean_dec(x_1);
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
lean_dec(x_7);
x_10 = l_Lean_Expr_fvar___override(x_9);
x_11 = lean_alloc_closure((void*)(l_ProofWidgets_ExprWithCtx_save___boxed), 6, 1);
lean_closure_set(x_11, 0, x_10);
x_12 = l_Lean_MVarId_withContext___at_____private_Lean_Meta_SynthInstance_0__Lean_Meta_synthPendingImp_spec__1___redArg(x_8, x_11, x_2, x_3, x_4, x_5, x_6);
return x_12;
}
case 1:
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_13 = lean_ctor_get(x_1, 0);
lean_inc(x_13);
lean_dec(x_1);
x_14 = lean_ctor_get(x_7, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_7, 1);
lean_inc(x_15);
lean_dec(x_7);
x_16 = lean_alloc_closure((void*)(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__0___boxed), 7, 0);
x_17 = l_Lean_Expr_fvar___override(x_14);
x_18 = lean_alloc_closure((void*)(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__1___boxed), 8, 3);
lean_closure_set(x_18, 0, x_17);
lean_closure_set(x_18, 1, x_16);
lean_closure_set(x_18, 2, x_15);
x_19 = l_Lean_MVarId_withContext___at_____private_Lean_Meta_SynthInstance_0__Lean_Meta_synthPendingImp_spec__1___redArg(x_13, x_18, x_2, x_3, x_4, x_5, x_6);
return x_19;
}
case 2:
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_20 = lean_ctor_get(x_1, 0);
lean_inc(x_20);
lean_dec(x_1);
x_21 = lean_ctor_get(x_7, 0);
lean_inc(x_21);
x_22 = lean_ctor_get(x_7, 1);
lean_inc(x_22);
lean_dec(x_7);
x_23 = lean_alloc_closure((void*)(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__0___boxed), 7, 0);
x_24 = lean_box(0);
x_25 = lean_alloc_closure((void*)(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___boxed), 9, 4);
lean_closure_set(x_25, 0, x_21);
lean_closure_set(x_25, 1, x_24);
lean_closure_set(x_25, 2, x_23);
lean_closure_set(x_25, 3, x_22);
x_26 = l_Lean_MVarId_withContext___at_____private_Lean_Meta_SynthInstance_0__Lean_Meta_synthPendingImp_spec__1___redArg(x_20, x_25, x_2, x_3, x_4, x_5, x_6);
return x_26;
}
default: 
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_27 = lean_ctor_get(x_1, 0);
lean_inc(x_27);
lean_dec(x_1);
x_28 = lean_ctor_get(x_7, 0);
lean_inc(x_28);
lean_dec(x_7);
x_29 = lean_alloc_closure((void*)(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__0___boxed), 7, 0);
lean_inc(x_27);
x_30 = l_Lean_Expr_mvar___override(x_27);
x_31 = lean_alloc_closure((void*)(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__1___boxed), 8, 3);
lean_closure_set(x_31, 0, x_30);
lean_closure_set(x_31, 1, x_29);
lean_closure_set(x_31, 2, x_28);
x_32 = l_Lean_MVarId_withContext___at_____private_Lean_Meta_SynthInstance_0__Lean_Meta_synthPendingImp_spec__1___redArg(x_27, x_31, x_2, x_3, x_4, x_5, x_6);
return x_32;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___lam__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_3);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_2);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_3);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_3);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
uint8_t x_10; lean_object* x_11; 
x_10 = lean_unbox(x_2);
lean_dec(x_2);
x_11 = l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3(x_1, x_10, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_4);
return x_11;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("locations", 9, 9);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_;
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_2 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_;
x_9 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_7, x_8);
x_10 = l_Lean_Json_mkObj(x_9);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_usize_dec_lt(x_3, x_2);
if (x_6 == 0)
{
lean_object* x_7; 
lean_dec(x_1);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_4);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_8 = lean_array_uget(x_4, x_3);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
lean_inc(x_1);
x_11 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_1, x_9, x_5);
lean_dec(x_9);
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; size_t x_18; size_t x_19; lean_object* x_20; 
x_13 = lean_ctor_get(x_11, 1);
x_14 = lean_box(0);
x_15 = lean_array_uset(x_4, x_3, x_14);
x_16 = l___private_Lean_SubExpr_0__Lean_SubExpr_toJsonGoalsLocation____x40_Lean_SubExpr___hyg_1946_(x_10);
lean_ctor_set(x_11, 1, x_16);
x_17 = l_Prod_toJson___at___ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5__spec__0(x_11);
x_18 = 1;
x_19 = lean_usize_add(x_3, x_18);
x_20 = lean_array_uset(x_15, x_3, x_17);
x_3 = x_19;
x_4 = x_20;
x_5 = x_13;
goto _start;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; size_t x_29; size_t x_30; lean_object* x_31; 
x_22 = lean_ctor_get(x_11, 0);
x_23 = lean_ctor_get(x_11, 1);
lean_inc(x_23);
lean_inc(x_22);
lean_dec(x_11);
x_24 = lean_box(0);
x_25 = lean_array_uset(x_4, x_3, x_24);
x_26 = l___private_Lean_SubExpr_0__Lean_SubExpr_toJsonGoalsLocation____x40_Lean_SubExpr___hyg_1946_(x_10);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_22);
lean_ctor_set(x_27, 1, x_26);
x_28 = l_Prod_toJson___at___ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5__spec__0(x_27);
x_29 = 1;
x_30 = lean_usize_add(x_3, x_29);
x_31 = lean_array_uset(x_25, x_3, x_28);
x_3 = x_30;
x_4 = x_31;
x_5 = x_23;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; size_t x_4; size_t x_5; lean_object* x_6; uint8_t x_7; 
x_3 = l_Lean_Widget_instImpl____x40_Lean_Widget_Basic___hyg_51_;
x_4 = lean_array_size(x_1);
x_5 = 0;
x_6 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0(x_3, x_4, x_5, x_1, x_2);
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_8);
x_10 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_(x_9);
lean_ctor_set(x_6, 0, x_10);
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_11 = lean_ctor_get(x_6, 0);
x_12 = lean_ctor_get(x_6, 1);
lean_inc(x_12);
lean_inc(x_11);
lean_dec(x_6);
x_13 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_11);
x_14 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_(x_13);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_14);
lean_ctor_set(x_15, 1, x_12);
return x_15;
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0(x_1, x_6, x_7, x_4, x_5);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0_spec__0(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_usize_dec_lt(x_3, x_2);
if (x_6 == 0)
{
lean_object* x_7; 
lean_dec(x_5);
lean_dec(x_1);
x_7 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_7, 0, x_4);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_array_uget(x_4, x_3);
x_9 = l_Prod_fromJson_x3f___at___ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5__spec__0(x_8);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
return x_9;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
else
{
lean_object* x_13; uint8_t x_14; 
x_13 = lean_ctor_get(x_9, 0);
lean_inc(x_13);
lean_dec(x_9);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_15 = lean_ctor_get(x_13, 0);
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_5);
lean_inc(x_1);
x_17 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_1, x_15, x_5);
if (lean_obj_tag(x_17) == 0)
{
uint8_t x_18; 
lean_free_object(x_13);
lean_dec(x_16);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
return x_17;
}
else
{
lean_object* x_19; lean_object* x_20; 
x_19 = lean_ctor_get(x_17, 0);
lean_inc(x_19);
lean_dec(x_17);
x_20 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_20, 0, x_19);
return x_20;
}
}
else
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_ctor_get(x_17, 0);
lean_inc(x_21);
lean_dec(x_17);
x_22 = l___private_Lean_SubExpr_0__Lean_SubExpr_fromJsonGoalsLocation____x40_Lean_SubExpr___hyg_1840_(x_16);
if (lean_obj_tag(x_22) == 0)
{
uint8_t x_23; 
lean_dec(x_21);
lean_free_object(x_13);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_23 = !lean_is_exclusive(x_22);
if (x_23 == 0)
{
return x_22;
}
else
{
lean_object* x_24; lean_object* x_25; 
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec(x_22);
x_25 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_25, 0, x_24);
return x_25;
}
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; size_t x_29; size_t x_30; lean_object* x_31; 
x_26 = lean_ctor_get(x_22, 0);
lean_inc(x_26);
lean_dec(x_22);
x_27 = lean_box(0);
x_28 = lean_array_uset(x_4, x_3, x_27);
lean_ctor_set(x_13, 1, x_26);
lean_ctor_set(x_13, 0, x_21);
x_29 = 1;
x_30 = lean_usize_add(x_3, x_29);
x_31 = lean_array_uset(x_28, x_3, x_13);
x_3 = x_30;
x_4 = x_31;
goto _start;
}
}
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_13, 0);
x_34 = lean_ctor_get(x_13, 1);
lean_inc(x_34);
lean_inc(x_33);
lean_dec(x_13);
lean_inc(x_5);
lean_inc(x_1);
x_35 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_1, x_33, x_5);
if (lean_obj_tag(x_35) == 0)
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; 
lean_dec(x_34);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_36 = lean_ctor_get(x_35, 0);
lean_inc(x_36);
if (lean_is_exclusive(x_35)) {
 lean_ctor_release(x_35, 0);
 x_37 = x_35;
} else {
 lean_dec_ref(x_35);
 x_37 = lean_box(0);
}
if (lean_is_scalar(x_37)) {
 x_38 = lean_alloc_ctor(0, 1, 0);
} else {
 x_38 = x_37;
}
lean_ctor_set(x_38, 0, x_36);
return x_38;
}
else
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_35, 0);
lean_inc(x_39);
lean_dec(x_35);
x_40 = l___private_Lean_SubExpr_0__Lean_SubExpr_fromJsonGoalsLocation____x40_Lean_SubExpr___hyg_1840_(x_34);
if (lean_obj_tag(x_40) == 0)
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_39);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_41 = lean_ctor_get(x_40, 0);
lean_inc(x_41);
if (lean_is_exclusive(x_40)) {
 lean_ctor_release(x_40, 0);
 x_42 = x_40;
} else {
 lean_dec_ref(x_40);
 x_42 = lean_box(0);
}
if (lean_is_scalar(x_42)) {
 x_43 = lean_alloc_ctor(0, 1, 0);
} else {
 x_43 = x_42;
}
lean_ctor_set(x_43, 0, x_41);
return x_43;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; size_t x_48; size_t x_49; lean_object* x_50; 
x_44 = lean_ctor_get(x_40, 0);
lean_inc(x_44);
lean_dec(x_40);
x_45 = lean_box(0);
x_46 = lean_array_uset(x_4, x_3, x_45);
x_47 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_47, 0, x_39);
lean_ctor_set(x_47, 1, x_44);
x_48 = 1;
x_49 = lean_usize_add(x_3, x_48);
x_50 = lean_array_uset(x_46, x_3, x_47);
x_3 = x_49;
x_4 = x_50;
goto _start;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_usize_dec_lt(x_3, x_2);
if (x_6 == 0)
{
lean_object* x_7; 
lean_dec(x_5);
lean_dec(x_1);
x_7 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_7, 0, x_4);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_array_uget(x_4, x_3);
x_9 = l_Prod_fromJson_x3f___at___ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5__spec__0(x_8);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
return x_9;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
else
{
lean_object* x_13; uint8_t x_14; 
x_13 = lean_ctor_get(x_9, 0);
lean_inc(x_13);
lean_dec(x_9);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_15 = lean_ctor_get(x_13, 0);
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_5);
lean_inc(x_1);
x_17 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_1, x_15, x_5);
if (lean_obj_tag(x_17) == 0)
{
uint8_t x_18; 
lean_free_object(x_13);
lean_dec(x_16);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
return x_17;
}
else
{
lean_object* x_19; lean_object* x_20; 
x_19 = lean_ctor_get(x_17, 0);
lean_inc(x_19);
lean_dec(x_17);
x_20 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_20, 0, x_19);
return x_20;
}
}
else
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_ctor_get(x_17, 0);
lean_inc(x_21);
lean_dec(x_17);
x_22 = l___private_Lean_SubExpr_0__Lean_SubExpr_fromJsonGoalsLocation____x40_Lean_SubExpr___hyg_1840_(x_16);
if (lean_obj_tag(x_22) == 0)
{
uint8_t x_23; 
lean_dec(x_21);
lean_free_object(x_13);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_23 = !lean_is_exclusive(x_22);
if (x_23 == 0)
{
return x_22;
}
else
{
lean_object* x_24; lean_object* x_25; 
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec(x_22);
x_25 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_25, 0, x_24);
return x_25;
}
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; size_t x_29; size_t x_30; lean_object* x_31; lean_object* x_32; 
x_26 = lean_ctor_get(x_22, 0);
lean_inc(x_26);
lean_dec(x_22);
x_27 = lean_box(0);
x_28 = lean_array_uset(x_4, x_3, x_27);
lean_ctor_set(x_13, 1, x_26);
lean_ctor_set(x_13, 0, x_21);
x_29 = 1;
x_30 = lean_usize_add(x_3, x_29);
x_31 = lean_array_uset(x_28, x_3, x_13);
x_32 = l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0_spec__0(x_1, x_2, x_30, x_31, x_5);
return x_32;
}
}
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_13, 0);
x_34 = lean_ctor_get(x_13, 1);
lean_inc(x_34);
lean_inc(x_33);
lean_dec(x_13);
lean_inc(x_5);
lean_inc(x_1);
x_35 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_1, x_33, x_5);
if (lean_obj_tag(x_35) == 0)
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; 
lean_dec(x_34);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_36 = lean_ctor_get(x_35, 0);
lean_inc(x_36);
if (lean_is_exclusive(x_35)) {
 lean_ctor_release(x_35, 0);
 x_37 = x_35;
} else {
 lean_dec_ref(x_35);
 x_37 = lean_box(0);
}
if (lean_is_scalar(x_37)) {
 x_38 = lean_alloc_ctor(0, 1, 0);
} else {
 x_38 = x_37;
}
lean_ctor_set(x_38, 0, x_36);
return x_38;
}
else
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_35, 0);
lean_inc(x_39);
lean_dec(x_35);
x_40 = l___private_Lean_SubExpr_0__Lean_SubExpr_fromJsonGoalsLocation____x40_Lean_SubExpr___hyg_1840_(x_34);
if (lean_obj_tag(x_40) == 0)
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_39);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_41 = lean_ctor_get(x_40, 0);
lean_inc(x_41);
if (lean_is_exclusive(x_40)) {
 lean_ctor_release(x_40, 0);
 x_42 = x_40;
} else {
 lean_dec_ref(x_40);
 x_42 = lean_box(0);
}
if (lean_is_scalar(x_42)) {
 x_43 = lean_alloc_ctor(0, 1, 0);
} else {
 x_43 = x_42;
}
lean_ctor_set(x_43, 0, x_41);
return x_43;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; size_t x_48; size_t x_49; lean_object* x_50; lean_object* x_51; 
x_44 = lean_ctor_get(x_40, 0);
lean_inc(x_44);
lean_dec(x_40);
x_45 = lean_box(0);
x_46 = lean_array_uset(x_4, x_3, x_45);
x_47 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_47, 0, x_39);
lean_ctor_set(x_47, 1, x_44);
x_48 = 1;
x_49 = lean_usize_add(x_3, x_48);
x_50 = lean_array_uset(x_46, x_3, x_47);
x_51 = l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0_spec__0(x_1, x_2, x_49, x_50, x_5);
return x_51;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(x_4);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_6; 
lean_dec(x_2);
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; 
x_7 = lean_ctor_get(x_5, 0);
lean_inc(x_7);
lean_dec(x_5);
x_8 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_8, 0, x_7);
return x_8;
}
}
else
{
lean_object* x_9; lean_object* x_10; size_t x_11; size_t x_12; lean_object* x_13; 
x_9 = lean_ctor_get(x_5, 0);
lean_inc(x_9);
lean_dec(x_5);
x_10 = l_Lean_Widget_instImpl____x40_Lean_Widget_Basic___hyg_51_;
x_11 = lean_array_size(x_9);
x_12 = 0;
x_13 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0(x_10, x_11, x_12, x_9, x_2);
if (lean_obj_tag(x_13) == 0)
{
uint8_t x_14; 
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
return x_13;
}
else
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_ctor_get(x_13, 0);
lean_inc(x_15);
lean_dec(x_13);
x_16 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_16, 0, x_15);
return x_16;
}
}
else
{
uint8_t x_17; 
x_17 = !lean_is_exclusive(x_13);
if (x_17 == 0)
{
return x_13;
}
else
{
lean_object* x_18; lean_object* x_19; 
x_18 = lean_ctor_get(x_13, 0);
lean_inc(x_18);
lean_dec(x_13);
x_19 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_19, 0, x_18);
return x_19;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0_spec__0(x_1, x_6, x_7, x_4, x_5);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200__spec__0(x_1, x_6, x_7, x_4, x_5);
return x_8;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__2;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("exprs", 5, 5);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_;
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_;
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_590_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_2 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_;
x_9 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_7, x_8);
x_10 = l_Lean_Json_mkObj(x_9);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_590_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_usize_dec_lt(x_3, x_2);
if (x_6 == 0)
{
lean_object* x_7; 
lean_dec(x_1);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_4);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; size_t x_14; size_t x_15; lean_object* x_16; 
x_8 = lean_array_uget(x_4, x_3);
lean_inc(x_1);
x_9 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_1, x_8, x_5);
lean_dec(x_8);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_box(0);
x_13 = lean_array_uset(x_4, x_3, x_12);
x_14 = 1;
x_15 = lean_usize_add(x_3, x_14);
x_16 = lean_array_uset(x_13, x_3, x_10);
x_3 = x_15;
x_4 = x_16;
x_5 = x_11;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; size_t x_4; size_t x_5; lean_object* x_6; uint8_t x_7; 
x_3 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_4 = lean_array_size(x_1);
x_5 = 0;
x_6 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0(x_3, x_4, x_5, x_1, x_2);
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_8);
x_10 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_590_(x_9);
lean_ctor_set(x_6, 0, x_10);
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_11 = lean_ctor_get(x_6, 0);
x_12 = lean_ctor_get(x_6, 1);
lean_inc(x_12);
lean_inc(x_11);
lean_dec(x_6);
x_13 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_11);
x_14 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_590_(x_13);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_14);
lean_ctor_set(x_15, 1, x_12);
return x_15;
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0(x_1, x_6, x_7, x_4, x_5);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_usize_dec_lt(x_3, x_2);
if (x_6 == 0)
{
lean_object* x_7; 
lean_dec(x_5);
lean_dec(x_1);
x_7 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_7, 0, x_4);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_array_uget(x_4, x_3);
lean_inc(x_5);
lean_inc(x_1);
x_9 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_1, x_8, x_5);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
return x_9;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; size_t x_16; size_t x_17; lean_object* x_18; 
x_13 = lean_ctor_get(x_9, 0);
lean_inc(x_13);
lean_dec(x_9);
x_14 = lean_box(0);
x_15 = lean_array_uset(x_4, x_3, x_14);
x_16 = 1;
x_17 = lean_usize_add(x_3, x_16);
x_18 = lean_array_uset(x_15, x_3, x_13);
x_3 = x_17;
x_4 = x_18;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(x_4);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_6; 
lean_dec(x_2);
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; 
x_7 = lean_ctor_get(x_5, 0);
lean_inc(x_7);
lean_dec(x_5);
x_8 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_8, 0, x_7);
return x_8;
}
}
else
{
lean_object* x_9; lean_object* x_10; size_t x_11; size_t x_12; lean_object* x_13; 
x_9 = lean_ctor_get(x_5, 0);
lean_inc(x_9);
lean_dec(x_5);
x_10 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_11 = lean_array_size(x_9);
x_12 = 0;
x_13 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0(x_10, x_11, x_12, x_9, x_2);
if (lean_obj_tag(x_13) == 0)
{
uint8_t x_14; 
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
return x_13;
}
else
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_ctor_get(x_13, 0);
lean_inc(x_15);
lean_dec(x_13);
x_16 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_16, 0, x_15);
return x_16;
}
}
else
{
uint8_t x_17; 
x_17 = !lean_is_exclusive(x_13);
if (x_17 == 0)
{
return x_13;
}
else
{
lean_object* x_18; lean_object* x_19; 
x_18 = lean_ctor_get(x_13, 0);
lean_inc(x_18);
lean_dec(x_13);
x_19 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_19, 0, x_18);
return x_19;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468__spec__0(x_1, x_6, x_7, x_4, x_5);
return x_8;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__2;
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__0;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(32u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__2;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__4() {
_start:
{
size_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__2;
x_4 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__3;
x_5 = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set_usize(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(0);
x_2 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__4;
x_3 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__1;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_usize_dec_lt(x_3, x_2);
if (x_6 == 0)
{
lean_object* x_7; 
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_4);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_8 = lean_array_uget(x_1, x_3);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__5;
x_13 = lean_alloc_closure((void*)(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx), 6, 1);
lean_closure_set(x_13, 0, x_10);
x_14 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_11, x_12, x_13, x_5);
if (lean_obj_tag(x_14) == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; size_t x_21; size_t x_22; 
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
x_16 = lean_ctor_get(x_14, 1);
lean_inc(x_16);
lean_dec(x_14);
x_17 = l_Lean_Server_WithRpcRef_mk___redArg(x_15, x_16);
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
x_19 = lean_ctor_get(x_17, 1);
lean_inc(x_19);
lean_dec(x_17);
x_20 = lean_array_push(x_4, x_18);
x_21 = 1;
x_22 = lean_usize_add(x_3, x_21);
x_3 = x_22;
x_4 = x_20;
x_5 = x_19;
goto _start;
}
else
{
uint8_t x_24; 
lean_dec(x_4);
x_24 = !lean_is_exclusive(x_14);
if (x_24 == 0)
{
lean_object* x_25; lean_object* x_26; 
x_25 = lean_ctor_get(x_14, 0);
x_26 = l_Lean_Server_RequestError_ofIoError(x_25);
lean_ctor_set(x_14, 0, x_26);
return x_14;
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_27 = lean_ctor_get(x_14, 0);
x_28 = lean_ctor_get(x_14, 1);
lean_inc(x_28);
lean_inc(x_27);
lean_dec(x_14);
x_29 = l_Lean_Server_RequestError_ofIoError(x_27);
x_30 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_30, 0, x_29);
lean_ctor_set(x_30, 1, x_28);
return x_30;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg(x_3, x_4, x_5, x_6, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_goalsLocationsToExprs___lam__0(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg(x_1, x_2, x_3, x_4, x_6);
if (lean_obj_tag(x_7) == 0)
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
return x_7;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_9 = lean_ctor_get(x_7, 0);
x_10 = lean_ctor_get(x_7, 1);
lean_inc(x_10);
lean_inc(x_9);
lean_dec(x_7);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_9);
lean_ctor_set(x_11, 1, x_10);
return x_11;
}
}
else
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_7);
if (x_12 == 0)
{
return x_7;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_13 = lean_ctor_get(x_7, 0);
x_14 = lean_ctor_get(x_7, 1);
lean_inc(x_14);
lean_inc(x_13);
lean_dec(x_7);
x_15 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_15, 0, x_13);
lean_ctor_set(x_15, 1, x_14);
return x_15;
}
}
}
}
static lean_object* _init_l_ProofWidgets_goalsLocationsToExprs___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_goalsLocationsToExprs___boxed__const__1() {
_start:
{
size_t x_1; lean_object* x_2; 
x_1 = 0;
x_2 = lean_box_usize(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_goalsLocationsToExprs(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; size_t x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_4 = l_ProofWidgets_goalsLocationsToExprs___closed__0;
x_5 = lean_array_size(x_1);
x_6 = lean_box_usize(x_5);
x_7 = l_ProofWidgets_goalsLocationsToExprs___boxed__const__1;
x_8 = lean_alloc_closure((void*)(l_ProofWidgets_goalsLocationsToExprs___lam__0___boxed), 6, 4);
lean_closure_set(x_8, 0, x_1);
lean_closure_set(x_8, 1, x_6);
lean_closure_set(x_8, 2, x_7);
lean_closure_set(x_8, 3, x_4);
x_9 = l_Lean_Server_RequestM_asTask___redArg(x_8, x_2, x_3);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg(x_1, x_6, x_7, x_4, x_5);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
size_t x_9; size_t x_10; lean_object* x_11; 
x_9 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_10 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_11 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0(x_1, x_2, x_3, x_9, x_10, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_11;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_goalsLocationsToExprs___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; size_t x_8; lean_object* x_9; 
x_7 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_8 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_9 = l_ProofWidgets_goalsLocationsToExprs___lam__0(x_1, x_7, x_8, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = lean_box(0);
x_3 = lean_unbox(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__1(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__2), 2, 1);
lean_closure_set(x_14, 0, x_13);
x_15 = l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse_enc____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_468_(x_8, x_12);
x_16 = l_Prod_map___redArg(x_2, x_14, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_1 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__0;
x_2 = lean_box(9);
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
x_4 = lean_unbox(x_2);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_4);
return x_3;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, uint64_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
x_10 = l_Lean_RBNode_find___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget___hyg_204__spec__0___redArg(x_9, x_5);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_11 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__1;
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_st_ref_get(x_13, x_8);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_16 = lean_ctor_get(x_14, 0);
x_17 = lean_ctor_get(x_14, 1);
x_18 = lean_ctor_get(x_16, 0);
lean_inc(x_18);
lean_dec(x_16);
lean_inc(x_6);
x_19 = l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200_(x_6, x_18);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; uint8_t x_35; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
lean_dec(x_19);
x_21 = lean_box(3);
x_22 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__2;
x_23 = lean_box(1);
x_24 = lean_unbox(x_23);
x_25 = l_Lean_Name_toString(x_1, x_24, x_2);
x_26 = lean_string_append(x_22, x_25);
lean_dec(x_25);
x_27 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__3;
x_28 = lean_string_append(x_26, x_27);
x_29 = l_Lean_Json_compress(x_6);
x_30 = lean_string_append(x_28, x_29);
lean_dec(x_29);
x_31 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__4;
x_32 = lean_string_append(x_30, x_31);
x_33 = lean_string_append(x_32, x_20);
lean_dec(x_20);
x_34 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_34, 0, x_33);
x_35 = lean_unbox(x_21);
lean_ctor_set_uint8(x_34, sizeof(void*)*1, x_35);
lean_ctor_set_tag(x_14, 1);
lean_ctor_set(x_14, 0, x_34);
return x_14;
}
else
{
lean_object* x_36; lean_object* x_37; 
lean_free_object(x_14);
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_36 = lean_ctor_get(x_19, 0);
lean_inc(x_36);
lean_dec(x_19);
lean_inc(x_7);
x_37 = lean_apply_3(x_3, x_36, x_7, x_17);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
x_40 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_40, 0, x_13);
lean_closure_set(x_40, 1, x_4);
x_41 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_38, x_40, x_7, x_39);
return x_41;
}
else
{
uint8_t x_42; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_42 = !lean_is_exclusive(x_37);
if (x_42 == 0)
{
return x_37;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_43 = lean_ctor_get(x_37, 0);
x_44 = lean_ctor_get(x_37, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_37);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
return x_45;
}
}
}
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_46 = lean_ctor_get(x_14, 0);
x_47 = lean_ctor_get(x_14, 1);
lean_inc(x_47);
lean_inc(x_46);
lean_dec(x_14);
x_48 = lean_ctor_get(x_46, 0);
lean_inc(x_48);
lean_dec(x_46);
lean_inc(x_6);
x_49 = l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams_dec____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_200_(x_6, x_48);
if (lean_obj_tag(x_49) == 0)
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; uint8_t x_65; lean_object* x_66; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec(x_49);
x_51 = lean_box(3);
x_52 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__2;
x_53 = lean_box(1);
x_54 = lean_unbox(x_53);
x_55 = l_Lean_Name_toString(x_1, x_54, x_2);
x_56 = lean_string_append(x_52, x_55);
lean_dec(x_55);
x_57 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__3;
x_58 = lean_string_append(x_56, x_57);
x_59 = l_Lean_Json_compress(x_6);
x_60 = lean_string_append(x_58, x_59);
lean_dec(x_59);
x_61 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__4;
x_62 = lean_string_append(x_60, x_61);
x_63 = lean_string_append(x_62, x_50);
lean_dec(x_50);
x_64 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_64, 0, x_63);
x_65 = lean_unbox(x_51);
lean_ctor_set_uint8(x_64, sizeof(void*)*1, x_65);
x_66 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_66, 0, x_64);
lean_ctor_set(x_66, 1, x_47);
return x_66;
}
else
{
lean_object* x_67; lean_object* x_68; 
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_67 = lean_ctor_get(x_49, 0);
lean_inc(x_67);
lean_dec(x_49);
lean_inc(x_7);
x_68 = lean_apply_3(x_3, x_67, x_7, x_47);
if (lean_obj_tag(x_68) == 0)
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
x_69 = lean_ctor_get(x_68, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_68, 1);
lean_inc(x_70);
lean_dec(x_68);
x_71 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_71, 0, x_13);
lean_closure_set(x_71, 1, x_4);
x_72 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_69, x_71, x_7, x_70);
return x_72;
}
else
{
lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_73 = lean_ctor_get(x_68, 0);
lean_inc(x_73);
x_74 = lean_ctor_get(x_68, 1);
lean_inc(x_74);
if (lean_is_exclusive(x_68)) {
 lean_ctor_release(x_68, 0);
 lean_ctor_release(x_68, 1);
 x_75 = x_68;
} else {
 lean_dec_ref(x_68);
 x_75 = lean_box(0);
}
if (lean_is_scalar(x_75)) {
 x_76 = lean_alloc_ctor(1, 2, 0);
} else {
 x_76 = x_75;
}
lean_ctor_set(x_76, 0, x_73);
lean_ctor_set(x_76, 1, x_74);
return x_76;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__1___boxed), 1, 0);
x_5 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___boxed), 8, 4);
lean_closure_set(x_5, 0, x_1);
lean_closure_set(x_5, 1, x_3);
lean_closure_set(x_5, 2, x_2);
lean_closure_set(x_5, 3, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("goalsLocationsToExprs", 21, 21);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__1;
x_2 = l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_goalsLocationsToExprs), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__2;
x_2 = l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__3;
x_3 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__1___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__1(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint64_t x_9; lean_object* x_10; 
x_9 = lean_unbox_uint64(x_5);
lean_dec(x_5);
x_10 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4(x_1, x_2, x_3, x_4, x_9, x_6, x_7, x_8);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_SelectionPanel___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as r,Fragment as n}from\"react/jsx-runtime\";import{useRpcSession as t,EnvPosContext as a,useAsyncPersistent as o,mapRpcError as s,importWidgetModule as i,InteractiveCode as l}from\"@leanprover/infoview\";import*as c from\"react\";async function m(t,a,o){if(\"text\"in o)return r(n,{children:o.text});if(\"element\"in o){const[e,n,s]=o.element,i={};for(const[e,r]of n)i[e]=r;const l=await Promise.all(s.map((async e=>await m(t,a,e))));return\"hr\"===e\?r(\"hr\",{}):0===l.length\?c.createElement(e,i):c.createElement(e,i,l)}if(\"component\"in o){const[e,r,n,s]=o.component,l=await Promise.all(s.map((async e=>await m(t,a,e)))),u={...n,pos:a},d=await i(t,a,e);if(!(r in d))throw new Error(`Module '${e}' does not export '${r}'`);return 0===l.length\?c.createElement(d[r],u):c.createElement(d[r],u,l)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(o)]})}function u({html:i}){const l=t(),u=c.useContext(a),d=o((()=>m(l,u,i)),[l,u,i]);return\"resolved\"===d.state\?d.value:\"rejected\"===d.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",s(d.error).message]}):r(n,{})}function d({expr:a}){const i=t(),c=o((()=>i.call(\"ProofWidgets.ppExprTagged\",{expr:a})),[a]);return\"resolved\"===c.state\?r(l,{fmt:c.value}):\"rejected\"===c.state\?e(n,{children:[\"Error: $\",s(c.error).message]}):r(n,{children:\"Loading..\"})}function f({expr:a}){const i=t(),[l,m]=c.useState({tag:\"auto\"}),f=o((async()=>{const e=await async function(e,r){return(await e.call(\"ProofWidgets.getExprPresentations\",{expr:r})).presentations}(i,a);return m((r=>\"manual\"!==r.tag||void 0===r.name||e.some((e=>e.name===r.name))\?r:{tag:\"auto\"})),new Map(e.map((e=>[e.name,e])))}),[i,a]);if(\"rejected\"===f.state)return e(n,{children:[\"Error: \",s(f.error).message]});if(\"resolved\"===f.state){let n=\"none\";return\"auto\"===l.tag&&0<f.value.size\?n=Array.from(f.value.values())[0].name:\"manual\"!==l.tag||\"none\"!==l.name&&!f.value.has(l.name)||(n=l.name),e(\"div\",{style:{display:\"flow-root\"},children:[\"none\"!==n&&r(u,{html:f.value.get(n).html}),\"none\"===n&&r(d,{expr:a}),e(\"select\",{className:\"fr\",value:n,onChange:e=>{m({tag:\"manual\",name:e.target.value})},children:[Array.from(f.value.values(),(e=>r(\"option\",{value:e.name,children:e.userName},e.name))),r(\"option\",{value:\"none\",children:\"Default\"},\"none\")]})]})}return r(d,{expr:a})}function p({pos:a,goals:i,loc:l}){const c=t(),m=o((async()=>{const e=function(e,r){for(const n of e)if(n.mvarId===r.mvarId)return n;throw new Error(`Could not find goal for location ${JSON.stringify(r)}`)}(i,l);if(void 0===e.ctx)throw new Error(\"Lean server 1.1.2 or newer is required.\");return(await c.call(\"ProofWidgets.goalsLocationsToExprs\",{locations:[[e.ctx,l]]})).exprs[0]}),[c,i,l]);return\"loading\"===m.state\?r(n,{children:\"Loading..\"}):\"rejected\"===m.state\?e(n,{children:[\"Error: \",s(m.error).message]}):r(f,{expr:m.value})}function g(t){return e(\"details\",{open:!0,children:[r(\"summary\",{className:\"mv2 pointer\",children:\"Selected expressions\"}),t.selectedLocations.length>0\?t.selectedLocations.map((e=>r(p,{pos:t.pos,goals:t.goals,loc:e},JSON.stringify(e.loc)))):r(n,{children:\"Nothing selected. You can use shift-click to select expressions in the goal.\"})]})}export{p as GoalsLocationPresentation,g as default};", 3260, 3260);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_SelectionPanel___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_SelectionPanel___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_SelectionPanel___closed__2___boxed__const__1() {
_start:
{
uint64_t x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_SelectionPanel___closed__1;
x_2 = lean_box_uint64(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_SelectionPanel___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_SelectionPanel___closed__0;
x_2 = l_ProofWidgets_SelectionPanel___closed__2___boxed__const__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_SelectionPanel___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_SelectionPanel___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_SelectionPanel___closed__3;
x_2 = l_ProofWidgets_SelectionPanel___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_SelectionPanel() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_SelectionPanel___closed__4;
return x_1;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Meta_ExprLens(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Panel_Basic(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Presentation_Expr(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Component_Panel_SelectionPanel(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Meta_ExprLens(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Panel_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Presentation_Expr(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__0 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__0();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__0);
l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__1 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__1();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__1);
l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__2 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__2();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__2);
l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__3 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__3();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__3);
l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__4 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__4();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__4);
l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__5 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__5();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__5);
l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__6 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__6();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__6);
l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__7 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__7();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewCoordAux___at_____private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0_spec__0___redArg___closed__7);
l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___closed__0 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___closed__0();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Meta_viewAux___at___Lean_Meta_viewSubexpr___at___Lean_SubExpr_GoalsLocation_saveExprWithCtx_spec__0_spec__0___redArg___closed__0);
l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__0 = _init_l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__0();
lean_mark_persistent(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__0);
l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__1 = _init_l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__1();
lean_mark_persistent(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__1);
l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__2 = _init_l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__2();
lean_mark_persistent(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__2);
l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__3 = _init_l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__3();
lean_mark_persistent(l_Lean_SubExpr_GoalsLocation_saveExprWithCtx___lam__3___closed__3);
l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_ = _init_l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_();
lean_mark_persistent(l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_241_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_323_);
l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_ = _init_l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_();
lean_mark_persistent(l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_326_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_361_);
l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__0 = _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__0);
l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__1 = _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__1);
l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__2 = _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams___closed__2);
l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams = _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsParams);
l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_ = _init_l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_();
lean_mark_persistent(l___private_ProofWidgets_Component_Panel_SelectionPanel_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_505_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_587_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_SelectionPanel___hyg_625_);
l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__0 = _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__0);
l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__1 = _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__1);
l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__2 = _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse___closed__2);
l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse = _init_l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGoalsLocationsToExprsResponse);
l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__0 = _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__0();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__0);
l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__1 = _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__1();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__1);
l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__2 = _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__2();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__2);
l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__3 = _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__3();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__3);
l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__4 = _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__4();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__4);
l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__5 = _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__5();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_goalsLocationsToExprs_spec__0___redArg___closed__5);
l_ProofWidgets_goalsLocationsToExprs___closed__0 = _init_l_ProofWidgets_goalsLocationsToExprs___closed__0();
lean_mark_persistent(l_ProofWidgets_goalsLocationsToExprs___closed__0);
l_ProofWidgets_goalsLocationsToExprs___boxed__const__1 = _init_l_ProofWidgets_goalsLocationsToExprs___boxed__const__1();
lean_mark_persistent(l_ProofWidgets_goalsLocationsToExprs___boxed__const__1);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__0 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__0();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__0);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__1 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__1();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__1);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__2 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__2();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__2);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__3 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__3();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__3);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__4 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__4();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_goalsLocationsToExprs___rpc__wrapped_spec__0___lam__4___closed__4);
l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__0 = _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__0();
lean_mark_persistent(l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__0);
l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__1 = _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__1();
lean_mark_persistent(l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__1);
l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__2 = _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__2();
lean_mark_persistent(l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__2);
l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__3 = _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__3();
lean_mark_persistent(l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped___closed__3);
l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped = _init_l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped();
lean_mark_persistent(l_ProofWidgets_goalsLocationsToExprs___rpc__wrapped);
l_ProofWidgets_SelectionPanel___closed__0 = _init_l_ProofWidgets_SelectionPanel___closed__0();
lean_mark_persistent(l_ProofWidgets_SelectionPanel___closed__0);
l_ProofWidgets_SelectionPanel___closed__1 = _init_l_ProofWidgets_SelectionPanel___closed__1();
l_ProofWidgets_SelectionPanel___closed__2___boxed__const__1 = _init_l_ProofWidgets_SelectionPanel___closed__2___boxed__const__1();
lean_mark_persistent(l_ProofWidgets_SelectionPanel___closed__2___boxed__const__1);
l_ProofWidgets_SelectionPanel___closed__2 = _init_l_ProofWidgets_SelectionPanel___closed__2();
lean_mark_persistent(l_ProofWidgets_SelectionPanel___closed__2);
l_ProofWidgets_SelectionPanel___closed__3 = _init_l_ProofWidgets_SelectionPanel___closed__3();
lean_mark_persistent(l_ProofWidgets_SelectionPanel___closed__3);
l_ProofWidgets_SelectionPanel___closed__4 = _init_l_ProofWidgets_SelectionPanel___closed__4();
lean_mark_persistent(l_ProofWidgets_SelectionPanel___closed__4);
l_ProofWidgets_SelectionPanel = _init_l_ProofWidgets_SelectionPanel();
lean_mark_persistent(l_ProofWidgets_SelectionPanel);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
