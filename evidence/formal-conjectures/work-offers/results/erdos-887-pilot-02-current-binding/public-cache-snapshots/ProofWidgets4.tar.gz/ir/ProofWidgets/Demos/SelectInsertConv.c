// Lean compiler output
// Module: ProofWidgets.Demos.SelectInsertConv
// Imports: Init Lean.Meta.ExprLens Batteries.Lean.Position ProofWidgets.Data.Html ProofWidgets.Component.OfRpcMethod ProofWidgets.Component.MakeEditLink ProofWidgets.Component.Panel.Basic
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__6;
lean_object* l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_liftMacroM___at___Lean_Elab_Tactic_evalTactic_expandEval_spec__0_spec__2___redArg(lean_object*);
static lean_object* l_tacticConv_x3f___closed__3;
static lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__17;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* l_insertEnter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_Lean_SubExpr_Pos_tail(lean_object*);
static lean_object* l_insertEnter___closed__5;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__36;
lean_object* l_List_toString___at___Lean_rewriteManualLinksCore_rw_spec__0(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__13;
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_mkObj(lean_object*);
uint8_t l_Array_isEmpty___redArg(lean_object*);
uint8_t l_Lean_Expr_isApp(lean_object*);
lean_object* l_Lean_Name_toString(lean_object*, uint8_t, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__1;
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__19;
LEAN_EXPORT lean_object* l_panic___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__3(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__15;
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__6;
static lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1;
static lean_object* l_tacticConv_x3f___closed__2;
static lean_object* l_insertEnter___closed__3;
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__0;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1;
lean_object* l_Lean_Widget_instRpcEncodableInteractiveTermGoal_enc____x40_Lean_Widget_InteractiveGoal___hyg_2275_(lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__4;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__35;
LEAN_EXPORT lean_object* l_ConvSelectionPanel___closed__2___boxed__const__1;
static lean_object* l_findGoalForLocation___closed__0;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__1(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__1;
static lean_object* l_instRpcEncodableConvSelectionPanelProps___closed__1;
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___lam__0(lean_object*, lean_object*);
uint64_t lean_string_hash(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__0;
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
uint8_t l_List_isEmpty___redArg(lean_object*);
lean_object* l_Lean_stringToMessageData(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__29;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__30;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4(lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__1___boxed(lean_object*);
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonRange____x40_Lean_Data_Lsp_Basic___hyg_625_(lean_object*);
lean_object* l_Lean_Expr_appArg_x21(lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0;
LEAN_EXPORT lean_object* l_findGoalForLocation(lean_object*, lean_object*);
lean_object* l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__27;
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_findGoalForLocation___boxed(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___boxed(lean_object*, lean_object*, lean_object*);
extern lean_object* l_Lean_Server_instInhabitedRequestError;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__37;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__3;
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__16;
lean_object* lean_st_ref_take(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__26;
lean_object* l_Lean_FileMap_rangeOfStx_x3f(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0;
lean_object* l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__7;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__3;
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__12;
lean_object* l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*);
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*);
lean_object* l_Lean_SubExpr_Pos_toArray(lean_object*);
lean_object* l_Lean_MessageData_ofFormat(lean_object*);
lean_object* lean_st_ref_get(lean_object*, lean_object*);
lean_object* l_instInhabitedForall___redArg___lam__0___boxed(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__24;
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at___insertEnter_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_to_list(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__4;
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__14;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0(lean_object*, lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3;
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__0___closed__0;
lean_object* l_EStateM_instInhabited___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps_enc____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1476_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__23;
LEAN_EXPORT lean_object* l_ConvSelectionPanel;
static lean_object* l_insertEnter___closed__2;
uint8_t lean_name_eq(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel___closed__3;
lean_object* l___private_Lean_SubExpr_0__Lean_SubExpr_toJsonGoalsLocation____x40_Lean_SubExpr___hyg_1946_(lean_object*);
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
lean_object* l_Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_enc____x40_Lean_Widget_InteractiveGoal___hyg_3401__spec__0(size_t, size_t, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__21;
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_object* l_Lean_Expr_appFn_x21(lean_object*);
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_tacticConv_x3f___closed__4;
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__28;
lean_object* l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonPosition____x40_Lean_Data_Lsp_Basic___hyg_226_(lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped;
static lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3;
static uint64_t l_ConvSelectionPanel___closed__1;
lean_object* l_Lean_MessageData_ofExpr(lean_object*);
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_SubExpr_Pos_head(lean_object*);
lean_object* l_List_head_x21___redArg(lean_object*, lean_object*);
static lean_object* l_insertEnter___closed__0;
uint8_t l_Lean_SubExpr_Pos_isRoot(lean_object*);
lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(size_t, size_t, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2;
lean_object* lean_array_fget(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_tacticConv_x3f___closed__1;
LEAN_EXPORT lean_object* l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_;
lean_object* l_Lean_Widget_savePanelWidgetInfo(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__7;
uint8_t l_String_anyAux___at___Lean_Name_isInaccessibleUserName_spec__0(uint32_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_insertEnter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_MVarId_getDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(lean_object*, uint64_t);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__33;
uint8_t l_Lean_BinderInfo_isExplicit(uint8_t);
lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_insertEnter___closed__1;
static lean_object* l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__32;
lean_object* l_Lean_Json_opt___at_____private_Lean_Data_Lsp_Diagnostics_0__Lean_Lsp_toJsonDiagnosticWith____x40_Lean_Data_Lsp_Diagnostics___hyg_1722____at___Array_toJson___at_____private_Lean_Data_Lsp_Diagnostics_0__Lean_Lsp_toJsonPublishDiagnosticsParams____x40_Lean_Data_Lsp_Diagnostics___hyg_2460__spec__1_spec__1_spec__13(lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__2;
lean_object* lean_panic_fn(lean_object*, lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Client_0__Lean_Lsp_fromJsonRegistration____x40_Lean_Data_Lsp_Client___hyg_106__spec__0(lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4;
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestM_readDoc___at___Lean_Server_RequestM_withWaitFindSnapAtPos_spec__0(lean_object*, lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* l_Lean_Widget_instRpcEncodableInteractiveTermGoal_dec____x40_Lean_Widget_InteractiveGoal___hyg_2275_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* l_List_tail_x21___redArg(lean_object*);
LEAN_EXPORT lean_object* l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_;
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel___closed__0;
static lean_object* l_instRpcEncodableConvSelectionPanelProps___closed__0;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__10;
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__18;
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_ProofWidgets_MakeEditLink;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__25;
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonPosition____x40_Lean_Data_Lsp_Basic___hyg_278_(lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* l_mkPanicMessageWithDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__9;
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_array_size(lean_object*);
lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(size_t, size_t, lean_object*, lean_object*);
static lean_object* l_tacticConv_x3f___closed__0;
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel___closed__4;
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__20;
lean_object* l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__5;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__31;
lean_object* lean_string_append(lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__22;
lean_object* l_Lean_Meta_withLCtx___at_____private_Lean_Meta_Basic_0__Lean_Meta_mkLevelErrorMessageCore_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__8;
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__11;
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1476_(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
static lean_object* l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_;
LEAN_EXPORT lean_object* l_tacticConv_x3f;
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_infer_type(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__34;
uint8_t lean_usize_dec_lt(size_t, size_t);
static lean_object* l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0;
lean_object* l_Lean_LocalContext_sanitizeNames(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
lean_object* l_Lean_Json_pretty(lean_object*, lean_object*);
uint8_t l_Lean_Expr_bindingInfo_x21(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Elab_ContextInfo_runMetaM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1;
lean_object* l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonRange____x40_Lean_Data_Lsp_Basic___hyg_677_(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_instRpcEncodableConvSelectionPanelProps___closed__2;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848____boxed(lean_object*);
lean_object* l___private_ProofWidgets_Component_MakeEditLink_0__ProofWidgets_toJsonMakeEditLinkProps____x40_ProofWidgets_Component_MakeEditLink___hyg_298_(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2;
lean_object* l_Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_dec____x40_Lean_Widget_InteractiveGoal___hyg_3401__spec__0(size_t, size_t, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_invalidParams(lean_object*);
static lean_object* l_ConvSelectionPanel_rpc___lam__2___closed__2;
static lean_object* l_insertEnter___closed__4;
static lean_object* l_ConvSelectionPanel___closed__2;
LEAN_EXPORT lean_object* l_panic___at___ConvSelectionPanel_rpc_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
x_7 = lean_ctor_get(x_1, 1);
lean_inc(x_7);
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
if (lean_is_exclusive(x_1)) {
 lean_ctor_release(x_1, 0);
 lean_ctor_release(x_1, 1);
 x_9 = x_1;
} else {
 lean_dec_ref(x_1);
 x_9 = lean_box(0);
}
x_10 = lean_ctor_get(x_7, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_7, 1);
lean_inc(x_11);
if (lean_is_exclusive(x_7)) {
 lean_ctor_release(x_7, 0);
 lean_ctor_release(x_7, 1);
 x_12 = x_7;
} else {
 lean_dec_ref(x_7);
 x_12 = lean_box(0);
}
x_13 = l_Lean_Expr_isApp(x_10);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; 
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
if (lean_is_scalar(x_12)) {
 x_14 = lean_alloc_ctor(0, 2, 0);
} else {
 x_14 = x_12;
}
lean_ctor_set(x_14, 0, x_10);
lean_ctor_set(x_14, 1, x_11);
if (lean_is_scalar(x_9)) {
 x_15 = lean_alloc_ctor(0, 2, 0);
} else {
 x_15 = x_9;
}
lean_ctor_set(x_15, 0, x_8);
lean_ctor_set(x_15, 1, x_14);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_6);
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; 
x_17 = l_Lean_Expr_appFn_x21(x_10);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
x_18 = lean_infer_type(x_17, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_29; uint8_t x_30; 
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
x_20 = lean_ctor_get(x_18, 1);
lean_inc(x_20);
lean_dec(x_18);
x_29 = l_Lean_Expr_bindingInfo_x21(x_19);
lean_dec(x_19);
x_30 = l_Lean_BinderInfo_isExplicit(x_29);
if (x_30 == 0)
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_box(x_30);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_11);
x_21 = x_8;
x_22 = x_10;
x_23 = x_32;
goto block_28;
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_33 = lean_box(x_30);
x_34 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_34, 0, x_33);
lean_ctor_set(x_34, 1, x_11);
x_35 = lean_unsigned_to_nat(1u);
x_36 = lean_nat_add(x_8, x_35);
lean_dec(x_8);
x_21 = x_36;
x_22 = x_10;
x_23 = x_34;
goto block_28;
}
block_28:
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_24 = l_Lean_Expr_appFn_x21(x_22);
lean_dec(x_22);
if (lean_is_scalar(x_12)) {
 x_25 = lean_alloc_ctor(0, 2, 0);
} else {
 x_25 = x_12;
}
lean_ctor_set(x_25, 0, x_24);
lean_ctor_set(x_25, 1, x_23);
if (lean_is_scalar(x_9)) {
 x_26 = lean_alloc_ctor(0, 2, 0);
} else {
 x_26 = x_9;
}
lean_ctor_set(x_26, 0, x_21);
lean_ctor_set(x_26, 1, x_25);
x_1 = x_26;
x_6 = x_20;
goto _start;
}
}
else
{
uint8_t x_37; 
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_37 = !lean_is_exclusive(x_18);
if (x_37 == 0)
{
return x_18;
}
else
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; 
x_38 = lean_ctor_get(x_18, 0);
x_39 = lean_ctor_get(x_18, 1);
lean_inc(x_39);
lean_inc(x_38);
lean_dec(x_18);
x_40 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_40, 0, x_38);
lean_ctor_set(x_40, 1, x_39);
return x_40;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; uint8_t x_29; 
x_15 = lean_ctor_get(x_3, 1);
lean_inc(x_15);
x_16 = lean_ctor_get(x_3, 0);
lean_inc(x_16);
if (lean_is_exclusive(x_3)) {
 lean_ctor_release(x_3, 0);
 lean_ctor_release(x_3, 1);
 x_17 = x_3;
} else {
 lean_dec_ref(x_3);
 x_17 = lean_box(0);
}
x_18 = lean_ctor_get(x_15, 0);
lean_inc(x_18);
x_19 = lean_ctor_get(x_15, 1);
lean_inc(x_19);
if (lean_is_exclusive(x_15)) {
 lean_ctor_release(x_15, 0);
 lean_ctor_release(x_15, 1);
 x_20 = x_15;
} else {
 lean_dec_ref(x_15);
 x_20 = lean_box(0);
}
x_29 = l_List_isEmpty___redArg(x_19);
if (x_29 == 0)
{
lean_object* x_30; uint8_t x_31; 
lean_inc(x_1);
x_30 = l_List_head_x21___redArg(x_1, x_19);
x_31 = lean_nat_dec_eq(x_30, x_2);
lean_dec(x_30);
if (x_31 == 0)
{
lean_dec(x_1);
goto block_28;
}
else
{
lean_object* x_32; lean_object* x_33; uint8_t x_34; 
lean_dec(x_20);
lean_dec(x_17);
x_32 = lean_box(x_29);
x_33 = l_List_head_x21___redArg(x_32, x_18);
x_34 = lean_unbox(x_33);
lean_dec(x_33);
if (x_34 == 0)
{
x_21 = x_29;
goto block_24;
}
else
{
x_21 = x_31;
goto block_24;
}
}
}
else
{
lean_dec(x_1);
goto block_28;
}
block_14:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_9 = l_List_tail_x21___redArg(x_6);
lean_dec(x_6);
x_10 = l_List_tail_x21___redArg(x_7);
lean_dec(x_7);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_9);
lean_ctor_set(x_11, 1, x_10);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_5);
lean_ctor_set(x_12, 1, x_11);
x_3 = x_12;
x_4 = x_8;
goto _start;
}
block_24:
{
if (x_21 == 0)
{
x_5 = x_16;
x_6 = x_18;
x_7 = x_19;
x_8 = x_4;
goto block_14;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_unsigned_to_nat(1u);
x_23 = lean_nat_sub(x_16, x_22);
lean_dec(x_16);
x_5 = x_23;
x_6 = x_18;
x_7 = x_19;
x_8 = x_4;
goto block_14;
}
}
block_28:
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; 
if (lean_is_scalar(x_20)) {
 x_25 = lean_alloc_ctor(0, 2, 0);
} else {
 x_25 = x_20;
}
lean_ctor_set(x_25, 0, x_18);
lean_ctor_set(x_25, 1, x_19);
if (lean_is_scalar(x_17)) {
 x_26 = lean_alloc_ctor(0, 2, 0);
} else {
 x_26 = x_17;
}
lean_ctor_set(x_26, 0, x_16);
lean_ctor_set(x_26, 1, x_25);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_26);
lean_ctor_set(x_27, 1, x_4);
return x_27;
}
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_1, x_2, x_3, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_2);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_5 = lean_ctor_get(x_2, 0);
x_6 = lean_ctor_get(x_2, 1);
x_7 = lean_nat_dec_lt(x_1, x_5);
if (x_7 == 0)
{
lean_object* x_8; 
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_2);
lean_ctor_set(x_8, 1, x_3);
return x_8;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_9 = l_Lean_Expr_appFn_x21(x_6);
lean_dec(x_6);
x_10 = lean_unsigned_to_nat(1u);
x_11 = lean_nat_sub(x_5, x_10);
lean_dec(x_5);
lean_ctor_set(x_2, 1, x_9);
lean_ctor_set(x_2, 0, x_11);
goto _start;
}
}
else
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_2, 0);
x_14 = lean_ctor_get(x_2, 1);
lean_inc(x_14);
lean_inc(x_13);
lean_dec(x_2);
x_15 = lean_nat_dec_lt(x_1, x_13);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_13);
lean_ctor_set(x_16, 1, x_14);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_3);
return x_17;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_18 = l_Lean_Expr_appFn_x21(x_14);
lean_dec(x_14);
x_19 = lean_unsigned_to_nat(1u);
x_20 = lean_nat_sub(x_13, x_19);
lean_dec(x_13);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_18);
x_2 = x_21;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_1, x_2, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_panic___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__3(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; 
x_2 = lean_box(0);
x_3 = lean_panic_fn(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Bad coordinate ", 15, 15);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" for ", 5, 5);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("", 0, 0);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Can't viewRaw the type of ", 26, 26);
return x_1;
}
}
static lean_object* _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__6;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_23; 
switch (lean_obj_tag(x_1)) {
case 5:
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; uint8_t x_34; 
x_31 = lean_ctor_get(x_1, 0);
lean_inc(x_31);
x_32 = lean_ctor_get(x_1, 1);
lean_inc(x_32);
x_33 = lean_unsigned_to_nat(3u);
x_34 = lean_nat_dec_eq(x_2, x_33);
if (x_34 == 0)
{
lean_object* x_35; uint8_t x_36; 
x_35 = lean_unsigned_to_nat(0u);
x_36 = lean_nat_dec_eq(x_2, x_35);
if (x_36 == 0)
{
lean_object* x_37; uint8_t x_38; 
lean_dec(x_31);
x_37 = lean_unsigned_to_nat(1u);
x_38 = lean_nat_dec_eq(x_2, x_37);
if (x_38 == 0)
{
lean_dec(x_32);
x_8 = x_1;
x_9 = x_2;
goto block_22;
}
else
{
lean_object* x_39; 
lean_dec(x_2);
lean_dec(x_1);
x_39 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_39, 0, x_32);
lean_ctor_set(x_39, 1, x_7);
return x_39;
}
}
else
{
lean_object* x_40; 
lean_dec(x_32);
lean_dec(x_2);
lean_dec(x_1);
x_40 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_40, 0, x_31);
lean_ctor_set(x_40, 1, x_7);
return x_40;
}
}
else
{
lean_dec(x_32);
lean_dec(x_31);
lean_dec(x_2);
x_23 = x_1;
goto block_30;
}
}
case 6:
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; uint8_t x_44; 
x_41 = lean_ctor_get(x_1, 1);
lean_inc(x_41);
x_42 = lean_ctor_get(x_1, 2);
lean_inc(x_42);
x_43 = lean_unsigned_to_nat(3u);
x_44 = lean_nat_dec_eq(x_2, x_43);
if (x_44 == 0)
{
lean_object* x_45; uint8_t x_46; 
x_45 = lean_unsigned_to_nat(0u);
x_46 = lean_nat_dec_eq(x_2, x_45);
if (x_46 == 0)
{
lean_object* x_47; uint8_t x_48; 
lean_dec(x_41);
x_47 = lean_unsigned_to_nat(1u);
x_48 = lean_nat_dec_eq(x_2, x_47);
if (x_48 == 0)
{
lean_dec(x_42);
x_8 = x_1;
x_9 = x_2;
goto block_22;
}
else
{
lean_object* x_49; 
lean_dec(x_2);
lean_dec(x_1);
x_49 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_49, 0, x_42);
lean_ctor_set(x_49, 1, x_7);
return x_49;
}
}
else
{
lean_object* x_50; 
lean_dec(x_42);
lean_dec(x_2);
lean_dec(x_1);
x_50 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_50, 0, x_41);
lean_ctor_set(x_50, 1, x_7);
return x_50;
}
}
else
{
lean_dec(x_42);
lean_dec(x_41);
lean_dec(x_2);
x_23 = x_1;
goto block_30;
}
}
case 7:
{
lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; 
x_51 = lean_ctor_get(x_1, 1);
lean_inc(x_51);
x_52 = lean_ctor_get(x_1, 2);
lean_inc(x_52);
x_53 = lean_unsigned_to_nat(3u);
x_54 = lean_nat_dec_eq(x_2, x_53);
if (x_54 == 0)
{
lean_object* x_55; uint8_t x_56; 
x_55 = lean_unsigned_to_nat(0u);
x_56 = lean_nat_dec_eq(x_2, x_55);
if (x_56 == 0)
{
lean_object* x_57; uint8_t x_58; 
lean_dec(x_51);
x_57 = lean_unsigned_to_nat(1u);
x_58 = lean_nat_dec_eq(x_2, x_57);
if (x_58 == 0)
{
lean_dec(x_52);
x_8 = x_1;
x_9 = x_2;
goto block_22;
}
else
{
lean_object* x_59; 
lean_dec(x_2);
lean_dec(x_1);
x_59 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_59, 0, x_52);
lean_ctor_set(x_59, 1, x_7);
return x_59;
}
}
else
{
lean_object* x_60; 
lean_dec(x_52);
lean_dec(x_2);
lean_dec(x_1);
x_60 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_60, 0, x_51);
lean_ctor_set(x_60, 1, x_7);
return x_60;
}
}
else
{
lean_dec(x_52);
lean_dec(x_51);
lean_dec(x_2);
x_23 = x_1;
goto block_30;
}
}
case 8:
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; uint8_t x_65; 
x_61 = lean_ctor_get(x_1, 1);
lean_inc(x_61);
x_62 = lean_ctor_get(x_1, 2);
lean_inc(x_62);
x_63 = lean_ctor_get(x_1, 3);
lean_inc(x_63);
x_64 = lean_unsigned_to_nat(3u);
x_65 = lean_nat_dec_eq(x_2, x_64);
if (x_65 == 0)
{
lean_object* x_66; uint8_t x_67; 
x_66 = lean_unsigned_to_nat(0u);
x_67 = lean_nat_dec_eq(x_2, x_66);
if (x_67 == 0)
{
lean_object* x_68; uint8_t x_69; 
lean_dec(x_61);
x_68 = lean_unsigned_to_nat(1u);
x_69 = lean_nat_dec_eq(x_2, x_68);
if (x_69 == 0)
{
lean_object* x_70; uint8_t x_71; 
lean_dec(x_62);
x_70 = lean_unsigned_to_nat(2u);
x_71 = lean_nat_dec_eq(x_2, x_70);
if (x_71 == 0)
{
lean_dec(x_63);
x_8 = x_1;
x_9 = x_2;
goto block_22;
}
else
{
lean_object* x_72; 
lean_dec(x_2);
lean_dec(x_1);
x_72 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_72, 0, x_63);
lean_ctor_set(x_72, 1, x_7);
return x_72;
}
}
else
{
lean_object* x_73; 
lean_dec(x_63);
lean_dec(x_2);
lean_dec(x_1);
x_73 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_73, 0, x_62);
lean_ctor_set(x_73, 1, x_7);
return x_73;
}
}
else
{
lean_object* x_74; 
lean_dec(x_63);
lean_dec(x_62);
lean_dec(x_2);
lean_dec(x_1);
x_74 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_74, 0, x_61);
lean_ctor_set(x_74, 1, x_7);
return x_74;
}
}
else
{
lean_dec(x_63);
lean_dec(x_62);
lean_dec(x_61);
lean_dec(x_2);
x_23 = x_1;
goto block_30;
}
}
case 10:
{
lean_object* x_75; lean_object* x_76; uint8_t x_77; 
x_75 = lean_ctor_get(x_1, 1);
lean_inc(x_75);
x_76 = lean_unsigned_to_nat(3u);
x_77 = lean_nat_dec_eq(x_2, x_76);
if (x_77 == 0)
{
lean_dec(x_1);
x_1 = x_75;
goto _start;
}
else
{
lean_dec(x_75);
lean_dec(x_2);
x_23 = x_1;
goto block_30;
}
}
case 11:
{
lean_object* x_79; lean_object* x_80; uint8_t x_81; 
x_79 = lean_ctor_get(x_1, 2);
lean_inc(x_79);
x_80 = lean_unsigned_to_nat(3u);
x_81 = lean_nat_dec_eq(x_2, x_80);
if (x_81 == 0)
{
lean_object* x_82; uint8_t x_83; 
x_82 = lean_unsigned_to_nat(0u);
x_83 = lean_nat_dec_eq(x_2, x_82);
if (x_83 == 0)
{
lean_dec(x_79);
x_8 = x_1;
x_9 = x_2;
goto block_22;
}
else
{
lean_object* x_84; 
lean_dec(x_2);
lean_dec(x_1);
x_84 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_84, 0, x_79);
lean_ctor_set(x_84, 1, x_7);
return x_84;
}
}
else
{
lean_dec(x_79);
lean_dec(x_2);
x_23 = x_1;
goto block_30;
}
}
default: 
{
lean_object* x_85; uint8_t x_86; 
x_85 = lean_unsigned_to_nat(3u);
x_86 = lean_nat_dec_eq(x_2, x_85);
if (x_86 == 0)
{
x_8 = x_1;
x_9 = x_2;
goto block_22;
}
else
{
lean_dec(x_2);
x_23 = x_1;
goto block_30;
}
}
}
block_22:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_10 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1;
x_11 = l_Nat_reprFast(x_9);
x_12 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_12, 0, x_11);
x_13 = l_Lean_MessageData_ofFormat(x_12);
x_14 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_14, 0, x_10);
lean_ctor_set(x_14, 1, x_13);
x_15 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3;
x_16 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_16, 0, x_14);
lean_ctor_set(x_16, 1, x_15);
x_17 = l_Lean_MessageData_ofExpr(x_8);
x_18 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_18, 0, x_16);
lean_ctor_set(x_18, 1, x_17);
x_19 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5;
x_20 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_20, 0, x_18);
lean_ctor_set(x_20, 1, x_19);
x_21 = l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(x_20, x_3, x_4, x_5, x_6, x_7);
return x_21;
}
block_30:
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_24 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__7;
x_25 = l_Lean_MessageData_ofExpr(x_23);
x_26 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_26, 0, x_24);
lean_ctor_set(x_26, 1, x_25);
x_27 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5;
x_28 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_28, 0, x_26);
lean_ctor_set(x_28, 1, x_27);
x_29 = l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(x_28, x_3, x_4, x_5, x_6, x_7);
return x_29;
}
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint8_t x_9; 
x_9 = l_Lean_SubExpr_Pos_isRoot(x_3);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; 
x_10 = l_Lean_SubExpr_Pos_tail(x_3);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_1);
x_11 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(x_1, x_2, x_10, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_10);
if (lean_obj_tag(x_11) == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_12 = lean_ctor_get(x_11, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_11, 1);
lean_inc(x_13);
lean_dec(x_11);
x_14 = l_Lean_SubExpr_Pos_head(x_3);
x_15 = lean_apply_7(x_1, x_12, x_14, x_4, x_5, x_6, x_7, x_13);
return x_15;
}
else
{
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
return x_11;
}
}
else
{
lean_object* x_16; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_2);
lean_ctor_set(x_16, 1, x_8);
return x_16;
}
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_alloc_closure((void*)(l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0___boxed), 7, 0);
x_9 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(x_8, x_2, x_1, x_3, x_4, x_5, x_6, x_7);
return x_9;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets.Demos.SelectInsertConv", 35, 35);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("_private.ProofWidgets.Demos.SelectInsertConv.0.solveLevel", 57, 57);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("no name found", 13, 13);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2;
x_2 = lean_unsigned_to_nat(13u);
x_3 = lean_unsigned_to_nat(67u);
x_4 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1;
x_5 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0;
x_6 = l_mkPanicMessageWithDecl(x_5, x_4, x_3, x_2, x_1);
return x_6;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2;
x_2 = lean_unsigned_to_nat(13u);
x_3 = lean_unsigned_to_nat(73u);
x_4 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1;
x_5 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0;
x_6 = l_mkPanicMessageWithDecl(x_5, x_4, x_3, x_2, x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = lean_box(0);
switch (lean_obj_tag(x_1)) {
case 5:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_9 = lean_unsigned_to_nat(0u);
x_10 = lean_box(0);
lean_inc(x_1);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_1);
lean_ctor_set(x_11, 1, x_10);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_9);
lean_ctor_set(x_12, 1, x_11);
x_13 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__0(x_12, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_13) == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_14 = lean_ctor_get(x_13, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_14, 1);
lean_inc(x_15);
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_16);
lean_dec(x_13);
x_17 = !lean_is_exclusive(x_14);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_18 = lean_ctor_get(x_14, 0);
x_19 = lean_ctor_get(x_14, 1);
lean_dec(x_19);
x_20 = !lean_is_exclusive(x_15);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; uint8_t x_29; 
x_21 = lean_ctor_get(x_15, 1);
x_22 = lean_ctor_get(x_15, 0);
lean_dec(x_22);
x_23 = l_List_reverse___redArg(x_21);
lean_ctor_set(x_15, 1, x_2);
lean_ctor_set(x_15, 0, x_23);
lean_inc(x_18);
x_24 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_8, x_9, x_14, x_16);
x_25 = lean_ctor_get(x_24, 0);
lean_inc(x_25);
x_26 = lean_ctor_get(x_25, 1);
lean_inc(x_26);
x_27 = lean_ctor_get(x_24, 1);
lean_inc(x_27);
lean_dec(x_24);
x_28 = lean_ctor_get(x_25, 0);
lean_inc(x_28);
lean_dec(x_25);
x_29 = !lean_is_exclusive(x_26);
if (x_29 == 0)
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; uint8_t x_44; 
x_30 = lean_ctor_get(x_26, 1);
x_31 = lean_ctor_get(x_26, 0);
lean_dec(x_31);
lean_ctor_set(x_26, 1, x_1);
lean_ctor_set(x_26, 0, x_18);
x_32 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_28, x_26, x_27);
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
x_34 = lean_ctor_get(x_32, 1);
lean_inc(x_34);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 lean_ctor_release(x_32, 1);
 x_35 = x_32;
} else {
 lean_dec_ref(x_32);
 x_35 = lean_box(0);
}
x_36 = lean_ctor_get(x_33, 1);
lean_inc(x_36);
lean_dec(x_33);
x_37 = l_Lean_Expr_appArg_x21(x_36);
lean_dec(x_36);
x_44 = l_List_isEmpty___redArg(x_30);
if (x_44 == 0)
{
lean_object* x_45; 
x_45 = l_List_tail_x21___redArg(x_30);
lean_dec(x_30);
x_38 = x_45;
goto block_43;
}
else
{
lean_object* x_46; 
lean_dec(x_30);
x_46 = lean_box(0);
x_38 = x_46;
goto block_43;
}
block_43:
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_39 = l_Nat_reprFast(x_28);
x_40 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_40, 0, x_39);
x_41 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_41, 0, x_37);
lean_ctor_set(x_41, 1, x_40);
lean_ctor_set(x_41, 2, x_38);
if (lean_is_scalar(x_35)) {
 x_42 = lean_alloc_ctor(0, 2, 0);
} else {
 x_42 = x_35;
}
lean_ctor_set(x_42, 0, x_41);
lean_ctor_set(x_42, 1, x_34);
return x_42;
}
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; uint8_t x_61; 
x_47 = lean_ctor_get(x_26, 1);
lean_inc(x_47);
lean_dec(x_26);
x_48 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_48, 0, x_18);
lean_ctor_set(x_48, 1, x_1);
x_49 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_28, x_48, x_27);
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
x_51 = lean_ctor_get(x_49, 1);
lean_inc(x_51);
if (lean_is_exclusive(x_49)) {
 lean_ctor_release(x_49, 0);
 lean_ctor_release(x_49, 1);
 x_52 = x_49;
} else {
 lean_dec_ref(x_49);
 x_52 = lean_box(0);
}
x_53 = lean_ctor_get(x_50, 1);
lean_inc(x_53);
lean_dec(x_50);
x_54 = l_Lean_Expr_appArg_x21(x_53);
lean_dec(x_53);
x_61 = l_List_isEmpty___redArg(x_47);
if (x_61 == 0)
{
lean_object* x_62; 
x_62 = l_List_tail_x21___redArg(x_47);
lean_dec(x_47);
x_55 = x_62;
goto block_60;
}
else
{
lean_object* x_63; 
lean_dec(x_47);
x_63 = lean_box(0);
x_55 = x_63;
goto block_60;
}
block_60:
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_56 = l_Nat_reprFast(x_28);
x_57 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_57, 0, x_56);
x_58 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_58, 0, x_54);
lean_ctor_set(x_58, 1, x_57);
lean_ctor_set(x_58, 2, x_55);
if (lean_is_scalar(x_52)) {
 x_59 = lean_alloc_ctor(0, 2, 0);
} else {
 x_59 = x_52;
}
lean_ctor_set(x_59, 0, x_58);
lean_ctor_set(x_59, 1, x_51);
return x_59;
}
}
}
else
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; uint8_t x_87; 
x_64 = lean_ctor_get(x_15, 1);
lean_inc(x_64);
lean_dec(x_15);
x_65 = l_List_reverse___redArg(x_64);
x_66 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_66, 0, x_65);
lean_ctor_set(x_66, 1, x_2);
lean_inc(x_18);
lean_ctor_set(x_14, 1, x_66);
x_67 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_8, x_9, x_14, x_16);
x_68 = lean_ctor_get(x_67, 0);
lean_inc(x_68);
x_69 = lean_ctor_get(x_68, 1);
lean_inc(x_69);
x_70 = lean_ctor_get(x_67, 1);
lean_inc(x_70);
lean_dec(x_67);
x_71 = lean_ctor_get(x_68, 0);
lean_inc(x_71);
lean_dec(x_68);
x_72 = lean_ctor_get(x_69, 1);
lean_inc(x_72);
if (lean_is_exclusive(x_69)) {
 lean_ctor_release(x_69, 0);
 lean_ctor_release(x_69, 1);
 x_73 = x_69;
} else {
 lean_dec_ref(x_69);
 x_73 = lean_box(0);
}
if (lean_is_scalar(x_73)) {
 x_74 = lean_alloc_ctor(0, 2, 0);
} else {
 x_74 = x_73;
}
lean_ctor_set(x_74, 0, x_18);
lean_ctor_set(x_74, 1, x_1);
x_75 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_71, x_74, x_70);
x_76 = lean_ctor_get(x_75, 0);
lean_inc(x_76);
x_77 = lean_ctor_get(x_75, 1);
lean_inc(x_77);
if (lean_is_exclusive(x_75)) {
 lean_ctor_release(x_75, 0);
 lean_ctor_release(x_75, 1);
 x_78 = x_75;
} else {
 lean_dec_ref(x_75);
 x_78 = lean_box(0);
}
x_79 = lean_ctor_get(x_76, 1);
lean_inc(x_79);
lean_dec(x_76);
x_80 = l_Lean_Expr_appArg_x21(x_79);
lean_dec(x_79);
x_87 = l_List_isEmpty___redArg(x_72);
if (x_87 == 0)
{
lean_object* x_88; 
x_88 = l_List_tail_x21___redArg(x_72);
lean_dec(x_72);
x_81 = x_88;
goto block_86;
}
else
{
lean_object* x_89; 
lean_dec(x_72);
x_89 = lean_box(0);
x_81 = x_89;
goto block_86;
}
block_86:
{
lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; 
x_82 = l_Nat_reprFast(x_71);
x_83 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_83, 0, x_82);
x_84 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_84, 0, x_80);
lean_ctor_set(x_84, 1, x_83);
lean_ctor_set(x_84, 2, x_81);
if (lean_is_scalar(x_78)) {
 x_85 = lean_alloc_ctor(0, 2, 0);
} else {
 x_85 = x_78;
}
lean_ctor_set(x_85, 0, x_84);
lean_ctor_set(x_85, 1, x_77);
return x_85;
}
}
}
else
{
lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; uint8_t x_116; 
x_90 = lean_ctor_get(x_14, 0);
lean_inc(x_90);
lean_dec(x_14);
x_91 = lean_ctor_get(x_15, 1);
lean_inc(x_91);
if (lean_is_exclusive(x_15)) {
 lean_ctor_release(x_15, 0);
 lean_ctor_release(x_15, 1);
 x_92 = x_15;
} else {
 lean_dec_ref(x_15);
 x_92 = lean_box(0);
}
x_93 = l_List_reverse___redArg(x_91);
if (lean_is_scalar(x_92)) {
 x_94 = lean_alloc_ctor(0, 2, 0);
} else {
 x_94 = x_92;
}
lean_ctor_set(x_94, 0, x_93);
lean_ctor_set(x_94, 1, x_2);
lean_inc(x_90);
x_95 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_95, 0, x_90);
lean_ctor_set(x_95, 1, x_94);
x_96 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_8, x_9, x_95, x_16);
x_97 = lean_ctor_get(x_96, 0);
lean_inc(x_97);
x_98 = lean_ctor_get(x_97, 1);
lean_inc(x_98);
x_99 = lean_ctor_get(x_96, 1);
lean_inc(x_99);
lean_dec(x_96);
x_100 = lean_ctor_get(x_97, 0);
lean_inc(x_100);
lean_dec(x_97);
x_101 = lean_ctor_get(x_98, 1);
lean_inc(x_101);
if (lean_is_exclusive(x_98)) {
 lean_ctor_release(x_98, 0);
 lean_ctor_release(x_98, 1);
 x_102 = x_98;
} else {
 lean_dec_ref(x_98);
 x_102 = lean_box(0);
}
if (lean_is_scalar(x_102)) {
 x_103 = lean_alloc_ctor(0, 2, 0);
} else {
 x_103 = x_102;
}
lean_ctor_set(x_103, 0, x_90);
lean_ctor_set(x_103, 1, x_1);
x_104 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_100, x_103, x_99);
x_105 = lean_ctor_get(x_104, 0);
lean_inc(x_105);
x_106 = lean_ctor_get(x_104, 1);
lean_inc(x_106);
if (lean_is_exclusive(x_104)) {
 lean_ctor_release(x_104, 0);
 lean_ctor_release(x_104, 1);
 x_107 = x_104;
} else {
 lean_dec_ref(x_104);
 x_107 = lean_box(0);
}
x_108 = lean_ctor_get(x_105, 1);
lean_inc(x_108);
lean_dec(x_105);
x_109 = l_Lean_Expr_appArg_x21(x_108);
lean_dec(x_108);
x_116 = l_List_isEmpty___redArg(x_101);
if (x_116 == 0)
{
lean_object* x_117; 
x_117 = l_List_tail_x21___redArg(x_101);
lean_dec(x_101);
x_110 = x_117;
goto block_115;
}
else
{
lean_object* x_118; 
lean_dec(x_101);
x_118 = lean_box(0);
x_110 = x_118;
goto block_115;
}
block_115:
{
lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; 
x_111 = l_Nat_reprFast(x_100);
x_112 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_112, 0, x_111);
x_113 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_113, 0, x_109);
lean_ctor_set(x_113, 1, x_112);
lean_ctor_set(x_113, 2, x_110);
if (lean_is_scalar(x_107)) {
 x_114 = lean_alloc_ctor(0, 2, 0);
} else {
 x_114 = x_107;
}
lean_ctor_set(x_114, 0, x_113);
lean_ctor_set(x_114, 1, x_106);
return x_114;
}
}
}
else
{
uint8_t x_119; 
lean_dec(x_2);
lean_dec(x_1);
x_119 = !lean_is_exclusive(x_13);
if (x_119 == 0)
{
return x_13;
}
else
{
lean_object* x_120; lean_object* x_121; lean_object* x_122; 
x_120 = lean_ctor_get(x_13, 0);
x_121 = lean_ctor_get(x_13, 1);
lean_inc(x_121);
lean_inc(x_120);
lean_dec(x_13);
x_122 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_122, 0, x_120);
lean_ctor_set(x_122, 1, x_121);
return x_122;
}
}
}
case 6:
{
lean_object* x_123; lean_object* x_124; lean_object* x_125; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
x_123 = lean_ctor_get(x_1, 0);
lean_inc(x_123);
x_124 = lean_ctor_get(x_1, 2);
lean_inc(x_124);
lean_dec(x_1);
if (lean_obj_tag(x_123) == 1)
{
lean_object* x_130; lean_object* x_131; 
x_130 = lean_ctor_get(x_123, 1);
lean_inc(x_130);
lean_dec(x_123);
x_131 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_131, 0, x_130);
x_125 = x_131;
goto block_129;
}
else
{
lean_object* x_132; lean_object* x_133; 
lean_dec(x_123);
x_132 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3;
x_133 = l_panic___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__3(x_132);
x_125 = x_133;
goto block_129;
}
block_129:
{
lean_object* x_126; lean_object* x_127; lean_object* x_128; 
x_126 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_127 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_127, 0, x_124);
lean_ctor_set(x_127, 1, x_125);
lean_ctor_set(x_127, 2, x_126);
x_128 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_128, 0, x_127);
lean_ctor_set(x_128, 1, x_7);
return x_128;
}
}
case 7:
{
lean_object* x_134; lean_object* x_135; lean_object* x_136; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
x_134 = lean_ctor_get(x_1, 0);
lean_inc(x_134);
x_135 = lean_ctor_get(x_1, 2);
lean_inc(x_135);
lean_dec(x_1);
if (lean_obj_tag(x_134) == 1)
{
lean_object* x_141; lean_object* x_142; 
x_141 = lean_ctor_get(x_134, 1);
lean_inc(x_141);
lean_dec(x_134);
x_142 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_142, 0, x_141);
x_136 = x_142;
goto block_140;
}
else
{
lean_object* x_143; lean_object* x_144; 
lean_dec(x_134);
x_143 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4;
x_144 = l_panic___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__3(x_143);
x_136 = x_144;
goto block_140;
}
block_140:
{
lean_object* x_137; lean_object* x_138; lean_object* x_139; 
x_137 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_138 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_138, 0, x_135);
lean_ctor_set(x_138, 1, x_136);
lean_ctor_set(x_138, 2, x_137);
x_139 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_139, 0, x_138);
lean_ctor_set(x_139, 1, x_7);
return x_139;
}
}
case 10:
{
lean_object* x_145; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
x_145 = lean_ctor_get(x_1, 1);
lean_inc(x_145);
lean_dec(x_1);
if (lean_obj_tag(x_145) == 10)
{
lean_object* x_146; lean_object* x_147; lean_object* x_148; 
x_146 = lean_box(0);
x_147 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_147, 0, x_145);
lean_ctor_set(x_147, 1, x_146);
lean_ctor_set(x_147, 2, x_2);
x_148 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_148, 0, x_147);
lean_ctor_set(x_148, 1, x_7);
return x_148;
}
else
{
lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; 
x_149 = l_Lean_Expr_appFn_x21(x_145);
lean_dec(x_145);
x_150 = l_Lean_Expr_appArg_x21(x_149);
lean_dec(x_149);
x_151 = lean_box(0);
x_152 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_153 = l_List_tail_x21___redArg(x_152);
lean_dec(x_152);
x_154 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_154, 0, x_150);
lean_ctor_set(x_154, 1, x_151);
lean_ctor_set(x_154, 2, x_153);
x_155 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_155, 0, x_154);
lean_ctor_set(x_155, 1, x_7);
return x_155;
}
}
default: 
{
lean_object* x_156; lean_object* x_157; 
x_156 = l_List_head_x21___redArg(x_8, x_2);
x_157 = l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4(x_156, x_1, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_157) == 0)
{
uint8_t x_158; 
x_158 = !lean_is_exclusive(x_157);
if (x_158 == 0)
{
lean_object* x_159; lean_object* x_160; lean_object* x_161; lean_object* x_162; lean_object* x_163; lean_object* x_164; lean_object* x_165; 
x_159 = lean_ctor_get(x_157, 0);
x_160 = lean_unsigned_to_nat(1u);
x_161 = lean_nat_add(x_156, x_160);
lean_dec(x_156);
x_162 = l_Nat_reprFast(x_161);
x_163 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_163, 0, x_162);
x_164 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_165 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_165, 0, x_159);
lean_ctor_set(x_165, 1, x_163);
lean_ctor_set(x_165, 2, x_164);
lean_ctor_set(x_157, 0, x_165);
return x_157;
}
else
{
lean_object* x_166; lean_object* x_167; lean_object* x_168; lean_object* x_169; lean_object* x_170; lean_object* x_171; lean_object* x_172; lean_object* x_173; lean_object* x_174; 
x_166 = lean_ctor_get(x_157, 0);
x_167 = lean_ctor_get(x_157, 1);
lean_inc(x_167);
lean_inc(x_166);
lean_dec(x_157);
x_168 = lean_unsigned_to_nat(1u);
x_169 = lean_nat_add(x_156, x_168);
lean_dec(x_156);
x_170 = l_Nat_reprFast(x_169);
x_171 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_171, 0, x_170);
x_172 = l_List_tail_x21___redArg(x_2);
lean_dec(x_2);
x_173 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_173, 0, x_166);
lean_ctor_set(x_173, 1, x_171);
lean_ctor_set(x_173, 2, x_172);
x_174 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_174, 0, x_173);
lean_ctor_set(x_174, 1, x_167);
return x_174;
}
}
else
{
uint8_t x_175; 
lean_dec(x_156);
lean_dec(x_2);
x_175 = !lean_is_exclusive(x_157);
if (x_175 == 0)
{
return x_157;
}
else
{
lean_object* x_176; lean_object* x_177; lean_object* x_178; 
x_176 = lean_ctor_get(x_157, 0);
x_177 = lean_ctor_get(x_157, 1);
lean_inc(x_177);
lean_inc(x_176);
lean_dec(x_157);
x_178 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_178, 0, x_176);
lean_ctor_set(x_178, 1, x_177);
return x_178;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___redArg(x_1, x_2, x_3, x_4);
lean_dec(x_2);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___redArg(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_Loop_forIn_loop___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__2(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_3);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Lean_SubExpr_Pos_foldlM___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__5(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_5);
lean_dec(x_2);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at___insertEnter_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
x_7 = lean_ctor_get(x_1, 1);
lean_inc(x_7);
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
if (lean_is_exclusive(x_1)) {
 lean_ctor_release(x_1, 0);
 lean_ctor_release(x_1, 1);
 x_9 = x_1;
} else {
 lean_dec_ref(x_1);
 x_9 = lean_box(0);
}
x_10 = lean_ctor_get(x_7, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_7, 1);
lean_inc(x_11);
if (lean_is_exclusive(x_7)) {
 lean_ctor_release(x_7, 0);
 lean_ctor_release(x_7, 1);
 x_12 = x_7;
} else {
 lean_dec_ref(x_7);
 x_12 = lean_box(0);
}
x_13 = l_List_isEmpty___redArg(x_10);
if (x_13 == 0)
{
lean_object* x_14; 
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
x_14 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel(x_8, x_10, x_2, x_3, x_4, x_5, x_6);
if (lean_obj_tag(x_14) == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
x_16 = lean_ctor_get(x_14, 1);
lean_inc(x_16);
lean_dec(x_14);
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_15, 1);
lean_inc(x_18);
x_19 = lean_ctor_get(x_15, 2);
lean_inc(x_19);
lean_dec(x_15);
if (lean_obj_tag(x_18) == 0)
{
x_20 = x_11;
goto block_24;
}
else
{
lean_object* x_25; lean_object* x_26; 
x_25 = lean_ctor_get(x_18, 0);
lean_inc(x_25);
lean_dec(x_18);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_25);
lean_ctor_set(x_26, 1, x_11);
x_20 = x_26;
goto block_24;
}
block_24:
{
lean_object* x_21; lean_object* x_22; 
if (lean_is_scalar(x_12)) {
 x_21 = lean_alloc_ctor(0, 2, 0);
} else {
 x_21 = x_12;
}
lean_ctor_set(x_21, 0, x_19);
lean_ctor_set(x_21, 1, x_20);
if (lean_is_scalar(x_9)) {
 x_22 = lean_alloc_ctor(0, 2, 0);
} else {
 x_22 = x_9;
}
lean_ctor_set(x_22, 0, x_17);
lean_ctor_set(x_22, 1, x_21);
x_1 = x_22;
x_6 = x_16;
goto _start;
}
}
else
{
uint8_t x_27; 
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_9);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_27 = !lean_is_exclusive(x_14);
if (x_27 == 0)
{
return x_14;
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_28 = lean_ctor_get(x_14, 0);
x_29 = lean_ctor_get(x_14, 1);
lean_inc(x_29);
lean_inc(x_28);
lean_dec(x_14);
x_30 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_30, 0, x_28);
lean_ctor_set(x_30, 1, x_29);
return x_30;
}
}
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; 
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
if (lean_is_scalar(x_12)) {
 x_31 = lean_alloc_ctor(0, 2, 0);
} else {
 x_31 = x_12;
}
lean_ctor_set(x_31, 0, x_10);
lean_ctor_set(x_31, 1, x_11);
if (lean_is_scalar(x_9)) {
 x_32 = lean_alloc_ctor(0, 2, 0);
} else {
 x_32 = x_9;
}
lean_ctor_set(x_32, 0, x_8);
lean_ctor_set(x_32, 1, x_31);
x_33 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_33, 0, x_32);
lean_ctor_set(x_33, 1, x_6);
return x_33;
}
}
}
static lean_object* _init_l_insertEnter___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("You must select something.", 26, 26);
return x_1;
}
}
static lean_object* _init_l_insertEnter___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_insertEnter___closed__0;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_insertEnter___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("conv => enter ", 14, 14);
return x_1;
}
}
static lean_object* _init_l_insertEnter___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Error: Not a valid conv target", 30, 30);
return x_1;
}
}
static lean_object* _init_l_insertEnter___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("You must select something in the goal.", 38, 38);
return x_1;
}
}
static lean_object* _init_l_insertEnter___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_insertEnter___closed__4;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_insertEnter(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_8 = lean_unsigned_to_nat(0u);
x_9 = lean_array_get_size(x_1);
x_10 = lean_nat_dec_lt(x_8, x_9);
lean_dec(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; 
lean_dec(x_2);
x_11 = l_insertEnter___closed__1;
x_12 = l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(x_11, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
return x_12;
}
else
{
lean_object* x_13; uint8_t x_14; 
x_13 = lean_array_fget(x_1, x_8);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_ctor_get(x_13, 1);
x_16 = lean_ctor_get(x_13, 0);
lean_dec(x_16);
if (lean_obj_tag(x_15) == 3)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
lean_dec(x_15);
x_18 = l_Lean_SubExpr_Pos_toArray(x_17);
lean_dec(x_17);
x_19 = lean_array_to_list(x_18);
x_20 = lean_box(0);
lean_ctor_set(x_13, 1, x_20);
lean_ctor_set(x_13, 0, x_19);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_2);
lean_ctor_set(x_21, 1, x_13);
x_22 = l_Lean_Loop_forIn_loop___at___insertEnter_spec__0(x_21, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_22) == 0)
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_36; lean_object* x_37; lean_object* x_38; uint32_t x_39; lean_object* x_40; uint8_t x_41; 
x_23 = lean_ctor_get(x_22, 0);
lean_inc(x_23);
x_24 = lean_ctor_get(x_23, 1);
lean_inc(x_24);
lean_dec(x_23);
x_25 = lean_ctor_get(x_22, 1);
lean_inc(x_25);
if (lean_is_exclusive(x_22)) {
 lean_ctor_release(x_22, 0);
 lean_ctor_release(x_22, 1);
 x_26 = x_22;
} else {
 lean_dec_ref(x_22);
 x_26 = lean_box(0);
}
x_27 = lean_ctor_get(x_24, 1);
lean_inc(x_27);
lean_dec(x_24);
x_28 = l_List_reverse___redArg(x_27);
x_36 = l_insertEnter___closed__2;
x_37 = l_List_toString___at___Lean_rewriteManualLinksCore_rw_spec__0(x_28);
x_38 = lean_string_append(x_36, x_37);
lean_dec(x_37);
x_39 = 48;
x_40 = lean_string_utf8_byte_size(x_38);
x_41 = l_String_anyAux___at___Lean_Name_isInaccessibleUserName_spec__0(x_39, x_38, x_40, x_8);
lean_dec(x_40);
if (x_41 == 0)
{
x_29 = x_38;
x_30 = x_25;
goto block_35;
}
else
{
lean_object* x_42; 
lean_dec(x_38);
x_42 = l_insertEnter___closed__3;
x_29 = x_42;
x_30 = x_25;
goto block_35;
}
block_35:
{
uint8_t x_31; 
x_31 = l_List_isEmpty___redArg(x_28);
lean_dec(x_28);
if (x_31 == 0)
{
lean_object* x_32; 
if (lean_is_scalar(x_26)) {
 x_32 = lean_alloc_ctor(0, 2, 0);
} else {
 x_32 = x_26;
}
lean_ctor_set(x_32, 0, x_29);
lean_ctor_set(x_32, 1, x_30);
return x_32;
}
else
{
lean_object* x_33; lean_object* x_34; 
lean_dec(x_29);
x_33 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4;
if (lean_is_scalar(x_26)) {
 x_34 = lean_alloc_ctor(0, 2, 0);
} else {
 x_34 = x_26;
}
lean_ctor_set(x_34, 0, x_33);
lean_ctor_set(x_34, 1, x_30);
return x_34;
}
}
}
else
{
uint8_t x_43; 
x_43 = !lean_is_exclusive(x_22);
if (x_43 == 0)
{
return x_22;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_ctor_get(x_22, 0);
x_45 = lean_ctor_get(x_22, 1);
lean_inc(x_45);
lean_inc(x_44);
lean_dec(x_22);
x_46 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_46, 0, x_44);
lean_ctor_set(x_46, 1, x_45);
return x_46;
}
}
}
else
{
lean_object* x_47; lean_object* x_48; 
lean_free_object(x_13);
lean_dec(x_15);
lean_dec(x_2);
x_47 = l_insertEnter___closed__5;
x_48 = l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(x_47, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
return x_48;
}
}
else
{
lean_object* x_49; 
x_49 = lean_ctor_get(x_13, 1);
lean_inc(x_49);
lean_dec(x_13);
if (lean_obj_tag(x_49) == 3)
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec(x_49);
x_51 = l_Lean_SubExpr_Pos_toArray(x_50);
lean_dec(x_50);
x_52 = lean_array_to_list(x_51);
x_53 = lean_box(0);
x_54 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_54, 0, x_52);
lean_ctor_set(x_54, 1, x_53);
x_55 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_55, 0, x_2);
lean_ctor_set(x_55, 1, x_54);
x_56 = l_Lean_Loop_forIn_loop___at___insertEnter_spec__0(x_55, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_56) == 0)
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_70; lean_object* x_71; lean_object* x_72; uint32_t x_73; lean_object* x_74; uint8_t x_75; 
x_57 = lean_ctor_get(x_56, 0);
lean_inc(x_57);
x_58 = lean_ctor_get(x_57, 1);
lean_inc(x_58);
lean_dec(x_57);
x_59 = lean_ctor_get(x_56, 1);
lean_inc(x_59);
if (lean_is_exclusive(x_56)) {
 lean_ctor_release(x_56, 0);
 lean_ctor_release(x_56, 1);
 x_60 = x_56;
} else {
 lean_dec_ref(x_56);
 x_60 = lean_box(0);
}
x_61 = lean_ctor_get(x_58, 1);
lean_inc(x_61);
lean_dec(x_58);
x_62 = l_List_reverse___redArg(x_61);
x_70 = l_insertEnter___closed__2;
x_71 = l_List_toString___at___Lean_rewriteManualLinksCore_rw_spec__0(x_62);
x_72 = lean_string_append(x_70, x_71);
lean_dec(x_71);
x_73 = 48;
x_74 = lean_string_utf8_byte_size(x_72);
x_75 = l_String_anyAux___at___Lean_Name_isInaccessibleUserName_spec__0(x_73, x_72, x_74, x_8);
lean_dec(x_74);
if (x_75 == 0)
{
x_63 = x_72;
x_64 = x_59;
goto block_69;
}
else
{
lean_object* x_76; 
lean_dec(x_72);
x_76 = l_insertEnter___closed__3;
x_63 = x_76;
x_64 = x_59;
goto block_69;
}
block_69:
{
uint8_t x_65; 
x_65 = l_List_isEmpty___redArg(x_62);
lean_dec(x_62);
if (x_65 == 0)
{
lean_object* x_66; 
if (lean_is_scalar(x_60)) {
 x_66 = lean_alloc_ctor(0, 2, 0);
} else {
 x_66 = x_60;
}
lean_ctor_set(x_66, 0, x_63);
lean_ctor_set(x_66, 1, x_64);
return x_66;
}
else
{
lean_object* x_67; lean_object* x_68; 
lean_dec(x_63);
x_67 = l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4;
if (lean_is_scalar(x_60)) {
 x_68 = lean_alloc_ctor(0, 2, 0);
} else {
 x_68 = x_60;
}
lean_ctor_set(x_68, 0, x_67);
lean_ctor_set(x_68, 1, x_64);
return x_68;
}
}
}
else
{
lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; 
x_77 = lean_ctor_get(x_56, 0);
lean_inc(x_77);
x_78 = lean_ctor_get(x_56, 1);
lean_inc(x_78);
if (lean_is_exclusive(x_56)) {
 lean_ctor_release(x_56, 0);
 lean_ctor_release(x_56, 1);
 x_79 = x_56;
} else {
 lean_dec_ref(x_56);
 x_79 = lean_box(0);
}
if (lean_is_scalar(x_79)) {
 x_80 = lean_alloc_ctor(1, 2, 0);
} else {
 x_80 = x_79;
}
lean_ctor_set(x_80, 0, x_77);
lean_ctor_set(x_80, 1, x_78);
return x_80;
}
}
else
{
lean_object* x_81; lean_object* x_82; 
lean_dec(x_49);
lean_dec(x_2);
x_81 = l_insertEnter___closed__5;
x_82 = l_Lean_throwError___at___Lean_getConstInfo___at___Lean_Meta_mkConstWithFreshMVarLevels_spec__0_spec__0___redArg(x_81, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
return x_82;
}
}
}
}
}
LEAN_EXPORT lean_object* l_insertEnter___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_insertEnter(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, size_t x_5, size_t x_6, lean_object* x_7) {
_start:
{
uint8_t x_8; 
x_8 = lean_usize_dec_lt(x_6, x_5);
if (x_8 == 0)
{
lean_dec(x_3);
lean_dec(x_1);
lean_inc(x_7);
return x_7;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_array_uget(x_4, x_6);
x_10 = lean_ctor_get(x_9, 3);
lean_inc(x_10);
x_11 = lean_ctor_get(x_1, 0);
lean_inc(x_11);
x_12 = lean_name_eq(x_10, x_11);
lean_dec(x_11);
lean_dec(x_10);
if (x_12 == 0)
{
size_t x_13; size_t x_14; 
lean_dec(x_9);
x_13 = 1;
x_14 = lean_usize_add(x_6, x_13);
{
size_t _tmp_5 = x_14;
lean_object* _tmp_6 = x_2;
x_6 = _tmp_5;
x_7 = _tmp_6;
}
goto _start;
}
else
{
uint8_t x_16; 
x_16 = !lean_is_exclusive(x_1);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_17 = lean_ctor_get(x_1, 1);
lean_dec(x_17);
x_18 = lean_ctor_get(x_1, 0);
lean_dec(x_18);
x_19 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_19, 0, x_9);
x_20 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_20, 0, x_19);
lean_ctor_set(x_1, 1, x_3);
lean_ctor_set(x_1, 0, x_20);
return x_1;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; 
lean_dec(x_1);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_9);
x_22 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_22, 0, x_21);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_3);
return x_23;
}
}
}
}
}
static lean_object* _init_l_findGoalForLocation___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = lean_box(0);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_findGoalForLocation(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; size_t x_5; size_t x_6; lean_object* x_7; lean_object* x_8; 
x_3 = lean_box(0);
x_4 = l_findGoalForLocation___closed__0;
x_5 = lean_array_size(x_1);
x_6 = 0;
x_7 = l_Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(x_2, x_4, x_3, x_1, x_5, x_6, x_4);
x_8 = lean_ctor_get(x_7, 0);
lean_inc(x_8);
lean_dec(x_7);
if (lean_obj_tag(x_8) == 0)
{
lean_object* x_9; 
x_9 = lean_box(0);
return x_9;
}
else
{
lean_object* x_10; 
x_10 = lean_ctor_get(x_8, 0);
lean_inc(x_10);
lean_dec(x_8);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
size_t x_8; size_t x_9; lean_object* x_10; 
x_8 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_9 = lean_unbox_usize(x_6);
lean_dec(x_6);
x_10 = l_Array_forIn_x27Unsafe_loop___at___findGoalForLocation_spec__0(x_1, x_2, x_3, x_4, x_8, x_9, x_7);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_findGoalForLocation___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_findGoalForLocation(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("pos", 3, 3);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("goals", 5, 5);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("termGoal", 8, 8);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("selectedLocations", 17, 17);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("replaceRange", 12, 12);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_2 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_inc(x_1);
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_inc(x_1);
x_6 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_5);
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
lean_dec(x_6);
x_8 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_inc(x_1);
x_9 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Client_0__Lean_Lsp_fromJsonRegistration____x40_Lean_Data_Lsp_Client___hyg_106__spec__0(x_1, x_8);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
lean_dec(x_9);
x_11 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_inc(x_1);
x_12 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_11);
x_13 = lean_ctor_get(x_12, 0);
lean_inc(x_13);
lean_dec(x_12);
x_14 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
x_15 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_14);
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_15, 0);
x_18 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_18, 0, x_4);
lean_ctor_set(x_18, 1, x_7);
lean_ctor_set(x_18, 2, x_10);
lean_ctor_set(x_18, 3, x_13);
lean_ctor_set(x_18, 4, x_17);
lean_ctor_set(x_15, 0, x_18);
return x_15;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_15, 0);
lean_inc(x_19);
lean_dec(x_15);
x_20 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_20, 0, x_4);
lean_ctor_set(x_20, 1, x_7);
lean_ctor_set(x_20, 2, x_10);
lean_ctor_set(x_20, 3, x_13);
lean_ctor_set(x_20, 4, x_19);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_20);
return x_21;
}
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_() {
_start:
{
lean_object* x_1; 
x_1 = l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_2 = lean_ctor_get(x_1, 0);
x_3 = lean_ctor_get(x_1, 1);
x_4 = lean_ctor_get(x_1, 2);
x_5 = lean_ctor_get(x_1, 3);
x_6 = lean_ctor_get(x_1, 4);
x_7 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_inc(x_2);
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_7);
lean_ctor_set(x_8, 1, x_2);
x_9 = lean_box(0);
x_10 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_10, 0, x_8);
lean_ctor_set(x_10, 1, x_9);
x_11 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_inc(x_3);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_3);
x_13 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_9);
x_14 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
x_15 = l_Lean_Json_opt___at_____private_Lean_Data_Lsp_Diagnostics_0__Lean_Lsp_toJsonDiagnosticWith____x40_Lean_Data_Lsp_Diagnostics___hyg_1722____at___Array_toJson___at_____private_Lean_Data_Lsp_Diagnostics_0__Lean_Lsp_toJsonPublishDiagnosticsParams____x40_Lean_Data_Lsp_Diagnostics___hyg_2460__spec__1_spec__1_spec__13(x_14, x_4);
x_16 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_inc(x_5);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_5);
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_9);
x_19 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
lean_inc(x_6);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_19);
lean_ctor_set(x_20, 1, x_6);
x_21 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_9);
x_22 = lean_box(0);
x_23 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_23, 0, x_21);
lean_ctor_set(x_23, 1, x_22);
x_24 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_24, 0, x_18);
lean_ctor_set(x_24, 1, x_23);
x_25 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_25, 0, x_15);
lean_ctor_set(x_25, 1, x_24);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_13);
lean_ctor_set(x_26, 1, x_25);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_10);
lean_ctor_set(x_27, 1, x_26);
x_28 = l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_;
x_29 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_27, x_28);
x_30 = l_Lean_Json_mkObj(x_29);
return x_30;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848____boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848____boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_() {
_start:
{
lean_object* x_1; 
x_1 = l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps_enc____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1476_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; size_t x_9; size_t x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc(x_3);
x_4 = lean_ctor_get(x_1, 1);
lean_inc(x_4);
lean_dec(x_1);
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_3, 1);
lean_inc(x_6);
x_7 = lean_ctor_get(x_3, 2);
lean_inc(x_7);
x_8 = lean_ctor_get(x_3, 3);
lean_inc(x_8);
lean_dec(x_3);
x_9 = lean_array_size(x_6);
x_10 = 0;
x_11 = l_Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_enc____x40_Lean_Widget_InteractiveGoal___hyg_3401__spec__0(x_9, x_10, x_6, x_2);
x_12 = lean_ctor_get(x_11, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_11, 1);
lean_inc(x_13);
lean_dec(x_11);
x_14 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonPosition____x40_Lean_Data_Lsp_Basic___hyg_226_(x_5);
x_15 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_12);
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_34; 
x_34 = lean_box(0);
x_16 = x_34;
x_17 = x_13;
goto block_33;
}
else
{
uint8_t x_35; 
x_35 = !lean_is_exclusive(x_7);
if (x_35 == 0)
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_36 = lean_ctor_get(x_7, 0);
x_37 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_enc____x40_Lean_Widget_InteractiveGoal___hyg_2275_(x_36, x_13);
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
lean_ctor_set(x_7, 0, x_38);
x_16 = x_7;
x_17 = x_39;
goto block_33;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_40 = lean_ctor_get(x_7, 0);
lean_inc(x_40);
lean_dec(x_7);
x_41 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_enc____x40_Lean_Widget_InteractiveGoal___hyg_2275_(x_40, x_13);
x_42 = lean_ctor_get(x_41, 0);
lean_inc(x_42);
x_43 = lean_ctor_get(x_41, 1);
lean_inc(x_43);
lean_dec(x_41);
x_44 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_44, 0, x_42);
x_16 = x_44;
x_17 = x_43;
goto block_33;
}
}
block_33:
{
size_t x_18; lean_object* x_19; uint8_t x_20; 
x_18 = lean_array_size(x_8);
x_19 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(x_18, x_10, x_8, x_17);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_21 = lean_ctor_get(x_19, 0);
x_22 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_21);
x_23 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonRange____x40_Lean_Data_Lsp_Basic___hyg_625_(x_4);
x_24 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_24, 0, x_14);
lean_ctor_set(x_24, 1, x_15);
lean_ctor_set(x_24, 2, x_16);
lean_ctor_set(x_24, 3, x_22);
lean_ctor_set(x_24, 4, x_23);
x_25 = l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_(x_24);
lean_dec(x_24);
lean_ctor_set(x_19, 0, x_25);
return x_19;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_26 = lean_ctor_get(x_19, 0);
x_27 = lean_ctor_get(x_19, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_19);
x_28 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_26);
x_29 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonRange____x40_Lean_Data_Lsp_Basic___hyg_625_(x_4);
x_30 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_30, 0, x_14);
lean_ctor_set(x_30, 1, x_15);
lean_ctor_set(x_30, 2, x_16);
lean_ctor_set(x_30, 3, x_28);
lean_ctor_set(x_30, 4, x_29);
x_31 = l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_(x_30);
lean_dec(x_30);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_27);
return x_32;
}
}
}
}
LEAN_EXPORT lean_object* l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1476_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_3 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = lean_ctor_get(x_4, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_4, 1);
lean_inc(x_6);
x_7 = lean_ctor_get(x_4, 2);
lean_inc(x_7);
x_8 = lean_ctor_get(x_4, 3);
lean_inc(x_8);
x_9 = lean_ctor_get(x_4, 4);
lean_inc(x_9);
lean_dec(x_4);
x_10 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonPosition____x40_Lean_Data_Lsp_Basic___hyg_278_(x_5);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
return x_10;
}
else
{
lean_object* x_12; lean_object* x_13; 
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_13, 0, x_12);
return x_13;
}
}
else
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_10, 0);
lean_inc(x_14);
lean_dec(x_10);
x_15 = l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(x_6);
if (lean_obj_tag(x_15) == 0)
{
uint8_t x_16; 
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
return x_15;
}
else
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
lean_dec(x_15);
x_18 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_18, 0, x_17);
return x_18;
}
}
else
{
lean_object* x_19; size_t x_20; size_t x_21; lean_object* x_22; 
x_19 = lean_ctor_get(x_15, 0);
lean_inc(x_19);
lean_dec(x_15);
x_20 = lean_array_size(x_19);
x_21 = 0;
lean_inc(x_2);
x_22 = l_Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_dec____x40_Lean_Widget_InteractiveGoal___hyg_3401__spec__0(x_20, x_21, x_19, x_2);
if (lean_obj_tag(x_22) == 0)
{
uint8_t x_23; 
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
x_23 = !lean_is_exclusive(x_22);
if (x_23 == 0)
{
return x_22;
}
else
{
lean_object* x_24; lean_object* x_25; 
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec(x_22);
x_25 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_25, 0, x_24);
return x_25;
}
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_22, 0);
lean_inc(x_26);
lean_dec(x_22);
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_53; 
x_53 = lean_box(0);
x_27 = x_53;
x_28 = x_2;
goto block_52;
}
else
{
uint8_t x_54; 
x_54 = !lean_is_exclusive(x_7);
if (x_54 == 0)
{
lean_object* x_55; lean_object* x_56; 
x_55 = lean_ctor_get(x_7, 0);
lean_inc(x_2);
x_56 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_dec____x40_Lean_Widget_InteractiveGoal___hyg_2275_(x_55, x_2);
if (lean_obj_tag(x_56) == 0)
{
uint8_t x_57; 
lean_free_object(x_7);
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_2);
x_57 = !lean_is_exclusive(x_56);
if (x_57 == 0)
{
return x_56;
}
else
{
lean_object* x_58; lean_object* x_59; 
x_58 = lean_ctor_get(x_56, 0);
lean_inc(x_58);
lean_dec(x_56);
x_59 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_59, 0, x_58);
return x_59;
}
}
else
{
lean_object* x_60; 
x_60 = lean_ctor_get(x_56, 0);
lean_inc(x_60);
lean_dec(x_56);
lean_ctor_set(x_7, 0, x_60);
x_27 = x_7;
x_28 = x_2;
goto block_52;
}
}
else
{
lean_object* x_61; lean_object* x_62; 
x_61 = lean_ctor_get(x_7, 0);
lean_inc(x_61);
lean_dec(x_7);
lean_inc(x_2);
x_62 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_dec____x40_Lean_Widget_InteractiveGoal___hyg_2275_(x_61, x_2);
if (lean_obj_tag(x_62) == 0)
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; 
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_2);
x_63 = lean_ctor_get(x_62, 0);
lean_inc(x_63);
if (lean_is_exclusive(x_62)) {
 lean_ctor_release(x_62, 0);
 x_64 = x_62;
} else {
 lean_dec_ref(x_62);
 x_64 = lean_box(0);
}
if (lean_is_scalar(x_64)) {
 x_65 = lean_alloc_ctor(0, 1, 0);
} else {
 x_65 = x_64;
}
lean_ctor_set(x_65, 0, x_63);
return x_65;
}
else
{
lean_object* x_66; lean_object* x_67; 
x_66 = lean_ctor_get(x_62, 0);
lean_inc(x_66);
lean_dec(x_62);
x_67 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_67, 0, x_66);
x_27 = x_67;
x_28 = x_2;
goto block_52;
}
}
}
block_52:
{
lean_object* x_29; 
x_29 = l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(x_8);
if (lean_obj_tag(x_29) == 0)
{
uint8_t x_30; 
lean_dec(x_28);
lean_dec(x_27);
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
x_30 = !lean_is_exclusive(x_29);
if (x_30 == 0)
{
return x_29;
}
else
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_ctor_get(x_29, 0);
lean_inc(x_31);
lean_dec(x_29);
x_32 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_32, 0, x_31);
return x_32;
}
}
else
{
lean_object* x_33; size_t x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_29, 0);
lean_inc(x_33);
lean_dec(x_29);
x_34 = lean_array_size(x_33);
x_35 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(x_34, x_21, x_33, x_28);
lean_dec(x_28);
if (lean_obj_tag(x_35) == 0)
{
uint8_t x_36; 
lean_dec(x_27);
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
x_36 = !lean_is_exclusive(x_35);
if (x_36 == 0)
{
return x_35;
}
else
{
lean_object* x_37; lean_object* x_38; 
x_37 = lean_ctor_get(x_35, 0);
lean_inc(x_37);
lean_dec(x_35);
x_38 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_38, 0, x_37);
return x_38;
}
}
else
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_35, 0);
lean_inc(x_39);
lean_dec(x_35);
x_40 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonRange____x40_Lean_Data_Lsp_Basic___hyg_677_(x_9);
if (lean_obj_tag(x_40) == 0)
{
uint8_t x_41; 
lean_dec(x_39);
lean_dec(x_27);
lean_dec(x_26);
lean_dec(x_14);
x_41 = !lean_is_exclusive(x_40);
if (x_41 == 0)
{
return x_40;
}
else
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_ctor_get(x_40, 0);
lean_inc(x_42);
lean_dec(x_40);
x_43 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_43, 0, x_42);
return x_43;
}
}
else
{
uint8_t x_44; 
x_44 = !lean_is_exclusive(x_40);
if (x_44 == 0)
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; 
x_45 = lean_ctor_get(x_40, 0);
x_46 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_46, 0, x_14);
lean_ctor_set(x_46, 1, x_26);
lean_ctor_set(x_46, 2, x_27);
lean_ctor_set(x_46, 3, x_39);
x_47 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_47, 0, x_46);
lean_ctor_set(x_47, 1, x_45);
lean_ctor_set(x_40, 0, x_47);
return x_40;
}
else
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
x_48 = lean_ctor_get(x_40, 0);
lean_inc(x_48);
lean_dec(x_40);
x_49 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_49, 0, x_14);
lean_ctor_set(x_49, 1, x_26);
lean_ctor_set(x_49, 2, x_27);
lean_ctor_set(x_49, 3, x_39);
x_50 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_50, 0, x_49);
lean_ctor_set(x_50, 1, x_48);
x_51 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_51, 0, x_50);
return x_51;
}
}
}
}
}
}
}
}
}
}
static lean_object* _init_l_instRpcEncodableConvSelectionPanelProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableConvSelectionPanelProps_enc____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1476_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableConvSelectionPanelProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1476_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_instRpcEncodableConvSelectionPanelProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_instRpcEncodableConvSelectionPanelProps___closed__1;
x_2 = l_instRpcEncodableConvSelectionPanelProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_instRpcEncodableConvSelectionPanelProps() {
_start:
{
lean_object* x_1; 
x_1 = l_instRpcEncodableConvSelectionPanelProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Lean_Server_instInhabitedRequestError;
x_2 = lean_alloc_closure((void*)(l_EStateM_instInhabited___redArg___lam__0), 2, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_panic___at___ConvSelectionPanel_rpc_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_4 = l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0;
x_5 = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(x_5, 0, x_4);
x_6 = lean_panic_fn(x_5, x_1);
x_7 = lean_apply_2(x_6, x_2, x_3);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l___private_ProofWidgets_Component_MakeEditLink_0__ProofWidgets_toJsonMakeEditLinkProps____x40_ProofWidgets_Component_MakeEditLink___hyg_298_(x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___lam__0), 2, 1);
lean_closure_set(x_7, 0, x_2);
x_8 = lean_string_hash(x_6);
lean_inc(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_7);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_8);
return x_9;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__0___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_insertEnter(x_1, x_2, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_12 = lean_ctor_get(x_3, 0);
x_13 = lean_ctor_get(x_10, 0);
x_14 = lean_ctor_get(x_12, 0);
x_15 = l_ProofWidgets_MakeEditLink;
x_16 = lean_box(0);
lean_inc(x_13);
x_17 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(x_14, x_4, x_13, x_16);
x_18 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_18, 0, x_13);
x_19 = l_ConvSelectionPanel_rpc___lam__0___closed__0;
x_20 = lean_array_push(x_19, x_18);
x_21 = l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(x_15, x_17, x_20);
lean_ctor_set(x_10, 0, x_21);
return x_10;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; 
x_22 = lean_ctor_get(x_3, 0);
x_23 = lean_ctor_get(x_10, 0);
x_24 = lean_ctor_get(x_10, 1);
lean_inc(x_24);
lean_inc(x_23);
lean_dec(x_10);
x_25 = lean_ctor_get(x_22, 0);
x_26 = l_ProofWidgets_MakeEditLink;
x_27 = lean_box(0);
lean_inc(x_23);
x_28 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(x_25, x_4, x_23, x_27);
x_29 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_29, 0, x_23);
x_30 = l_ConvSelectionPanel_rpc___lam__0___closed__0;
x_31 = lean_array_push(x_30, x_29);
x_32 = l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(x_26, x_28, x_31);
x_33 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_33, 0, x_32);
lean_ctor_set(x_33, 1, x_24);
return x_33;
}
}
else
{
uint8_t x_34; 
lean_dec(x_4);
x_34 = !lean_is_exclusive(x_10);
if (x_34 == 0)
{
return x_10;
}
else
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_35 = lean_ctor_get(x_10, 0);
x_36 = lean_ctor_get(x_10, 1);
lean_inc(x_36);
lean_inc(x_35);
lean_dec(x_10);
x_37 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_37, 0, x_35);
lean_ctor_set(x_37, 1, x_36);
return x_37;
}
}
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_MVarId_getDecl(x_1, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_ctor_get(x_7, 2);
lean_inc(x_13);
x_14 = lean_ctor_get(x_11, 1);
lean_inc(x_14);
x_15 = lean_ctor_get(x_11, 2);
lean_inc(x_15);
x_16 = lean_ctor_get(x_11, 4);
lean_inc(x_16);
lean_dec(x_11);
x_17 = lean_box(0);
x_18 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_18, 0, x_13);
lean_ctor_set(x_18, 1, x_17);
lean_ctor_set(x_18, 2, x_17);
x_19 = l_Lean_LocalContext_sanitizeNames(x_14, x_18);
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
lean_dec(x_19);
x_21 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc___lam__0___boxed), 9, 4);
lean_closure_set(x_21, 0, x_2);
lean_closure_set(x_21, 1, x_15);
lean_closure_set(x_21, 2, x_3);
lean_closure_set(x_21, 3, x_4);
x_22 = l_Lean_Meta_withLCtx___at_____private_Lean_Meta_Basic_0__Lean_Meta_mkLevelErrorMessageCore_spec__2___redArg(x_20, x_16, x_21, x_5, x_6, x_7, x_8, x_12);
return x_22;
}
else
{
uint8_t x_23; 
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_23 = !lean_is_exclusive(x_10);
if (x_23 == 0)
{
return x_10;
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_24 = lean_ctor_get(x_10, 0);
x_25 = lean_ctor_get(x_10, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_10);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_24);
lean_ctor_set(x_26, 1, x_25);
return x_26;
}
}
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("details", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("open", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; 
x_1 = lean_box(1);
x_2 = lean_alloc_ctor(1, 0, 1);
x_3 = lean_unbox(x_1);
lean_ctor_set_uint8(x_2, 0, x_3);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__2;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__3;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("summary", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("className", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("mv2 pointer", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__8;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__9;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__7;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__10;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Conv 🔍", 9, 6);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__12;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__13;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__14;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__11;
x_3 = l_ConvSelectionPanel_rpc___lam__2___closed__6;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__16() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("div", 3, 3);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__17() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ml1", 3, 3);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__17;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__18;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__7;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__19;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__15;
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__21;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__23() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ConvSelectionPanel.rpc", 22, 22);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__24() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("unreachable code has been reached", 33, 33);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__24;
x_2 = lean_unsigned_to_nat(60u);
x_3 = lean_unsigned_to_nat(128u);
x_4 = l_ConvSelectionPanel_rpc___lam__2___closed__23;
x_5 = l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0;
x_6 = l_mkPanicMessageWithDecl(x_5, x_4, x_3, x_2, x_1);
return x_6;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__26() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("could not find goal for location ", 33, 33);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__27() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__28() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__27;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__29() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(32u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__30() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__29;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__31() {
_start:
{
size_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_ConvSelectionPanel_rpc___lam__2___closed__29;
x_4 = l_ConvSelectionPanel_rpc___lam__2___closed__30;
x_5 = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set_usize(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__32() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(0);
x_2 = l_ConvSelectionPanel_rpc___lam__2___closed__31;
x_3 = l_ConvSelectionPanel_rpc___lam__2___closed__28;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__33() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("span", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__34() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Use shift-click to select one sub-expression in the goal that you want to zoom on.", 82, 82);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__35() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__34;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__36() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__35;
x_2 = l_ConvSelectionPanel_rpc___lam__0___closed__0;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___lam__2___closed__37() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ConvSelectionPanel_rpc___lam__2___closed__36;
x_2 = l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_;
x_3 = l_ConvSelectionPanel_rpc___lam__2___closed__33;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; uint8_t x_9; 
x_4 = l_Lean_Server_RequestM_readDoc___at___Lean_Server_RequestM_withWaitFindSnapAtPos_spec__0(x_2, x_3);
x_5 = lean_ctor_get(x_1, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_4, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_4, 1);
lean_inc(x_7);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 x_8 = x_4;
} else {
 lean_dec_ref(x_4);
 x_8 = lean_box(0);
}
x_9 = !lean_is_exclusive(x_1);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; lean_object* x_15; lean_object* x_16; 
x_10 = lean_ctor_get(x_1, 1);
x_11 = lean_ctor_get(x_1, 0);
lean_dec(x_11);
x_12 = lean_ctor_get(x_5, 1);
lean_inc(x_12);
x_13 = lean_ctor_get(x_5, 3);
lean_inc(x_13);
lean_dec(x_5);
x_14 = l_Array_isEmpty___redArg(x_13);
if (x_14 == 0)
{
lean_object* x_29; lean_object* x_30; uint8_t x_31; 
x_29 = lean_unsigned_to_nat(0u);
x_30 = lean_array_get_size(x_13);
x_31 = lean_nat_dec_lt(x_29, x_30);
lean_dec(x_30);
if (x_31 == 0)
{
lean_object* x_32; lean_object* x_33; 
lean_dec(x_13);
lean_dec(x_12);
lean_free_object(x_1);
lean_dec(x_10);
lean_dec(x_6);
x_32 = l_ConvSelectionPanel_rpc___lam__2___closed__25;
x_33 = l_panic___at___ConvSelectionPanel_rpc_spec__0(x_32, x_2, x_7);
if (lean_obj_tag(x_33) == 0)
{
lean_object* x_34; lean_object* x_35; 
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_33, 1);
lean_inc(x_35);
lean_dec(x_33);
x_15 = x_34;
x_16 = x_35;
goto block_28;
}
else
{
lean_dec(x_8);
return x_33;
}
}
else
{
lean_object* x_36; lean_object* x_37; 
lean_dec(x_2);
x_36 = lean_array_fget(x_13, x_29);
lean_inc(x_36);
x_37 = l_findGoalForLocation(x_12, x_36);
lean_dec(x_12);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_13);
lean_dec(x_10);
lean_dec(x_8);
lean_dec(x_6);
x_38 = l_ConvSelectionPanel_rpc___lam__2___closed__26;
x_39 = l___private_Lean_SubExpr_0__Lean_SubExpr_toJsonGoalsLocation____x40_Lean_SubExpr___hyg_1946_(x_36);
x_40 = lean_unsigned_to_nat(80u);
x_41 = l_Lean_Json_pretty(x_39, x_40);
x_42 = lean_string_append(x_38, x_41);
lean_dec(x_41);
x_43 = l_Lean_Server_RequestError_invalidParams(x_42);
lean_ctor_set_tag(x_1, 1);
lean_ctor_set(x_1, 1, x_7);
lean_ctor_set(x_1, 0, x_43);
return x_1;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
lean_dec(x_36);
lean_free_object(x_1);
x_44 = lean_ctor_get(x_37, 0);
lean_inc(x_44);
lean_dec(x_37);
x_45 = lean_ctor_get(x_44, 0);
lean_inc(x_45);
x_46 = lean_ctor_get(x_45, 2);
lean_inc(x_46);
lean_dec(x_45);
x_47 = lean_ctor_get(x_44, 3);
lean_inc(x_47);
lean_dec(x_44);
x_48 = lean_ctor_get(x_46, 0);
lean_inc(x_48);
lean_dec(x_46);
x_49 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc___lam__1), 9, 4);
lean_closure_set(x_49, 0, x_47);
lean_closure_set(x_49, 1, x_13);
lean_closure_set(x_49, 2, x_6);
lean_closure_set(x_49, 3, x_10);
x_50 = l_ConvSelectionPanel_rpc___lam__2___closed__32;
x_51 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_48, x_50, x_49, x_7);
if (lean_obj_tag(x_51) == 0)
{
lean_object* x_52; lean_object* x_53; 
x_52 = lean_ctor_get(x_51, 0);
lean_inc(x_52);
x_53 = lean_ctor_get(x_51, 1);
lean_inc(x_53);
lean_dec(x_51);
x_15 = x_52;
x_16 = x_53;
goto block_28;
}
else
{
uint8_t x_54; 
lean_dec(x_8);
x_54 = !lean_is_exclusive(x_51);
if (x_54 == 0)
{
lean_object* x_55; lean_object* x_56; 
x_55 = lean_ctor_get(x_51, 0);
x_56 = l_Lean_Server_RequestError_ofIoError(x_55);
lean_ctor_set(x_51, 0, x_56);
return x_51;
}
else
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; 
x_57 = lean_ctor_get(x_51, 0);
x_58 = lean_ctor_get(x_51, 1);
lean_inc(x_58);
lean_inc(x_57);
lean_dec(x_51);
x_59 = l_Lean_Server_RequestError_ofIoError(x_57);
x_60 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set(x_60, 1, x_58);
return x_60;
}
}
}
}
}
else
{
lean_object* x_61; 
lean_dec(x_13);
lean_dec(x_12);
lean_free_object(x_1);
lean_dec(x_10);
lean_dec(x_6);
lean_dec(x_2);
x_61 = l_ConvSelectionPanel_rpc___lam__2___closed__37;
x_15 = x_61;
x_16 = x_7;
goto block_28;
}
block_28:
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_17 = l_ConvSelectionPanel_rpc___lam__2___closed__0;
x_18 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_19 = l_ConvSelectionPanel_rpc___lam__2___closed__5;
x_20 = l_ConvSelectionPanel_rpc___lam__2___closed__16;
x_21 = l_ConvSelectionPanel_rpc___lam__2___closed__20;
x_22 = lean_array_push(x_18, x_15);
x_23 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_23, 0, x_20);
lean_ctor_set(x_23, 1, x_21);
lean_ctor_set(x_23, 2, x_22);
x_24 = l_ConvSelectionPanel_rpc___lam__2___closed__22;
x_25 = lean_array_push(x_24, x_23);
x_26 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_26, 0, x_17);
lean_ctor_set(x_26, 1, x_19);
lean_ctor_set(x_26, 2, x_25);
if (lean_is_scalar(x_8)) {
 x_27 = lean_alloc_ctor(0, 2, 0);
} else {
 x_27 = x_8;
}
lean_ctor_set(x_27, 0, x_26);
lean_ctor_set(x_27, 1, x_16);
return x_27;
}
}
else
{
lean_object* x_62; lean_object* x_63; lean_object* x_64; uint8_t x_65; lean_object* x_66; lean_object* x_67; 
x_62 = lean_ctor_get(x_1, 1);
lean_inc(x_62);
lean_dec(x_1);
x_63 = lean_ctor_get(x_5, 1);
lean_inc(x_63);
x_64 = lean_ctor_get(x_5, 3);
lean_inc(x_64);
lean_dec(x_5);
x_65 = l_Array_isEmpty___redArg(x_64);
if (x_65 == 0)
{
lean_object* x_80; lean_object* x_81; uint8_t x_82; 
x_80 = lean_unsigned_to_nat(0u);
x_81 = lean_array_get_size(x_64);
x_82 = lean_nat_dec_lt(x_80, x_81);
lean_dec(x_81);
if (x_82 == 0)
{
lean_object* x_83; lean_object* x_84; 
lean_dec(x_64);
lean_dec(x_63);
lean_dec(x_62);
lean_dec(x_6);
x_83 = l_ConvSelectionPanel_rpc___lam__2___closed__25;
x_84 = l_panic___at___ConvSelectionPanel_rpc_spec__0(x_83, x_2, x_7);
if (lean_obj_tag(x_84) == 0)
{
lean_object* x_85; lean_object* x_86; 
x_85 = lean_ctor_get(x_84, 0);
lean_inc(x_85);
x_86 = lean_ctor_get(x_84, 1);
lean_inc(x_86);
lean_dec(x_84);
x_66 = x_85;
x_67 = x_86;
goto block_79;
}
else
{
lean_dec(x_8);
return x_84;
}
}
else
{
lean_object* x_87; lean_object* x_88; 
lean_dec(x_2);
x_87 = lean_array_fget(x_64, x_80);
lean_inc(x_87);
x_88 = l_findGoalForLocation(x_63, x_87);
lean_dec(x_63);
if (lean_obj_tag(x_88) == 0)
{
lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; 
lean_dec(x_64);
lean_dec(x_62);
lean_dec(x_8);
lean_dec(x_6);
x_89 = l_ConvSelectionPanel_rpc___lam__2___closed__26;
x_90 = l___private_Lean_SubExpr_0__Lean_SubExpr_toJsonGoalsLocation____x40_Lean_SubExpr___hyg_1946_(x_87);
x_91 = lean_unsigned_to_nat(80u);
x_92 = l_Lean_Json_pretty(x_90, x_91);
x_93 = lean_string_append(x_89, x_92);
lean_dec(x_92);
x_94 = l_Lean_Server_RequestError_invalidParams(x_93);
x_95 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_95, 0, x_94);
lean_ctor_set(x_95, 1, x_7);
return x_95;
}
else
{
lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; 
lean_dec(x_87);
x_96 = lean_ctor_get(x_88, 0);
lean_inc(x_96);
lean_dec(x_88);
x_97 = lean_ctor_get(x_96, 0);
lean_inc(x_97);
x_98 = lean_ctor_get(x_97, 2);
lean_inc(x_98);
lean_dec(x_97);
x_99 = lean_ctor_get(x_96, 3);
lean_inc(x_99);
lean_dec(x_96);
x_100 = lean_ctor_get(x_98, 0);
lean_inc(x_100);
lean_dec(x_98);
x_101 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc___lam__1), 9, 4);
lean_closure_set(x_101, 0, x_99);
lean_closure_set(x_101, 1, x_64);
lean_closure_set(x_101, 2, x_6);
lean_closure_set(x_101, 3, x_62);
x_102 = l_ConvSelectionPanel_rpc___lam__2___closed__32;
x_103 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_100, x_102, x_101, x_7);
if (lean_obj_tag(x_103) == 0)
{
lean_object* x_104; lean_object* x_105; 
x_104 = lean_ctor_get(x_103, 0);
lean_inc(x_104);
x_105 = lean_ctor_get(x_103, 1);
lean_inc(x_105);
lean_dec(x_103);
x_66 = x_104;
x_67 = x_105;
goto block_79;
}
else
{
lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; 
lean_dec(x_8);
x_106 = lean_ctor_get(x_103, 0);
lean_inc(x_106);
x_107 = lean_ctor_get(x_103, 1);
lean_inc(x_107);
if (lean_is_exclusive(x_103)) {
 lean_ctor_release(x_103, 0);
 lean_ctor_release(x_103, 1);
 x_108 = x_103;
} else {
 lean_dec_ref(x_103);
 x_108 = lean_box(0);
}
x_109 = l_Lean_Server_RequestError_ofIoError(x_106);
if (lean_is_scalar(x_108)) {
 x_110 = lean_alloc_ctor(1, 2, 0);
} else {
 x_110 = x_108;
}
lean_ctor_set(x_110, 0, x_109);
lean_ctor_set(x_110, 1, x_107);
return x_110;
}
}
}
}
else
{
lean_object* x_111; 
lean_dec(x_64);
lean_dec(x_63);
lean_dec(x_62);
lean_dec(x_6);
lean_dec(x_2);
x_111 = l_ConvSelectionPanel_rpc___lam__2___closed__37;
x_66 = x_111;
x_67 = x_7;
goto block_79;
}
block_79:
{
lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; 
x_68 = l_ConvSelectionPanel_rpc___lam__2___closed__0;
x_69 = l_ConvSelectionPanel_rpc___lam__2___closed__4;
x_70 = l_ConvSelectionPanel_rpc___lam__2___closed__5;
x_71 = l_ConvSelectionPanel_rpc___lam__2___closed__16;
x_72 = l_ConvSelectionPanel_rpc___lam__2___closed__20;
x_73 = lean_array_push(x_69, x_66);
x_74 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_74, 0, x_71);
lean_ctor_set(x_74, 1, x_72);
lean_ctor_set(x_74, 2, x_73);
x_75 = l_ConvSelectionPanel_rpc___lam__2___closed__22;
x_76 = lean_array_push(x_75, x_74);
x_77 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_77, 0, x_68);
lean_ctor_set(x_77, 1, x_70);
lean_ctor_set(x_77, 2, x_76);
if (lean_is_scalar(x_8)) {
 x_78 = lean_alloc_ctor(0, 2, 0);
} else {
 x_78 = x_8;
}
lean_ctor_set(x_78, 0, x_77);
lean_ctor_set(x_78, 1, x_67);
return x_78;
}
}
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; 
x_4 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc___lam__2), 3, 1);
lean_closure_set(x_4, 0, x_1);
x_5 = l_Lean_Server_RequestM_asTask___redArg(x_4, x_2, x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___ConvSelectionPanel_rpc_spec__1(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ConvSelectionPanel_rpc___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_ConvSelectionPanel_rpc___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_3);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = lean_box(0);
x_3 = lean_unbox(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__1(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__2), 2, 1);
lean_closure_set(x_14, 0, x_13);
x_15 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(x_8, x_12);
x_16 = l_Prod_map___redArg(x_2, x_14, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_1 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__0;
x_2 = lean_box(9);
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
x_4 = lean_unbox(x_2);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_4);
return x_3;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, uint64_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
x_10 = l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_9, x_5);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_11 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__1;
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_st_ref_get(x_13, x_8);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_16 = lean_ctor_get(x_14, 0);
x_17 = lean_ctor_get(x_14, 1);
x_18 = lean_ctor_get(x_16, 0);
lean_inc(x_18);
lean_dec(x_16);
lean_inc(x_6);
x_19 = l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1476_(x_6, x_18);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; uint8_t x_35; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
lean_dec(x_19);
x_21 = lean_box(3);
x_22 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__2;
x_23 = lean_box(1);
x_24 = lean_unbox(x_23);
x_25 = l_Lean_Name_toString(x_1, x_24, x_2);
x_26 = lean_string_append(x_22, x_25);
lean_dec(x_25);
x_27 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__3;
x_28 = lean_string_append(x_26, x_27);
x_29 = l_Lean_Json_compress(x_6);
x_30 = lean_string_append(x_28, x_29);
lean_dec(x_29);
x_31 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__4;
x_32 = lean_string_append(x_30, x_31);
x_33 = lean_string_append(x_32, x_20);
lean_dec(x_20);
x_34 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_34, 0, x_33);
x_35 = lean_unbox(x_21);
lean_ctor_set_uint8(x_34, sizeof(void*)*1, x_35);
lean_ctor_set_tag(x_14, 1);
lean_ctor_set(x_14, 0, x_34);
return x_14;
}
else
{
lean_object* x_36; lean_object* x_37; 
lean_free_object(x_14);
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_36 = lean_ctor_get(x_19, 0);
lean_inc(x_36);
lean_dec(x_19);
lean_inc(x_7);
x_37 = lean_apply_3(x_3, x_36, x_7, x_17);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
x_40 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_40, 0, x_13);
lean_closure_set(x_40, 1, x_4);
x_41 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_38, x_40, x_7, x_39);
return x_41;
}
else
{
uint8_t x_42; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_42 = !lean_is_exclusive(x_37);
if (x_42 == 0)
{
return x_37;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_43 = lean_ctor_get(x_37, 0);
x_44 = lean_ctor_get(x_37, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_37);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
return x_45;
}
}
}
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_46 = lean_ctor_get(x_14, 0);
x_47 = lean_ctor_get(x_14, 1);
lean_inc(x_47);
lean_inc(x_46);
lean_dec(x_14);
x_48 = lean_ctor_get(x_46, 0);
lean_inc(x_48);
lean_dec(x_46);
lean_inc(x_6);
x_49 = l_instRpcEncodableConvSelectionPanelProps_dec____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1476_(x_6, x_48);
if (lean_obj_tag(x_49) == 0)
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; uint8_t x_65; lean_object* x_66; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec(x_49);
x_51 = lean_box(3);
x_52 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__2;
x_53 = lean_box(1);
x_54 = lean_unbox(x_53);
x_55 = l_Lean_Name_toString(x_1, x_54, x_2);
x_56 = lean_string_append(x_52, x_55);
lean_dec(x_55);
x_57 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__3;
x_58 = lean_string_append(x_56, x_57);
x_59 = l_Lean_Json_compress(x_6);
x_60 = lean_string_append(x_58, x_59);
lean_dec(x_59);
x_61 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__4;
x_62 = lean_string_append(x_60, x_61);
x_63 = lean_string_append(x_62, x_50);
lean_dec(x_50);
x_64 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_64, 0, x_63);
x_65 = lean_unbox(x_51);
lean_ctor_set_uint8(x_64, sizeof(void*)*1, x_65);
x_66 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_66, 0, x_64);
lean_ctor_set(x_66, 1, x_47);
return x_66;
}
else
{
lean_object* x_67; lean_object* x_68; 
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_67 = lean_ctor_get(x_49, 0);
lean_inc(x_67);
lean_dec(x_49);
lean_inc(x_7);
x_68 = lean_apply_3(x_3, x_67, x_7, x_47);
if (lean_obj_tag(x_68) == 0)
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
x_69 = lean_ctor_get(x_68, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_68, 1);
lean_inc(x_70);
lean_dec(x_68);
x_71 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_71, 0, x_13);
lean_closure_set(x_71, 1, x_4);
x_72 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_69, x_71, x_7, x_70);
return x_72;
}
else
{
lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_73 = lean_ctor_get(x_68, 0);
lean_inc(x_73);
x_74 = lean_ctor_get(x_68, 1);
lean_inc(x_74);
if (lean_is_exclusive(x_68)) {
 lean_ctor_release(x_68, 0);
 lean_ctor_release(x_68, 1);
 x_75 = x_68;
} else {
 lean_dec_ref(x_68);
 x_75 = lean_box(0);
}
if (lean_is_scalar(x_75)) {
 x_76 = lean_alloc_ctor(1, 2, 0);
} else {
 x_76 = x_75;
}
lean_ctor_set(x_76, 0, x_73);
lean_ctor_set(x_76, 1, x_74);
return x_76;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__1___boxed), 1, 0);
x_5 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___boxed), 8, 4);
lean_closure_set(x_5, 0, x_1);
lean_closure_set(x_5, 1, x_3);
lean_closure_set(x_5, 2, x_2);
lean_closure_set(x_5, 3, x_4);
return x_5;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ConvSelectionPanel", 18, 18);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("rpc", 3, 3);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1;
x_2 = l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ConvSelectionPanel_rpc), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel_rpc___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2;
x_2 = l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3;
x_3 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__1___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__1(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint64_t x_9; lean_object* x_10; 
x_9 = lean_unbox_uint64(x_5);
lean_dec(x_5);
x_10 = l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4(x_1, x_2, x_3, x_4, x_9, x_6, x_7, x_8);
return x_10;
}
}
static lean_object* _init_l_ConvSelectionPanel___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as t,Fragment as n}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as a,EnvPosContext as o,useAsyncPersistent as c,mapRpcError as s,importWidgetModule as i}from\"@leanprover/infoview\";async function l(a,o,c){if(\"text\"in c)return t(n,{children:c.text});if(\"element\"in c){const[e,n,s]=c.element,i={};for(const[e,t]of n)i[e]=t;const u=await Promise.all(s.map((async e=>await l(a,o,e))));return\"hr\"===e\?t(\"hr\",{}):0===u.length\?r.createElement(e,i):r.createElement(e,i,u)}if(\"component\"in c){const[e,t,n,s]=c.component,u=await Promise.all(s.map((async e=>await l(a,o,e)))),m={...n,pos:o},f=await i(a,o,e);if(!(t in f))throw new Error(`Module '${e}' does not export '${t}'`);return 0===u.length\?r.createElement(f[t],m):r.createElement(f[t],m,u)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(c)]})}function u({html:i}){const u=a(),m=r.useContext(o),f=c((()=>l(u,m,i)),[u,m,i]);return\"resolved\"===f.state\?f.value:\"rejected\"===f.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",s(f.error).message]}):t(n,{})}const m=\"ConvSelectionPanel.rpc\",f='false';var d=r.memo((e=>{const o=a(),i=r.useRef({fn:()=>{}}),l=c((async()=>{if(\"true\"===f){i.current.fn();const[t,n]=function(e,t,n){const r={fn:()=>{}};return[new Promise((async(a,o)=>{const c=await e.call(t,n),s=window.setInterval((async()=>{try{const t=await e.call(\"ProofWidgets.checkRequest\",c);if(\"running\"===t)return;window.clearInterval(s),a(t.done.result)}catch(e){window.clearInterval(s),o(e)}}),100);r.fn=()=>{e.call(\"ProofWidgets.cancelRequest\",c)}})),r]}(o,m,e);return i.current=n,t}return o.call(m,e)}),[o,e]);return r.useEffect((()=>()=>{i.current.fn()}),[]),\"rejected\"===l.state\?t(\"p\",{style:{color:\"red\"},children:s(l.error).message}):\"loading\"===l.state\?t(n,{children:\"Loading..\"}):t(u,{html:l.value})}));export{d as default};", 1882, 1882);
return x_1;
}
}
static uint64_t _init_l_ConvSelectionPanel___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ConvSelectionPanel___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel___closed__2___boxed__const__1() {
_start:
{
uint64_t x_1; lean_object* x_2; 
x_1 = l_ConvSelectionPanel___closed__1;
x_2 = lean_box_uint64(x_1);
return x_2;
}
}
static lean_object* _init_l_ConvSelectionPanel___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel___closed__0;
x_2 = l_ConvSelectionPanel___closed__2___boxed__const__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ConvSelectionPanel___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ConvSelectionPanel___closed__3;
x_2 = l_ConvSelectionPanel___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ConvSelectionPanel() {
_start:
{
lean_object* x_1; 
x_1 = l_ConvSelectionPanel___closed__4;
return x_1;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("tacticConv\?", 11, 11);
return x_1;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_tacticConv_x3f___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("conv\?", 5, 5);
return x_1;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_1 = lean_box(0);
x_2 = l_tacticConv_x3f___closed__2;
x_3 = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(x_3, 0, x_2);
x_4 = lean_unbox(x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_4);
return x_3;
}
}
static lean_object* _init_l_tacticConv_x3f___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_tacticConv_x3f___closed__3;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_tacticConv_x3f___closed__1;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_tacticConv_x3f() {
_start:
{
lean_object* x_1; 
x_1 = l_tacticConv_x3f___closed__4;
return x_1;
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; uint8_t x_6; 
x_5 = l_tacticConv_x3f___closed__1;
lean_inc(x_1);
x_6 = l_Lean_Syntax_isOfKind(x_1, x_5);
if (x_6 == 0)
{
lean_object* x_7; 
lean_dec(x_2);
lean_dec(x_1);
x_7 = l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_liftMacroM___at___Lean_Elab_Tactic_evalTactic_expandEval_spec__0_spec__2___redArg(x_4);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_2, 1);
lean_inc(x_8);
x_9 = lean_unsigned_to_nat(0u);
x_10 = l_Lean_Syntax_getArg(x_1, x_9);
lean_dec(x_1);
x_11 = l_Lean_FileMap_rangeOfStx_x3f(x_8, x_10);
if (lean_obj_tag(x_11) == 0)
{
lean_object* x_12; lean_object* x_13; 
lean_dec(x_10);
lean_dec(x_2);
x_12 = lean_box(0);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_4);
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_14 = lean_ctor_get(x_11, 0);
lean_inc(x_14);
lean_dec(x_11);
x_15 = l_ConvSelectionPanel;
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_17 = lean_ctor_get(x_15, 0);
x_18 = lean_ctor_get(x_15, 1);
lean_dec(x_18);
x_19 = !lean_is_exclusive(x_17);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; uint64_t x_27; lean_object* x_28; 
x_20 = lean_ctor_get(x_17, 1);
x_21 = lean_ctor_get(x_17, 0);
lean_dec(x_21);
x_22 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
x_23 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonRange____x40_Lean_Data_Lsp_Basic___hyg_625_(x_14);
lean_ctor_set(x_17, 1, x_23);
lean_ctor_set(x_17, 0, x_22);
x_24 = lean_box(0);
lean_ctor_set_tag(x_15, 1);
lean_ctor_set(x_15, 1, x_24);
x_25 = l_Lean_Json_mkObj(x_15);
x_26 = lean_alloc_closure((void*)(l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___lam__0), 2, 1);
lean_closure_set(x_26, 0, x_25);
x_27 = lean_unbox_uint64(x_20);
lean_dec(x_20);
x_28 = l_Lean_Widget_savePanelWidgetInfo(x_27, x_26, x_10, x_2, x_3, x_4);
lean_dec(x_2);
return x_28;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; uint64_t x_36; lean_object* x_37; 
x_29 = lean_ctor_get(x_17, 1);
lean_inc(x_29);
lean_dec(x_17);
x_30 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
x_31 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonRange____x40_Lean_Data_Lsp_Basic___hyg_625_(x_14);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
x_33 = lean_box(0);
lean_ctor_set_tag(x_15, 1);
lean_ctor_set(x_15, 1, x_33);
lean_ctor_set(x_15, 0, x_32);
x_34 = l_Lean_Json_mkObj(x_15);
x_35 = lean_alloc_closure((void*)(l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___lam__0), 2, 1);
lean_closure_set(x_35, 0, x_34);
x_36 = lean_unbox_uint64(x_29);
lean_dec(x_29);
x_37 = l_Lean_Widget_savePanelWidgetInfo(x_36, x_35, x_10, x_2, x_3, x_4);
lean_dec(x_2);
return x_37;
}
}
else
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; uint64_t x_48; lean_object* x_49; 
x_38 = lean_ctor_get(x_15, 0);
lean_inc(x_38);
lean_dec(x_15);
x_39 = lean_ctor_get(x_38, 1);
lean_inc(x_39);
if (lean_is_exclusive(x_38)) {
 lean_ctor_release(x_38, 0);
 lean_ctor_release(x_38, 1);
 x_40 = x_38;
} else {
 lean_dec_ref(x_38);
 x_40 = lean_box(0);
}
x_41 = l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_;
x_42 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonRange____x40_Lean_Data_Lsp_Basic___hyg_625_(x_14);
if (lean_is_scalar(x_40)) {
 x_43 = lean_alloc_ctor(0, 2, 0);
} else {
 x_43 = x_40;
}
lean_ctor_set(x_43, 0, x_41);
lean_ctor_set(x_43, 1, x_42);
x_44 = lean_box(0);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
x_46 = l_Lean_Json_mkObj(x_45);
x_47 = lean_alloc_closure((void*)(l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___lam__0), 2, 1);
lean_closure_set(x_47, 0, x_46);
x_48 = lean_unbox_uint64(x_39);
lean_dec(x_39);
x_49 = l_Lean_Widget_savePanelWidgetInfo(x_48, x_47, x_10, x_2, x_3, x_4);
lean_dec(x_2);
return x_49;
}
}
}
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg(x_1, x_8, x_9, x_10);
return x_11;
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___redArg(x_1, x_2, x_3, x_4);
lean_dec(x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l___aux__ProofWidgets__Demos__SelectInsertConv______elabRules__tacticConv_x3f__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_9);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_11;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Meta_ExprLens(uint8_t builtin, lean_object*);
lean_object* initialize_Batteries_Lean_Position(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Data_Html(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_OfRpcMethod(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_MakeEditLink(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Panel_Basic(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_SelectInsertConv(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Meta_ExprLens(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Batteries_Lean_Position(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Data_Html(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_OfRpcMethod(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_MakeEditLink(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Panel_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__0);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__1);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__2);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__3);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__4);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__5);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__6 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__6();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__6);
l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__7 = _init_l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__7();
lean_mark_persistent(l___private_Lean_Meta_ExprLens_0__Lean_Core_viewCoordRaw___at___Lean_Core_viewSubexpr___at_____private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel_spec__4_spec__4___closed__7);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__0);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__1);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__2);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__3);
l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4 = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__solveLevel___closed__4);
l_insertEnter___closed__0 = _init_l_insertEnter___closed__0();
lean_mark_persistent(l_insertEnter___closed__0);
l_insertEnter___closed__1 = _init_l_insertEnter___closed__1();
lean_mark_persistent(l_insertEnter___closed__1);
l_insertEnter___closed__2 = _init_l_insertEnter___closed__2();
lean_mark_persistent(l_insertEnter___closed__2);
l_insertEnter___closed__3 = _init_l_insertEnter___closed__3();
lean_mark_persistent(l_insertEnter___closed__3);
l_insertEnter___closed__4 = _init_l_insertEnter___closed__4();
lean_mark_persistent(l_insertEnter___closed__4);
l_insertEnter___closed__5 = _init_l_insertEnter___closed__5();
lean_mark_persistent(l_insertEnter___closed__5);
l_findGoalForLocation___closed__0 = _init_l_findGoalForLocation___closed__0();
lean_mark_persistent(l_findGoalForLocation___closed__0);
l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_ = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_);
l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_ = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_);
l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_ = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_);
l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_ = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_);
l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_ = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__fromJsonRpcEncodablePacket___closed__4____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1555_);
l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_ = _init_l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_);
l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_ = _init_l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_();
lean_mark_persistent(l_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1845_);
l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_ = _init_l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_();
lean_mark_persistent(l___private_ProofWidgets_Demos_SelectInsertConv_0__toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1848_);
l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_ = _init_l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_);
l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_ = _init_l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_();
lean_mark_persistent(l_instToJsonRpcEncodablePacket____x40_ProofWidgets_Demos_SelectInsertConv___hyg_1929_);
l_instRpcEncodableConvSelectionPanelProps___closed__0 = _init_l_instRpcEncodableConvSelectionPanelProps___closed__0();
lean_mark_persistent(l_instRpcEncodableConvSelectionPanelProps___closed__0);
l_instRpcEncodableConvSelectionPanelProps___closed__1 = _init_l_instRpcEncodableConvSelectionPanelProps___closed__1();
lean_mark_persistent(l_instRpcEncodableConvSelectionPanelProps___closed__1);
l_instRpcEncodableConvSelectionPanelProps___closed__2 = _init_l_instRpcEncodableConvSelectionPanelProps___closed__2();
lean_mark_persistent(l_instRpcEncodableConvSelectionPanelProps___closed__2);
l_instRpcEncodableConvSelectionPanelProps = _init_l_instRpcEncodableConvSelectionPanelProps();
lean_mark_persistent(l_instRpcEncodableConvSelectionPanelProps);
l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0 = _init_l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0();
lean_mark_persistent(l_panic___at___ConvSelectionPanel_rpc_spec__0___closed__0);
l_ConvSelectionPanel_rpc___lam__0___closed__0 = _init_l_ConvSelectionPanel_rpc___lam__0___closed__0();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__0___closed__0);
l_ConvSelectionPanel_rpc___lam__2___closed__0 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__0();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__0);
l_ConvSelectionPanel_rpc___lam__2___closed__1 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__1();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__1);
l_ConvSelectionPanel_rpc___lam__2___closed__2 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__2();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__2);
l_ConvSelectionPanel_rpc___lam__2___closed__3 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__3();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__3);
l_ConvSelectionPanel_rpc___lam__2___closed__4 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__4();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__4);
l_ConvSelectionPanel_rpc___lam__2___closed__5 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__5();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__5);
l_ConvSelectionPanel_rpc___lam__2___closed__6 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__6();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__6);
l_ConvSelectionPanel_rpc___lam__2___closed__7 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__7();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__7);
l_ConvSelectionPanel_rpc___lam__2___closed__8 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__8();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__8);
l_ConvSelectionPanel_rpc___lam__2___closed__9 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__9();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__9);
l_ConvSelectionPanel_rpc___lam__2___closed__10 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__10();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__10);
l_ConvSelectionPanel_rpc___lam__2___closed__11 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__11();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__11);
l_ConvSelectionPanel_rpc___lam__2___closed__12 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__12();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__12);
l_ConvSelectionPanel_rpc___lam__2___closed__13 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__13();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__13);
l_ConvSelectionPanel_rpc___lam__2___closed__14 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__14();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__14);
l_ConvSelectionPanel_rpc___lam__2___closed__15 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__15();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__15);
l_ConvSelectionPanel_rpc___lam__2___closed__16 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__16();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__16);
l_ConvSelectionPanel_rpc___lam__2___closed__17 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__17();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__17);
l_ConvSelectionPanel_rpc___lam__2___closed__18 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__18();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__18);
l_ConvSelectionPanel_rpc___lam__2___closed__19 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__19();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__19);
l_ConvSelectionPanel_rpc___lam__2___closed__20 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__20();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__20);
l_ConvSelectionPanel_rpc___lam__2___closed__21 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__21();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__21);
l_ConvSelectionPanel_rpc___lam__2___closed__22 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__22();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__22);
l_ConvSelectionPanel_rpc___lam__2___closed__23 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__23();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__23);
l_ConvSelectionPanel_rpc___lam__2___closed__24 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__24();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__24);
l_ConvSelectionPanel_rpc___lam__2___closed__25 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__25();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__25);
l_ConvSelectionPanel_rpc___lam__2___closed__26 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__26();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__26);
l_ConvSelectionPanel_rpc___lam__2___closed__27 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__27();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__27);
l_ConvSelectionPanel_rpc___lam__2___closed__28 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__28();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__28);
l_ConvSelectionPanel_rpc___lam__2___closed__29 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__29();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__29);
l_ConvSelectionPanel_rpc___lam__2___closed__30 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__30();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__30);
l_ConvSelectionPanel_rpc___lam__2___closed__31 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__31();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__31);
l_ConvSelectionPanel_rpc___lam__2___closed__32 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__32();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__32);
l_ConvSelectionPanel_rpc___lam__2___closed__33 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__33();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__33);
l_ConvSelectionPanel_rpc___lam__2___closed__34 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__34();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__34);
l_ConvSelectionPanel_rpc___lam__2___closed__35 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__35();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__35);
l_ConvSelectionPanel_rpc___lam__2___closed__36 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__36();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__36);
l_ConvSelectionPanel_rpc___lam__2___closed__37 = _init_l_ConvSelectionPanel_rpc___lam__2___closed__37();
lean_mark_persistent(l_ConvSelectionPanel_rpc___lam__2___closed__37);
l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__0 = _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__0();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__0);
l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__1 = _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__1();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__1);
l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__2 = _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__2();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__2);
l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__3 = _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__3();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__3);
l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__4 = _init_l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__4();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ConvSelectionPanel_rpc___rpc__wrapped_spec__0___lam__4___closed__4);
l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0 = _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped___closed__0);
l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1 = _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped___closed__1);
l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2 = _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped___closed__2);
l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3 = _init_l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped___closed__3);
l_ConvSelectionPanel_rpc___rpc__wrapped = _init_l_ConvSelectionPanel_rpc___rpc__wrapped();
lean_mark_persistent(l_ConvSelectionPanel_rpc___rpc__wrapped);
l_ConvSelectionPanel___closed__0 = _init_l_ConvSelectionPanel___closed__0();
lean_mark_persistent(l_ConvSelectionPanel___closed__0);
l_ConvSelectionPanel___closed__1 = _init_l_ConvSelectionPanel___closed__1();
l_ConvSelectionPanel___closed__2___boxed__const__1 = _init_l_ConvSelectionPanel___closed__2___boxed__const__1();
lean_mark_persistent(l_ConvSelectionPanel___closed__2___boxed__const__1);
l_ConvSelectionPanel___closed__2 = _init_l_ConvSelectionPanel___closed__2();
lean_mark_persistent(l_ConvSelectionPanel___closed__2);
l_ConvSelectionPanel___closed__3 = _init_l_ConvSelectionPanel___closed__3();
lean_mark_persistent(l_ConvSelectionPanel___closed__3);
l_ConvSelectionPanel___closed__4 = _init_l_ConvSelectionPanel___closed__4();
lean_mark_persistent(l_ConvSelectionPanel___closed__4);
l_ConvSelectionPanel = _init_l_ConvSelectionPanel();
lean_mark_persistent(l_ConvSelectionPanel);
l_tacticConv_x3f___closed__0 = _init_l_tacticConv_x3f___closed__0();
lean_mark_persistent(l_tacticConv_x3f___closed__0);
l_tacticConv_x3f___closed__1 = _init_l_tacticConv_x3f___closed__1();
lean_mark_persistent(l_tacticConv_x3f___closed__1);
l_tacticConv_x3f___closed__2 = _init_l_tacticConv_x3f___closed__2();
lean_mark_persistent(l_tacticConv_x3f___closed__2);
l_tacticConv_x3f___closed__3 = _init_l_tacticConv_x3f___closed__3();
lean_mark_persistent(l_tacticConv_x3f___closed__3);
l_tacticConv_x3f___closed__4 = _init_l_tacticConv_x3f___closed__4();
lean_mark_persistent(l_tacticConv_x3f___closed__4);
l_tacticConv_x3f = _init_l_tacticConv_x3f();
lean_mark_persistent(l_tacticConv_x3f);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
