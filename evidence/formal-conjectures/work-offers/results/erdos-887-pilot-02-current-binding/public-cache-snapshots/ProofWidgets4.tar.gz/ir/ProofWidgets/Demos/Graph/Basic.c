// Lean compiler output
// Module: ProofWidgets.Demos.Graph.Basic
// Imports: Init ProofWidgets.Component.GraphDisplay ProofWidgets.Component.HtmlDisplay
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
static lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__0;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_K_u2081_u2080;
LEAN_EXPORT lean_object* l_mkEdge___boxed(lean_object*);
static lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__2;
static lean_object* l_K_u2081_u2080___closed__0;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
double lean_float_of_nat(lean_object*);
static lean_object* l_mkEdge___closed__0;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_mkEdge(lean_object*);
lean_object* l_ProofWidgets_GraphDisplay_mkCircle(lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
static lean_object* l_complete___closed__0;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_complete___closed__1;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static double l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__1;
lean_object* lean_nat_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_complete(lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_l_mkEdge___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_mkEdge(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_2 = lean_ctor_get(x_1, 0);
x_3 = lean_ctor_get(x_1, 1);
x_4 = l_mkEdge___closed__0;
x_5 = lean_box(0);
lean_inc(x_3);
lean_inc(x_2);
x_6 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_6, 0, x_2);
lean_ctor_set(x_6, 1, x_3);
lean_ctor_set(x_6, 2, x_4);
lean_ctor_set(x_6, 3, x_5);
lean_ctor_set(x_6, 4, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_mkEdge___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_mkEdge(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; uint8_t x_9; 
x_7 = lean_ctor_get(x_4, 1);
x_8 = lean_ctor_get(x_4, 2);
x_9 = lean_nat_dec_lt(x_6, x_7);
if (x_9 == 0)
{
lean_dec(x_6);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
lean_inc(x_6);
x_10 = l_Nat_reprFast(x_6);
lean_inc_n(x_3, 2);
lean_inc(x_2);
lean_inc(x_10);
lean_inc(x_1);
x_11 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_11, 0, x_1);
lean_ctor_set(x_11, 1, x_10);
lean_ctor_set(x_11, 2, x_2);
lean_ctor_set(x_11, 3, x_3);
lean_ctor_set(x_11, 4, x_3);
x_12 = lean_array_push(x_5, x_11);
lean_inc_n(x_3, 2);
lean_inc(x_2);
lean_inc(x_1);
x_13 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_13, 0, x_10);
lean_ctor_set(x_13, 1, x_1);
lean_ctor_set(x_13, 2, x_2);
lean_ctor_set(x_13, 3, x_3);
lean_ctor_set(x_13, 4, x_3);
x_14 = lean_array_push(x_12, x_13);
x_15 = lean_nat_add(x_6, x_8);
lean_dec(x_6);
x_5 = x_14;
x_6 = x_15;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg(x_1, x_2, x_3, x_4, x_5, x_6);
return x_9;
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_mkEdge___closed__0;
x_2 = l_ProofWidgets_GraphDisplay_mkCircle(x_1);
return x_2;
}
}
static double _init_l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__1() {
_start:
{
lean_object* x_1; double x_2; 
x_1 = lean_unsigned_to_nat(5u);
x_2 = lean_float_of_nat(x_1);
return x_2;
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__2() {
_start:
{
double x_1; lean_object* x_2; 
x_1 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__1;
x_2 = lean_alloc_ctor(0, 0, 8);
lean_ctor_set_float(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; uint8_t x_8; 
x_6 = lean_ctor_get(x_3, 1);
x_7 = lean_ctor_get(x_3, 2);
x_8 = lean_nat_dec_lt(x_5, x_6);
if (x_8 == 0)
{
lean_dec(x_5);
lean_dec(x_2);
lean_dec(x_1);
return x_4;
}
else
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_4);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_10 = lean_ctor_get(x_4, 0);
x_11 = lean_ctor_get(x_4, 1);
lean_inc(x_5);
x_12 = l_Nat_reprFast(x_5);
x_13 = l_mkEdge___closed__0;
x_14 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__0;
x_15 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__2;
x_16 = lean_box(0);
lean_inc(x_12);
x_17 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_17, 0, x_12);
lean_ctor_set(x_17, 1, x_14);
lean_ctor_set(x_17, 2, x_15);
lean_ctor_set(x_17, 3, x_16);
x_18 = lean_array_push(x_11, x_17);
lean_inc(x_2);
lean_inc(x_5);
lean_inc(x_1);
x_19 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_19, 0, x_1);
lean_ctor_set(x_19, 1, x_5);
lean_ctor_set(x_19, 2, x_2);
lean_inc(x_1);
x_20 = l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg(x_12, x_13, x_16, x_19, x_10, x_1);
lean_dec(x_19);
lean_ctor_set(x_4, 1, x_18);
lean_ctor_set(x_4, 0, x_20);
x_21 = lean_nat_add(x_5, x_7);
lean_dec(x_5);
x_5 = x_21;
goto _start;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_23 = lean_ctor_get(x_4, 0);
x_24 = lean_ctor_get(x_4, 1);
lean_inc(x_24);
lean_inc(x_23);
lean_dec(x_4);
lean_inc(x_5);
x_25 = l_Nat_reprFast(x_5);
x_26 = l_mkEdge___closed__0;
x_27 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__0;
x_28 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__2;
x_29 = lean_box(0);
lean_inc(x_25);
x_30 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_30, 0, x_25);
lean_ctor_set(x_30, 1, x_27);
lean_ctor_set(x_30, 2, x_28);
lean_ctor_set(x_30, 3, x_29);
x_31 = lean_array_push(x_24, x_30);
lean_inc(x_2);
lean_inc(x_5);
lean_inc(x_1);
x_32 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_32, 0, x_1);
lean_ctor_set(x_32, 1, x_5);
lean_ctor_set(x_32, 2, x_2);
lean_inc(x_1);
x_33 = l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg(x_25, x_26, x_29, x_32, x_23, x_1);
lean_dec(x_32);
x_34 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_34, 0, x_33);
lean_ctor_set(x_34, 1, x_31);
x_35 = lean_nat_add(x_5, x_7);
lean_dec(x_5);
x_4 = x_34;
x_5 = x_35;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg(x_1, x_2, x_3, x_4, x_5);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__1___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; uint8_t x_8; 
x_6 = lean_ctor_get(x_3, 1);
x_7 = lean_ctor_get(x_3, 2);
x_8 = lean_nat_dec_lt(x_5, x_6);
if (x_8 == 0)
{
lean_dec(x_5);
lean_dec(x_2);
lean_dec(x_1);
return x_4;
}
else
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_4);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_10 = lean_ctor_get(x_4, 0);
x_11 = lean_ctor_get(x_4, 1);
lean_inc(x_5);
x_12 = l_Nat_reprFast(x_5);
x_13 = l_mkEdge___closed__0;
x_14 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__0;
x_15 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__2;
x_16 = lean_box(0);
lean_inc(x_12);
x_17 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_17, 0, x_12);
lean_ctor_set(x_17, 1, x_14);
lean_ctor_set(x_17, 2, x_15);
lean_ctor_set(x_17, 3, x_16);
x_18 = lean_array_push(x_11, x_17);
lean_inc(x_2);
lean_inc(x_5);
lean_inc(x_1);
x_19 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_19, 0, x_1);
lean_ctor_set(x_19, 1, x_5);
lean_ctor_set(x_19, 2, x_2);
lean_inc(x_1);
x_20 = l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg(x_12, x_13, x_16, x_19, x_10, x_1);
lean_dec(x_19);
lean_ctor_set(x_4, 1, x_18);
lean_ctor_set(x_4, 0, x_20);
x_21 = lean_nat_add(x_5, x_7);
lean_dec(x_5);
x_22 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg(x_1, x_2, x_3, x_4, x_21);
return x_22;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_23 = lean_ctor_get(x_4, 0);
x_24 = lean_ctor_get(x_4, 1);
lean_inc(x_24);
lean_inc(x_23);
lean_dec(x_4);
lean_inc(x_5);
x_25 = l_Nat_reprFast(x_5);
x_26 = l_mkEdge___closed__0;
x_27 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__0;
x_28 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__2;
x_29 = lean_box(0);
lean_inc(x_25);
x_30 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_30, 0, x_25);
lean_ctor_set(x_30, 1, x_27);
lean_ctor_set(x_30, 2, x_28);
lean_ctor_set(x_30, 3, x_29);
x_31 = lean_array_push(x_24, x_30);
lean_inc(x_2);
lean_inc(x_5);
lean_inc(x_1);
x_32 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_32, 0, x_1);
lean_ctor_set(x_32, 1, x_5);
lean_ctor_set(x_32, 2, x_2);
lean_inc(x_1);
x_33 = l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg(x_25, x_26, x_29, x_32, x_23, x_1);
lean_dec(x_32);
x_34 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_34, 0, x_33);
lean_ctor_set(x_34, 1, x_31);
x_35 = lean_nat_add(x_5, x_7);
lean_dec(x_5);
x_36 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg(x_1, x_2, x_3, x_34, x_35);
return x_36;
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Std_Range_forIn_x27_loop___at___complete_spec__1___redArg(x_1, x_2, x_3, x_4, x_5);
return x_8;
}
}
static lean_object* _init_l_complete___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_complete___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_complete___closed__0;
x_2 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_complete(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_unsigned_to_nat(1u);
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_2);
lean_ctor_set(x_4, 1, x_1);
lean_ctor_set(x_4, 2, x_3);
x_5 = l_complete___closed__1;
x_6 = l_Std_Range_forIn_x27_loop___at___complete_spec__1___redArg(x_2, x_3, x_4, x_5, x_2);
lean_dec(x_4);
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = lean_ctor_get(x_6, 1);
lean_ctor_set(x_6, 1, x_8);
lean_ctor_set(x_6, 0, x_9);
return x_6;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_6, 0);
x_11 = lean_ctor_get(x_6, 1);
lean_inc(x_11);
lean_inc(x_10);
lean_dec(x_6);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_10);
return x_12;
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_Std_Range_forIn_x27_loop___at___complete_spec__0___redArg(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Std_Range_forIn_x27_loop___at___complete_spec__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_4);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_3);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Std_Range_forIn_x27_loop___at___complete_spec__1___redArg(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___complete_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Std_Range_forIn_x27_loop___at___complete_spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_3);
return x_8;
}
}
static lean_object* _init_l_K_u2081_u2080___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(10u);
x_2 = l_complete(x_1);
return x_2;
}
}
static lean_object* _init_l_K_u2081_u2080() {
_start:
{
lean_object* x_1; 
x_1 = l_K_u2081_u2080___closed__0;
return x_1;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_GraphDisplay(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_HtmlDisplay(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_Graph_Basic(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_GraphDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_HtmlDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_mkEdge___closed__0 = _init_l_mkEdge___closed__0();
lean_mark_persistent(l_mkEdge___closed__0);
l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__0 = _init_l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__0();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__0);
l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__1 = _init_l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__1();
l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__2 = _init_l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__2();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___complete_spec__1_spec__1___redArg___closed__2);
l_complete___closed__0 = _init_l_complete___closed__0();
lean_mark_persistent(l_complete___closed__0);
l_complete___closed__1 = _init_l_complete___closed__1();
lean_mark_persistent(l_complete___closed__1);
l_K_u2081_u2080___closed__0 = _init_l_K_u2081_u2080___closed__0();
lean_mark_persistent(l_K_u2081_u2080___closed__0);
l_K_u2081_u2080 = _init_l_K_u2081_u2080();
lean_mark_persistent(l_K_u2081_u2080);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
