// Lean compiler output
// Module: ProofWidgets.Component.OfRpcMethod
// Imports: Init Lean.Elab.ElabRules ProofWidgets.Component.Basic ProofWidgets.Data.Html ProofWidgets.Cancellable
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Expr_const___override(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__3;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__6;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__38;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__22;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
extern lean_object* l_Lean_Server_builtinRpcProcedures;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__15;
lean_object* l_Lean_indentD(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__11;
lean_object* l_Lean_Elab_Term_elabTerm(lean_object*, lean_object*, uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Meta_isExprDefEq(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__10;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__44;
lean_object* l_Lean_Name_toString(lean_object*, uint8_t, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__18;
lean_object* l_Lean_Elab_Term_elabTermEnsuringType(lean_object*, lean_object*, uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__9;
lean_object* l_Lean_Expr_sort___override(lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__31;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45;
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
lean_object* l_Lean_stringToMessageData(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__42;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__13;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__20;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__7;
lean_object* l_Array_mkArray0(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__10;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__2;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__8;
lean_object* l_Lean_Name_mkStr3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__47;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__5;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__14;
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__1___boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__46;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__17;
lean_object* l_Lean_Elab_Term_withExpectedType(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_liftMacroM___at_____private_Lean_Elab_Term_0__Lean_Elab_Term_elabTermAux_spec__0_spec__4___redArg(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__12;
lean_object* l_Lean_SourceInfo_fromRef(lean_object*, uint8_t);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__48;
lean_object* l_Lean_Syntax_node6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_mkStrLit(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__1;
lean_object* l_Lean_MessageData_ofFormat(lean_object*);
lean_object* lean_st_ref_get(lean_object*, lean_object*);
lean_object* l_Lean_Meta_mkAppM(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__0;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__0;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__49;
extern lean_object* l_ProofWidgets_cancellableSuffix;
lean_object* l_Lean_Syntax_node3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_append(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__24;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__26;
lean_object* l_Lean_addMacroScope(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__28;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__27;
lean_object* l_Lean_Syntax_node2(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__4;
lean_object* l___private_Lean_Meta_Basic_0__Lean_Meta_mkFreshExprMVarImpl(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__23;
extern lean_object* l_Lean_Server_userRpcProcedures;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__34;
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__37;
lean_object* l_Lean_MessageData_ofExpr(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__32;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__39;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__36;
lean_object* l_Lean_instantiateMVars___at___Lean_Elab_Term_MVarErrorInfo_logError_spec__0___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__35;
lean_object* l_Lean_mkArrow___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__40;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__6;
lean_object* l_String_replace(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__33;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__16;
lean_object* l_Lean_Environment_mainModule(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__41;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__8;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__25;
LEAN_EXPORT uint8_t l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0(lean_object*);
lean_object* l_Lean_Syntax_node1(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__3;
extern lean_object* l_Lean_levelOne;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__5;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_termMk__rpc__widget_x25__;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__1;
LEAN_EXPORT uint8_t l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__1(uint8_t, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__9;
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* l_Lean_Name_mkStr4(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ofRpcMethodTemplate;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__7;
uint8_t l_Lean_MapDeclarationExtension_contains___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__19;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__11;
static lean_object* l_ProofWidgets_termMk__rpc__widget_x25_____closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___boxed(lean_object*);
lean_object* l_String_toSubstring_x27(lean_object*);
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__29;
static lean_object* l_ProofWidgets_ofRpcMethodTemplate___closed__0;
static lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__21;
uint8_t l_Lean_PersistentHashMap_contains___at___Lean_SMap_contains___at___Lean_Environment_containsOnBranch_spec__0_spec__0___redArg(lean_object*, lean_object*);
static lean_object* _init_l_ProofWidgets_ofRpcMethodTemplate___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as t,Fragment as n}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as a,EnvPosContext as o,useAsyncPersistent as c,mapRpcError as s,importWidgetModule as i}from\"@leanprover/infoview\";async function l(a,o,c){if(\"text\"in c)return t(n,{children:c.text});if(\"element\"in c){const[e,n,s]=c.element,i={};for(const[e,t]of n)i[e]=t;const u=await Promise.all(s.map((async e=>await l(a,o,e))));return\"hr\"===e\?t(\"hr\",{}):0===u.length\?r.createElement(e,i):r.createElement(e,i,u)}if(\"component\"in c){const[e,t,n,s]=c.component,u=await Promise.all(s.map((async e=>await l(a,o,e)))),m={...n,pos:o},f=await i(a,o,e);if(!(t in f))throw new Error(`Module '${e}' does not export '${t}'`);return 0===u.length\?r.createElement(f[t],m):r.createElement(f[t],m,u)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(c)]})}function u({html:i}){const u=a(),m=r.useContext(o),f=c((()=>l(u,m,i)),[u,m,i]);return\"resolved\"===f.state\?f.value:\"rejected\"===f.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",s(f.error).message]}):t(n,{})}const m=\"$RPC_METHOD\",f=window.toString();var d=r.memo((e=>{const o=a(),i=r.useRef({fn:()=>{}}),l=c((async()=>{if(\"true\"===f){i.current.fn();const[t,n]=function(e,t,n){const r={fn:()=>{}};return[new Promise((async(a,o)=>{const c=await e.call(t,n),s=window.setInterval((async()=>{try{const t=await e.call(\"ProofWidgets.checkRequest\",c);if(\"running\"===t)return;window.clearInterval(s),a(t.done.result)}catch(e){window.clearInterval(s),o(e)}}),100);r.fn=()=>{e.call(\"ProofWidgets.cancelRequest\",c)}})),r]}(o,m,e);return i.current=n,t}return o.call(m,e)}),[o,e]);return r.useEffect((()=>()=>{i.current.fn()}),[]),\"rejected\"===l.state\?t(\"p\",{style:{color:\"red\"},children:s(l.error).message}):\"loading\"===l.state\?t(n,{children:\"Loading..\"}):t(u,{html:l.value})}));export{d as default};", 1881, 1881);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ofRpcMethodTemplate() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_ofRpcMethodTemplate___closed__0;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("termMk_rpc_widget%_", 19, 19);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__1;
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("andthen", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__3;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("mk_rpc_widget%", 14, 14);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__5;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("term", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__7;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__8;
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__9;
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__6;
x_3 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__4;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__10;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__2;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_termMk__rpc__widget_x25__() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__11;
return x_1;
}
}
LEAN_EXPORT uint8_t l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = lean_box(0);
x_3 = lean_unbox(x_2);
return x_3;
}
}
LEAN_EXPORT uint8_t l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__1(uint8_t x_1, lean_object* x_2) {
_start:
{
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("$RPC_METHOD", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window.toString()", 17, 17);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("'false'", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Parser", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Term", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInst", 10, 10);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("{", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("null", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__7;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = l_Array_mkArray0(lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstFields", 16, 16);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstField", 15, 15);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstLVal", 14, 14);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("javascript", 10, 10);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__13;
x_2 = l_String_toSubstring_x27(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__13;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__16() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstFieldDef", 18, 18);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__17() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(":=", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__18() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("optEllipsis", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__19() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("}", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__20() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("'", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__21() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("' is not a known RPC method. Use `@[server_rpc_method]` to register it.", 71, 71);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__22() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("'true'", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Lean_levelOne;
x_2 = l_Lean_Expr_sort___override(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__24() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__23;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__25() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("α", 2, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__25;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__27() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Component", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__28() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__27;
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__29() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Lean", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__31() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Server", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__32() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("RequestTask", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__33() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__32;
x_2 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__31;
x_3 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30;
x_4 = l_Lean_Name_mkStr3(x_3, x_2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__34() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Html", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__35() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__34;
x_2 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__36() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__35;
x_3 = l_Lean_Expr_const___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__37() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__36;
x_2 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__29;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__38() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("RequestM", 8, 8);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__39() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__38;
x_2 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__31;
x_3 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30;
x_4 = l_Lean_Name_mkStr3(x_3, x_2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__40() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_Server_builtinRpcProcedures;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__41() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_Server_userRpcProcedures;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__42() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Expected the name of a constant, got a complex term", 51, 51);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__42;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__44() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("", 0, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__44;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__46() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expected type", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__47() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__46;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__48() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\nis not of the form", 19, 19);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__49() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__48;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; uint8_t x_12; lean_object* x_13; lean_object* x_14; uint8_t x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; lean_object* x_140; lean_object* x_141; lean_object* x_142; lean_object* x_143; lean_object* x_144; uint8_t x_145; lean_object* x_146; lean_object* x_147; lean_object* x_148; uint8_t x_149; lean_object* x_164; lean_object* x_165; lean_object* x_166; lean_object* x_167; lean_object* x_168; lean_object* x_169; lean_object* x_170; lean_object* x_171; lean_object* x_172; uint8_t x_173; 
x_11 = l_ProofWidgets_termMk__rpc__widget_x25_____closed__2;
lean_inc(x_1);
x_12 = l_Lean_Syntax_isOfKind(x_1, x_11);
if (x_12 == 0)
{
lean_object* x_288; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_288 = l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_liftMacroM___at_____private_Lean_Elab_Term_0__Lean_Elab_Term_elabTermAux_spec__0_spec__4___redArg(x_10);
return x_288;
}
else
{
lean_object* x_289; lean_object* x_290; lean_object* x_291; uint8_t x_292; lean_object* x_293; uint8_t x_294; 
x_289 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__24;
x_290 = lean_box(0);
x_291 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__26;
x_292 = lean_unbox(x_290);
lean_inc(x_6);
x_293 = l___private_Lean_Meta_Basic_0__Lean_Meta_mkFreshExprMVarImpl(x_289, x_292, x_291, x_6, x_7, x_8, x_9, x_10);
x_294 = !lean_is_exclusive(x_293);
if (x_294 == 0)
{
lean_object* x_295; lean_object* x_296; lean_object* x_297; lean_object* x_298; lean_object* x_299; lean_object* x_300; lean_object* x_301; 
x_295 = lean_ctor_get(x_293, 0);
x_296 = lean_ctor_get(x_293, 1);
x_297 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__28;
x_298 = lean_unsigned_to_nat(1u);
x_299 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__29;
lean_inc(x_295);
x_300 = lean_array_push(x_299, x_295);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
x_301 = l_Lean_Meta_mkAppM(x_297, x_300, x_6, x_7, x_8, x_9, x_296);
if (lean_obj_tag(x_301) == 0)
{
uint8_t x_302; 
x_302 = !lean_is_exclusive(x_301);
if (x_302 == 0)
{
lean_object* x_303; lean_object* x_304; lean_object* x_305; 
x_303 = lean_ctor_get(x_301, 0);
x_304 = lean_ctor_get(x_301, 1);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_303);
lean_inc(x_3);
x_305 = l_Lean_Meta_isExprDefEq(x_3, x_303, x_6, x_7, x_8, x_9, x_304);
if (lean_obj_tag(x_305) == 0)
{
lean_object* x_306; lean_object* x_307; lean_object* x_308; lean_object* x_309; lean_object* x_310; lean_object* x_311; lean_object* x_312; lean_object* x_313; lean_object* x_314; lean_object* x_315; uint8_t x_419; 
x_306 = lean_ctor_get(x_305, 0);
lean_inc(x_306);
x_307 = lean_ctor_get(x_305, 1);
lean_inc(x_307);
lean_dec(x_305);
x_308 = l_Lean_Syntax_getArg(x_1, x_298);
lean_dec(x_1);
x_419 = lean_unbox(x_306);
lean_dec(x_306);
if (x_419 == 0)
{
if (x_12 == 0)
{
lean_free_object(x_301);
lean_dec(x_303);
lean_free_object(x_293);
x_309 = x_4;
x_310 = x_5;
x_311 = x_6;
x_312 = x_7;
x_313 = x_8;
x_314 = x_9;
x_315 = x_307;
goto block_418;
}
else
{
lean_object* x_420; lean_object* x_421; lean_object* x_422; lean_object* x_423; lean_object* x_424; lean_object* x_425; lean_object* x_426; lean_object* x_427; lean_object* x_428; lean_object* x_429; uint8_t x_430; 
lean_dec(x_308);
lean_dec(x_295);
lean_dec(x_2);
x_420 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__47;
x_421 = l_Lean_MessageData_ofExpr(x_3);
x_422 = l_Lean_indentD(x_421);
lean_ctor_set_tag(x_301, 7);
lean_ctor_set(x_301, 1, x_422);
lean_ctor_set(x_301, 0, x_420);
x_423 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__49;
lean_ctor_set_tag(x_293, 7);
lean_ctor_set(x_293, 1, x_423);
lean_ctor_set(x_293, 0, x_301);
x_424 = l_Lean_MessageData_ofExpr(x_303);
x_425 = l_Lean_indentD(x_424);
x_426 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_426, 0, x_293);
lean_ctor_set(x_426, 1, x_425);
x_427 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45;
x_428 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_428, 0, x_426);
lean_ctor_set(x_428, 1, x_427);
x_429 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_428, x_4, x_5, x_6, x_7, x_8, x_9, x_307);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
x_430 = !lean_is_exclusive(x_429);
if (x_430 == 0)
{
return x_429;
}
else
{
lean_object* x_431; lean_object* x_432; lean_object* x_433; 
x_431 = lean_ctor_get(x_429, 0);
x_432 = lean_ctor_get(x_429, 1);
lean_inc(x_432);
lean_inc(x_431);
lean_dec(x_429);
x_433 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_433, 0, x_431);
lean_ctor_set(x_433, 1, x_432);
return x_433;
}
}
}
else
{
lean_free_object(x_301);
lean_dec(x_303);
lean_free_object(x_293);
x_309 = x_4;
x_310 = x_5;
x_311 = x_6;
x_312 = x_7;
x_313 = x_8;
x_314 = x_9;
x_315 = x_307;
goto block_418;
}
block_418:
{
lean_object* x_316; lean_object* x_317; lean_object* x_318; lean_object* x_319; 
x_316 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30;
x_317 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__33;
x_318 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__37;
lean_inc(x_314);
lean_inc(x_313);
lean_inc(x_312);
lean_inc(x_311);
x_319 = l_Lean_Meta_mkAppM(x_317, x_318, x_311, x_312, x_313, x_314, x_315);
if (lean_obj_tag(x_319) == 0)
{
lean_object* x_320; lean_object* x_321; lean_object* x_322; lean_object* x_323; lean_object* x_324; 
x_320 = lean_ctor_get(x_319, 0);
lean_inc(x_320);
x_321 = lean_ctor_get(x_319, 1);
lean_inc(x_321);
lean_dec(x_319);
x_322 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__39;
x_323 = lean_array_push(x_299, x_320);
lean_inc(x_314);
lean_inc(x_313);
lean_inc(x_312);
lean_inc(x_311);
x_324 = l_Lean_Meta_mkAppM(x_322, x_323, x_311, x_312, x_313, x_314, x_321);
if (lean_obj_tag(x_324) == 0)
{
lean_object* x_325; lean_object* x_326; lean_object* x_327; lean_object* x_328; lean_object* x_329; lean_object* x_330; lean_object* x_331; lean_object* x_332; 
x_325 = lean_ctor_get(x_324, 0);
lean_inc(x_325);
x_326 = lean_ctor_get(x_324, 1);
lean_inc(x_326);
lean_dec(x_324);
x_327 = l_Lean_mkArrow___redArg(x_295, x_325, x_314, x_326);
x_328 = lean_ctor_get(x_327, 0);
lean_inc(x_328);
x_329 = lean_ctor_get(x_327, 1);
lean_inc(x_329);
lean_dec(x_327);
x_330 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_330, 0, x_328);
x_331 = lean_box(0);
lean_inc(x_314);
lean_inc(x_313);
lean_inc(x_312);
lean_inc(x_311);
lean_inc(x_310);
lean_inc(x_309);
x_332 = l_Lean_Elab_Term_elabTermEnsuringType(x_308, x_330, x_12, x_12, x_331, x_309, x_310, x_311, x_312, x_313, x_314, x_329);
if (lean_obj_tag(x_332) == 0)
{
uint8_t x_333; 
x_333 = !lean_is_exclusive(x_332);
if (x_333 == 0)
{
lean_object* x_334; lean_object* x_335; lean_object* x_336; lean_object* x_337; 
x_334 = lean_ctor_get(x_332, 0);
x_335 = lean_ctor_get(x_332, 1);
x_336 = l_Lean_instantiateMVars___at___Lean_Elab_Term_MVarErrorInfo_logError_spec__0___redArg(x_334, x_312, x_335);
x_337 = lean_ctor_get(x_336, 0);
lean_inc(x_337);
if (lean_obj_tag(x_337) == 4)
{
lean_object* x_338; lean_object* x_339; lean_object* x_340; lean_object* x_341; lean_object* x_342; lean_object* x_343; lean_object* x_344; lean_object* x_345; lean_object* x_346; lean_object* x_347; lean_object* x_348; uint8_t x_349; 
lean_free_object(x_332);
x_338 = lean_ctor_get(x_336, 1);
lean_inc(x_338);
lean_dec(x_336);
x_339 = lean_ctor_get(x_337, 0);
lean_inc(x_339);
lean_dec(x_337);
x_340 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__40;
x_341 = lean_st_ref_get(x_340, x_338);
x_342 = lean_ctor_get(x_341, 0);
lean_inc(x_342);
x_343 = lean_ctor_get(x_341, 1);
lean_inc(x_343);
lean_dec(x_341);
x_344 = lean_st_ref_get(x_314, x_343);
x_345 = lean_ctor_get(x_344, 0);
lean_inc(x_345);
x_346 = lean_ctor_get(x_344, 1);
lean_inc(x_346);
lean_dec(x_344);
x_347 = l_ProofWidgets_cancellableSuffix;
lean_inc(x_339);
x_348 = l_Lean_Name_append(x_339, x_347);
x_349 = l_Lean_PersistentHashMap_contains___at___Lean_SMap_contains___at___Lean_Environment_containsOnBranch_spec__0_spec__0___redArg(x_342, x_348);
if (x_349 == 0)
{
lean_object* x_350; lean_object* x_351; lean_object* x_352; uint8_t x_353; 
x_350 = lean_ctor_get(x_345, 0);
lean_inc(x_350);
lean_dec(x_345);
x_351 = lean_box(0);
x_352 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__41;
lean_inc(x_348);
x_353 = l_Lean_MapDeclarationExtension_contains___redArg(x_351, x_352, x_350, x_348);
if (x_353 == 0)
{
lean_object* x_354; lean_object* x_355; lean_object* x_356; lean_object* x_357; lean_object* x_358; lean_object* x_359; lean_object* x_360; lean_object* x_361; lean_object* x_362; uint8_t x_363; 
lean_dec(x_348);
lean_dec(x_2);
x_354 = lean_st_ref_get(x_340, x_346);
x_355 = lean_ctor_get(x_354, 0);
lean_inc(x_355);
x_356 = lean_ctor_get(x_354, 1);
lean_inc(x_356);
lean_dec(x_354);
x_357 = lean_st_ref_get(x_314, x_356);
x_358 = lean_ctor_get(x_357, 0);
lean_inc(x_358);
x_359 = lean_ctor_get(x_357, 1);
lean_inc(x_359);
lean_dec(x_357);
x_360 = lean_ctor_get(x_358, 0);
lean_inc(x_360);
lean_dec(x_358);
x_361 = lean_box(x_353);
x_362 = lean_alloc_closure((void*)(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__1___boxed), 2, 1);
lean_closure_set(x_362, 0, x_361);
x_363 = l_Lean_PersistentHashMap_contains___at___Lean_SMap_contains___at___Lean_Environment_containsOnBranch_spec__0_spec__0___redArg(x_355, x_339);
if (x_363 == 0)
{
lean_inc(x_362);
x_134 = x_312;
x_135 = x_360;
x_136 = x_311;
x_137 = x_352;
x_138 = x_310;
x_139 = x_313;
x_140 = x_309;
x_141 = x_314;
x_142 = x_359;
x_143 = x_339;
x_144 = x_316;
x_145 = x_353;
x_146 = x_362;
x_147 = x_362;
x_148 = x_351;
x_149 = x_12;
goto block_163;
}
else
{
lean_inc(x_362);
x_134 = x_312;
x_135 = x_360;
x_136 = x_311;
x_137 = x_352;
x_138 = x_310;
x_139 = x_313;
x_140 = x_309;
x_141 = x_314;
x_142 = x_359;
x_143 = x_339;
x_144 = x_316;
x_145 = x_353;
x_146 = x_362;
x_147 = x_362;
x_148 = x_351;
x_149 = x_353;
goto block_163;
}
}
else
{
lean_dec(x_339);
x_164 = x_346;
x_165 = x_312;
x_166 = x_311;
x_167 = x_310;
x_168 = x_316;
x_169 = x_313;
x_170 = x_348;
x_171 = x_309;
x_172 = x_314;
x_173 = x_353;
goto block_287;
}
}
else
{
lean_dec(x_345);
lean_dec(x_339);
x_164 = x_346;
x_165 = x_312;
x_166 = x_311;
x_167 = x_310;
x_168 = x_316;
x_169 = x_313;
x_170 = x_348;
x_171 = x_309;
x_172 = x_314;
x_173 = x_12;
goto block_287;
}
}
else
{
uint8_t x_364; 
lean_dec(x_3);
lean_dec(x_2);
x_364 = !lean_is_exclusive(x_336);
if (x_364 == 0)
{
lean_object* x_365; lean_object* x_366; lean_object* x_367; lean_object* x_368; lean_object* x_369; lean_object* x_370; lean_object* x_371; 
x_365 = lean_ctor_get(x_336, 1);
x_366 = lean_ctor_get(x_336, 0);
lean_dec(x_366);
x_367 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43;
x_368 = l_Lean_MessageData_ofExpr(x_337);
x_369 = l_Lean_indentD(x_368);
lean_ctor_set_tag(x_336, 7);
lean_ctor_set(x_336, 1, x_369);
lean_ctor_set(x_336, 0, x_367);
x_370 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45;
lean_ctor_set_tag(x_332, 7);
lean_ctor_set(x_332, 1, x_370);
lean_ctor_set(x_332, 0, x_336);
x_371 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_332, x_309, x_310, x_311, x_312, x_313, x_314, x_365);
lean_dec(x_314);
lean_dec(x_313);
lean_dec(x_312);
lean_dec(x_311);
lean_dec(x_310);
return x_371;
}
else
{
lean_object* x_372; lean_object* x_373; lean_object* x_374; lean_object* x_375; lean_object* x_376; lean_object* x_377; lean_object* x_378; 
x_372 = lean_ctor_get(x_336, 1);
lean_inc(x_372);
lean_dec(x_336);
x_373 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43;
x_374 = l_Lean_MessageData_ofExpr(x_337);
x_375 = l_Lean_indentD(x_374);
x_376 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_376, 0, x_373);
lean_ctor_set(x_376, 1, x_375);
x_377 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45;
lean_ctor_set_tag(x_332, 7);
lean_ctor_set(x_332, 1, x_377);
lean_ctor_set(x_332, 0, x_376);
x_378 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_332, x_309, x_310, x_311, x_312, x_313, x_314, x_372);
lean_dec(x_314);
lean_dec(x_313);
lean_dec(x_312);
lean_dec(x_311);
lean_dec(x_310);
return x_378;
}
}
}
else
{
lean_object* x_379; lean_object* x_380; lean_object* x_381; lean_object* x_382; 
x_379 = lean_ctor_get(x_332, 0);
x_380 = lean_ctor_get(x_332, 1);
lean_inc(x_380);
lean_inc(x_379);
lean_dec(x_332);
x_381 = l_Lean_instantiateMVars___at___Lean_Elab_Term_MVarErrorInfo_logError_spec__0___redArg(x_379, x_312, x_380);
x_382 = lean_ctor_get(x_381, 0);
lean_inc(x_382);
if (lean_obj_tag(x_382) == 4)
{
lean_object* x_383; lean_object* x_384; lean_object* x_385; lean_object* x_386; lean_object* x_387; lean_object* x_388; lean_object* x_389; lean_object* x_390; lean_object* x_391; lean_object* x_392; lean_object* x_393; uint8_t x_394; 
x_383 = lean_ctor_get(x_381, 1);
lean_inc(x_383);
lean_dec(x_381);
x_384 = lean_ctor_get(x_382, 0);
lean_inc(x_384);
lean_dec(x_382);
x_385 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__40;
x_386 = lean_st_ref_get(x_385, x_383);
x_387 = lean_ctor_get(x_386, 0);
lean_inc(x_387);
x_388 = lean_ctor_get(x_386, 1);
lean_inc(x_388);
lean_dec(x_386);
x_389 = lean_st_ref_get(x_314, x_388);
x_390 = lean_ctor_get(x_389, 0);
lean_inc(x_390);
x_391 = lean_ctor_get(x_389, 1);
lean_inc(x_391);
lean_dec(x_389);
x_392 = l_ProofWidgets_cancellableSuffix;
lean_inc(x_384);
x_393 = l_Lean_Name_append(x_384, x_392);
x_394 = l_Lean_PersistentHashMap_contains___at___Lean_SMap_contains___at___Lean_Environment_containsOnBranch_spec__0_spec__0___redArg(x_387, x_393);
if (x_394 == 0)
{
lean_object* x_395; lean_object* x_396; lean_object* x_397; uint8_t x_398; 
x_395 = lean_ctor_get(x_390, 0);
lean_inc(x_395);
lean_dec(x_390);
x_396 = lean_box(0);
x_397 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__41;
lean_inc(x_393);
x_398 = l_Lean_MapDeclarationExtension_contains___redArg(x_396, x_397, x_395, x_393);
if (x_398 == 0)
{
lean_object* x_399; lean_object* x_400; lean_object* x_401; lean_object* x_402; lean_object* x_403; lean_object* x_404; lean_object* x_405; lean_object* x_406; lean_object* x_407; uint8_t x_408; 
lean_dec(x_393);
lean_dec(x_2);
x_399 = lean_st_ref_get(x_385, x_391);
x_400 = lean_ctor_get(x_399, 0);
lean_inc(x_400);
x_401 = lean_ctor_get(x_399, 1);
lean_inc(x_401);
lean_dec(x_399);
x_402 = lean_st_ref_get(x_314, x_401);
x_403 = lean_ctor_get(x_402, 0);
lean_inc(x_403);
x_404 = lean_ctor_get(x_402, 1);
lean_inc(x_404);
lean_dec(x_402);
x_405 = lean_ctor_get(x_403, 0);
lean_inc(x_405);
lean_dec(x_403);
x_406 = lean_box(x_398);
x_407 = lean_alloc_closure((void*)(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__1___boxed), 2, 1);
lean_closure_set(x_407, 0, x_406);
x_408 = l_Lean_PersistentHashMap_contains___at___Lean_SMap_contains___at___Lean_Environment_containsOnBranch_spec__0_spec__0___redArg(x_400, x_384);
if (x_408 == 0)
{
lean_inc(x_407);
x_134 = x_312;
x_135 = x_405;
x_136 = x_311;
x_137 = x_397;
x_138 = x_310;
x_139 = x_313;
x_140 = x_309;
x_141 = x_314;
x_142 = x_404;
x_143 = x_384;
x_144 = x_316;
x_145 = x_398;
x_146 = x_407;
x_147 = x_407;
x_148 = x_396;
x_149 = x_12;
goto block_163;
}
else
{
lean_inc(x_407);
x_134 = x_312;
x_135 = x_405;
x_136 = x_311;
x_137 = x_397;
x_138 = x_310;
x_139 = x_313;
x_140 = x_309;
x_141 = x_314;
x_142 = x_404;
x_143 = x_384;
x_144 = x_316;
x_145 = x_398;
x_146 = x_407;
x_147 = x_407;
x_148 = x_396;
x_149 = x_398;
goto block_163;
}
}
else
{
lean_dec(x_384);
x_164 = x_391;
x_165 = x_312;
x_166 = x_311;
x_167 = x_310;
x_168 = x_316;
x_169 = x_313;
x_170 = x_393;
x_171 = x_309;
x_172 = x_314;
x_173 = x_398;
goto block_287;
}
}
else
{
lean_dec(x_390);
lean_dec(x_384);
x_164 = x_391;
x_165 = x_312;
x_166 = x_311;
x_167 = x_310;
x_168 = x_316;
x_169 = x_313;
x_170 = x_393;
x_171 = x_309;
x_172 = x_314;
x_173 = x_12;
goto block_287;
}
}
else
{
lean_object* x_409; lean_object* x_410; lean_object* x_411; lean_object* x_412; lean_object* x_413; lean_object* x_414; lean_object* x_415; lean_object* x_416; lean_object* x_417; 
lean_dec(x_3);
lean_dec(x_2);
x_409 = lean_ctor_get(x_381, 1);
lean_inc(x_409);
if (lean_is_exclusive(x_381)) {
 lean_ctor_release(x_381, 0);
 lean_ctor_release(x_381, 1);
 x_410 = x_381;
} else {
 lean_dec_ref(x_381);
 x_410 = lean_box(0);
}
x_411 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43;
x_412 = l_Lean_MessageData_ofExpr(x_382);
x_413 = l_Lean_indentD(x_412);
if (lean_is_scalar(x_410)) {
 x_414 = lean_alloc_ctor(7, 2, 0);
} else {
 x_414 = x_410;
 lean_ctor_set_tag(x_414, 7);
}
lean_ctor_set(x_414, 0, x_411);
lean_ctor_set(x_414, 1, x_413);
x_415 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45;
x_416 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_416, 0, x_414);
lean_ctor_set(x_416, 1, x_415);
x_417 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_416, x_309, x_310, x_311, x_312, x_313, x_314, x_409);
lean_dec(x_314);
lean_dec(x_313);
lean_dec(x_312);
lean_dec(x_311);
lean_dec(x_310);
return x_417;
}
}
}
else
{
lean_dec(x_314);
lean_dec(x_313);
lean_dec(x_312);
lean_dec(x_311);
lean_dec(x_310);
lean_dec(x_309);
lean_dec(x_3);
lean_dec(x_2);
return x_332;
}
}
else
{
lean_dec(x_314);
lean_dec(x_313);
lean_dec(x_312);
lean_dec(x_311);
lean_dec(x_310);
lean_dec(x_309);
lean_dec(x_308);
lean_dec(x_295);
lean_dec(x_3);
lean_dec(x_2);
return x_324;
}
}
else
{
lean_dec(x_314);
lean_dec(x_313);
lean_dec(x_312);
lean_dec(x_311);
lean_dec(x_310);
lean_dec(x_309);
lean_dec(x_308);
lean_dec(x_295);
lean_dec(x_3);
lean_dec(x_2);
return x_319;
}
}
}
else
{
uint8_t x_434; 
lean_free_object(x_301);
lean_dec(x_303);
lean_free_object(x_293);
lean_dec(x_295);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_434 = !lean_is_exclusive(x_305);
if (x_434 == 0)
{
return x_305;
}
else
{
lean_object* x_435; lean_object* x_436; lean_object* x_437; 
x_435 = lean_ctor_get(x_305, 0);
x_436 = lean_ctor_get(x_305, 1);
lean_inc(x_436);
lean_inc(x_435);
lean_dec(x_305);
x_437 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_437, 0, x_435);
lean_ctor_set(x_437, 1, x_436);
return x_437;
}
}
}
else
{
lean_object* x_438; lean_object* x_439; lean_object* x_440; 
x_438 = lean_ctor_get(x_301, 0);
x_439 = lean_ctor_get(x_301, 1);
lean_inc(x_439);
lean_inc(x_438);
lean_dec(x_301);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_438);
lean_inc(x_3);
x_440 = l_Lean_Meta_isExprDefEq(x_3, x_438, x_6, x_7, x_8, x_9, x_439);
if (lean_obj_tag(x_440) == 0)
{
lean_object* x_441; lean_object* x_442; lean_object* x_443; lean_object* x_444; lean_object* x_445; lean_object* x_446; lean_object* x_447; lean_object* x_448; lean_object* x_449; lean_object* x_450; uint8_t x_509; 
x_441 = lean_ctor_get(x_440, 0);
lean_inc(x_441);
x_442 = lean_ctor_get(x_440, 1);
lean_inc(x_442);
lean_dec(x_440);
x_443 = l_Lean_Syntax_getArg(x_1, x_298);
lean_dec(x_1);
x_509 = lean_unbox(x_441);
lean_dec(x_441);
if (x_509 == 0)
{
if (x_12 == 0)
{
lean_dec(x_438);
lean_free_object(x_293);
x_444 = x_4;
x_445 = x_5;
x_446 = x_6;
x_447 = x_7;
x_448 = x_8;
x_449 = x_9;
x_450 = x_442;
goto block_508;
}
else
{
lean_object* x_510; lean_object* x_511; lean_object* x_512; lean_object* x_513; lean_object* x_514; lean_object* x_515; lean_object* x_516; lean_object* x_517; lean_object* x_518; lean_object* x_519; lean_object* x_520; lean_object* x_521; lean_object* x_522; lean_object* x_523; lean_object* x_524; 
lean_dec(x_443);
lean_dec(x_295);
lean_dec(x_2);
x_510 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__47;
x_511 = l_Lean_MessageData_ofExpr(x_3);
x_512 = l_Lean_indentD(x_511);
x_513 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_513, 0, x_510);
lean_ctor_set(x_513, 1, x_512);
x_514 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__49;
lean_ctor_set_tag(x_293, 7);
lean_ctor_set(x_293, 1, x_514);
lean_ctor_set(x_293, 0, x_513);
x_515 = l_Lean_MessageData_ofExpr(x_438);
x_516 = l_Lean_indentD(x_515);
x_517 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_517, 0, x_293);
lean_ctor_set(x_517, 1, x_516);
x_518 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45;
x_519 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_519, 0, x_517);
lean_ctor_set(x_519, 1, x_518);
x_520 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_519, x_4, x_5, x_6, x_7, x_8, x_9, x_442);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
x_521 = lean_ctor_get(x_520, 0);
lean_inc(x_521);
x_522 = lean_ctor_get(x_520, 1);
lean_inc(x_522);
if (lean_is_exclusive(x_520)) {
 lean_ctor_release(x_520, 0);
 lean_ctor_release(x_520, 1);
 x_523 = x_520;
} else {
 lean_dec_ref(x_520);
 x_523 = lean_box(0);
}
if (lean_is_scalar(x_523)) {
 x_524 = lean_alloc_ctor(1, 2, 0);
} else {
 x_524 = x_523;
}
lean_ctor_set(x_524, 0, x_521);
lean_ctor_set(x_524, 1, x_522);
return x_524;
}
}
else
{
lean_dec(x_438);
lean_free_object(x_293);
x_444 = x_4;
x_445 = x_5;
x_446 = x_6;
x_447 = x_7;
x_448 = x_8;
x_449 = x_9;
x_450 = x_442;
goto block_508;
}
block_508:
{
lean_object* x_451; lean_object* x_452; lean_object* x_453; lean_object* x_454; 
x_451 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30;
x_452 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__33;
x_453 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__37;
lean_inc(x_449);
lean_inc(x_448);
lean_inc(x_447);
lean_inc(x_446);
x_454 = l_Lean_Meta_mkAppM(x_452, x_453, x_446, x_447, x_448, x_449, x_450);
if (lean_obj_tag(x_454) == 0)
{
lean_object* x_455; lean_object* x_456; lean_object* x_457; lean_object* x_458; lean_object* x_459; 
x_455 = lean_ctor_get(x_454, 0);
lean_inc(x_455);
x_456 = lean_ctor_get(x_454, 1);
lean_inc(x_456);
lean_dec(x_454);
x_457 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__39;
x_458 = lean_array_push(x_299, x_455);
lean_inc(x_449);
lean_inc(x_448);
lean_inc(x_447);
lean_inc(x_446);
x_459 = l_Lean_Meta_mkAppM(x_457, x_458, x_446, x_447, x_448, x_449, x_456);
if (lean_obj_tag(x_459) == 0)
{
lean_object* x_460; lean_object* x_461; lean_object* x_462; lean_object* x_463; lean_object* x_464; lean_object* x_465; lean_object* x_466; lean_object* x_467; 
x_460 = lean_ctor_get(x_459, 0);
lean_inc(x_460);
x_461 = lean_ctor_get(x_459, 1);
lean_inc(x_461);
lean_dec(x_459);
x_462 = l_Lean_mkArrow___redArg(x_295, x_460, x_449, x_461);
x_463 = lean_ctor_get(x_462, 0);
lean_inc(x_463);
x_464 = lean_ctor_get(x_462, 1);
lean_inc(x_464);
lean_dec(x_462);
x_465 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_465, 0, x_463);
x_466 = lean_box(0);
lean_inc(x_449);
lean_inc(x_448);
lean_inc(x_447);
lean_inc(x_446);
lean_inc(x_445);
lean_inc(x_444);
x_467 = l_Lean_Elab_Term_elabTermEnsuringType(x_443, x_465, x_12, x_12, x_466, x_444, x_445, x_446, x_447, x_448, x_449, x_464);
if (lean_obj_tag(x_467) == 0)
{
lean_object* x_468; lean_object* x_469; lean_object* x_470; lean_object* x_471; lean_object* x_472; 
x_468 = lean_ctor_get(x_467, 0);
lean_inc(x_468);
x_469 = lean_ctor_get(x_467, 1);
lean_inc(x_469);
if (lean_is_exclusive(x_467)) {
 lean_ctor_release(x_467, 0);
 lean_ctor_release(x_467, 1);
 x_470 = x_467;
} else {
 lean_dec_ref(x_467);
 x_470 = lean_box(0);
}
x_471 = l_Lean_instantiateMVars___at___Lean_Elab_Term_MVarErrorInfo_logError_spec__0___redArg(x_468, x_447, x_469);
x_472 = lean_ctor_get(x_471, 0);
lean_inc(x_472);
if (lean_obj_tag(x_472) == 4)
{
lean_object* x_473; lean_object* x_474; lean_object* x_475; lean_object* x_476; lean_object* x_477; lean_object* x_478; lean_object* x_479; lean_object* x_480; lean_object* x_481; lean_object* x_482; lean_object* x_483; uint8_t x_484; 
lean_dec(x_470);
x_473 = lean_ctor_get(x_471, 1);
lean_inc(x_473);
lean_dec(x_471);
x_474 = lean_ctor_get(x_472, 0);
lean_inc(x_474);
lean_dec(x_472);
x_475 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__40;
x_476 = lean_st_ref_get(x_475, x_473);
x_477 = lean_ctor_get(x_476, 0);
lean_inc(x_477);
x_478 = lean_ctor_get(x_476, 1);
lean_inc(x_478);
lean_dec(x_476);
x_479 = lean_st_ref_get(x_449, x_478);
x_480 = lean_ctor_get(x_479, 0);
lean_inc(x_480);
x_481 = lean_ctor_get(x_479, 1);
lean_inc(x_481);
lean_dec(x_479);
x_482 = l_ProofWidgets_cancellableSuffix;
lean_inc(x_474);
x_483 = l_Lean_Name_append(x_474, x_482);
x_484 = l_Lean_PersistentHashMap_contains___at___Lean_SMap_contains___at___Lean_Environment_containsOnBranch_spec__0_spec__0___redArg(x_477, x_483);
if (x_484 == 0)
{
lean_object* x_485; lean_object* x_486; lean_object* x_487; uint8_t x_488; 
x_485 = lean_ctor_get(x_480, 0);
lean_inc(x_485);
lean_dec(x_480);
x_486 = lean_box(0);
x_487 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__41;
lean_inc(x_483);
x_488 = l_Lean_MapDeclarationExtension_contains___redArg(x_486, x_487, x_485, x_483);
if (x_488 == 0)
{
lean_object* x_489; lean_object* x_490; lean_object* x_491; lean_object* x_492; lean_object* x_493; lean_object* x_494; lean_object* x_495; lean_object* x_496; lean_object* x_497; uint8_t x_498; 
lean_dec(x_483);
lean_dec(x_2);
x_489 = lean_st_ref_get(x_475, x_481);
x_490 = lean_ctor_get(x_489, 0);
lean_inc(x_490);
x_491 = lean_ctor_get(x_489, 1);
lean_inc(x_491);
lean_dec(x_489);
x_492 = lean_st_ref_get(x_449, x_491);
x_493 = lean_ctor_get(x_492, 0);
lean_inc(x_493);
x_494 = lean_ctor_get(x_492, 1);
lean_inc(x_494);
lean_dec(x_492);
x_495 = lean_ctor_get(x_493, 0);
lean_inc(x_495);
lean_dec(x_493);
x_496 = lean_box(x_488);
x_497 = lean_alloc_closure((void*)(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__1___boxed), 2, 1);
lean_closure_set(x_497, 0, x_496);
x_498 = l_Lean_PersistentHashMap_contains___at___Lean_SMap_contains___at___Lean_Environment_containsOnBranch_spec__0_spec__0___redArg(x_490, x_474);
if (x_498 == 0)
{
lean_inc(x_497);
x_134 = x_447;
x_135 = x_495;
x_136 = x_446;
x_137 = x_487;
x_138 = x_445;
x_139 = x_448;
x_140 = x_444;
x_141 = x_449;
x_142 = x_494;
x_143 = x_474;
x_144 = x_451;
x_145 = x_488;
x_146 = x_497;
x_147 = x_497;
x_148 = x_486;
x_149 = x_12;
goto block_163;
}
else
{
lean_inc(x_497);
x_134 = x_447;
x_135 = x_495;
x_136 = x_446;
x_137 = x_487;
x_138 = x_445;
x_139 = x_448;
x_140 = x_444;
x_141 = x_449;
x_142 = x_494;
x_143 = x_474;
x_144 = x_451;
x_145 = x_488;
x_146 = x_497;
x_147 = x_497;
x_148 = x_486;
x_149 = x_488;
goto block_163;
}
}
else
{
lean_dec(x_474);
x_164 = x_481;
x_165 = x_447;
x_166 = x_446;
x_167 = x_445;
x_168 = x_451;
x_169 = x_448;
x_170 = x_483;
x_171 = x_444;
x_172 = x_449;
x_173 = x_488;
goto block_287;
}
}
else
{
lean_dec(x_480);
lean_dec(x_474);
x_164 = x_481;
x_165 = x_447;
x_166 = x_446;
x_167 = x_445;
x_168 = x_451;
x_169 = x_448;
x_170 = x_483;
x_171 = x_444;
x_172 = x_449;
x_173 = x_12;
goto block_287;
}
}
else
{
lean_object* x_499; lean_object* x_500; lean_object* x_501; lean_object* x_502; lean_object* x_503; lean_object* x_504; lean_object* x_505; lean_object* x_506; lean_object* x_507; 
lean_dec(x_3);
lean_dec(x_2);
x_499 = lean_ctor_get(x_471, 1);
lean_inc(x_499);
if (lean_is_exclusive(x_471)) {
 lean_ctor_release(x_471, 0);
 lean_ctor_release(x_471, 1);
 x_500 = x_471;
} else {
 lean_dec_ref(x_471);
 x_500 = lean_box(0);
}
x_501 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43;
x_502 = l_Lean_MessageData_ofExpr(x_472);
x_503 = l_Lean_indentD(x_502);
if (lean_is_scalar(x_500)) {
 x_504 = lean_alloc_ctor(7, 2, 0);
} else {
 x_504 = x_500;
 lean_ctor_set_tag(x_504, 7);
}
lean_ctor_set(x_504, 0, x_501);
lean_ctor_set(x_504, 1, x_503);
x_505 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45;
if (lean_is_scalar(x_470)) {
 x_506 = lean_alloc_ctor(7, 2, 0);
} else {
 x_506 = x_470;
 lean_ctor_set_tag(x_506, 7);
}
lean_ctor_set(x_506, 0, x_504);
lean_ctor_set(x_506, 1, x_505);
x_507 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_506, x_444, x_445, x_446, x_447, x_448, x_449, x_499);
lean_dec(x_449);
lean_dec(x_448);
lean_dec(x_447);
lean_dec(x_446);
lean_dec(x_445);
return x_507;
}
}
else
{
lean_dec(x_449);
lean_dec(x_448);
lean_dec(x_447);
lean_dec(x_446);
lean_dec(x_445);
lean_dec(x_444);
lean_dec(x_3);
lean_dec(x_2);
return x_467;
}
}
else
{
lean_dec(x_449);
lean_dec(x_448);
lean_dec(x_447);
lean_dec(x_446);
lean_dec(x_445);
lean_dec(x_444);
lean_dec(x_443);
lean_dec(x_295);
lean_dec(x_3);
lean_dec(x_2);
return x_459;
}
}
else
{
lean_dec(x_449);
lean_dec(x_448);
lean_dec(x_447);
lean_dec(x_446);
lean_dec(x_445);
lean_dec(x_444);
lean_dec(x_443);
lean_dec(x_295);
lean_dec(x_3);
lean_dec(x_2);
return x_454;
}
}
}
else
{
lean_object* x_525; lean_object* x_526; lean_object* x_527; lean_object* x_528; 
lean_dec(x_438);
lean_free_object(x_293);
lean_dec(x_295);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_525 = lean_ctor_get(x_440, 0);
lean_inc(x_525);
x_526 = lean_ctor_get(x_440, 1);
lean_inc(x_526);
if (lean_is_exclusive(x_440)) {
 lean_ctor_release(x_440, 0);
 lean_ctor_release(x_440, 1);
 x_527 = x_440;
} else {
 lean_dec_ref(x_440);
 x_527 = lean_box(0);
}
if (lean_is_scalar(x_527)) {
 x_528 = lean_alloc_ctor(1, 2, 0);
} else {
 x_528 = x_527;
}
lean_ctor_set(x_528, 0, x_525);
lean_ctor_set(x_528, 1, x_526);
return x_528;
}
}
}
else
{
lean_free_object(x_293);
lean_dec(x_295);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_301;
}
}
else
{
lean_object* x_529; lean_object* x_530; lean_object* x_531; lean_object* x_532; lean_object* x_533; lean_object* x_534; lean_object* x_535; 
x_529 = lean_ctor_get(x_293, 0);
x_530 = lean_ctor_get(x_293, 1);
lean_inc(x_530);
lean_inc(x_529);
lean_dec(x_293);
x_531 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__28;
x_532 = lean_unsigned_to_nat(1u);
x_533 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__29;
lean_inc(x_529);
x_534 = lean_array_push(x_533, x_529);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
x_535 = l_Lean_Meta_mkAppM(x_531, x_534, x_6, x_7, x_8, x_9, x_530);
if (lean_obj_tag(x_535) == 0)
{
lean_object* x_536; lean_object* x_537; lean_object* x_538; lean_object* x_539; 
x_536 = lean_ctor_get(x_535, 0);
lean_inc(x_536);
x_537 = lean_ctor_get(x_535, 1);
lean_inc(x_537);
if (lean_is_exclusive(x_535)) {
 lean_ctor_release(x_535, 0);
 lean_ctor_release(x_535, 1);
 x_538 = x_535;
} else {
 lean_dec_ref(x_535);
 x_538 = lean_box(0);
}
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_536);
lean_inc(x_3);
x_539 = l_Lean_Meta_isExprDefEq(x_3, x_536, x_6, x_7, x_8, x_9, x_537);
if (lean_obj_tag(x_539) == 0)
{
lean_object* x_540; lean_object* x_541; lean_object* x_542; lean_object* x_543; lean_object* x_544; lean_object* x_545; lean_object* x_546; lean_object* x_547; lean_object* x_548; lean_object* x_549; uint8_t x_608; 
x_540 = lean_ctor_get(x_539, 0);
lean_inc(x_540);
x_541 = lean_ctor_get(x_539, 1);
lean_inc(x_541);
lean_dec(x_539);
x_542 = l_Lean_Syntax_getArg(x_1, x_532);
lean_dec(x_1);
x_608 = lean_unbox(x_540);
lean_dec(x_540);
if (x_608 == 0)
{
if (x_12 == 0)
{
lean_dec(x_538);
lean_dec(x_536);
x_543 = x_4;
x_544 = x_5;
x_545 = x_6;
x_546 = x_7;
x_547 = x_8;
x_548 = x_9;
x_549 = x_541;
goto block_607;
}
else
{
lean_object* x_609; lean_object* x_610; lean_object* x_611; lean_object* x_612; lean_object* x_613; lean_object* x_614; lean_object* x_615; lean_object* x_616; lean_object* x_617; lean_object* x_618; lean_object* x_619; lean_object* x_620; lean_object* x_621; lean_object* x_622; lean_object* x_623; lean_object* x_624; 
lean_dec(x_542);
lean_dec(x_529);
lean_dec(x_2);
x_609 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__47;
x_610 = l_Lean_MessageData_ofExpr(x_3);
x_611 = l_Lean_indentD(x_610);
if (lean_is_scalar(x_538)) {
 x_612 = lean_alloc_ctor(7, 2, 0);
} else {
 x_612 = x_538;
 lean_ctor_set_tag(x_612, 7);
}
lean_ctor_set(x_612, 0, x_609);
lean_ctor_set(x_612, 1, x_611);
x_613 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__49;
x_614 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_614, 0, x_612);
lean_ctor_set(x_614, 1, x_613);
x_615 = l_Lean_MessageData_ofExpr(x_536);
x_616 = l_Lean_indentD(x_615);
x_617 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_617, 0, x_614);
lean_ctor_set(x_617, 1, x_616);
x_618 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45;
x_619 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_619, 0, x_617);
lean_ctor_set(x_619, 1, x_618);
x_620 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_619, x_4, x_5, x_6, x_7, x_8, x_9, x_541);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
x_621 = lean_ctor_get(x_620, 0);
lean_inc(x_621);
x_622 = lean_ctor_get(x_620, 1);
lean_inc(x_622);
if (lean_is_exclusive(x_620)) {
 lean_ctor_release(x_620, 0);
 lean_ctor_release(x_620, 1);
 x_623 = x_620;
} else {
 lean_dec_ref(x_620);
 x_623 = lean_box(0);
}
if (lean_is_scalar(x_623)) {
 x_624 = lean_alloc_ctor(1, 2, 0);
} else {
 x_624 = x_623;
}
lean_ctor_set(x_624, 0, x_621);
lean_ctor_set(x_624, 1, x_622);
return x_624;
}
}
else
{
lean_dec(x_538);
lean_dec(x_536);
x_543 = x_4;
x_544 = x_5;
x_545 = x_6;
x_546 = x_7;
x_547 = x_8;
x_548 = x_9;
x_549 = x_541;
goto block_607;
}
block_607:
{
lean_object* x_550; lean_object* x_551; lean_object* x_552; lean_object* x_553; 
x_550 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30;
x_551 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__33;
x_552 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__37;
lean_inc(x_548);
lean_inc(x_547);
lean_inc(x_546);
lean_inc(x_545);
x_553 = l_Lean_Meta_mkAppM(x_551, x_552, x_545, x_546, x_547, x_548, x_549);
if (lean_obj_tag(x_553) == 0)
{
lean_object* x_554; lean_object* x_555; lean_object* x_556; lean_object* x_557; lean_object* x_558; 
x_554 = lean_ctor_get(x_553, 0);
lean_inc(x_554);
x_555 = lean_ctor_get(x_553, 1);
lean_inc(x_555);
lean_dec(x_553);
x_556 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__39;
x_557 = lean_array_push(x_533, x_554);
lean_inc(x_548);
lean_inc(x_547);
lean_inc(x_546);
lean_inc(x_545);
x_558 = l_Lean_Meta_mkAppM(x_556, x_557, x_545, x_546, x_547, x_548, x_555);
if (lean_obj_tag(x_558) == 0)
{
lean_object* x_559; lean_object* x_560; lean_object* x_561; lean_object* x_562; lean_object* x_563; lean_object* x_564; lean_object* x_565; lean_object* x_566; 
x_559 = lean_ctor_get(x_558, 0);
lean_inc(x_559);
x_560 = lean_ctor_get(x_558, 1);
lean_inc(x_560);
lean_dec(x_558);
x_561 = l_Lean_mkArrow___redArg(x_529, x_559, x_548, x_560);
x_562 = lean_ctor_get(x_561, 0);
lean_inc(x_562);
x_563 = lean_ctor_get(x_561, 1);
lean_inc(x_563);
lean_dec(x_561);
x_564 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_564, 0, x_562);
x_565 = lean_box(0);
lean_inc(x_548);
lean_inc(x_547);
lean_inc(x_546);
lean_inc(x_545);
lean_inc(x_544);
lean_inc(x_543);
x_566 = l_Lean_Elab_Term_elabTermEnsuringType(x_542, x_564, x_12, x_12, x_565, x_543, x_544, x_545, x_546, x_547, x_548, x_563);
if (lean_obj_tag(x_566) == 0)
{
lean_object* x_567; lean_object* x_568; lean_object* x_569; lean_object* x_570; lean_object* x_571; 
x_567 = lean_ctor_get(x_566, 0);
lean_inc(x_567);
x_568 = lean_ctor_get(x_566, 1);
lean_inc(x_568);
if (lean_is_exclusive(x_566)) {
 lean_ctor_release(x_566, 0);
 lean_ctor_release(x_566, 1);
 x_569 = x_566;
} else {
 lean_dec_ref(x_566);
 x_569 = lean_box(0);
}
x_570 = l_Lean_instantiateMVars___at___Lean_Elab_Term_MVarErrorInfo_logError_spec__0___redArg(x_567, x_546, x_568);
x_571 = lean_ctor_get(x_570, 0);
lean_inc(x_571);
if (lean_obj_tag(x_571) == 4)
{
lean_object* x_572; lean_object* x_573; lean_object* x_574; lean_object* x_575; lean_object* x_576; lean_object* x_577; lean_object* x_578; lean_object* x_579; lean_object* x_580; lean_object* x_581; lean_object* x_582; uint8_t x_583; 
lean_dec(x_569);
x_572 = lean_ctor_get(x_570, 1);
lean_inc(x_572);
lean_dec(x_570);
x_573 = lean_ctor_get(x_571, 0);
lean_inc(x_573);
lean_dec(x_571);
x_574 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__40;
x_575 = lean_st_ref_get(x_574, x_572);
x_576 = lean_ctor_get(x_575, 0);
lean_inc(x_576);
x_577 = lean_ctor_get(x_575, 1);
lean_inc(x_577);
lean_dec(x_575);
x_578 = lean_st_ref_get(x_548, x_577);
x_579 = lean_ctor_get(x_578, 0);
lean_inc(x_579);
x_580 = lean_ctor_get(x_578, 1);
lean_inc(x_580);
lean_dec(x_578);
x_581 = l_ProofWidgets_cancellableSuffix;
lean_inc(x_573);
x_582 = l_Lean_Name_append(x_573, x_581);
x_583 = l_Lean_PersistentHashMap_contains___at___Lean_SMap_contains___at___Lean_Environment_containsOnBranch_spec__0_spec__0___redArg(x_576, x_582);
if (x_583 == 0)
{
lean_object* x_584; lean_object* x_585; lean_object* x_586; uint8_t x_587; 
x_584 = lean_ctor_get(x_579, 0);
lean_inc(x_584);
lean_dec(x_579);
x_585 = lean_box(0);
x_586 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__41;
lean_inc(x_582);
x_587 = l_Lean_MapDeclarationExtension_contains___redArg(x_585, x_586, x_584, x_582);
if (x_587 == 0)
{
lean_object* x_588; lean_object* x_589; lean_object* x_590; lean_object* x_591; lean_object* x_592; lean_object* x_593; lean_object* x_594; lean_object* x_595; lean_object* x_596; uint8_t x_597; 
lean_dec(x_582);
lean_dec(x_2);
x_588 = lean_st_ref_get(x_574, x_580);
x_589 = lean_ctor_get(x_588, 0);
lean_inc(x_589);
x_590 = lean_ctor_get(x_588, 1);
lean_inc(x_590);
lean_dec(x_588);
x_591 = lean_st_ref_get(x_548, x_590);
x_592 = lean_ctor_get(x_591, 0);
lean_inc(x_592);
x_593 = lean_ctor_get(x_591, 1);
lean_inc(x_593);
lean_dec(x_591);
x_594 = lean_ctor_get(x_592, 0);
lean_inc(x_594);
lean_dec(x_592);
x_595 = lean_box(x_587);
x_596 = lean_alloc_closure((void*)(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__1___boxed), 2, 1);
lean_closure_set(x_596, 0, x_595);
x_597 = l_Lean_PersistentHashMap_contains___at___Lean_SMap_contains___at___Lean_Environment_containsOnBranch_spec__0_spec__0___redArg(x_589, x_573);
if (x_597 == 0)
{
lean_inc(x_596);
x_134 = x_546;
x_135 = x_594;
x_136 = x_545;
x_137 = x_586;
x_138 = x_544;
x_139 = x_547;
x_140 = x_543;
x_141 = x_548;
x_142 = x_593;
x_143 = x_573;
x_144 = x_550;
x_145 = x_587;
x_146 = x_596;
x_147 = x_596;
x_148 = x_585;
x_149 = x_12;
goto block_163;
}
else
{
lean_inc(x_596);
x_134 = x_546;
x_135 = x_594;
x_136 = x_545;
x_137 = x_586;
x_138 = x_544;
x_139 = x_547;
x_140 = x_543;
x_141 = x_548;
x_142 = x_593;
x_143 = x_573;
x_144 = x_550;
x_145 = x_587;
x_146 = x_596;
x_147 = x_596;
x_148 = x_585;
x_149 = x_587;
goto block_163;
}
}
else
{
lean_dec(x_573);
x_164 = x_580;
x_165 = x_546;
x_166 = x_545;
x_167 = x_544;
x_168 = x_550;
x_169 = x_547;
x_170 = x_582;
x_171 = x_543;
x_172 = x_548;
x_173 = x_587;
goto block_287;
}
}
else
{
lean_dec(x_579);
lean_dec(x_573);
x_164 = x_580;
x_165 = x_546;
x_166 = x_545;
x_167 = x_544;
x_168 = x_550;
x_169 = x_547;
x_170 = x_582;
x_171 = x_543;
x_172 = x_548;
x_173 = x_12;
goto block_287;
}
}
else
{
lean_object* x_598; lean_object* x_599; lean_object* x_600; lean_object* x_601; lean_object* x_602; lean_object* x_603; lean_object* x_604; lean_object* x_605; lean_object* x_606; 
lean_dec(x_3);
lean_dec(x_2);
x_598 = lean_ctor_get(x_570, 1);
lean_inc(x_598);
if (lean_is_exclusive(x_570)) {
 lean_ctor_release(x_570, 0);
 lean_ctor_release(x_570, 1);
 x_599 = x_570;
} else {
 lean_dec_ref(x_570);
 x_599 = lean_box(0);
}
x_600 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43;
x_601 = l_Lean_MessageData_ofExpr(x_571);
x_602 = l_Lean_indentD(x_601);
if (lean_is_scalar(x_599)) {
 x_603 = lean_alloc_ctor(7, 2, 0);
} else {
 x_603 = x_599;
 lean_ctor_set_tag(x_603, 7);
}
lean_ctor_set(x_603, 0, x_600);
lean_ctor_set(x_603, 1, x_602);
x_604 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45;
if (lean_is_scalar(x_569)) {
 x_605 = lean_alloc_ctor(7, 2, 0);
} else {
 x_605 = x_569;
 lean_ctor_set_tag(x_605, 7);
}
lean_ctor_set(x_605, 0, x_603);
lean_ctor_set(x_605, 1, x_604);
x_606 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_605, x_543, x_544, x_545, x_546, x_547, x_548, x_598);
lean_dec(x_548);
lean_dec(x_547);
lean_dec(x_546);
lean_dec(x_545);
lean_dec(x_544);
return x_606;
}
}
else
{
lean_dec(x_548);
lean_dec(x_547);
lean_dec(x_546);
lean_dec(x_545);
lean_dec(x_544);
lean_dec(x_543);
lean_dec(x_3);
lean_dec(x_2);
return x_566;
}
}
else
{
lean_dec(x_548);
lean_dec(x_547);
lean_dec(x_546);
lean_dec(x_545);
lean_dec(x_544);
lean_dec(x_543);
lean_dec(x_542);
lean_dec(x_529);
lean_dec(x_3);
lean_dec(x_2);
return x_558;
}
}
else
{
lean_dec(x_548);
lean_dec(x_547);
lean_dec(x_546);
lean_dec(x_545);
lean_dec(x_544);
lean_dec(x_543);
lean_dec(x_542);
lean_dec(x_529);
lean_dec(x_3);
lean_dec(x_2);
return x_553;
}
}
}
else
{
lean_object* x_625; lean_object* x_626; lean_object* x_627; lean_object* x_628; 
lean_dec(x_538);
lean_dec(x_536);
lean_dec(x_529);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_625 = lean_ctor_get(x_539, 0);
lean_inc(x_625);
x_626 = lean_ctor_get(x_539, 1);
lean_inc(x_626);
if (lean_is_exclusive(x_539)) {
 lean_ctor_release(x_539, 0);
 lean_ctor_release(x_539, 1);
 x_627 = x_539;
} else {
 lean_dec_ref(x_539);
 x_627 = lean_box(0);
}
if (lean_is_scalar(x_627)) {
 x_628 = lean_alloc_ctor(1, 2, 0);
} else {
 x_628 = x_627;
}
lean_ctor_set(x_628, 0, x_625);
lean_ctor_set(x_628, 1, x_626);
return x_628;
}
}
else
{
lean_dec(x_529);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_535;
}
}
}
block_133:
{
lean_object* x_24; uint8_t x_25; 
x_24 = lean_st_ref_get(x_22, x_23);
x_25 = !lean_is_exclusive(x_24);
if (x_25 == 0)
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; 
x_26 = lean_ctor_get(x_24, 0);
x_27 = lean_ctor_get(x_24, 1);
x_28 = lean_ctor_get(x_21, 5);
lean_inc(x_28);
x_29 = lean_ctor_get(x_21, 10);
lean_inc(x_29);
x_30 = lean_ctor_get(x_26, 0);
lean_inc(x_30);
lean_dec(x_26);
x_31 = l_ProofWidgets_ofRpcMethodTemplate___closed__0;
x_32 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__0;
x_33 = l_Lean_Name_toString(x_13, x_12, x_16);
x_34 = l_String_replace(x_31, x_32, x_33);
lean_dec(x_33);
x_35 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__1;
x_36 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__2;
x_37 = l_String_replace(x_34, x_35, x_36);
lean_dec(x_34);
x_38 = lean_box(2);
x_39 = l_Lean_Syntax_mkStrLit(x_37, x_38);
lean_dec(x_37);
x_40 = l_Lean_SourceInfo_fromRef(x_28, x_15);
lean_dec(x_28);
x_41 = l_Lean_Environment_mainModule(x_30);
lean_dec(x_30);
x_42 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__3;
x_43 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__4;
x_44 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__5;
lean_inc(x_14);
x_45 = l_Lean_Name_mkStr4(x_14, x_42, x_43, x_44);
x_46 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__6;
lean_inc(x_40);
lean_ctor_set_tag(x_24, 2);
lean_ctor_set(x_24, 1, x_46);
lean_ctor_set(x_24, 0, x_40);
x_47 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__8;
x_48 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__9;
lean_inc(x_40);
x_49 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_49, 0, x_40);
lean_ctor_set(x_49, 1, x_47);
lean_ctor_set(x_49, 2, x_48);
x_50 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__10;
lean_inc(x_14);
x_51 = l_Lean_Name_mkStr4(x_14, x_42, x_43, x_50);
x_52 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__11;
lean_inc(x_14);
x_53 = l_Lean_Name_mkStr4(x_14, x_42, x_43, x_52);
x_54 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__12;
lean_inc(x_14);
x_55 = l_Lean_Name_mkStr4(x_14, x_42, x_43, x_54);
x_56 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__14;
x_57 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__15;
x_58 = l_Lean_addMacroScope(x_41, x_57, x_29);
x_59 = lean_box(0);
lean_inc(x_40);
x_60 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_60, 0, x_40);
lean_ctor_set(x_60, 1, x_56);
lean_ctor_set(x_60, 2, x_58);
lean_ctor_set(x_60, 3, x_59);
lean_inc(x_49);
lean_inc(x_40);
x_61 = l_Lean_Syntax_node2(x_40, x_55, x_60, x_49);
x_62 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__16;
lean_inc(x_14);
x_63 = l_Lean_Name_mkStr4(x_14, x_42, x_43, x_62);
x_64 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__17;
lean_inc(x_40);
x_65 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_65, 0, x_40);
lean_ctor_set(x_65, 1, x_64);
lean_inc(x_49);
lean_inc(x_40);
x_66 = l_Lean_Syntax_node3(x_40, x_63, x_65, x_49, x_39);
lean_inc_n(x_49, 2);
lean_inc(x_40);
x_67 = l_Lean_Syntax_node3(x_40, x_47, x_49, x_49, x_66);
lean_inc(x_40);
x_68 = l_Lean_Syntax_node2(x_40, x_53, x_61, x_67);
lean_inc(x_40);
x_69 = l_Lean_Syntax_node1(x_40, x_47, x_68);
lean_inc(x_40);
x_70 = l_Lean_Syntax_node1(x_40, x_51, x_69);
x_71 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__18;
x_72 = l_Lean_Name_mkStr4(x_14, x_42, x_43, x_71);
lean_inc(x_49);
lean_inc(x_40);
x_73 = l_Lean_Syntax_node1(x_40, x_72, x_49);
x_74 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__19;
lean_inc(x_40);
x_75 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_75, 0, x_40);
lean_ctor_set(x_75, 1, x_74);
lean_inc(x_49);
x_76 = l_Lean_Syntax_node6(x_40, x_45, x_24, x_49, x_70, x_73, x_49, x_75);
x_77 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_77, 0, x_3);
x_78 = l_Lean_Elab_Term_elabTerm(x_76, x_77, x_12, x_12, x_17, x_18, x_19, x_20, x_21, x_22, x_27);
return x_78;
}
else
{
lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; 
x_79 = lean_ctor_get(x_24, 0);
x_80 = lean_ctor_get(x_24, 1);
lean_inc(x_80);
lean_inc(x_79);
lean_dec(x_24);
x_81 = lean_ctor_get(x_21, 5);
lean_inc(x_81);
x_82 = lean_ctor_get(x_21, 10);
lean_inc(x_82);
x_83 = lean_ctor_get(x_79, 0);
lean_inc(x_83);
lean_dec(x_79);
x_84 = l_ProofWidgets_ofRpcMethodTemplate___closed__0;
x_85 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__0;
x_86 = l_Lean_Name_toString(x_13, x_12, x_16);
x_87 = l_String_replace(x_84, x_85, x_86);
lean_dec(x_86);
x_88 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__1;
x_89 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__2;
x_90 = l_String_replace(x_87, x_88, x_89);
lean_dec(x_87);
x_91 = lean_box(2);
x_92 = l_Lean_Syntax_mkStrLit(x_90, x_91);
lean_dec(x_90);
x_93 = l_Lean_SourceInfo_fromRef(x_81, x_15);
lean_dec(x_81);
x_94 = l_Lean_Environment_mainModule(x_83);
lean_dec(x_83);
x_95 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__3;
x_96 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__4;
x_97 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__5;
lean_inc(x_14);
x_98 = l_Lean_Name_mkStr4(x_14, x_95, x_96, x_97);
x_99 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__6;
lean_inc(x_93);
x_100 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_100, 0, x_93);
lean_ctor_set(x_100, 1, x_99);
x_101 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__8;
x_102 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__9;
lean_inc(x_93);
x_103 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_103, 0, x_93);
lean_ctor_set(x_103, 1, x_101);
lean_ctor_set(x_103, 2, x_102);
x_104 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__10;
lean_inc(x_14);
x_105 = l_Lean_Name_mkStr4(x_14, x_95, x_96, x_104);
x_106 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__11;
lean_inc(x_14);
x_107 = l_Lean_Name_mkStr4(x_14, x_95, x_96, x_106);
x_108 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__12;
lean_inc(x_14);
x_109 = l_Lean_Name_mkStr4(x_14, x_95, x_96, x_108);
x_110 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__14;
x_111 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__15;
x_112 = l_Lean_addMacroScope(x_94, x_111, x_82);
x_113 = lean_box(0);
lean_inc(x_93);
x_114 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_114, 0, x_93);
lean_ctor_set(x_114, 1, x_110);
lean_ctor_set(x_114, 2, x_112);
lean_ctor_set(x_114, 3, x_113);
lean_inc(x_103);
lean_inc(x_93);
x_115 = l_Lean_Syntax_node2(x_93, x_109, x_114, x_103);
x_116 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__16;
lean_inc(x_14);
x_117 = l_Lean_Name_mkStr4(x_14, x_95, x_96, x_116);
x_118 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__17;
lean_inc(x_93);
x_119 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_119, 0, x_93);
lean_ctor_set(x_119, 1, x_118);
lean_inc(x_103);
lean_inc(x_93);
x_120 = l_Lean_Syntax_node3(x_93, x_117, x_119, x_103, x_92);
lean_inc_n(x_103, 2);
lean_inc(x_93);
x_121 = l_Lean_Syntax_node3(x_93, x_101, x_103, x_103, x_120);
lean_inc(x_93);
x_122 = l_Lean_Syntax_node2(x_93, x_107, x_115, x_121);
lean_inc(x_93);
x_123 = l_Lean_Syntax_node1(x_93, x_101, x_122);
lean_inc(x_93);
x_124 = l_Lean_Syntax_node1(x_93, x_105, x_123);
x_125 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__18;
x_126 = l_Lean_Name_mkStr4(x_14, x_95, x_96, x_125);
lean_inc(x_103);
lean_inc(x_93);
x_127 = l_Lean_Syntax_node1(x_93, x_126, x_103);
x_128 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__19;
lean_inc(x_93);
x_129 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_129, 0, x_93);
lean_ctor_set(x_129, 1, x_128);
lean_inc(x_103);
x_130 = l_Lean_Syntax_node6(x_93, x_98, x_100, x_103, x_124, x_127, x_103, x_129);
x_131 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_131, 0, x_3);
x_132 = l_Lean_Elab_Term_elabTerm(x_130, x_131, x_12, x_12, x_17, x_18, x_19, x_20, x_21, x_22, x_80);
return x_132;
}
}
block_163:
{
if (x_149 == 0)
{
lean_dec(x_148);
lean_dec(x_146);
lean_dec(x_137);
lean_dec(x_135);
x_13 = x_143;
x_14 = x_144;
x_15 = x_145;
x_16 = x_147;
x_17 = x_140;
x_18 = x_138;
x_19 = x_136;
x_20 = x_134;
x_21 = x_139;
x_22 = x_141;
x_23 = x_142;
goto block_133;
}
else
{
uint8_t x_150; 
lean_inc(x_143);
x_150 = l_Lean_MapDeclarationExtension_contains___redArg(x_148, x_137, x_135, x_143);
lean_dec(x_137);
if (x_150 == 0)
{
lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; uint8_t x_159; 
lean_dec(x_147);
lean_dec(x_144);
lean_dec(x_3);
x_151 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__20;
x_152 = l_Lean_Name_toString(x_143, x_149, x_146);
x_153 = lean_string_append(x_151, x_152);
lean_dec(x_152);
x_154 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__21;
x_155 = lean_string_append(x_153, x_154);
x_156 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_156, 0, x_155);
x_157 = l_Lean_MessageData_ofFormat(x_156);
x_158 = l_Lean_throwError___at___Lean_Elab_Term_throwErrorIfErrors_spec__0___redArg(x_157, x_140, x_138, x_136, x_134, x_139, x_141, x_142);
lean_dec(x_141);
lean_dec(x_139);
lean_dec(x_134);
lean_dec(x_136);
lean_dec(x_138);
x_159 = !lean_is_exclusive(x_158);
if (x_159 == 0)
{
return x_158;
}
else
{
lean_object* x_160; lean_object* x_161; lean_object* x_162; 
x_160 = lean_ctor_get(x_158, 0);
x_161 = lean_ctor_get(x_158, 1);
lean_inc(x_161);
lean_inc(x_160);
lean_dec(x_158);
x_162 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_162, 0, x_160);
lean_ctor_set(x_162, 1, x_161);
return x_162;
}
}
else
{
lean_dec(x_146);
x_13 = x_143;
x_14 = x_144;
x_15 = x_145;
x_16 = x_147;
x_17 = x_140;
x_18 = x_138;
x_19 = x_136;
x_20 = x_134;
x_21 = x_139;
x_22 = x_141;
x_23 = x_142;
goto block_133;
}
}
}
block_287:
{
lean_object* x_174; uint8_t x_175; 
x_174 = lean_st_ref_get(x_172, x_164);
x_175 = !lean_is_exclusive(x_174);
if (x_175 == 0)
{
lean_object* x_176; lean_object* x_177; lean_object* x_178; lean_object* x_179; lean_object* x_180; lean_object* x_181; lean_object* x_182; lean_object* x_183; lean_object* x_184; lean_object* x_185; lean_object* x_186; lean_object* x_187; lean_object* x_188; lean_object* x_189; lean_object* x_190; uint8_t x_191; lean_object* x_192; lean_object* x_193; lean_object* x_194; lean_object* x_195; lean_object* x_196; lean_object* x_197; lean_object* x_198; lean_object* x_199; lean_object* x_200; lean_object* x_201; lean_object* x_202; lean_object* x_203; lean_object* x_204; lean_object* x_205; lean_object* x_206; lean_object* x_207; lean_object* x_208; lean_object* x_209; lean_object* x_210; lean_object* x_211; lean_object* x_212; lean_object* x_213; lean_object* x_214; lean_object* x_215; lean_object* x_216; lean_object* x_217; lean_object* x_218; lean_object* x_219; lean_object* x_220; lean_object* x_221; lean_object* x_222; lean_object* x_223; lean_object* x_224; lean_object* x_225; lean_object* x_226; lean_object* x_227; lean_object* x_228; lean_object* x_229; lean_object* x_230; 
x_176 = lean_ctor_get(x_174, 0);
x_177 = lean_ctor_get(x_174, 1);
x_178 = lean_ctor_get(x_169, 5);
lean_inc(x_178);
x_179 = lean_ctor_get(x_169, 10);
lean_inc(x_179);
x_180 = lean_ctor_get(x_176, 0);
lean_inc(x_180);
lean_dec(x_176);
x_181 = l_ProofWidgets_ofRpcMethodTemplate___closed__0;
x_182 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__0;
x_183 = l_Lean_Name_toString(x_170, x_173, x_2);
x_184 = l_String_replace(x_181, x_182, x_183);
lean_dec(x_183);
x_185 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__1;
x_186 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__22;
x_187 = l_String_replace(x_184, x_185, x_186);
lean_dec(x_184);
x_188 = lean_box(2);
x_189 = l_Lean_Syntax_mkStrLit(x_187, x_188);
lean_dec(x_187);
x_190 = lean_box(0);
x_191 = lean_unbox(x_190);
x_192 = l_Lean_SourceInfo_fromRef(x_178, x_191);
lean_dec(x_178);
x_193 = l_Lean_Environment_mainModule(x_180);
lean_dec(x_180);
x_194 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__3;
x_195 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__4;
x_196 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__5;
lean_inc(x_168);
x_197 = l_Lean_Name_mkStr4(x_168, x_194, x_195, x_196);
x_198 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__6;
lean_inc(x_192);
lean_ctor_set_tag(x_174, 2);
lean_ctor_set(x_174, 1, x_198);
lean_ctor_set(x_174, 0, x_192);
x_199 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__8;
x_200 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__9;
lean_inc(x_192);
x_201 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_201, 0, x_192);
lean_ctor_set(x_201, 1, x_199);
lean_ctor_set(x_201, 2, x_200);
x_202 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__10;
lean_inc(x_168);
x_203 = l_Lean_Name_mkStr4(x_168, x_194, x_195, x_202);
x_204 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__11;
lean_inc(x_168);
x_205 = l_Lean_Name_mkStr4(x_168, x_194, x_195, x_204);
x_206 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__12;
lean_inc(x_168);
x_207 = l_Lean_Name_mkStr4(x_168, x_194, x_195, x_206);
x_208 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__14;
x_209 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__15;
x_210 = l_Lean_addMacroScope(x_193, x_209, x_179);
x_211 = lean_box(0);
lean_inc(x_192);
x_212 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_212, 0, x_192);
lean_ctor_set(x_212, 1, x_208);
lean_ctor_set(x_212, 2, x_210);
lean_ctor_set(x_212, 3, x_211);
lean_inc(x_201);
lean_inc(x_192);
x_213 = l_Lean_Syntax_node2(x_192, x_207, x_212, x_201);
x_214 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__16;
lean_inc(x_168);
x_215 = l_Lean_Name_mkStr4(x_168, x_194, x_195, x_214);
x_216 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__17;
lean_inc(x_192);
x_217 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_217, 0, x_192);
lean_ctor_set(x_217, 1, x_216);
lean_inc(x_201);
lean_inc(x_192);
x_218 = l_Lean_Syntax_node3(x_192, x_215, x_217, x_201, x_189);
lean_inc_n(x_201, 2);
lean_inc(x_192);
x_219 = l_Lean_Syntax_node3(x_192, x_199, x_201, x_201, x_218);
lean_inc(x_192);
x_220 = l_Lean_Syntax_node2(x_192, x_205, x_213, x_219);
lean_inc(x_192);
x_221 = l_Lean_Syntax_node1(x_192, x_199, x_220);
lean_inc(x_192);
x_222 = l_Lean_Syntax_node1(x_192, x_203, x_221);
x_223 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__18;
x_224 = l_Lean_Name_mkStr4(x_168, x_194, x_195, x_223);
lean_inc(x_201);
lean_inc(x_192);
x_225 = l_Lean_Syntax_node1(x_192, x_224, x_201);
x_226 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__19;
lean_inc(x_192);
x_227 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_227, 0, x_192);
lean_ctor_set(x_227, 1, x_226);
lean_inc(x_201);
x_228 = l_Lean_Syntax_node6(x_192, x_197, x_174, x_201, x_222, x_225, x_201, x_227);
x_229 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_229, 0, x_3);
x_230 = l_Lean_Elab_Term_elabTerm(x_228, x_229, x_12, x_12, x_171, x_167, x_166, x_165, x_169, x_172, x_177);
return x_230;
}
else
{
lean_object* x_231; lean_object* x_232; lean_object* x_233; lean_object* x_234; lean_object* x_235; lean_object* x_236; lean_object* x_237; lean_object* x_238; lean_object* x_239; lean_object* x_240; lean_object* x_241; lean_object* x_242; lean_object* x_243; lean_object* x_244; lean_object* x_245; uint8_t x_246; lean_object* x_247; lean_object* x_248; lean_object* x_249; lean_object* x_250; lean_object* x_251; lean_object* x_252; lean_object* x_253; lean_object* x_254; lean_object* x_255; lean_object* x_256; lean_object* x_257; lean_object* x_258; lean_object* x_259; lean_object* x_260; lean_object* x_261; lean_object* x_262; lean_object* x_263; lean_object* x_264; lean_object* x_265; lean_object* x_266; lean_object* x_267; lean_object* x_268; lean_object* x_269; lean_object* x_270; lean_object* x_271; lean_object* x_272; lean_object* x_273; lean_object* x_274; lean_object* x_275; lean_object* x_276; lean_object* x_277; lean_object* x_278; lean_object* x_279; lean_object* x_280; lean_object* x_281; lean_object* x_282; lean_object* x_283; lean_object* x_284; lean_object* x_285; lean_object* x_286; 
x_231 = lean_ctor_get(x_174, 0);
x_232 = lean_ctor_get(x_174, 1);
lean_inc(x_232);
lean_inc(x_231);
lean_dec(x_174);
x_233 = lean_ctor_get(x_169, 5);
lean_inc(x_233);
x_234 = lean_ctor_get(x_169, 10);
lean_inc(x_234);
x_235 = lean_ctor_get(x_231, 0);
lean_inc(x_235);
lean_dec(x_231);
x_236 = l_ProofWidgets_ofRpcMethodTemplate___closed__0;
x_237 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__0;
x_238 = l_Lean_Name_toString(x_170, x_173, x_2);
x_239 = l_String_replace(x_236, x_237, x_238);
lean_dec(x_238);
x_240 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__1;
x_241 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__22;
x_242 = l_String_replace(x_239, x_240, x_241);
lean_dec(x_239);
x_243 = lean_box(2);
x_244 = l_Lean_Syntax_mkStrLit(x_242, x_243);
lean_dec(x_242);
x_245 = lean_box(0);
x_246 = lean_unbox(x_245);
x_247 = l_Lean_SourceInfo_fromRef(x_233, x_246);
lean_dec(x_233);
x_248 = l_Lean_Environment_mainModule(x_235);
lean_dec(x_235);
x_249 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__3;
x_250 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__4;
x_251 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__5;
lean_inc(x_168);
x_252 = l_Lean_Name_mkStr4(x_168, x_249, x_250, x_251);
x_253 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__6;
lean_inc(x_247);
x_254 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_254, 0, x_247);
lean_ctor_set(x_254, 1, x_253);
x_255 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__8;
x_256 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__9;
lean_inc(x_247);
x_257 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_257, 0, x_247);
lean_ctor_set(x_257, 1, x_255);
lean_ctor_set(x_257, 2, x_256);
x_258 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__10;
lean_inc(x_168);
x_259 = l_Lean_Name_mkStr4(x_168, x_249, x_250, x_258);
x_260 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__11;
lean_inc(x_168);
x_261 = l_Lean_Name_mkStr4(x_168, x_249, x_250, x_260);
x_262 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__12;
lean_inc(x_168);
x_263 = l_Lean_Name_mkStr4(x_168, x_249, x_250, x_262);
x_264 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__14;
x_265 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__15;
x_266 = l_Lean_addMacroScope(x_248, x_265, x_234);
x_267 = lean_box(0);
lean_inc(x_247);
x_268 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_268, 0, x_247);
lean_ctor_set(x_268, 1, x_264);
lean_ctor_set(x_268, 2, x_266);
lean_ctor_set(x_268, 3, x_267);
lean_inc(x_257);
lean_inc(x_247);
x_269 = l_Lean_Syntax_node2(x_247, x_263, x_268, x_257);
x_270 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__16;
lean_inc(x_168);
x_271 = l_Lean_Name_mkStr4(x_168, x_249, x_250, x_270);
x_272 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__17;
lean_inc(x_247);
x_273 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_273, 0, x_247);
lean_ctor_set(x_273, 1, x_272);
lean_inc(x_257);
lean_inc(x_247);
x_274 = l_Lean_Syntax_node3(x_247, x_271, x_273, x_257, x_244);
lean_inc_n(x_257, 2);
lean_inc(x_247);
x_275 = l_Lean_Syntax_node3(x_247, x_255, x_257, x_257, x_274);
lean_inc(x_247);
x_276 = l_Lean_Syntax_node2(x_247, x_261, x_269, x_275);
lean_inc(x_247);
x_277 = l_Lean_Syntax_node1(x_247, x_255, x_276);
lean_inc(x_247);
x_278 = l_Lean_Syntax_node1(x_247, x_259, x_277);
x_279 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__18;
x_280 = l_Lean_Name_mkStr4(x_168, x_249, x_250, x_279);
lean_inc(x_257);
lean_inc(x_247);
x_281 = l_Lean_Syntax_node1(x_247, x_280, x_257);
x_282 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__19;
lean_inc(x_247);
x_283 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_283, 0, x_247);
lean_ctor_set(x_283, 1, x_282);
lean_inc(x_257);
x_284 = l_Lean_Syntax_node6(x_247, x_252, x_254, x_257, x_278, x_281, x_257, x_283);
x_285 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_285, 0, x_3);
x_286 = l_Lean_Elab_Term_elabTerm(x_284, x_285, x_12, x_12, x_171, x_167, x_166, x_165, x_169, x_172, x_232);
return x_286;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_alloc_closure((void*)(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___boxed), 1, 0);
x_11 = lean_alloc_closure((void*)(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3), 10, 2);
lean_closure_set(x_11, 0, x_1);
lean_closure_set(x_11, 1, x_10);
x_12 = l_Lean_Elab_Term_withExpectedType(x_2, x_11, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
return x_12;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__0(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; uint8_t x_4; lean_object* x_5; 
x_3 = lean_unbox(x_1);
lean_dec(x_1);
x_4 = l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__1(x_3, x_2);
lean_dec(x_2);
x_5 = lean_box(x_4);
return x_5;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Elab_ElabRules(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Basic(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Data_Html(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Cancellable(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Component_OfRpcMethod(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Elab_ElabRules(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Data_Html(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Cancellable(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_ofRpcMethodTemplate___closed__0 = _init_l_ProofWidgets_ofRpcMethodTemplate___closed__0();
lean_mark_persistent(l_ProofWidgets_ofRpcMethodTemplate___closed__0);
l_ProofWidgets_ofRpcMethodTemplate = _init_l_ProofWidgets_ofRpcMethodTemplate();
lean_mark_persistent(l_ProofWidgets_ofRpcMethodTemplate);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__0 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__0();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__0);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__1 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__1();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__1);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__2 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__2();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__2);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__3 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__3();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__3);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__4 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__4();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__4);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__5 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__5();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__5);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__6 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__6();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__6);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__7 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__7();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__7);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__8 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__8();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__8);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__9 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__9();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__9);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__10 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__10();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__10);
l_ProofWidgets_termMk__rpc__widget_x25_____closed__11 = _init_l_ProofWidgets_termMk__rpc__widget_x25_____closed__11();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25_____closed__11);
l_ProofWidgets_termMk__rpc__widget_x25__ = _init_l_ProofWidgets_termMk__rpc__widget_x25__();
lean_mark_persistent(l_ProofWidgets_termMk__rpc__widget_x25__);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__0 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__0();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__0);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__1 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__1();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__1);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__2 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__2();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__2);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__3 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__3();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__3);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__4 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__4();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__4);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__5 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__5();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__5);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__6 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__6();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__6);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__7 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__7();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__7);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__8 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__8();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__8);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__9 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__9();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__9);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__10 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__10();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__10);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__11 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__11();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__11);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__12 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__12();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__12);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__13 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__13();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__13);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__14 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__14();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__14);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__15 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__15();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__15);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__16 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__16();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__16);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__17 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__17();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__17);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__18 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__18();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__18);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__19 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__19();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__19);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__20 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__20();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__20);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__21 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__21();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__21);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__22 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__22();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__22);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__23 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__23();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__23);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__24 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__24();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__24);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__25 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__25();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__25);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__26 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__26();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__26);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__27 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__27();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__27);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__28 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__28();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__28);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__29 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__29();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__29);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__30);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__31 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__31();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__31);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__32 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__32();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__32);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__33 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__33();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__33);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__34 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__34();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__34);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__35 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__35();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__35);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__36 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__36();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__36);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__37 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__37();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__37);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__38 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__38();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__38);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__39 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__39();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__39);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__40 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__40();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__40);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__41 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__41();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__41);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__42 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__42();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__42);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__43);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__44 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__44();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__44);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__45);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__46 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__46();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__46);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__47 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__47();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__47);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__48 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__48();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__48);
l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__49 = _init_l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__49();
lean_mark_persistent(l_ProofWidgets___aux__ProofWidgets__Component__OfRpcMethod______elabRules__ProofWidgets__termMk__rpc__widget_x25____1___lam__3___closed__49);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
