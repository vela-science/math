// Lean compiler output
// Module: ProofWidgets.Component.Panel.Basic
// Imports: Init ProofWidgets.Compat ProofWidgets.Component.Basic Lean.Elab.Tactic
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_liftMacroM___at___Lean_Elab_Tactic_evalTactic_expandEval_spec__0_spec__2___redArg(lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__14;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__6;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_351_(lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__9;
lean_object* l_Lean_Json_mkObj(lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__16;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_95_(lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__21;
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__7;
uint8_t lean_usize_dec_eq(size_t, size_t);
lean_object* l_Lean_Syntax_getArgs(lean_object*);
lean_object* l___private_Lean_SubExpr_0__Lean_SubExpr_fromJsonGoalsLocation____x40_Lean_SubExpr___hyg_1840_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_withPanelWidgetsTacticStx;
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__2;
lean_object* l_Lean_Widget_instRpcEncodableInteractiveTermGoal_enc____x40_Lean_Widget_InteractiveGoal___hyg_2275_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__18;
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__3;
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__0;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_348_;
lean_object* l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(lean_object*);
lean_object* l___private_Lean_Widget_UserWidget_0__Lean_Widget_evalWidgetInstanceUnsafe(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_withPanelWidgets(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__2;
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__1;
size_t lean_usize_of_nat(lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__19;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0___redArg(size_t, size_t, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__4;
static lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__20;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0(size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(lean_object*);
lean_object* l_Lean_Syntax_TSepArray_getElems___redArg(lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_351____boxed(lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__10;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Widget_elabWidgetInstanceSpec(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__5;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_418_;
lean_object* l___private_Lean_SubExpr_0__Lean_SubExpr_toJsonGoalsLocation____x40_Lean_SubExpr___hyg_1946_(lean_object*);
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
lean_object* l_Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_enc____x40_Lean_Widget_InteractiveGoal___hyg_3401__spec__0(size_t, size_t, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps;
static lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__17;
static lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
static lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
lean_object* l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonPosition____x40_Lean_Data_Lsp_Basic___hyg_226_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_418_;
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__11;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(size_t, size_t, lean_object*, lean_object*);
lean_object* l_Lean_Widget_savePanelWidgetInfo(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__1;
lean_object* l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__12;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__22;
lean_object* l_Lean_Json_opt___at_____private_Lean_Data_Lsp_Diagnostics_0__Lean_Lsp_toJsonDiagnosticWith____x40_Lean_Data_Lsp_Diagnostics___hyg_1722____at___Array_toJson___at_____private_Lean_Data_Lsp_Diagnostics_0__Lean_Lsp_toJsonPublishDiagnosticsParams____x40_Lean_Data_Lsp_Diagnostics___hyg_2460__spec__1_spec__1_spec__13(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__15;
extern lean_object* l_Lean_Widget_widgetInstanceSpec;
lean_object* l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Client_0__Lean_Lsp_fromJsonRegistration____x40_Lean_Data_Lsp_Client___hyg_106__spec__0(lean_object*, lean_object*);
lean_object* l_Lean_Widget_instRpcEncodableInteractiveTermGoal_dec____x40_Lean_Widget_InteractiveGoal___hyg_2275_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__8;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_348_;
lean_object* l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonPosition____x40_Lean_Data_Lsp_Basic___hyg_278_(lean_object*);
size_t lean_usize_add(size_t, size_t);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_array_size(lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(size_t, size_t, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4_(lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* l_Lean_Elab_Tactic_evalTacticSeq(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_withPanelWidgetsTacticStx___closed__13;
static lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__0;
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_351_;
lean_object* l_Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_dec____x40_Lean_Widget_InteractiveGoal___hyg_3401__spec__0(size_t, size_t, lean_object*, lean_object*);
static lean_object* _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_95_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("pos", 3, 3);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Component_Panel_Basic___hyg_95_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("goals", 5, 5);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Component_Panel_Basic___hyg_95_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("termGoal", 8, 8);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Component_Panel_Basic___hyg_95_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("selectedLocations", 17, 17);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_95_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
x_2 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
lean_inc(x_1);
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
lean_inc(x_1);
x_6 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_5);
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
lean_dec(x_6);
x_8 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
lean_inc(x_1);
x_9 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Client_0__Lean_Lsp_fromJsonRegistration____x40_Lean_Data_Lsp_Client___hyg_106__spec__0(x_1, x_8);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
lean_dec(x_9);
x_11 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
x_12 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_11);
x_13 = !lean_is_exclusive(x_12);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_12, 0);
x_15 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_15, 0, x_4);
lean_ctor_set(x_15, 1, x_7);
lean_ctor_set(x_15, 2, x_10);
lean_ctor_set(x_15, 3, x_14);
lean_ctor_set(x_12, 0, x_15);
return x_12;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_16 = lean_ctor_get(x_12, 0);
lean_inc(x_16);
lean_dec(x_12);
x_17 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_17, 0, x_4);
lean_ctor_set(x_17, 1, x_7);
lean_ctor_set(x_17, 2, x_10);
lean_ctor_set(x_17, 3, x_16);
x_18 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_18, 0, x_17);
return x_18;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_348_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_95_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_348_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_348_;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_351_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_351_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_2 = lean_ctor_get(x_1, 0);
x_3 = lean_ctor_get(x_1, 1);
x_4 = lean_ctor_get(x_1, 2);
x_5 = lean_ctor_get(x_1, 3);
x_6 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
lean_inc(x_2);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_2);
x_8 = lean_box(0);
x_9 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
lean_inc(x_3);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_3);
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
x_13 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
x_14 = l_Lean_Json_opt___at_____private_Lean_Data_Lsp_Diagnostics_0__Lean_Lsp_toJsonDiagnosticWith____x40_Lean_Data_Lsp_Diagnostics___hyg_1722____at___Array_toJson___at_____private_Lean_Data_Lsp_Diagnostics_0__Lean_Lsp_toJsonPublishDiagnosticsParams____x40_Lean_Data_Lsp_Diagnostics___hyg_2460__spec__1_spec__1_spec__13(x_13, x_4);
x_15 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Component_Panel_Basic___hyg_95_;
lean_inc(x_5);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_5);
x_17 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_8);
x_18 = lean_box(0);
x_19 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_19, 0, x_17);
lean_ctor_set(x_19, 1, x_18);
x_20 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_20, 0, x_14);
lean_ctor_set(x_20, 1, x_19);
x_21 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_21, 0, x_12);
lean_ctor_set(x_21, 1, x_20);
x_22 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_22, 0, x_9);
lean_ctor_set(x_22, 1, x_21);
x_23 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_351_;
x_24 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_22, x_23);
x_25 = l_Lean_Json_mkObj(x_24);
return x_25;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_351____boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_351_(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_418_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_351____boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_418_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_418_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_lt(x_2, x_1);
if (x_5 == 0)
{
lean_object* x_6; 
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_3);
lean_ctor_set(x_6, 1, x_4);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; size_t x_11; size_t x_12; lean_object* x_13; 
x_7 = lean_array_uget(x_3, x_2);
x_8 = lean_box(0);
x_9 = lean_array_uset(x_3, x_2, x_8);
x_10 = l___private_Lean_SubExpr_0__Lean_SubExpr_toJsonGoalsLocation____x40_Lean_SubExpr___hyg_1946_(x_7);
x_11 = 1;
x_12 = lean_usize_add(x_2, x_11);
x_13 = lean_array_uset(x_9, x_2, x_10);
x_2 = x_12;
x_3 = x_13;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; size_t x_8; size_t x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc(x_3);
x_4 = lean_ctor_get(x_1, 1);
lean_inc(x_4);
x_5 = lean_ctor_get(x_1, 2);
lean_inc(x_5);
x_6 = lean_ctor_get(x_1, 3);
lean_inc(x_6);
if (lean_is_exclusive(x_1)) {
 lean_ctor_release(x_1, 0);
 lean_ctor_release(x_1, 1);
 lean_ctor_release(x_1, 2);
 lean_ctor_release(x_1, 3);
 x_7 = x_1;
} else {
 lean_dec_ref(x_1);
 x_7 = lean_box(0);
}
x_8 = lean_array_size(x_4);
x_9 = 0;
x_10 = l_Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_enc____x40_Lean_Widget_InteractiveGoal___hyg_3401__spec__0(x_8, x_9, x_4, x_2);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonPosition____x40_Lean_Data_Lsp_Basic___hyg_226_(x_3);
x_14 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_11);
if (lean_obj_tag(x_5) == 0)
{
lean_object* x_31; 
x_31 = lean_box(0);
x_15 = x_31;
x_16 = x_12;
goto block_30;
}
else
{
uint8_t x_32; 
x_32 = !lean_is_exclusive(x_5);
if (x_32 == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_33 = lean_ctor_get(x_5, 0);
x_34 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_enc____x40_Lean_Widget_InteractiveGoal___hyg_2275_(x_33, x_12);
x_35 = lean_ctor_get(x_34, 0);
lean_inc(x_35);
x_36 = lean_ctor_get(x_34, 1);
lean_inc(x_36);
lean_dec(x_34);
lean_ctor_set(x_5, 0, x_35);
x_15 = x_5;
x_16 = x_36;
goto block_30;
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_37 = lean_ctor_get(x_5, 0);
lean_inc(x_37);
lean_dec(x_5);
x_38 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_enc____x40_Lean_Widget_InteractiveGoal___hyg_2275_(x_37, x_12);
x_39 = lean_ctor_get(x_38, 0);
lean_inc(x_39);
x_40 = lean_ctor_get(x_38, 1);
lean_inc(x_40);
lean_dec(x_38);
x_41 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_41, 0, x_39);
x_15 = x_41;
x_16 = x_40;
goto block_30;
}
}
block_30:
{
size_t x_17; lean_object* x_18; uint8_t x_19; 
x_17 = lean_array_size(x_6);
x_18 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(x_17, x_9, x_6, x_16);
x_19 = !lean_is_exclusive(x_18);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_20 = lean_ctor_get(x_18, 0);
x_21 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_20);
if (lean_is_scalar(x_7)) {
 x_22 = lean_alloc_ctor(0, 4, 0);
} else {
 x_22 = x_7;
}
lean_ctor_set(x_22, 0, x_13);
lean_ctor_set(x_22, 1, x_14);
lean_ctor_set(x_22, 2, x_15);
lean_ctor_set(x_22, 3, x_21);
x_23 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_351_(x_22);
lean_dec(x_22);
lean_ctor_set(x_18, 0, x_23);
return x_18;
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_24 = lean_ctor_get(x_18, 0);
x_25 = lean_ctor_get(x_18, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_18);
x_26 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_24);
if (lean_is_scalar(x_7)) {
 x_27 = lean_alloc_ctor(0, 4, 0);
} else {
 x_27 = x_7;
}
lean_ctor_set(x_27, 0, x_13);
lean_ctor_set(x_27, 1, x_14);
lean_ctor_set(x_27, 2, x_15);
lean_ctor_set(x_27, 3, x_26);
x_28 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_351_(x_27);
lean_dec(x_27);
x_29 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_29, 0, x_28);
lean_ctor_set(x_29, 1, x_25);
return x_29;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(x_5, x_6, x_3, x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0___redArg(size_t x_1, size_t x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = lean_usize_dec_lt(x_2, x_1);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_5, 0, x_3);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_array_uget(x_3, x_2);
x_7 = l___private_Lean_SubExpr_0__Lean_SubExpr_fromJsonGoalsLocation____x40_Lean_SubExpr___hyg_1840_(x_6);
if (lean_obj_tag(x_7) == 0)
{
uint8_t x_8; 
lean_dec(x_3);
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
return x_7;
}
else
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
lean_dec(x_7);
x_10 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_10, 0, x_9);
return x_10;
}
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; size_t x_14; size_t x_15; lean_object* x_16; 
x_11 = lean_ctor_get(x_7, 0);
lean_inc(x_11);
lean_dec(x_7);
x_12 = lean_box(0);
x_13 = lean_array_uset(x_3, x_2, x_12);
x_14 = 1;
x_15 = lean_usize_add(x_2, x_14);
x_16 = lean_array_uset(x_13, x_2, x_11);
x_2 = x_15;
x_3 = x_16;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0___redArg(x_1, x_2, x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_lt(x_2, x_1);
if (x_5 == 0)
{
lean_object* x_6; 
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_3);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; 
x_7 = lean_array_uget(x_3, x_2);
x_8 = l___private_Lean_SubExpr_0__Lean_SubExpr_fromJsonGoalsLocation____x40_Lean_SubExpr___hyg_1840_(x_7);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
lean_dec(x_3);
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
return x_8;
}
else
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_ctor_get(x_8, 0);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
return x_11;
}
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; size_t x_15; size_t x_16; lean_object* x_17; lean_object* x_18; 
x_12 = lean_ctor_get(x_8, 0);
lean_inc(x_12);
lean_dec(x_8);
x_13 = lean_box(0);
x_14 = lean_array_uset(x_3, x_2, x_13);
x_15 = 1;
x_16 = lean_usize_add(x_2, x_15);
x_17 = lean_array_uset(x_14, x_2, x_12);
x_18 = l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0___redArg(x_1, x_16, x_17);
return x_18;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_3 = l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_95_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = lean_ctor_get(x_4, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_4, 1);
lean_inc(x_6);
x_7 = lean_ctor_get(x_4, 2);
lean_inc(x_7);
x_8 = lean_ctor_get(x_4, 3);
lean_inc(x_8);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 lean_ctor_release(x_4, 2);
 lean_ctor_release(x_4, 3);
 x_9 = x_4;
} else {
 lean_dec_ref(x_4);
 x_9 = lean_box(0);
}
x_10 = l___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonPosition____x40_Lean_Data_Lsp_Basic___hyg_278_(x_5);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
return x_10;
}
else
{
lean_object* x_12; lean_object* x_13; 
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_13, 0, x_12);
return x_13;
}
}
else
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_10, 0);
lean_inc(x_14);
lean_dec(x_10);
x_15 = l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(x_6);
if (lean_obj_tag(x_15) == 0)
{
uint8_t x_16; 
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
return x_15;
}
else
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
lean_dec(x_15);
x_18 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_18, 0, x_17);
return x_18;
}
}
else
{
lean_object* x_19; size_t x_20; size_t x_21; lean_object* x_22; 
x_19 = lean_ctor_get(x_15, 0);
lean_inc(x_19);
lean_dec(x_15);
x_20 = lean_array_size(x_19);
x_21 = 0;
lean_inc(x_2);
x_22 = l_Array_mapMUnsafe_map___at___Lean_Widget_instRpcEncodableInteractiveGoals_dec____x40_Lean_Widget_InteractiveGoal___hyg_3401__spec__0(x_20, x_21, x_19, x_2);
if (lean_obj_tag(x_22) == 0)
{
uint8_t x_23; 
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
x_23 = !lean_is_exclusive(x_22);
if (x_23 == 0)
{
return x_22;
}
else
{
lean_object* x_24; lean_object* x_25; 
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec(x_22);
x_25 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_25, 0, x_24);
return x_25;
}
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_22, 0);
lean_inc(x_26);
lean_dec(x_22);
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_46; 
x_46 = lean_box(0);
x_27 = x_46;
x_28 = x_2;
goto block_45;
}
else
{
uint8_t x_47; 
x_47 = !lean_is_exclusive(x_7);
if (x_47 == 0)
{
lean_object* x_48; lean_object* x_49; 
x_48 = lean_ctor_get(x_7, 0);
lean_inc(x_2);
x_49 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_dec____x40_Lean_Widget_InteractiveGoal___hyg_2275_(x_48, x_2);
if (lean_obj_tag(x_49) == 0)
{
uint8_t x_50; 
lean_free_object(x_7);
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_2);
x_50 = !lean_is_exclusive(x_49);
if (x_50 == 0)
{
return x_49;
}
else
{
lean_object* x_51; lean_object* x_52; 
x_51 = lean_ctor_get(x_49, 0);
lean_inc(x_51);
lean_dec(x_49);
x_52 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_52, 0, x_51);
return x_52;
}
}
else
{
lean_object* x_53; 
x_53 = lean_ctor_get(x_49, 0);
lean_inc(x_53);
lean_dec(x_49);
lean_ctor_set(x_7, 0, x_53);
x_27 = x_7;
x_28 = x_2;
goto block_45;
}
}
else
{
lean_object* x_54; lean_object* x_55; 
x_54 = lean_ctor_get(x_7, 0);
lean_inc(x_54);
lean_dec(x_7);
lean_inc(x_2);
x_55 = l_Lean_Widget_instRpcEncodableInteractiveTermGoal_dec____x40_Lean_Widget_InteractiveGoal___hyg_2275_(x_54, x_2);
if (lean_obj_tag(x_55) == 0)
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; 
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_2);
x_56 = lean_ctor_get(x_55, 0);
lean_inc(x_56);
if (lean_is_exclusive(x_55)) {
 lean_ctor_release(x_55, 0);
 x_57 = x_55;
} else {
 lean_dec_ref(x_55);
 x_57 = lean_box(0);
}
if (lean_is_scalar(x_57)) {
 x_58 = lean_alloc_ctor(0, 1, 0);
} else {
 x_58 = x_57;
}
lean_ctor_set(x_58, 0, x_56);
return x_58;
}
else
{
lean_object* x_59; lean_object* x_60; 
x_59 = lean_ctor_get(x_55, 0);
lean_inc(x_59);
lean_dec(x_55);
x_60 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_60, 0, x_59);
x_27 = x_60;
x_28 = x_2;
goto block_45;
}
}
}
block_45:
{
lean_object* x_29; 
x_29 = l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(x_8);
if (lean_obj_tag(x_29) == 0)
{
uint8_t x_30; 
lean_dec(x_28);
lean_dec(x_27);
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
x_30 = !lean_is_exclusive(x_29);
if (x_30 == 0)
{
return x_29;
}
else
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_ctor_get(x_29, 0);
lean_inc(x_31);
lean_dec(x_29);
x_32 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_32, 0, x_31);
return x_32;
}
}
else
{
lean_object* x_33; size_t x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_29, 0);
lean_inc(x_33);
lean_dec(x_29);
x_34 = lean_array_size(x_33);
x_35 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(x_34, x_21, x_33, x_28);
lean_dec(x_28);
if (lean_obj_tag(x_35) == 0)
{
uint8_t x_36; 
lean_dec(x_27);
lean_dec(x_26);
lean_dec(x_14);
lean_dec(x_9);
x_36 = !lean_is_exclusive(x_35);
if (x_36 == 0)
{
return x_35;
}
else
{
lean_object* x_37; lean_object* x_38; 
x_37 = lean_ctor_get(x_35, 0);
lean_inc(x_37);
lean_dec(x_35);
x_38 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_38, 0, x_37);
return x_38;
}
}
else
{
uint8_t x_39; 
x_39 = !lean_is_exclusive(x_35);
if (x_39 == 0)
{
lean_object* x_40; lean_object* x_41; 
x_40 = lean_ctor_get(x_35, 0);
if (lean_is_scalar(x_9)) {
 x_41 = lean_alloc_ctor(0, 4, 0);
} else {
 x_41 = x_9;
}
lean_ctor_set(x_41, 0, x_14);
lean_ctor_set(x_41, 1, x_26);
lean_ctor_set(x_41, 2, x_27);
lean_ctor_set(x_41, 3, x_40);
lean_ctor_set(x_35, 0, x_41);
return x_35;
}
else
{
lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_42 = lean_ctor_get(x_35, 0);
lean_inc(x_42);
lean_dec(x_35);
if (lean_is_scalar(x_9)) {
 x_43 = lean_alloc_ctor(0, 4, 0);
} else {
 x_43 = x_9;
}
lean_ctor_set(x_43, 0, x_14);
lean_ctor_set(x_43, 1, x_26);
lean_ctor_set(x_43, 2, x_27);
lean_ctor_set(x_43, 3, x_42);
x_44 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_44, 0, x_43);
return x_44;
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
size_t x_4; size_t x_5; lean_object* x_6; 
x_4 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0___redArg(x_4, x_5, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = l_Array_mapMUnsafe_map___at___Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0_spec__0(x_5, x_6, x_3, x_4);
lean_dec(x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4__spec__0(x_5, x_6, x_3, x_4);
lean_dec(x_4);
return x_7;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodablePanelWidgetProps_enc____x40_ProofWidgets_Component_Panel_Basic___hyg_4_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__1;
x_2 = l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodablePanelWidgetProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("withPanelWidgetsTacticStx", 25, 25);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__1;
x_2 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("andthen", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__3;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("with_panel_widgets", 18, 18);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__5;
x_3 = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(x_3, 0, x_2);
x_4 = lean_unbox(x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_4);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("[", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__7;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__8;
x_2 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__6;
x_3 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__4;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(",", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(", ", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__11;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; uint8_t x_6; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__12;
x_3 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__10;
x_4 = l_Lean_Widget_widgetInstanceSpec;
x_5 = lean_alloc_ctor(11, 3, 1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
x_6 = lean_unbox(x_1);
lean_ctor_set_uint8(x_5, sizeof(void*)*3, x_6);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__13;
x_2 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__9;
x_3 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__4;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__15() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("]", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__15;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__16;
x_2 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__14;
x_3 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__4;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__18() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("tacticSeq", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__18;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__19;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__20;
x_2 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__17;
x_3 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__4;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__21;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__2;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_withPanelWidgetsTacticStx() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__22;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0___redArg(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
uint8_t x_13; 
x_13 = lean_usize_dec_eq(x_3, x_4);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; 
lean_dec(x_5);
x_14 = lean_array_uget(x_2, x_3);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
x_15 = l_Lean_Widget_elabWidgetInstanceSpec(x_14, x_6, x_7, x_8, x_9, x_10, x_11, x_12);
if (lean_obj_tag(x_15) == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_16 = lean_ctor_get(x_15, 0);
lean_inc(x_16);
x_17 = lean_ctor_get(x_15, 1);
lean_inc(x_17);
lean_dec(x_15);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
x_18 = l___private_Lean_Widget_UserWidget_0__Lean_Widget_evalWidgetInstanceUnsafe(x_16, x_8, x_9, x_10, x_11, x_17);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; lean_object* x_20; uint64_t x_21; lean_object* x_22; lean_object* x_23; 
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
x_20 = lean_ctor_get(x_18, 1);
lean_inc(x_20);
lean_dec(x_18);
x_21 = lean_ctor_get_uint64(x_19, sizeof(void*)*2);
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
lean_inc(x_1);
x_23 = l_Lean_Widget_savePanelWidgetInfo(x_21, x_22, x_1, x_10, x_11, x_20);
if (lean_obj_tag(x_23) == 0)
{
lean_object* x_24; lean_object* x_25; size_t x_26; size_t x_27; 
x_24 = lean_ctor_get(x_23, 0);
lean_inc(x_24);
x_25 = lean_ctor_get(x_23, 1);
lean_inc(x_25);
lean_dec(x_23);
x_26 = 1;
x_27 = lean_usize_add(x_3, x_26);
x_3 = x_27;
x_5 = x_24;
x_12 = x_25;
goto _start;
}
else
{
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_1);
return x_23;
}
}
else
{
uint8_t x_29; 
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_1);
x_29 = !lean_is_exclusive(x_18);
if (x_29 == 0)
{
return x_18;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_18, 0);
x_31 = lean_ctor_get(x_18, 1);
lean_inc(x_31);
lean_inc(x_30);
lean_dec(x_18);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
return x_32;
}
}
}
else
{
uint8_t x_33; 
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_1);
x_33 = !lean_is_exclusive(x_15);
if (x_33 == 0)
{
return x_15;
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_34 = lean_ctor_get(x_15, 0);
x_35 = lean_ctor_get(x_15, 1);
lean_inc(x_35);
lean_inc(x_34);
lean_dec(x_15);
x_36 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_36, 0, x_34);
lean_ctor_set(x_36, 1, x_35);
return x_36;
}
}
}
else
{
lean_object* x_37; 
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_1);
x_37 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_37, 0, x_5);
lean_ctor_set(x_37, 1, x_12);
return x_37;
}
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; 
x_15 = l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0___redArg(x_1, x_2, x_3, x_4, x_5, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
return x_15;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_withPanelWidgets(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; uint8_t x_12; 
x_11 = l_ProofWidgets_withPanelWidgetsTacticStx___closed__2;
lean_inc(x_1);
x_12 = l_Lean_Syntax_isOfKind(x_1, x_11);
if (x_12 == 0)
{
lean_object* x_13; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_13 = l_Lean_Elab_throwUnsupportedSyntax___at___Lean_Elab_liftMacroM___at___Lean_Elab_Tactic_evalTactic_expandEval_spec__0_spec__2___redArg(x_10);
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; uint8_t x_22; 
x_14 = lean_unsigned_to_nat(0u);
x_15 = lean_unsigned_to_nat(2u);
x_16 = l_Lean_Syntax_getArg(x_1, x_15);
x_17 = lean_unsigned_to_nat(4u);
x_18 = l_Lean_Syntax_getArg(x_1, x_17);
x_19 = l_Lean_Syntax_getArgs(x_16);
lean_dec(x_16);
x_20 = l_Lean_Syntax_TSepArray_getElems___redArg(x_19);
lean_dec(x_19);
x_21 = lean_array_get_size(x_20);
x_22 = lean_nat_dec_lt(x_14, x_21);
if (x_22 == 0)
{
lean_object* x_23; 
lean_dec(x_21);
lean_dec(x_20);
lean_dec(x_1);
x_23 = l_Lean_Elab_Tactic_evalTacticSeq(x_18, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
return x_23;
}
else
{
uint8_t x_24; 
x_24 = lean_nat_dec_le(x_21, x_21);
if (x_24 == 0)
{
lean_object* x_25; 
lean_dec(x_21);
lean_dec(x_20);
lean_dec(x_1);
x_25 = l_Lean_Elab_Tactic_evalTacticSeq(x_18, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
return x_25;
}
else
{
lean_object* x_26; size_t x_27; size_t x_28; lean_object* x_29; 
x_26 = lean_box(0);
x_27 = 0;
x_28 = lean_usize_of_nat(x_21);
lean_dec(x_21);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
x_29 = l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0___redArg(x_1, x_20, x_27, x_28, x_26, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_20);
if (lean_obj_tag(x_29) == 0)
{
lean_object* x_30; lean_object* x_31; 
x_30 = lean_ctor_get(x_29, 1);
lean_inc(x_30);
lean_dec(x_29);
x_31 = l_Lean_Elab_Tactic_evalTacticSeq(x_18, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_30);
return x_31;
}
else
{
lean_dec(x_18);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_29;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
size_t x_13; size_t x_14; lean_object* x_15; 
x_13 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_14 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_15 = l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0___redArg(x_1, x_2, x_13, x_14, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12);
lean_dec(x_2);
return x_15;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
size_t x_15; size_t x_16; lean_object* x_17; 
x_15 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_16 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_17 = l_Array_foldlMUnsafe_fold___at___ProofWidgets_withPanelWidgets_spec__0(x_1, x_2, x_15, x_16, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
return x_17;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Compat(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Basic(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Elab_Tactic(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Component_Panel_Basic(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Compat(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Elab_Tactic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_95_ = _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_95_();
lean_mark_persistent(l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_95_);
l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Component_Panel_Basic___hyg_95_ = _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Component_Panel_Basic___hyg_95_();
lean_mark_persistent(l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Component_Panel_Basic___hyg_95_);
l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Component_Panel_Basic___hyg_95_ = _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Component_Panel_Basic___hyg_95_();
lean_mark_persistent(l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Component_Panel_Basic___hyg_95_);
l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Component_Panel_Basic___hyg_95_ = _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Component_Panel_Basic___hyg_95_();
lean_mark_persistent(l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Component_Panel_Basic___hyg_95_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_348_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_348_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_348_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_348_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_348_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_348_);
l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_351_ = _init_l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_351_();
lean_mark_persistent(l___private_ProofWidgets_Component_Panel_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_351_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_418_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_418_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Panel_Basic___hyg_418_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_418_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_418_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Panel_Basic___hyg_418_);
l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__0 = _init_l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__0);
l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__1 = _init_l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__1);
l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__2 = _init_l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodablePanelWidgetProps___closed__2);
l_ProofWidgets_instRpcEncodablePanelWidgetProps = _init_l_ProofWidgets_instRpcEncodablePanelWidgetProps();
lean_mark_persistent(l_ProofWidgets_instRpcEncodablePanelWidgetProps);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__0 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__0();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__0);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__1 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__1();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__1);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__2 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__2();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__2);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__3 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__3();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__3);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__4 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__4();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__4);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__5 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__5();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__5);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__6 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__6();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__6);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__7 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__7();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__7);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__8 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__8();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__8);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__9 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__9();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__9);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__10 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__10();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__10);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__11 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__11();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__11);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__12 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__12();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__12);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__13 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__13();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__13);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__14 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__14();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__14);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__15 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__15();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__15);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__16 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__16();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__16);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__17 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__17();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__17);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__18 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__18();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__18);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__19 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__19();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__19);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__20 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__20();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__20);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__21 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__21();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__21);
l_ProofWidgets_withPanelWidgetsTacticStx___closed__22 = _init_l_ProofWidgets_withPanelWidgetsTacticStx___closed__22();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx___closed__22);
l_ProofWidgets_withPanelWidgetsTacticStx = _init_l_ProofWidgets_withPanelWidgetsTacticStx();
lean_mark_persistent(l_ProofWidgets_withPanelWidgetsTacticStx);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
