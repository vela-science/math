// Lean compiler output
// Module: ProofWidgets.Demos.Euclidean
// Imports: Init Lean.Elab.Tactic ProofWidgets.Component.PenroseDiagram ProofWidgets.Component.HtmlDisplay ProofWidgets.Component.Panel.Basic ProofWidgets.Component.OfRpcMethod ProofWidgets.Component.MakeEditLink
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__1___boxed(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__8;
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__3;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2;
LEAN_EXPORT lean_object* l_addHypotheses___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isBetweenPred_x3f(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__1;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__29;
static lean_object* l_constructLines___closed__1;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__21;
static lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__1;
lean_object* l_Lean_Json_compress(lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__0(lean_object*);
static lean_object* l_constructLines___lam__0___closed__7;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__23;
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__2___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__3(uint8_t, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__8;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__11;
static lean_object* l_constructLines___lam__0___closed__8;
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__6;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___constructLines_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__0___closed__3;
lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___at_____private_Lean_Meta_ExprDefEq_0__Lean_Meta_mkLambdaFVarsWithLetDeps_collectLetDeclsFrom_visit_spec__1___redArg(lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanDisplay_rpc_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t l_Array_isEmpty___redArg(lean_object*);
static lean_object* l_isLine_x3f___closed__0;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__12;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay___closed__3;
size_t lean_uint64_to_usize(uint64_t);
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t l_Lean_Expr_isAppOfArity(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_toString(lean_object*, uint8_t, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__4;
static lean_object* l_EuclideanDisplay___closed__4;
static lean_object* l_EuclideanDisplay_rpc___lam__0___closed__2;
LEAN_EXPORT lean_object* l_constructLines___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__0;
uint8_t lean_usize_dec_eq(size_t, size_t);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__33;
lean_object* lean_mk_array(lean_object*, lean_object*);
static lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__0;
static lean_object* l_isBetweenPred_x3f___closed__1;
LEAN_EXPORT lean_object* l_EuclideanDisplay_dsl;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__15;
LEAN_EXPORT lean_object* l_isOnCirclePred_x3f(lean_object*);
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___rpc__wrapped;
LEAN_EXPORT lean_object* l_Lean_instantiateMVars___at___addHypotheses_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_EuclideanConstructions___closed__2___boxed__const__1;
LEAN_EXPORT lean_object* l_constructLines(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t l_Lean_Expr_isAppOf(lean_object*, lean_object*);
uint64_t lean_string_hash(lean_object*);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanConstructions_rpc___rpc__wrapped___closed__0;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__1;
LEAN_EXPORT lean_object* l_panic___at___EuclideanDisplay_rpc_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanConstructions___closed__0;
static lean_object* l_isPoint_x3f___closed__1;
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__0___closed__0;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4(lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Expr_appArg_x21(lean_object*);
static lean_object* l_isPoint_x3f___closed__0;
uint8_t l_Lean_Expr_hasMVar(lean_object*);
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanDisplay_rpc_spec__2_spec__2(lean_object*, lean_object*, size_t, size_t, lean_object*);
static lean_object* l_constructLines___lam__0___closed__5;
static lean_object* l_EuclideanDisplay___closed__2;
static lean_object* l_EuclideanConstructions_rpc___rpc__wrapped___closed__3;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
extern lean_object* l_Lean_Server_instInhabitedRequestError;
static lean_object* l_constructLines___lam__0___closed__3;
static lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__4;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*);
lean_object* lean_st_ref_take(lean_object*, lean_object*);
static lean_object* l_panic___at___EuclideanDisplay_rpc_spec__0___closed__0;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__4;
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___rpc__wrapped;
LEAN_EXPORT lean_object* l_EuclideanDisplay___closed__2___boxed__const__1;
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__2___boxed__const__1;
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
LEAN_EXPORT lean_object* l_isOnCirclePred_x3f___boxed(lean_object*);
lean_object* l_ProofWidgets_Penrose_DiagramBuilderM_addEmbed___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_isOnCirclePred_x3f___closed__0;
static lean_object* l_isInCirclePred_x3f___closed__1;
lean_object* lean_nat_div(lean_object*, lean_object*);
lean_object* l_Array_empty(lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__27;
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isCirclesInterPred_x3f___boxed(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__9;
LEAN_EXPORT uint8_t l_isLine_x3f(lean_object*);
LEAN_EXPORT lean_object* l_constructLines___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isOnLinePred_x3f(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__25;
static uint64_t l_EuclideanDisplay___closed__1;
LEAN_EXPORT lean_object* l_isLine_x3f___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Lean_instantiateMVars___at___addHypotheses_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__18;
static lean_object* l_isOnCirclePred_x3f___closed__1;
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__4;
lean_object* lean_st_ref_get(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___constructLines_spec__0___lam__0(lean_object*, lean_object*);
lean_object* l_instInhabitedForall___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__3;
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isCenterCirclePred_x3f___boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___constructLines_spec__0(lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__8;
static uint64_t l_EuclideanConstructions___closed__1;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__34;
static lean_object* l_constructLines___closed__2;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___rpc__wrapped___closed__1;
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__5;
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__3(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__1;
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__5;
lean_object* l_EStateM_instInhabited___redArg___lam__0(lean_object*, lean_object*);
lean_object* l_ProofWidgets_Penrose_DiagramBuilderM_run___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__0;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___closed__0;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__19;
LEAN_EXPORT lean_object* l_Lean_instantiateMVars___at___addHypotheses_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_isLine_x3f___closed__1;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__20;
uint8_t lean_name_eq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc(lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__0;
lean_object* l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__4;
static lean_object* l_constructLines___closed__0;
static lean_object* l_EuclideanDisplay_rpc___rpc__wrapped___closed__2;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Expr_appFn_x21(lean_object*);
static lean_object* l_constructLines___lam__0___closed__6;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0(lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__0___closed__1;
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint64_t l_Lean_hashFVarId____x40_Lean_Expr___hyg_1561_(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__31;
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__3;
static lean_object* l_EuclideanDisplay_dsl___closed__0;
LEAN_EXPORT lean_object* l_EuclideanDisplay_sty;
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_isCirclesInterPred_x3f___closed__1;
static lean_object* l_EuclideanDisplay___closed__0;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__6;
static lean_object* l_isCirclesInterPred_x3f___closed__0;
LEAN_EXPORT lean_object* l_Lean_instantiateMVars___at___addHypotheses_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_isOnLinePred_x3f___closed__0;
static lean_object* l_isBetweenPred_x3f___closed__2;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__6;
static lean_object* l_EuclideanConstructions_rpc___rpc__wrapped___closed__2;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__17;
LEAN_EXPORT lean_object* l_addHypotheses(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__5;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__22;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__28;
static lean_object* l_EuclideanDisplay_rpc___rpc__wrapped___closed__3;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__30;
lean_object* l_Lean_MVarId_getDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_constructLines___lam__0___closed__2;
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isCenterCirclePred_x3f(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___rpc__wrapped___closed__0;
LEAN_EXPORT uint8_t l_isPoint_x3f(lean_object*);
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__1(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_sty___closed__0;
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__2;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(lean_object*, uint64_t);
static lean_object* l_isInCirclePred_x3f___closed__0;
lean_object* l_Lean_PersistentArray_toArray___redArg(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__13;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
static lean_object* l_constructLines___lam__0___closed__1;
lean_object* l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__16;
lean_object* l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__7;
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
static lean_object* l_isCenterCirclePred_x3f___closed__1;
lean_object* lean_panic_fn(lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestM_readDoc___at___Lean_Server_RequestM_withWaitFindSnapAtPos_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___constructLines_spec__1(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_ProofWidgets_Penrose_DiagramBuilderM_buildDiagram(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__3___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isBetweenPred_x3f___boxed(lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__10;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__32;
static lean_object* l_EuclideanConstructions_rpc___rpc__wrapped___closed__1;
static lean_object* l_EuclideanConstructions___closed__3;
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__14;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__2;
LEAN_EXPORT lean_object* l_EuclideanDisplay;
lean_object* l_Nat_nextPowerOfTwo(lean_object*);
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isCirclesInterPred_x3f(lean_object*);
extern lean_object* l_ProofWidgets_MakeEditLink;
static lean_object* l_isCenterCirclePred_x3f___closed__0;
size_t lean_usize_sub(size_t, size_t);
lean_object* l_Lean_instantiateMVarsCore(lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* l_mkPanicMessageWithDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__5;
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc(lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanConstructions___closed__2;
static lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__1;
static lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__3;
lean_object* l_Lean_FVarId_getDecl___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_isOnLinePred_x3f___closed__1;
static lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__2;
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_array_size(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__2;
LEAN_EXPORT lean_object* l_isInCirclePred_x3f(lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_EuclideanConstructions;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isPoint_x3f___boxed(lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__24;
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_isBetweenPred_x3f___closed__0;
LEAN_EXPORT lean_object* l_constructLines___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__2_spec__2(lean_object*, size_t, size_t, lean_object*);
lean_object* l_Lean_Meta_withLCtx___at_____private_Lean_Meta_Basic_0__Lean_Meta_mkLevelErrorMessageCore_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
lean_object* l_Lean_LocalDecl_toExpr(lean_object*);
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__0;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__7;
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__3___closed__26;
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* l_Lean_LocalContext_sanitizeNames(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__9;
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__7;
lean_object* l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
static lean_object* l_constructLines___lam__0___closed__4;
LEAN_EXPORT lean_object* l_isOnLinePred_x3f___boxed(lean_object*);
static lean_object* l_constructLines___lam__0___closed__0;
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Elab_ContextInfo_runMetaM___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
static lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0;
uint8_t l_Std_DHashMap_Internal_AssocList_contains___at_____private_Lean_Meta_ExprDefEq_0__Lean_Meta_mkLambdaFVarsWithLetDeps_collectLetDeclsFrom_visit_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___constructLines_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_EuclideanDisplay_rpc___lam__0___closed__4;
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_isInCirclePred_x3f___boxed(lean_object*);
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_ProofWidgets_Component_MakeEditLink_0__ProofWidgets_toJsonMakeEditLinkProps____x40_ProofWidgets_Component_MakeEditLink___hyg_298_(lean_object*);
size_t lean_usize_land(size_t, size_t);
static lean_object* l_EuclideanConstructions_rpc___lam__3___closed__1;
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__2_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_l_isBetweenPred_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("IncidenceGeometry", 17, 17);
return x_1;
}
}
static lean_object* _init_l_isBetweenPred_x3f___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("between", 7, 7);
return x_1;
}
}
static lean_object* _init_l_isBetweenPred_x3f___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isBetweenPred_x3f___closed__1;
x_2 = l_isBetweenPred_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isBetweenPred_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_isBetweenPred_x3f___closed__2;
x_3 = lean_unsigned_to_nat(4u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_box(0);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_6 = l_Lean_Expr_appFn_x21(x_1);
x_7 = l_Lean_Expr_appFn_x21(x_6);
x_8 = l_Lean_Expr_appArg_x21(x_7);
lean_dec(x_7);
x_9 = l_Lean_Expr_appArg_x21(x_6);
lean_dec(x_6);
x_10 = l_Lean_Expr_appArg_x21(x_1);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_9);
lean_ctor_set(x_11, 1, x_10);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_8);
lean_ctor_set(x_12, 1, x_11);
x_13 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_13, 0, x_12);
return x_13;
}
}
}
LEAN_EXPORT lean_object* l_isBetweenPred_x3f___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_isBetweenPred_x3f(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_isOnLinePred_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("onLine", 6, 6);
return x_1;
}
}
static lean_object* _init_l_isOnLinePred_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isOnLinePred_x3f___closed__0;
x_2 = l_isBetweenPred_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isOnLinePred_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_isOnLinePred_x3f___closed__1;
x_3 = lean_unsigned_to_nat(3u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_box(0);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_6 = l_Lean_Expr_appFn_x21(x_1);
x_7 = l_Lean_Expr_appArg_x21(x_6);
lean_dec(x_6);
x_8 = l_Lean_Expr_appArg_x21(x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_10, 0, x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_isOnLinePred_x3f___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_isOnLinePred_x3f(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_isOnCirclePred_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("onCircle", 8, 8);
return x_1;
}
}
static lean_object* _init_l_isOnCirclePred_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isOnCirclePred_x3f___closed__0;
x_2 = l_isBetweenPred_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isOnCirclePred_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_isOnCirclePred_x3f___closed__1;
x_3 = lean_unsigned_to_nat(3u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_box(0);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_6 = l_Lean_Expr_appFn_x21(x_1);
x_7 = l_Lean_Expr_appArg_x21(x_6);
lean_dec(x_6);
x_8 = l_Lean_Expr_appArg_x21(x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_10, 0, x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_isOnCirclePred_x3f___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_isOnCirclePred_x3f(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_isInCirclePred_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("inCircle", 8, 8);
return x_1;
}
}
static lean_object* _init_l_isInCirclePred_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isInCirclePred_x3f___closed__0;
x_2 = l_isBetweenPred_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isInCirclePred_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_isInCirclePred_x3f___closed__1;
x_3 = lean_unsigned_to_nat(3u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_box(0);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_6 = l_Lean_Expr_appFn_x21(x_1);
x_7 = l_Lean_Expr_appArg_x21(x_6);
lean_dec(x_6);
x_8 = l_Lean_Expr_appArg_x21(x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_10, 0, x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_isInCirclePred_x3f___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_isInCirclePred_x3f(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_isCenterCirclePred_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("centerCircle", 12, 12);
return x_1;
}
}
static lean_object* _init_l_isCenterCirclePred_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isCenterCirclePred_x3f___closed__0;
x_2 = l_isBetweenPred_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isCenterCirclePred_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_isCenterCirclePred_x3f___closed__1;
x_3 = lean_unsigned_to_nat(3u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_box(0);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_6 = l_Lean_Expr_appFn_x21(x_1);
x_7 = l_Lean_Expr_appArg_x21(x_6);
lean_dec(x_6);
x_8 = l_Lean_Expr_appArg_x21(x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_10, 0, x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_isCenterCirclePred_x3f___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_isCenterCirclePred_x3f(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_isCirclesInterPred_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("circlesInter", 12, 12);
return x_1;
}
}
static lean_object* _init_l_isCirclesInterPred_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isCirclesInterPred_x3f___closed__0;
x_2 = l_isBetweenPred_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isCirclesInterPred_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_isCirclesInterPred_x3f___closed__1;
x_3 = lean_unsigned_to_nat(3u);
x_4 = l_Lean_Expr_isAppOfArity(x_1, x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; 
x_5 = lean_box(0);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_6 = l_Lean_Expr_appFn_x21(x_1);
x_7 = l_Lean_Expr_appArg_x21(x_6);
lean_dec(x_6);
x_8 = l_Lean_Expr_appArg_x21(x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_10, 0, x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_isCirclesInterPred_x3f___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_isCirclesInterPred_x3f(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_isPoint_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Point", 5, 5);
return x_1;
}
}
static lean_object* _init_l_isPoint_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isPoint_x3f___closed__0;
x_2 = l_isBetweenPred_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT uint8_t l_isPoint_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l_isPoint_x3f___closed__1;
x_3 = l_Lean_Expr_isAppOf(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isPoint_x3f___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_isPoint_x3f(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
static lean_object* _init_l_isLine_x3f___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Line", 4, 4);
return x_1;
}
}
static lean_object* _init_l_isLine_x3f___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_isLine_x3f___closed__0;
x_2 = l_isBetweenPred_x3f___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT uint8_t l_isLine_x3f(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l_isLine_x3f___closed__1;
x_3 = l_Lean_Expr_isAppOf(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_isLine_x3f___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_isLine_x3f(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_instantiateMVars___at___addHypotheses_spec__0___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = l_Lean_Expr_hasMVar(x_1);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_1);
lean_ctor_set(x_6, 1, x_2);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_4);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
x_8 = lean_st_ref_get(x_3, x_4);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = l_Lean_instantiateMVarsCore(x_11, x_1);
x_13 = !lean_is_exclusive(x_12);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; uint8_t x_18; 
x_14 = lean_ctor_get(x_12, 1);
x_15 = lean_st_ref_take(x_3, x_10);
x_16 = lean_ctor_get(x_15, 0);
lean_inc(x_16);
x_17 = lean_ctor_get(x_15, 1);
lean_inc(x_17);
lean_dec(x_15);
x_18 = !lean_is_exclusive(x_16);
if (x_18 == 0)
{
lean_object* x_19; lean_object* x_20; uint8_t x_21; 
x_19 = lean_ctor_get(x_16, 0);
lean_dec(x_19);
lean_ctor_set(x_16, 0, x_14);
x_20 = lean_st_ref_set(x_3, x_16, x_17);
x_21 = !lean_is_exclusive(x_20);
if (x_21 == 0)
{
lean_object* x_22; 
x_22 = lean_ctor_get(x_20, 0);
lean_dec(x_22);
lean_ctor_set(x_12, 1, x_2);
lean_ctor_set(x_20, 0, x_12);
return x_20;
}
else
{
lean_object* x_23; lean_object* x_24; 
x_23 = lean_ctor_get(x_20, 1);
lean_inc(x_23);
lean_dec(x_20);
lean_ctor_set(x_12, 1, x_2);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_12);
lean_ctor_set(x_24, 1, x_23);
return x_24;
}
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; 
x_25 = lean_ctor_get(x_16, 1);
x_26 = lean_ctor_get(x_16, 2);
x_27 = lean_ctor_get(x_16, 3);
x_28 = lean_ctor_get(x_16, 4);
lean_inc(x_28);
lean_inc(x_27);
lean_inc(x_26);
lean_inc(x_25);
lean_dec(x_16);
x_29 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_29, 0, x_14);
lean_ctor_set(x_29, 1, x_25);
lean_ctor_set(x_29, 2, x_26);
lean_ctor_set(x_29, 3, x_27);
lean_ctor_set(x_29, 4, x_28);
x_30 = lean_st_ref_set(x_3, x_29, x_17);
x_31 = lean_ctor_get(x_30, 1);
lean_inc(x_31);
if (lean_is_exclusive(x_30)) {
 lean_ctor_release(x_30, 0);
 lean_ctor_release(x_30, 1);
 x_32 = x_30;
} else {
 lean_dec_ref(x_30);
 x_32 = lean_box(0);
}
lean_ctor_set(x_12, 1, x_2);
if (lean_is_scalar(x_32)) {
 x_33 = lean_alloc_ctor(0, 2, 0);
} else {
 x_33 = x_32;
}
lean_ctor_set(x_33, 0, x_12);
lean_ctor_set(x_33, 1, x_31);
return x_33;
}
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_34 = lean_ctor_get(x_12, 0);
x_35 = lean_ctor_get(x_12, 1);
lean_inc(x_35);
lean_inc(x_34);
lean_dec(x_12);
x_36 = lean_st_ref_take(x_3, x_10);
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec(x_36);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
x_40 = lean_ctor_get(x_37, 2);
lean_inc(x_40);
x_41 = lean_ctor_get(x_37, 3);
lean_inc(x_41);
x_42 = lean_ctor_get(x_37, 4);
lean_inc(x_42);
if (lean_is_exclusive(x_37)) {
 lean_ctor_release(x_37, 0);
 lean_ctor_release(x_37, 1);
 lean_ctor_release(x_37, 2);
 lean_ctor_release(x_37, 3);
 lean_ctor_release(x_37, 4);
 x_43 = x_37;
} else {
 lean_dec_ref(x_37);
 x_43 = lean_box(0);
}
if (lean_is_scalar(x_43)) {
 x_44 = lean_alloc_ctor(0, 5, 0);
} else {
 x_44 = x_43;
}
lean_ctor_set(x_44, 0, x_35);
lean_ctor_set(x_44, 1, x_39);
lean_ctor_set(x_44, 2, x_40);
lean_ctor_set(x_44, 3, x_41);
lean_ctor_set(x_44, 4, x_42);
x_45 = lean_st_ref_set(x_3, x_44, x_38);
x_46 = lean_ctor_get(x_45, 1);
lean_inc(x_46);
if (lean_is_exclusive(x_45)) {
 lean_ctor_release(x_45, 0);
 lean_ctor_release(x_45, 1);
 x_47 = x_45;
} else {
 lean_dec_ref(x_45);
 x_47 = lean_box(0);
}
x_48 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_48, 0, x_34);
lean_ctor_set(x_48, 1, x_2);
if (lean_is_scalar(x_47)) {
 x_49 = lean_alloc_ctor(0, 2, 0);
} else {
 x_49 = x_47;
}
lean_ctor_set(x_49, 0, x_48);
lean_ctor_set(x_49, 1, x_46);
return x_49;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_instantiateMVars___at___addHypotheses_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_instantiateMVars___at___addHypotheses_spec__0___redArg(x_1, x_2, x_4, x_7);
return x_8;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Circle", 6, 6);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("CirclesInter(", 13, 13);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(", ", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("CenterCircle(", 13, 13);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("InCircle(", 9, 9);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("OnCircle(", 9, 9);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("OnLine(", 7, 7);
return x_1;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Between(", 8, 8);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_147; lean_object* x_148; lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_190; lean_object* x_191; lean_object* x_192; lean_object* x_193; lean_object* x_194; lean_object* x_195; lean_object* x_196; lean_object* x_233; lean_object* x_234; lean_object* x_235; lean_object* x_236; lean_object* x_237; lean_object* x_238; lean_object* x_239; uint8_t x_288; 
x_288 = lean_usize_dec_lt(x_4, x_3);
if (x_288 == 0)
{
lean_object* x_289; lean_object* x_290; 
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_289 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_289, 0, x_5);
lean_ctor_set(x_289, 1, x_6);
x_290 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_290, 0, x_289);
lean_ctor_set(x_290, 1, x_11);
return x_290;
}
else
{
lean_object* x_291; lean_object* x_292; lean_object* x_293; lean_object* x_294; lean_object* x_295; lean_object* x_296; lean_object* x_297; lean_object* x_298; lean_object* x_311; lean_object* x_329; 
lean_dec(x_5);
x_291 = lean_array_uget(x_2, x_4);
x_329 = lean_ctor_get(x_291, 3);
lean_inc(x_329);
x_311 = x_329;
goto block_328;
block_310:
{
uint8_t x_299; 
x_299 = l_isLine_x3f(x_292);
if (x_299 == 0)
{
lean_dec(x_291);
x_233 = x_292;
x_234 = x_293;
x_235 = x_294;
x_236 = x_295;
x_237 = x_296;
x_238 = x_297;
x_239 = x_298;
goto block_287;
}
else
{
lean_object* x_300; lean_object* x_301; lean_object* x_302; 
x_300 = l_isLine_x3f___closed__0;
x_301 = l_Lean_LocalDecl_toExpr(x_291);
lean_inc(x_297);
lean_inc(x_296);
lean_inc(x_295);
lean_inc(x_294);
x_302 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_300, x_301, x_293, x_294, x_295, x_296, x_297, x_298);
if (lean_obj_tag(x_302) == 0)
{
lean_object* x_303; lean_object* x_304; lean_object* x_305; 
x_303 = lean_ctor_get(x_302, 0);
lean_inc(x_303);
x_304 = lean_ctor_get(x_302, 1);
lean_inc(x_304);
lean_dec(x_302);
x_305 = lean_ctor_get(x_303, 1);
lean_inc(x_305);
lean_dec(x_303);
x_233 = x_292;
x_234 = x_305;
x_235 = x_294;
x_236 = x_295;
x_237 = x_296;
x_238 = x_297;
x_239 = x_304;
goto block_287;
}
else
{
uint8_t x_306; 
lean_dec(x_297);
lean_dec(x_296);
lean_dec(x_295);
lean_dec(x_294);
lean_dec(x_292);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_306 = !lean_is_exclusive(x_302);
if (x_306 == 0)
{
return x_302;
}
else
{
lean_object* x_307; lean_object* x_308; lean_object* x_309; 
x_307 = lean_ctor_get(x_302, 0);
x_308 = lean_ctor_get(x_302, 1);
lean_inc(x_308);
lean_inc(x_307);
lean_dec(x_302);
x_309 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_309, 0, x_307);
lean_ctor_set(x_309, 1, x_308);
return x_309;
}
}
}
}
block_328:
{
lean_object* x_312; lean_object* x_313; lean_object* x_314; lean_object* x_315; lean_object* x_316; uint8_t x_317; 
x_312 = l_Lean_instantiateMVars___at___addHypotheses_spec__0___redArg(x_311, x_6, x_8, x_11);
x_313 = lean_ctor_get(x_312, 0);
lean_inc(x_313);
x_314 = lean_ctor_get(x_312, 1);
lean_inc(x_314);
lean_dec(x_312);
x_315 = lean_ctor_get(x_313, 0);
lean_inc(x_315);
x_316 = lean_ctor_get(x_313, 1);
lean_inc(x_316);
lean_dec(x_313);
x_317 = l_isPoint_x3f(x_315);
if (x_317 == 0)
{
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
x_292 = x_315;
x_293 = x_316;
x_294 = x_7;
x_295 = x_8;
x_296 = x_9;
x_297 = x_10;
x_298 = x_314;
goto block_310;
}
else
{
lean_object* x_318; lean_object* x_319; lean_object* x_320; 
x_318 = l_isPoint_x3f___closed__0;
lean_inc(x_291);
x_319 = l_Lean_LocalDecl_toExpr(x_291);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
x_320 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_318, x_319, x_316, x_7, x_8, x_9, x_10, x_314);
if (lean_obj_tag(x_320) == 0)
{
lean_object* x_321; lean_object* x_322; lean_object* x_323; 
x_321 = lean_ctor_get(x_320, 0);
lean_inc(x_321);
x_322 = lean_ctor_get(x_320, 1);
lean_inc(x_322);
lean_dec(x_320);
x_323 = lean_ctor_get(x_321, 1);
lean_inc(x_323);
lean_dec(x_321);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
x_292 = x_315;
x_293 = x_323;
x_294 = x_7;
x_295 = x_8;
x_296 = x_9;
x_297 = x_10;
x_298 = x_322;
goto block_310;
}
else
{
uint8_t x_324; 
lean_dec(x_315);
lean_dec(x_291);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_324 = !lean_is_exclusive(x_320);
if (x_324 == 0)
{
return x_320;
}
else
{
lean_object* x_325; lean_object* x_326; lean_object* x_327; 
x_325 = lean_ctor_get(x_320, 0);
x_326 = lean_ctor_get(x_320, 1);
lean_inc(x_326);
lean_inc(x_325);
lean_dec(x_320);
x_327 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_327, 0, x_325);
lean_ctor_set(x_327, 1, x_326);
return x_327;
}
}
}
}
}
block_18:
{
size_t x_15; size_t x_16; 
x_15 = 1;
x_16 = lean_usize_add(x_4, x_15);
x_4 = x_16;
x_5 = x_12;
x_6 = x_13;
x_11 = x_14;
goto _start;
}
block_60:
{
lean_object* x_26; 
x_26 = l_isCirclesInterPred_x3f(x_19);
lean_dec(x_19);
if (lean_obj_tag(x_26) == 0)
{
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_21);
lean_inc(x_1);
x_12 = x_1;
x_13 = x_20;
x_14 = x_25;
goto block_18;
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_27 = lean_ctor_get(x_26, 0);
lean_inc(x_27);
lean_dec(x_26);
x_28 = lean_ctor_get(x_27, 0);
lean_inc(x_28);
x_29 = lean_ctor_get(x_27, 1);
lean_inc(x_29);
lean_dec(x_27);
x_30 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0;
lean_inc(x_24);
lean_inc(x_23);
lean_inc(x_22);
lean_inc(x_21);
x_31 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_30, x_28, x_20, x_21, x_22, x_23, x_24, x_25);
if (lean_obj_tag(x_31) == 0)
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_32 = lean_ctor_get(x_31, 0);
lean_inc(x_32);
x_33 = lean_ctor_get(x_31, 1);
lean_inc(x_33);
lean_dec(x_31);
x_34 = lean_ctor_get(x_32, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_32, 1);
lean_inc(x_35);
lean_dec(x_32);
x_36 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_30, x_29, x_35, x_21, x_22, x_23, x_24, x_33);
if (lean_obj_tag(x_36) == 0)
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec(x_36);
x_39 = lean_ctor_get(x_37, 0);
lean_inc(x_39);
x_40 = lean_ctor_get(x_37, 1);
lean_inc(x_40);
lean_dec(x_37);
x_41 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__1;
x_42 = lean_string_append(x_41, x_34);
lean_dec(x_34);
x_43 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2;
x_44 = lean_string_append(x_42, x_43);
x_45 = lean_string_append(x_44, x_39);
lean_dec(x_39);
x_46 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
x_47 = lean_string_append(x_45, x_46);
x_48 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_47, x_40, x_38);
x_49 = lean_ctor_get(x_48, 0);
lean_inc(x_49);
x_50 = lean_ctor_get(x_48, 1);
lean_inc(x_50);
lean_dec(x_48);
x_51 = lean_ctor_get(x_49, 1);
lean_inc(x_51);
lean_dec(x_49);
lean_inc(x_1);
x_12 = x_1;
x_13 = x_51;
x_14 = x_50;
goto block_18;
}
else
{
uint8_t x_52; 
lean_dec(x_34);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_52 = !lean_is_exclusive(x_36);
if (x_52 == 0)
{
return x_36;
}
else
{
lean_object* x_53; lean_object* x_54; lean_object* x_55; 
x_53 = lean_ctor_get(x_36, 0);
x_54 = lean_ctor_get(x_36, 1);
lean_inc(x_54);
lean_inc(x_53);
lean_dec(x_36);
x_55 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_55, 0, x_53);
lean_ctor_set(x_55, 1, x_54);
return x_55;
}
}
}
else
{
uint8_t x_56; 
lean_dec(x_29);
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_21);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_56 = !lean_is_exclusive(x_31);
if (x_56 == 0)
{
return x_31;
}
else
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_57 = lean_ctor_get(x_31, 0);
x_58 = lean_ctor_get(x_31, 1);
lean_inc(x_58);
lean_inc(x_57);
lean_dec(x_31);
x_59 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_59, 0, x_57);
lean_ctor_set(x_59, 1, x_58);
return x_59;
}
}
}
}
block_103:
{
lean_object* x_68; 
x_68 = l_isCenterCirclePred_x3f(x_61);
if (lean_obj_tag(x_68) == 0)
{
x_19 = x_61;
x_20 = x_62;
x_21 = x_63;
x_22 = x_64;
x_23 = x_65;
x_24 = x_66;
x_25 = x_67;
goto block_60;
}
else
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; 
x_69 = lean_ctor_get(x_68, 0);
lean_inc(x_69);
lean_dec(x_68);
x_70 = lean_ctor_get(x_69, 0);
lean_inc(x_70);
x_71 = lean_ctor_get(x_69, 1);
lean_inc(x_71);
lean_dec(x_69);
x_72 = l_isPoint_x3f___closed__0;
lean_inc(x_66);
lean_inc(x_65);
lean_inc(x_64);
lean_inc(x_63);
x_73 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_72, x_70, x_62, x_63, x_64, x_65, x_66, x_67);
if (lean_obj_tag(x_73) == 0)
{
lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; 
x_74 = lean_ctor_get(x_73, 0);
lean_inc(x_74);
x_75 = lean_ctor_get(x_73, 1);
lean_inc(x_75);
lean_dec(x_73);
x_76 = lean_ctor_get(x_74, 0);
lean_inc(x_76);
x_77 = lean_ctor_get(x_74, 1);
lean_inc(x_77);
lean_dec(x_74);
x_78 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0;
lean_inc(x_66);
lean_inc(x_65);
lean_inc(x_64);
lean_inc(x_63);
x_79 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_78, x_71, x_77, x_63, x_64, x_65, x_66, x_75);
if (lean_obj_tag(x_79) == 0)
{
lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; 
x_80 = lean_ctor_get(x_79, 0);
lean_inc(x_80);
x_81 = lean_ctor_get(x_79, 1);
lean_inc(x_81);
lean_dec(x_79);
x_82 = lean_ctor_get(x_80, 0);
lean_inc(x_82);
x_83 = lean_ctor_get(x_80, 1);
lean_inc(x_83);
lean_dec(x_80);
x_84 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__4;
x_85 = lean_string_append(x_84, x_76);
lean_dec(x_76);
x_86 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2;
x_87 = lean_string_append(x_85, x_86);
x_88 = lean_string_append(x_87, x_82);
lean_dec(x_82);
x_89 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
x_90 = lean_string_append(x_88, x_89);
x_91 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_90, x_83, x_81);
x_92 = lean_ctor_get(x_91, 0);
lean_inc(x_92);
x_93 = lean_ctor_get(x_91, 1);
lean_inc(x_93);
lean_dec(x_91);
x_94 = lean_ctor_get(x_92, 1);
lean_inc(x_94);
lean_dec(x_92);
x_19 = x_61;
x_20 = x_94;
x_21 = x_63;
x_22 = x_64;
x_23 = x_65;
x_24 = x_66;
x_25 = x_93;
goto block_60;
}
else
{
uint8_t x_95; 
lean_dec(x_76);
lean_dec(x_66);
lean_dec(x_65);
lean_dec(x_64);
lean_dec(x_63);
lean_dec(x_61);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_95 = !lean_is_exclusive(x_79);
if (x_95 == 0)
{
return x_79;
}
else
{
lean_object* x_96; lean_object* x_97; lean_object* x_98; 
x_96 = lean_ctor_get(x_79, 0);
x_97 = lean_ctor_get(x_79, 1);
lean_inc(x_97);
lean_inc(x_96);
lean_dec(x_79);
x_98 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_98, 0, x_96);
lean_ctor_set(x_98, 1, x_97);
return x_98;
}
}
}
else
{
uint8_t x_99; 
lean_dec(x_71);
lean_dec(x_66);
lean_dec(x_65);
lean_dec(x_64);
lean_dec(x_63);
lean_dec(x_61);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_99 = !lean_is_exclusive(x_73);
if (x_99 == 0)
{
return x_73;
}
else
{
lean_object* x_100; lean_object* x_101; lean_object* x_102; 
x_100 = lean_ctor_get(x_73, 0);
x_101 = lean_ctor_get(x_73, 1);
lean_inc(x_101);
lean_inc(x_100);
lean_dec(x_73);
x_102 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_102, 0, x_100);
lean_ctor_set(x_102, 1, x_101);
return x_102;
}
}
}
}
block_146:
{
lean_object* x_111; 
x_111 = l_isInCirclePred_x3f(x_104);
if (lean_obj_tag(x_111) == 0)
{
x_61 = x_104;
x_62 = x_105;
x_63 = x_106;
x_64 = x_107;
x_65 = x_108;
x_66 = x_109;
x_67 = x_110;
goto block_103;
}
else
{
lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; 
x_112 = lean_ctor_get(x_111, 0);
lean_inc(x_112);
lean_dec(x_111);
x_113 = lean_ctor_get(x_112, 0);
lean_inc(x_113);
x_114 = lean_ctor_get(x_112, 1);
lean_inc(x_114);
lean_dec(x_112);
x_115 = l_isPoint_x3f___closed__0;
lean_inc(x_109);
lean_inc(x_108);
lean_inc(x_107);
lean_inc(x_106);
x_116 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_115, x_113, x_105, x_106, x_107, x_108, x_109, x_110);
if (lean_obj_tag(x_116) == 0)
{
lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; 
x_117 = lean_ctor_get(x_116, 0);
lean_inc(x_117);
x_118 = lean_ctor_get(x_116, 1);
lean_inc(x_118);
lean_dec(x_116);
x_119 = lean_ctor_get(x_117, 0);
lean_inc(x_119);
x_120 = lean_ctor_get(x_117, 1);
lean_inc(x_120);
lean_dec(x_117);
x_121 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0;
lean_inc(x_109);
lean_inc(x_108);
lean_inc(x_107);
lean_inc(x_106);
x_122 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_121, x_114, x_120, x_106, x_107, x_108, x_109, x_118);
if (lean_obj_tag(x_122) == 0)
{
lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; 
x_123 = lean_ctor_get(x_122, 0);
lean_inc(x_123);
x_124 = lean_ctor_get(x_122, 1);
lean_inc(x_124);
lean_dec(x_122);
x_125 = lean_ctor_get(x_123, 0);
lean_inc(x_125);
x_126 = lean_ctor_get(x_123, 1);
lean_inc(x_126);
lean_dec(x_123);
x_127 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__5;
x_128 = lean_string_append(x_127, x_119);
lean_dec(x_119);
x_129 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2;
x_130 = lean_string_append(x_128, x_129);
x_131 = lean_string_append(x_130, x_125);
lean_dec(x_125);
x_132 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
x_133 = lean_string_append(x_131, x_132);
x_134 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_133, x_126, x_124);
x_135 = lean_ctor_get(x_134, 0);
lean_inc(x_135);
x_136 = lean_ctor_get(x_134, 1);
lean_inc(x_136);
lean_dec(x_134);
x_137 = lean_ctor_get(x_135, 1);
lean_inc(x_137);
lean_dec(x_135);
x_61 = x_104;
x_62 = x_137;
x_63 = x_106;
x_64 = x_107;
x_65 = x_108;
x_66 = x_109;
x_67 = x_136;
goto block_103;
}
else
{
uint8_t x_138; 
lean_dec(x_119);
lean_dec(x_109);
lean_dec(x_108);
lean_dec(x_107);
lean_dec(x_106);
lean_dec(x_104);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_138 = !lean_is_exclusive(x_122);
if (x_138 == 0)
{
return x_122;
}
else
{
lean_object* x_139; lean_object* x_140; lean_object* x_141; 
x_139 = lean_ctor_get(x_122, 0);
x_140 = lean_ctor_get(x_122, 1);
lean_inc(x_140);
lean_inc(x_139);
lean_dec(x_122);
x_141 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_141, 0, x_139);
lean_ctor_set(x_141, 1, x_140);
return x_141;
}
}
}
else
{
uint8_t x_142; 
lean_dec(x_114);
lean_dec(x_109);
lean_dec(x_108);
lean_dec(x_107);
lean_dec(x_106);
lean_dec(x_104);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_142 = !lean_is_exclusive(x_116);
if (x_142 == 0)
{
return x_116;
}
else
{
lean_object* x_143; lean_object* x_144; lean_object* x_145; 
x_143 = lean_ctor_get(x_116, 0);
x_144 = lean_ctor_get(x_116, 1);
lean_inc(x_144);
lean_inc(x_143);
lean_dec(x_116);
x_145 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_145, 0, x_143);
lean_ctor_set(x_145, 1, x_144);
return x_145;
}
}
}
}
block_189:
{
lean_object* x_154; 
x_154 = l_isOnCirclePred_x3f(x_147);
if (lean_obj_tag(x_154) == 0)
{
x_104 = x_147;
x_105 = x_148;
x_106 = x_149;
x_107 = x_150;
x_108 = x_151;
x_109 = x_152;
x_110 = x_153;
goto block_146;
}
else
{
lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; 
x_155 = lean_ctor_get(x_154, 0);
lean_inc(x_155);
lean_dec(x_154);
x_156 = lean_ctor_get(x_155, 0);
lean_inc(x_156);
x_157 = lean_ctor_get(x_155, 1);
lean_inc(x_157);
lean_dec(x_155);
x_158 = l_isPoint_x3f___closed__0;
lean_inc(x_152);
lean_inc(x_151);
lean_inc(x_150);
lean_inc(x_149);
x_159 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_158, x_156, x_148, x_149, x_150, x_151, x_152, x_153);
if (lean_obj_tag(x_159) == 0)
{
lean_object* x_160; lean_object* x_161; lean_object* x_162; lean_object* x_163; lean_object* x_164; lean_object* x_165; 
x_160 = lean_ctor_get(x_159, 0);
lean_inc(x_160);
x_161 = lean_ctor_get(x_159, 1);
lean_inc(x_161);
lean_dec(x_159);
x_162 = lean_ctor_get(x_160, 0);
lean_inc(x_162);
x_163 = lean_ctor_get(x_160, 1);
lean_inc(x_163);
lean_dec(x_160);
x_164 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0;
lean_inc(x_152);
lean_inc(x_151);
lean_inc(x_150);
lean_inc(x_149);
x_165 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_164, x_157, x_163, x_149, x_150, x_151, x_152, x_161);
if (lean_obj_tag(x_165) == 0)
{
lean_object* x_166; lean_object* x_167; lean_object* x_168; lean_object* x_169; lean_object* x_170; lean_object* x_171; lean_object* x_172; lean_object* x_173; lean_object* x_174; lean_object* x_175; lean_object* x_176; lean_object* x_177; lean_object* x_178; lean_object* x_179; lean_object* x_180; 
x_166 = lean_ctor_get(x_165, 0);
lean_inc(x_166);
x_167 = lean_ctor_get(x_165, 1);
lean_inc(x_167);
lean_dec(x_165);
x_168 = lean_ctor_get(x_166, 0);
lean_inc(x_168);
x_169 = lean_ctor_get(x_166, 1);
lean_inc(x_169);
lean_dec(x_166);
x_170 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__6;
x_171 = lean_string_append(x_170, x_162);
lean_dec(x_162);
x_172 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2;
x_173 = lean_string_append(x_171, x_172);
x_174 = lean_string_append(x_173, x_168);
lean_dec(x_168);
x_175 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
x_176 = lean_string_append(x_174, x_175);
x_177 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_176, x_169, x_167);
x_178 = lean_ctor_get(x_177, 0);
lean_inc(x_178);
x_179 = lean_ctor_get(x_177, 1);
lean_inc(x_179);
lean_dec(x_177);
x_180 = lean_ctor_get(x_178, 1);
lean_inc(x_180);
lean_dec(x_178);
x_104 = x_147;
x_105 = x_180;
x_106 = x_149;
x_107 = x_150;
x_108 = x_151;
x_109 = x_152;
x_110 = x_179;
goto block_146;
}
else
{
uint8_t x_181; 
lean_dec(x_162);
lean_dec(x_152);
lean_dec(x_151);
lean_dec(x_150);
lean_dec(x_149);
lean_dec(x_147);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_181 = !lean_is_exclusive(x_165);
if (x_181 == 0)
{
return x_165;
}
else
{
lean_object* x_182; lean_object* x_183; lean_object* x_184; 
x_182 = lean_ctor_get(x_165, 0);
x_183 = lean_ctor_get(x_165, 1);
lean_inc(x_183);
lean_inc(x_182);
lean_dec(x_165);
x_184 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_184, 0, x_182);
lean_ctor_set(x_184, 1, x_183);
return x_184;
}
}
}
else
{
uint8_t x_185; 
lean_dec(x_157);
lean_dec(x_152);
lean_dec(x_151);
lean_dec(x_150);
lean_dec(x_149);
lean_dec(x_147);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_185 = !lean_is_exclusive(x_159);
if (x_185 == 0)
{
return x_159;
}
else
{
lean_object* x_186; lean_object* x_187; lean_object* x_188; 
x_186 = lean_ctor_get(x_159, 0);
x_187 = lean_ctor_get(x_159, 1);
lean_inc(x_187);
lean_inc(x_186);
lean_dec(x_159);
x_188 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_188, 0, x_186);
lean_ctor_set(x_188, 1, x_187);
return x_188;
}
}
}
}
block_232:
{
lean_object* x_197; 
x_197 = l_isOnLinePred_x3f(x_190);
if (lean_obj_tag(x_197) == 0)
{
x_147 = x_190;
x_148 = x_191;
x_149 = x_192;
x_150 = x_193;
x_151 = x_194;
x_152 = x_195;
x_153 = x_196;
goto block_189;
}
else
{
lean_object* x_198; lean_object* x_199; lean_object* x_200; lean_object* x_201; lean_object* x_202; 
x_198 = lean_ctor_get(x_197, 0);
lean_inc(x_198);
lean_dec(x_197);
x_199 = lean_ctor_get(x_198, 0);
lean_inc(x_199);
x_200 = lean_ctor_get(x_198, 1);
lean_inc(x_200);
lean_dec(x_198);
x_201 = l_isPoint_x3f___closed__0;
lean_inc(x_195);
lean_inc(x_194);
lean_inc(x_193);
lean_inc(x_192);
x_202 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_201, x_199, x_191, x_192, x_193, x_194, x_195, x_196);
if (lean_obj_tag(x_202) == 0)
{
lean_object* x_203; lean_object* x_204; lean_object* x_205; lean_object* x_206; lean_object* x_207; lean_object* x_208; 
x_203 = lean_ctor_get(x_202, 0);
lean_inc(x_203);
x_204 = lean_ctor_get(x_202, 1);
lean_inc(x_204);
lean_dec(x_202);
x_205 = lean_ctor_get(x_203, 0);
lean_inc(x_205);
x_206 = lean_ctor_get(x_203, 1);
lean_inc(x_206);
lean_dec(x_203);
x_207 = l_isLine_x3f___closed__0;
lean_inc(x_195);
lean_inc(x_194);
lean_inc(x_193);
lean_inc(x_192);
x_208 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_207, x_200, x_206, x_192, x_193, x_194, x_195, x_204);
if (lean_obj_tag(x_208) == 0)
{
lean_object* x_209; lean_object* x_210; lean_object* x_211; lean_object* x_212; lean_object* x_213; lean_object* x_214; lean_object* x_215; lean_object* x_216; lean_object* x_217; lean_object* x_218; lean_object* x_219; lean_object* x_220; lean_object* x_221; lean_object* x_222; lean_object* x_223; 
x_209 = lean_ctor_get(x_208, 0);
lean_inc(x_209);
x_210 = lean_ctor_get(x_208, 1);
lean_inc(x_210);
lean_dec(x_208);
x_211 = lean_ctor_get(x_209, 0);
lean_inc(x_211);
x_212 = lean_ctor_get(x_209, 1);
lean_inc(x_212);
lean_dec(x_209);
x_213 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__7;
x_214 = lean_string_append(x_213, x_205);
lean_dec(x_205);
x_215 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2;
x_216 = lean_string_append(x_214, x_215);
x_217 = lean_string_append(x_216, x_211);
lean_dec(x_211);
x_218 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
x_219 = lean_string_append(x_217, x_218);
x_220 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_219, x_212, x_210);
x_221 = lean_ctor_get(x_220, 0);
lean_inc(x_221);
x_222 = lean_ctor_get(x_220, 1);
lean_inc(x_222);
lean_dec(x_220);
x_223 = lean_ctor_get(x_221, 1);
lean_inc(x_223);
lean_dec(x_221);
x_147 = x_190;
x_148 = x_223;
x_149 = x_192;
x_150 = x_193;
x_151 = x_194;
x_152 = x_195;
x_153 = x_222;
goto block_189;
}
else
{
uint8_t x_224; 
lean_dec(x_205);
lean_dec(x_195);
lean_dec(x_194);
lean_dec(x_193);
lean_dec(x_192);
lean_dec(x_190);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_224 = !lean_is_exclusive(x_208);
if (x_224 == 0)
{
return x_208;
}
else
{
lean_object* x_225; lean_object* x_226; lean_object* x_227; 
x_225 = lean_ctor_get(x_208, 0);
x_226 = lean_ctor_get(x_208, 1);
lean_inc(x_226);
lean_inc(x_225);
lean_dec(x_208);
x_227 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_227, 0, x_225);
lean_ctor_set(x_227, 1, x_226);
return x_227;
}
}
}
else
{
uint8_t x_228; 
lean_dec(x_200);
lean_dec(x_195);
lean_dec(x_194);
lean_dec(x_193);
lean_dec(x_192);
lean_dec(x_190);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_228 = !lean_is_exclusive(x_202);
if (x_228 == 0)
{
return x_202;
}
else
{
lean_object* x_229; lean_object* x_230; lean_object* x_231; 
x_229 = lean_ctor_get(x_202, 0);
x_230 = lean_ctor_get(x_202, 1);
lean_inc(x_230);
lean_inc(x_229);
lean_dec(x_202);
x_231 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_231, 0, x_229);
lean_ctor_set(x_231, 1, x_230);
return x_231;
}
}
}
}
block_287:
{
lean_object* x_240; 
x_240 = l_isBetweenPred_x3f(x_233);
if (lean_obj_tag(x_240) == 0)
{
x_190 = x_233;
x_191 = x_234;
x_192 = x_235;
x_193 = x_236;
x_194 = x_237;
x_195 = x_238;
x_196 = x_239;
goto block_232;
}
else
{
lean_object* x_241; lean_object* x_242; lean_object* x_243; lean_object* x_244; lean_object* x_245; lean_object* x_246; lean_object* x_247; 
x_241 = lean_ctor_get(x_240, 0);
lean_inc(x_241);
lean_dec(x_240);
x_242 = lean_ctor_get(x_241, 1);
lean_inc(x_242);
x_243 = lean_ctor_get(x_241, 0);
lean_inc(x_243);
lean_dec(x_241);
x_244 = lean_ctor_get(x_242, 0);
lean_inc(x_244);
x_245 = lean_ctor_get(x_242, 1);
lean_inc(x_245);
lean_dec(x_242);
x_246 = l_isPoint_x3f___closed__0;
lean_inc(x_238);
lean_inc(x_237);
lean_inc(x_236);
lean_inc(x_235);
x_247 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_246, x_243, x_234, x_235, x_236, x_237, x_238, x_239);
if (lean_obj_tag(x_247) == 0)
{
lean_object* x_248; lean_object* x_249; lean_object* x_250; lean_object* x_251; lean_object* x_252; 
x_248 = lean_ctor_get(x_247, 0);
lean_inc(x_248);
x_249 = lean_ctor_get(x_247, 1);
lean_inc(x_249);
lean_dec(x_247);
x_250 = lean_ctor_get(x_248, 0);
lean_inc(x_250);
x_251 = lean_ctor_get(x_248, 1);
lean_inc(x_251);
lean_dec(x_248);
lean_inc(x_238);
lean_inc(x_237);
lean_inc(x_236);
lean_inc(x_235);
x_252 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_246, x_244, x_251, x_235, x_236, x_237, x_238, x_249);
if (lean_obj_tag(x_252) == 0)
{
lean_object* x_253; lean_object* x_254; lean_object* x_255; lean_object* x_256; lean_object* x_257; 
x_253 = lean_ctor_get(x_252, 0);
lean_inc(x_253);
x_254 = lean_ctor_get(x_252, 1);
lean_inc(x_254);
lean_dec(x_252);
x_255 = lean_ctor_get(x_253, 0);
lean_inc(x_255);
x_256 = lean_ctor_get(x_253, 1);
lean_inc(x_256);
lean_dec(x_253);
lean_inc(x_238);
lean_inc(x_237);
lean_inc(x_236);
lean_inc(x_235);
x_257 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_246, x_245, x_256, x_235, x_236, x_237, x_238, x_254);
if (lean_obj_tag(x_257) == 0)
{
lean_object* x_258; lean_object* x_259; lean_object* x_260; lean_object* x_261; lean_object* x_262; lean_object* x_263; lean_object* x_264; lean_object* x_265; lean_object* x_266; lean_object* x_267; lean_object* x_268; lean_object* x_269; lean_object* x_270; lean_object* x_271; lean_object* x_272; lean_object* x_273; lean_object* x_274; 
x_258 = lean_ctor_get(x_257, 0);
lean_inc(x_258);
x_259 = lean_ctor_get(x_257, 1);
lean_inc(x_259);
lean_dec(x_257);
x_260 = lean_ctor_get(x_258, 0);
lean_inc(x_260);
x_261 = lean_ctor_get(x_258, 1);
lean_inc(x_261);
lean_dec(x_258);
x_262 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__8;
x_263 = lean_string_append(x_262, x_250);
lean_dec(x_250);
x_264 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2;
x_265 = lean_string_append(x_263, x_264);
x_266 = lean_string_append(x_265, x_255);
lean_dec(x_255);
x_267 = lean_string_append(x_266, x_264);
x_268 = lean_string_append(x_267, x_260);
lean_dec(x_260);
x_269 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
x_270 = lean_string_append(x_268, x_269);
x_271 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_270, x_261, x_259);
x_272 = lean_ctor_get(x_271, 0);
lean_inc(x_272);
x_273 = lean_ctor_get(x_271, 1);
lean_inc(x_273);
lean_dec(x_271);
x_274 = lean_ctor_get(x_272, 1);
lean_inc(x_274);
lean_dec(x_272);
x_190 = x_233;
x_191 = x_274;
x_192 = x_235;
x_193 = x_236;
x_194 = x_237;
x_195 = x_238;
x_196 = x_273;
goto block_232;
}
else
{
uint8_t x_275; 
lean_dec(x_255);
lean_dec(x_250);
lean_dec(x_238);
lean_dec(x_237);
lean_dec(x_236);
lean_dec(x_235);
lean_dec(x_233);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_275 = !lean_is_exclusive(x_257);
if (x_275 == 0)
{
return x_257;
}
else
{
lean_object* x_276; lean_object* x_277; lean_object* x_278; 
x_276 = lean_ctor_get(x_257, 0);
x_277 = lean_ctor_get(x_257, 1);
lean_inc(x_277);
lean_inc(x_276);
lean_dec(x_257);
x_278 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_278, 0, x_276);
lean_ctor_set(x_278, 1, x_277);
return x_278;
}
}
}
else
{
uint8_t x_279; 
lean_dec(x_250);
lean_dec(x_245);
lean_dec(x_238);
lean_dec(x_237);
lean_dec(x_236);
lean_dec(x_235);
lean_dec(x_233);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_279 = !lean_is_exclusive(x_252);
if (x_279 == 0)
{
return x_252;
}
else
{
lean_object* x_280; lean_object* x_281; lean_object* x_282; 
x_280 = lean_ctor_get(x_252, 0);
x_281 = lean_ctor_get(x_252, 1);
lean_inc(x_281);
lean_inc(x_280);
lean_dec(x_252);
x_282 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_282, 0, x_280);
lean_ctor_set(x_282, 1, x_281);
return x_282;
}
}
}
else
{
uint8_t x_283; 
lean_dec(x_245);
lean_dec(x_244);
lean_dec(x_238);
lean_dec(x_237);
lean_dec(x_236);
lean_dec(x_235);
lean_dec(x_233);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
x_283 = !lean_is_exclusive(x_247);
if (x_283 == 0)
{
return x_247;
}
else
{
lean_object* x_284; lean_object* x_285; lean_object* x_286; 
x_284 = lean_ctor_get(x_247, 0);
x_285 = lean_ctor_get(x_247, 1);
lean_inc(x_285);
lean_inc(x_284);
lean_dec(x_247);
x_286 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_286, 0, x_284);
lean_ctor_set(x_286, 1, x_285);
return x_286;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_addHypotheses(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; size_t x_9; size_t x_10; lean_object* x_11; 
x_8 = lean_box(0);
x_9 = lean_array_size(x_1);
x_10 = 0;
x_11 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1(x_8, x_1, x_9, x_10, x_8, x_2, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_11) == 0)
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
lean_object* x_13; uint8_t x_14; 
x_13 = lean_ctor_get(x_11, 0);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; 
x_15 = lean_ctor_get(x_13, 0);
lean_dec(x_15);
lean_ctor_set(x_13, 0, x_8);
return x_11;
}
else
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_16);
lean_dec(x_13);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_8);
lean_ctor_set(x_17, 1, x_16);
lean_ctor_set(x_11, 0, x_17);
return x_11;
}
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_18 = lean_ctor_get(x_11, 0);
x_19 = lean_ctor_get(x_11, 1);
lean_inc(x_19);
lean_inc(x_18);
lean_dec(x_11);
x_20 = lean_ctor_get(x_18, 1);
lean_inc(x_20);
if (lean_is_exclusive(x_18)) {
 lean_ctor_release(x_18, 0);
 lean_ctor_release(x_18, 1);
 x_21 = x_18;
} else {
 lean_dec_ref(x_18);
 x_21 = lean_box(0);
}
if (lean_is_scalar(x_21)) {
 x_22 = lean_alloc_ctor(0, 2, 0);
} else {
 x_22 = x_21;
}
lean_ctor_set(x_22, 0, x_8);
lean_ctor_set(x_22, 1, x_20);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_19);
return x_23;
}
}
else
{
return x_11;
}
}
}
LEAN_EXPORT lean_object* l_Lean_instantiateMVars___at___addHypotheses_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Lean_instantiateMVars___at___addHypotheses_spec__0___redArg(x_1, x_2, x_3, x_4);
lean_dec(x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Lean_instantiateMVars___at___addHypotheses_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_instantiateMVars___at___addHypotheses_spec__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
size_t x_12; size_t x_13; lean_object* x_14; 
x_12 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_13 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_14 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1(x_1, x_2, x_12, x_13, x_5, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec(x_2);
return x_14;
}
}
LEAN_EXPORT lean_object* l_addHypotheses___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_addHypotheses(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_1);
return x_8;
}
}
static lean_object* _init_l_EuclideanDisplay_dsl___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("type Object\ntype Point <: Object\ntype Line <: Object\ntype Circle <: Object\n\npredicate Between(Point a, Point b, Point c)\npredicate OnLine(Point a, Line L)\npredicate OnCircle(Point a, Circle C)\npredicate InCircle(Point a, Circle C)\npredicate CenterCircle(Point a, Circle C)\npredicate CirclesInter(Circle C, Circle D)\n\npredicate Emphasize(Object o)\n", 347, 347);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_dsl() {
_start:
{
lean_object* x_1; 
x_1 = l_EuclideanDisplay_dsl___closed__0;
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_sty___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("-- inspired by https://github.com/penrose/penrose/blob/499cd21f39549abd317976f492b803a09ce2277d/packages/examples/src/geometry-domain/euclidean-teaser.style\n\nlayout = [shape, label]\n\nColors {\n  -- Keenan palette\n  black = #000000\n  white = #fff\n  darkpurple = #8c90c1\n  lightpurple = #d0d3e6\n  purple2 = rgba(0.106, 0.122, 0.54, 0.2)\n  verylightpurple = rgba(0.953, 0.957, 0.977, 1.0)\n  purple3 = rgba(0.557, 0.627, 0.769, 1.0)\n  midnightblue = rgba(0.14, 0.16, 0.52, 1.0)\n  none = none()\n}\n\nconst {\n  strokeWidth = 1.75\n  textPadding = 0.1\n  labelOffset = 15\n  repelWeight = 0.3\n  pointRadius = 4.0\n  minCircleRadius = 50.0\n  maxCircleRadius = 250.0\n  lineOffset = 10.0\n}\n\nforall Object o {\n  o.color = Colors.none\n}\n\nforall Point p {\n  p.color = theme.tooltipBorder\n\n  p.vec = (\? in shape, \? in shape)\n\n  p.icon = Circle {\n    center : p.vec\n    r : const.pointRadius\n    fillColor : theme.foreground\n    strokeWidth : const.strokeWidth\n    strokeColor : p.color\n  }\n\n  p.textBox = Rectangle {\n    fillColor : Colors.none\n  }\n\n  ensure signedDistance(p.textBox, p.vec) == const.textPadding - const.labelOffset in label\n  ensure disjoint(p.textBox, p.icon) in label\n}\n\nforall Line L {\n  L.color = theme.foreground\n\n  L.icon = Line {\n    start : (\? in shape, \? in shape)\n    end : (\? in shape, \? in shape)\n    strokeColor : L.color\n    strokeWidth : const.strokeWidth\n    style : \"solid\"\n  }\n\n  L.textBox = Rectangle {\n    fillColor : Colors.none\n  }\n\n  ensure touching(L.textBox, L.icon) in label\n}\n\nforall Circle C {\n  C.color = theme.foreground\n\n  C.radius = \? in shape\n  C.center = (\? in shape, \? in shape)\n\n  C.icon = Circle {\n    center : C.center\n    r : C.radius\n    strokeWidth : const.strokeWidth\n    strokeColor : C.color\n    fillColor : Colors.none\n  }\n\n  C.textBox = Rectangle {\n    fillColor : Colors.none\n  }\n\n  encourage const.minCircleRadius < C.radius in shape\n  encourage C.radius < const.maxCircleRadius in shape\n  ensure touching(C.textBox, C.icon) in label\n}\n\n-- Point on Line\nforall Point p; Line L\nwhere OnLine(p, L) {\n  ensure signedDistance(L.icon, p.vec) == 0 in shape\n}\n\n-- Line uniqueness\nforall Point p; Point q; Line L; Line M\nwhere OnLine(p, L); OnLine(p, M); OnLine(q, L); OnLine(q, M) {\n  ensure L.icon.start[0] == M.icon.start[0] in shape\n  ensure L.icon.start[1] == M.icon.start[1] in shape\n  ensure L.icon.end[0] == M.icon.end[0] in shape\n  ensure L.icon.end[1] == M.icon.end[1] in shape\n}\n\n-- Line uniqueness v1\nforall Point p; Point q; Point r; Line L; Line M\nwhere Between(p, q, r); OnLine(p, L); OnLine(q, M); OnLine(r, L); OnLine(r, M) {\n  ensure L.icon.start[0] == M.icon.start[0] in shape\n  ensure L.icon.start[1] == M.icon.start[1] in shape\n  ensure L.icon.end[0] == M.icon.end[0] in shape\n  ensure L.icon.end[1] == M.icon.end[1] in shape\n}\n\n-- Line uniqueness v2\nforall Point p; Point q; Point r; Line L; Line M\nwhere Between(p, r, q); OnLine(p, L); OnLine(q, M); OnLine(r, L); OnLine(r, M) {\n  ensure L.icon.start[0] == M.icon.start[0] in shape\n  ensure L.icon.start[1] == M.icon.start[1] in shape\n  ensure L.icon.end[0] == M.icon.end[0] in shape\n  ensure L.icon.end[1] == M.icon.end[1] in shape\n}\n\n-- Line uniqueness v3\nforall Point p; Point q; Point r; Line L; Line M\nwhere Between(r, p, q); OnLine(p, L); OnLine(q, M); OnLine(r, L); OnLine(r, M) {\n  ensure L.icon.start[0] == M.icon.start[0] in shape\n  ensure L.icon.start[1] == M.icon.start[1] in shape\n  ensure L.icon.end[0] == M.icon.end[0] in shape\n  ensure L.icon.end[1] == M.icon.end[1] in shape\n}\n\n-- Between\nforall Point p, q, r\nwhere Between(p, q, r) {\n  ensure collinearOrdered(p.vec, q.vec, r.vec) in shape\n}\n\n-- Point on Circle\nforall Point p; Circle C\nwhere OnCircle(p, C) {\n  ensure norm(C.center - p.vec) == C.radius in shape\n}\n\n-- Point in Circle\nforall Point p; Circle C\nwhere InCircle(p, C) {\n  ensure norm(C.center - p.vec) < C.radius in shape\n}\n\n-- Point as Circle center\nforall Point p; Circle C\nwhere CenterCircle(p, C) {\n  ensure equal(C.center[0], p.vec[0]) in shape\n  ensure equal(C.center[1], p.vec[1]) in shape\n}\n\n-- Circles intersect\nforall Circle C; Circle D\nwhere CirclesInter(C, D) {\n  ensure norm(C.center - D.center) < C.radius in shape\n}\n\n-- Repelling\nforall Point p; Point q {\n  encourage notTooClose(p.icon, q.icon, const.repelWeight) in shape\n  ensure disjoint(p.textBox, q.textBox) in label\n  ensure disjoint(p.textBox, q.icon) in label\n  ensure disjoint(p.icon, q.textBox) in label\n}\n\nforall Line L; Line M {\n  ensure disjoint(L.textBox, M.textBox) in label\n  ensure disjoint(L.textBox, M.icon) in label\n  ensure disjoint(L.icon, M.textBox) in label\n}\n\nforall Circle C; Circle D {\n  ensure disjoint(C.textBox, D.textBox) in label\n  ensure disjoint(C.textBox, D.icon) in label\n  ensure disjoint(C.icon, D.textBox) in label\n}\n\nforall Point p; Line L {\n  ensure disjoint(p.textBox, L.textBox) in label\n  ensure disjoint(p.textBox, L.icon) in label\n  ensure disjoint(p.icon, L.textBox) in label\n  encourage norm(p.vec - L.icon.start) > const.lineOffset in shape\n  encourage norm(p.vec - L.icon.end) > const.lineOffset in shape\n  p.icon above L.icon\n}\n\nforall Point p; Circle C {\n  ensure disjoint(p.textBox, C.textBox) in label\n  --encourage notTooClose(p.textBox, C.icon, 0.01) in label\n  ensure disjoint(p.icon, C.textBox) in label\n  p.icon above C.icon\n  p.textBox above C.icon\n}\n\nforall Line L; Circle C {\n  ensure disjoint(L.textBox, C.textBox) in label\n  encourage notTooClose(L.textBox, C.icon, const.repelWeight) in label\n  ensure disjoint(L.icon, C.textBox) in label\n}\n\nforall Object o where Emphasize(o) {\n  o.color = Colors.darkpurple\n}\n", 5583, 5583);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_sty() {
_start:
{
lean_object* x_1; 
x_1 = l_EuclideanDisplay_sty___closed__0;
return x_1;
}
}
static lean_object* _init_l_panic___at___EuclideanDisplay_rpc_spec__0___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Lean_Server_instInhabitedRequestError;
x_2 = lean_alloc_closure((void*)(l_EStateM_instInhabited___redArg___lam__0), 2, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_panic___at___EuclideanDisplay_rpc_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_4 = l_panic___at___EuclideanDisplay_rpc_spec__0___closed__0;
x_5 = lean_alloc_closure((void*)(l_instInhabitedForall___redArg___lam__0___boxed), 2, 1);
lean_closure_set(x_5, 0, x_4);
x_6 = lean_panic_fn(x_5, x_1);
x_7 = lean_apply_2(x_6, x_2, x_3);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1___redArg(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; uint8_t x_13; 
x_13 = lean_usize_dec_lt(x_4, x_3);
if (x_13 == 0)
{
lean_object* x_14; 
x_14 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_14, 0, x_5);
lean_ctor_set(x_14, 1, x_6);
return x_14;
}
else
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_array_uget(x_2, x_4);
x_16 = lean_ctor_get(x_15, 1);
lean_inc(x_16);
switch (lean_obj_tag(x_16)) {
case 0:
{
lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
lean_dec(x_15);
x_18 = lean_ctor_get(x_16, 0);
lean_inc(x_18);
lean_dec(x_16);
x_19 = lean_name_eq(x_17, x_1);
lean_dec(x_17);
if (x_19 == 0)
{
lean_dec(x_18);
x_7 = x_5;
x_8 = x_6;
goto block_12;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; uint64_t x_23; uint64_t x_24; uint64_t x_25; uint64_t x_26; uint64_t x_27; uint64_t x_28; uint64_t x_29; size_t x_30; size_t x_31; size_t x_32; size_t x_33; size_t x_34; lean_object* x_35; uint8_t x_36; 
x_20 = lean_ctor_get(x_5, 0);
lean_inc(x_20);
x_21 = lean_ctor_get(x_5, 1);
lean_inc(x_21);
x_22 = lean_array_get_size(x_21);
x_23 = l_Lean_hashFVarId____x40_Lean_Expr___hyg_1561_(x_18);
x_24 = 32;
x_25 = lean_uint64_shift_right(x_23, x_24);
x_26 = lean_uint64_xor(x_23, x_25);
x_27 = 16;
x_28 = lean_uint64_shift_right(x_26, x_27);
x_29 = lean_uint64_xor(x_26, x_28);
x_30 = lean_uint64_to_usize(x_29);
x_31 = lean_usize_of_nat(x_22);
lean_dec(x_22);
x_32 = 1;
x_33 = lean_usize_sub(x_31, x_32);
x_34 = lean_usize_land(x_30, x_33);
x_35 = lean_array_uget(x_21, x_34);
x_36 = l_Std_DHashMap_Internal_AssocList_contains___at_____private_Lean_Meta_ExprDefEq_0__Lean_Meta_mkLambdaFVarsWithLetDeps_collectLetDeclsFrom_visit_spec__0___redArg(x_18, x_35);
if (x_36 == 0)
{
uint8_t x_37; 
x_37 = !lean_is_exclusive(x_5);
if (x_37 == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; uint8_t x_50; 
x_38 = lean_ctor_get(x_5, 1);
lean_dec(x_38);
x_39 = lean_ctor_get(x_5, 0);
lean_dec(x_39);
x_40 = lean_box(0);
x_41 = lean_unsigned_to_nat(1u);
x_42 = lean_nat_add(x_20, x_41);
lean_dec(x_20);
x_43 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_43, 0, x_18);
lean_ctor_set(x_43, 1, x_40);
lean_ctor_set(x_43, 2, x_35);
x_44 = lean_array_uset(x_21, x_34, x_43);
x_45 = lean_unsigned_to_nat(4u);
x_46 = lean_nat_mul(x_42, x_45);
x_47 = lean_unsigned_to_nat(3u);
x_48 = lean_nat_div(x_46, x_47);
lean_dec(x_46);
x_49 = lean_array_get_size(x_44);
x_50 = lean_nat_dec_le(x_48, x_49);
lean_dec(x_49);
lean_dec(x_48);
if (x_50 == 0)
{
lean_object* x_51; 
x_51 = l_Std_DHashMap_Internal_Raw_u2080_expand___at_____private_Lean_Meta_ExprDefEq_0__Lean_Meta_mkLambdaFVarsWithLetDeps_collectLetDeclsFrom_visit_spec__1___redArg(x_44);
lean_ctor_set(x_5, 1, x_51);
lean_ctor_set(x_5, 0, x_42);
x_7 = x_5;
x_8 = x_6;
goto block_12;
}
else
{
lean_ctor_set(x_5, 1, x_44);
lean_ctor_set(x_5, 0, x_42);
x_7 = x_5;
x_8 = x_6;
goto block_12;
}
}
else
{
lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; uint8_t x_62; 
lean_dec(x_5);
x_52 = lean_box(0);
x_53 = lean_unsigned_to_nat(1u);
x_54 = lean_nat_add(x_20, x_53);
lean_dec(x_20);
x_55 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_55, 0, x_18);
lean_ctor_set(x_55, 1, x_52);
lean_ctor_set(x_55, 2, x_35);
x_56 = lean_array_uset(x_21, x_34, x_55);
x_57 = lean_unsigned_to_nat(4u);
x_58 = lean_nat_mul(x_54, x_57);
x_59 = lean_unsigned_to_nat(3u);
x_60 = lean_nat_div(x_58, x_59);
lean_dec(x_58);
x_61 = lean_array_get_size(x_56);
x_62 = lean_nat_dec_le(x_60, x_61);
lean_dec(x_61);
lean_dec(x_60);
if (x_62 == 0)
{
lean_object* x_63; lean_object* x_64; 
x_63 = l_Std_DHashMap_Internal_Raw_u2080_expand___at_____private_Lean_Meta_ExprDefEq_0__Lean_Meta_mkLambdaFVarsWithLetDeps_collectLetDeclsFrom_visit_spec__1___redArg(x_56);
x_64 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_64, 0, x_54);
lean_ctor_set(x_64, 1, x_63);
x_7 = x_64;
x_8 = x_6;
goto block_12;
}
else
{
lean_object* x_65; 
x_65 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_65, 0, x_54);
lean_ctor_set(x_65, 1, x_56);
x_7 = x_65;
x_8 = x_6;
goto block_12;
}
}
}
else
{
lean_dec(x_35);
lean_dec(x_21);
lean_dec(x_20);
lean_dec(x_18);
x_7 = x_5;
x_8 = x_6;
goto block_12;
}
}
}
case 1:
{
lean_object* x_66; lean_object* x_67; uint8_t x_68; 
x_66 = lean_ctor_get(x_15, 0);
lean_inc(x_66);
lean_dec(x_15);
x_67 = lean_ctor_get(x_16, 0);
lean_inc(x_67);
lean_dec(x_16);
x_68 = lean_name_eq(x_66, x_1);
lean_dec(x_66);
if (x_68 == 0)
{
lean_dec(x_67);
x_7 = x_5;
x_8 = x_6;
goto block_12;
}
else
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; uint64_t x_72; uint64_t x_73; uint64_t x_74; uint64_t x_75; uint64_t x_76; uint64_t x_77; uint64_t x_78; size_t x_79; size_t x_80; size_t x_81; size_t x_82; size_t x_83; lean_object* x_84; uint8_t x_85; 
x_69 = lean_ctor_get(x_5, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_5, 1);
lean_inc(x_70);
x_71 = lean_array_get_size(x_70);
x_72 = l_Lean_hashFVarId____x40_Lean_Expr___hyg_1561_(x_67);
x_73 = 32;
x_74 = lean_uint64_shift_right(x_72, x_73);
x_75 = lean_uint64_xor(x_72, x_74);
x_76 = 16;
x_77 = lean_uint64_shift_right(x_75, x_76);
x_78 = lean_uint64_xor(x_75, x_77);
x_79 = lean_uint64_to_usize(x_78);
x_80 = lean_usize_of_nat(x_71);
lean_dec(x_71);
x_81 = 1;
x_82 = lean_usize_sub(x_80, x_81);
x_83 = lean_usize_land(x_79, x_82);
x_84 = lean_array_uget(x_70, x_83);
x_85 = l_Std_DHashMap_Internal_AssocList_contains___at_____private_Lean_Meta_ExprDefEq_0__Lean_Meta_mkLambdaFVarsWithLetDeps_collectLetDeclsFrom_visit_spec__0___redArg(x_67, x_84);
if (x_85 == 0)
{
uint8_t x_86; 
x_86 = !lean_is_exclusive(x_5);
if (x_86 == 0)
{
lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; uint8_t x_99; 
x_87 = lean_ctor_get(x_5, 1);
lean_dec(x_87);
x_88 = lean_ctor_get(x_5, 0);
lean_dec(x_88);
x_89 = lean_box(0);
x_90 = lean_unsigned_to_nat(1u);
x_91 = lean_nat_add(x_69, x_90);
lean_dec(x_69);
x_92 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_92, 0, x_67);
lean_ctor_set(x_92, 1, x_89);
lean_ctor_set(x_92, 2, x_84);
x_93 = lean_array_uset(x_70, x_83, x_92);
x_94 = lean_unsigned_to_nat(4u);
x_95 = lean_nat_mul(x_91, x_94);
x_96 = lean_unsigned_to_nat(3u);
x_97 = lean_nat_div(x_95, x_96);
lean_dec(x_95);
x_98 = lean_array_get_size(x_93);
x_99 = lean_nat_dec_le(x_97, x_98);
lean_dec(x_98);
lean_dec(x_97);
if (x_99 == 0)
{
lean_object* x_100; 
x_100 = l_Std_DHashMap_Internal_Raw_u2080_expand___at_____private_Lean_Meta_ExprDefEq_0__Lean_Meta_mkLambdaFVarsWithLetDeps_collectLetDeclsFrom_visit_spec__1___redArg(x_93);
lean_ctor_set(x_5, 1, x_100);
lean_ctor_set(x_5, 0, x_91);
x_7 = x_5;
x_8 = x_6;
goto block_12;
}
else
{
lean_ctor_set(x_5, 1, x_93);
lean_ctor_set(x_5, 0, x_91);
x_7 = x_5;
x_8 = x_6;
goto block_12;
}
}
else
{
lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; uint8_t x_111; 
lean_dec(x_5);
x_101 = lean_box(0);
x_102 = lean_unsigned_to_nat(1u);
x_103 = lean_nat_add(x_69, x_102);
lean_dec(x_69);
x_104 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_104, 0, x_67);
lean_ctor_set(x_104, 1, x_101);
lean_ctor_set(x_104, 2, x_84);
x_105 = lean_array_uset(x_70, x_83, x_104);
x_106 = lean_unsigned_to_nat(4u);
x_107 = lean_nat_mul(x_103, x_106);
x_108 = lean_unsigned_to_nat(3u);
x_109 = lean_nat_div(x_107, x_108);
lean_dec(x_107);
x_110 = lean_array_get_size(x_105);
x_111 = lean_nat_dec_le(x_109, x_110);
lean_dec(x_110);
lean_dec(x_109);
if (x_111 == 0)
{
lean_object* x_112; lean_object* x_113; 
x_112 = l_Std_DHashMap_Internal_Raw_u2080_expand___at_____private_Lean_Meta_ExprDefEq_0__Lean_Meta_mkLambdaFVarsWithLetDeps_collectLetDeclsFrom_visit_spec__1___redArg(x_105);
x_113 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_113, 0, x_103);
lean_ctor_set(x_113, 1, x_112);
x_7 = x_113;
x_8 = x_6;
goto block_12;
}
else
{
lean_object* x_114; 
x_114 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_114, 0, x_103);
lean_ctor_set(x_114, 1, x_105);
x_7 = x_114;
x_8 = x_6;
goto block_12;
}
}
}
else
{
lean_dec(x_84);
lean_dec(x_70);
lean_dec(x_69);
lean_dec(x_67);
x_7 = x_5;
x_8 = x_6;
goto block_12;
}
}
}
default: 
{
lean_dec(x_16);
lean_dec(x_15);
x_7 = x_5;
x_8 = x_6;
goto block_12;
}
}
}
block_12:
{
size_t x_9; size_t x_10; 
x_9 = 1;
x_10 = lean_usize_add(x_4, x_9);
x_4 = x_10;
x_5 = x_7;
x_6 = x_8;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, size_t x_5, size_t x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
lean_object* x_13; 
x_13 = l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1___redArg(x_3, x_4, x_5, x_6, x_7, x_12);
return x_13;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanDisplay_rpc_spec__2_spec__2(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; uint8_t x_11; 
x_11 = lean_usize_dec_eq(x_3, x_4);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; 
x_12 = lean_array_uget(x_2, x_3);
if (lean_obj_tag(x_12) == 0)
{
x_6 = x_5;
goto block_10;
}
else
{
lean_object* x_33; lean_object* x_34; 
x_33 = lean_ctor_get(x_12, 0);
lean_inc(x_33);
x_34 = lean_ctor_get(x_33, 1);
lean_inc(x_34);
lean_dec(x_33);
x_13 = x_34;
goto block_32;
}
block_32:
{
lean_object* x_14; lean_object* x_15; uint64_t x_16; uint64_t x_17; uint64_t x_18; uint64_t x_19; uint64_t x_20; uint64_t x_21; uint64_t x_22; size_t x_23; size_t x_24; size_t x_25; size_t x_26; size_t x_27; lean_object* x_28; uint8_t x_29; 
x_14 = lean_ctor_get(x_1, 1);
x_15 = lean_array_get_size(x_14);
x_16 = l_Lean_hashFVarId____x40_Lean_Expr___hyg_1561_(x_13);
x_17 = 32;
x_18 = lean_uint64_shift_right(x_16, x_17);
x_19 = lean_uint64_xor(x_16, x_18);
x_20 = 16;
x_21 = lean_uint64_shift_right(x_19, x_20);
x_22 = lean_uint64_xor(x_19, x_21);
x_23 = lean_uint64_to_usize(x_22);
x_24 = lean_usize_of_nat(x_15);
lean_dec(x_15);
x_25 = 1;
x_26 = lean_usize_sub(x_24, x_25);
x_27 = lean_usize_land(x_23, x_26);
x_28 = lean_array_uget(x_14, x_27);
x_29 = l_Std_DHashMap_Internal_AssocList_contains___at_____private_Lean_Meta_ExprDefEq_0__Lean_Meta_mkLambdaFVarsWithLetDeps_collectLetDeclsFrom_visit_spec__0___redArg(x_13, x_28);
lean_dec(x_28);
lean_dec(x_13);
if (x_29 == 0)
{
if (lean_obj_tag(x_12) == 0)
{
x_6 = x_5;
goto block_10;
}
else
{
lean_object* x_30; lean_object* x_31; 
x_30 = lean_ctor_get(x_12, 0);
lean_inc(x_30);
lean_dec(x_12);
x_31 = lean_array_push(x_5, x_30);
x_6 = x_31;
goto block_10;
}
}
else
{
lean_dec(x_12);
x_6 = x_5;
goto block_10;
}
}
}
else
{
return x_5;
}
block_10:
{
size_t x_7; size_t x_8; 
x_7 = 1;
x_8 = lean_usize_add(x_3, x_7);
x_3 = x_8;
x_5 = x_6;
goto _start;
}
}
}
static lean_object* _init_l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; uint8_t x_6; 
x_5 = l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___closed__0;
x_6 = lean_nat_dec_lt(x_3, x_4);
if (x_6 == 0)
{
return x_5;
}
else
{
lean_object* x_7; uint8_t x_8; 
x_7 = lean_array_get_size(x_2);
x_8 = lean_nat_dec_le(x_4, x_7);
lean_dec(x_7);
if (x_8 == 0)
{
return x_5;
}
else
{
size_t x_9; size_t x_10; lean_object* x_11; 
x_9 = lean_usize_of_nat(x_3);
x_10 = lean_usize_of_nat(x_4);
x_11 = l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanDisplay_rpc_spec__2_spec__2(x_1, x_2, x_9, x_10, x_5);
return x_11;
}
}
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("span", 4, 4);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__0___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("No Euclidean goal.", 18, 18);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__0___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_EuclideanDisplay_rpc___lam__0___closed__1;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__0___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__0___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___lam__0___closed__2;
x_2 = l_EuclideanDisplay_rpc___lam__0___closed__3;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
x_9 = l_addHypotheses(x_1, x_3, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = l_EuclideanDisplay_dsl___closed__0;
x_14 = l_EuclideanDisplay_sty___closed__0;
x_15 = lean_unsigned_to_nat(500u);
x_16 = l_ProofWidgets_Penrose_DiagramBuilderM_buildDiagram(x_13, x_14, x_15, x_12, x_4, x_5, x_6, x_7, x_11);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
if (lean_obj_tag(x_18) == 0)
{
uint8_t x_19; 
x_19 = !lean_is_exclusive(x_16);
if (x_19 == 0)
{
lean_object* x_20; uint8_t x_21; 
x_20 = lean_ctor_get(x_16, 0);
lean_dec(x_20);
x_21 = !lean_is_exclusive(x_17);
if (x_21 == 0)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_22 = lean_ctor_get(x_17, 0);
lean_dec(x_22);
x_23 = l_EuclideanDisplay_rpc___lam__0___closed__0;
x_24 = lean_mk_empty_array_with_capacity(x_2);
x_25 = l_EuclideanDisplay_rpc___lam__0___closed__4;
x_26 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_26, 0, x_23);
lean_ctor_set(x_26, 1, x_24);
lean_ctor_set(x_26, 2, x_25);
lean_ctor_set(x_17, 0, x_26);
return x_16;
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_27 = lean_ctor_get(x_17, 1);
lean_inc(x_27);
lean_dec(x_17);
x_28 = l_EuclideanDisplay_rpc___lam__0___closed__0;
x_29 = lean_mk_empty_array_with_capacity(x_2);
x_30 = l_EuclideanDisplay_rpc___lam__0___closed__4;
x_31 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_31, 0, x_28);
lean_ctor_set(x_31, 1, x_29);
lean_ctor_set(x_31, 2, x_30);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_27);
lean_ctor_set(x_16, 0, x_32);
return x_16;
}
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_33 = lean_ctor_get(x_16, 1);
lean_inc(x_33);
lean_dec(x_16);
x_34 = lean_ctor_get(x_17, 1);
lean_inc(x_34);
if (lean_is_exclusive(x_17)) {
 lean_ctor_release(x_17, 0);
 lean_ctor_release(x_17, 1);
 x_35 = x_17;
} else {
 lean_dec_ref(x_17);
 x_35 = lean_box(0);
}
x_36 = l_EuclideanDisplay_rpc___lam__0___closed__0;
x_37 = lean_mk_empty_array_with_capacity(x_2);
x_38 = l_EuclideanDisplay_rpc___lam__0___closed__4;
x_39 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_39, 0, x_36);
lean_ctor_set(x_39, 1, x_37);
lean_ctor_set(x_39, 2, x_38);
if (lean_is_scalar(x_35)) {
 x_40 = lean_alloc_ctor(0, 2, 0);
} else {
 x_40 = x_35;
}
lean_ctor_set(x_40, 0, x_39);
lean_ctor_set(x_40, 1, x_34);
x_41 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_41, 0, x_40);
lean_ctor_set(x_41, 1, x_33);
return x_41;
}
}
else
{
uint8_t x_42; 
x_42 = !lean_is_exclusive(x_16);
if (x_42 == 0)
{
lean_object* x_43; uint8_t x_44; 
x_43 = lean_ctor_get(x_16, 0);
lean_dec(x_43);
x_44 = !lean_is_exclusive(x_17);
if (x_44 == 0)
{
lean_object* x_45; lean_object* x_46; 
x_45 = lean_ctor_get(x_17, 0);
lean_dec(x_45);
x_46 = lean_ctor_get(x_18, 0);
lean_inc(x_46);
lean_dec(x_18);
lean_ctor_set(x_17, 0, x_46);
return x_16;
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_47 = lean_ctor_get(x_17, 1);
lean_inc(x_47);
lean_dec(x_17);
x_48 = lean_ctor_get(x_18, 0);
lean_inc(x_48);
lean_dec(x_18);
x_49 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_49, 0, x_48);
lean_ctor_set(x_49, 1, x_47);
lean_ctor_set(x_16, 0, x_49);
return x_16;
}
}
else
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; 
x_50 = lean_ctor_get(x_16, 1);
lean_inc(x_50);
lean_dec(x_16);
x_51 = lean_ctor_get(x_17, 1);
lean_inc(x_51);
if (lean_is_exclusive(x_17)) {
 lean_ctor_release(x_17, 0);
 lean_ctor_release(x_17, 1);
 x_52 = x_17;
} else {
 lean_dec_ref(x_17);
 x_52 = lean_box(0);
}
x_53 = lean_ctor_get(x_18, 0);
lean_inc(x_53);
lean_dec(x_18);
if (lean_is_scalar(x_52)) {
 x_54 = lean_alloc_ctor(0, 2, 0);
} else {
 x_54 = x_52;
}
lean_ctor_set(x_54, 0, x_53);
lean_ctor_set(x_54, 1, x_51);
x_55 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_55, 0, x_54);
lean_ctor_set(x_55, 1, x_50);
return x_55;
}
}
}
else
{
uint8_t x_56; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
x_56 = !lean_is_exclusive(x_9);
if (x_56 == 0)
{
return x_9;
}
else
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_57 = lean_ctor_get(x_9, 0);
x_58 = lean_ctor_get(x_9, 1);
lean_inc(x_58);
lean_inc(x_57);
lean_dec(x_9);
x_59 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_59, 0, x_57);
lean_ctor_set(x_59, 1, x_58);
return x_59;
}
}
}
}
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__1(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_12 = l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1___redArg(x_1, x_2, x_3, x_4, x_5, x_11);
x_13 = lean_ctor_get(x_7, 2);
lean_inc(x_13);
x_14 = lean_ctor_get(x_12, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_12, 1);
lean_inc(x_15);
lean_dec(x_12);
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_16);
lean_dec(x_13);
x_17 = l_Lean_PersistentArray_toArray___redArg(x_16);
lean_dec(x_16);
x_18 = lean_array_get_size(x_17);
x_19 = l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2(x_14, x_17, x_6, x_18);
lean_dec(x_18);
lean_dec(x_17);
lean_dec(x_14);
x_20 = lean_alloc_closure((void*)(l_EuclideanDisplay_rpc___lam__0___boxed), 8, 2);
lean_closure_set(x_20, 0, x_19);
lean_closure_set(x_20, 1, x_6);
x_21 = l_ProofWidgets_Penrose_DiagramBuilderM_run___redArg(x_20, x_7, x_8, x_9, x_10, x_15);
return x_21;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__2___boxed__const__1() {
_start:
{
size_t x_1; lean_object* x_2; 
x_1 = 0;
x_2 = lean_box_usize(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
lean_inc(x_1);
x_9 = l_Lean_MVarId_getDecl(x_1, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; uint8_t x_18; 
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_ctor_get(x_6, 2);
lean_inc(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
x_14 = lean_ctor_get(x_10, 4);
lean_inc(x_14);
lean_dec(x_10);
x_15 = lean_box(0);
x_16 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_16, 0, x_12);
lean_ctor_set(x_16, 1, x_15);
lean_ctor_set(x_16, 2, x_15);
x_17 = l_Lean_LocalContext_sanitizeNames(x_13, x_16);
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; size_t x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; 
x_19 = lean_ctor_get(x_17, 0);
x_20 = lean_ctor_get(x_17, 1);
lean_dec(x_20);
x_21 = lean_array_get_size(x_2);
x_22 = lean_unsigned_to_nat(4u);
x_23 = lean_nat_mul(x_21, x_22);
lean_dec(x_21);
x_24 = lean_unsigned_to_nat(3u);
x_25 = lean_nat_div(x_23, x_24);
lean_dec(x_23);
x_26 = l_Nat_nextPowerOfTwo(x_25);
lean_dec(x_25);
x_27 = lean_box(0);
x_28 = lean_mk_array(x_26, x_27);
lean_inc(x_3);
lean_ctor_set(x_17, 1, x_28);
lean_ctor_set(x_17, 0, x_3);
x_29 = lean_array_size(x_2);
x_30 = lean_box_usize(x_29);
x_31 = l_EuclideanDisplay_rpc___lam__2___boxed__const__1;
x_32 = lean_alloc_closure((void*)(l_EuclideanDisplay_rpc___lam__1___boxed), 11, 6);
lean_closure_set(x_32, 0, x_1);
lean_closure_set(x_32, 1, x_2);
lean_closure_set(x_32, 2, x_30);
lean_closure_set(x_32, 3, x_31);
lean_closure_set(x_32, 4, x_17);
lean_closure_set(x_32, 5, x_3);
x_33 = l_Lean_Meta_withLCtx___at_____private_Lean_Meta_Basic_0__Lean_Meta_mkLevelErrorMessageCore_spec__2___redArg(x_19, x_14, x_32, x_4, x_5, x_6, x_7, x_11);
return x_33;
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; size_t x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_34 = lean_ctor_get(x_17, 0);
lean_inc(x_34);
lean_dec(x_17);
x_35 = lean_array_get_size(x_2);
x_36 = lean_unsigned_to_nat(4u);
x_37 = lean_nat_mul(x_35, x_36);
lean_dec(x_35);
x_38 = lean_unsigned_to_nat(3u);
x_39 = lean_nat_div(x_37, x_38);
lean_dec(x_37);
x_40 = l_Nat_nextPowerOfTwo(x_39);
lean_dec(x_39);
x_41 = lean_box(0);
x_42 = lean_mk_array(x_40, x_41);
lean_inc(x_3);
x_43 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_43, 0, x_3);
lean_ctor_set(x_43, 1, x_42);
x_44 = lean_array_size(x_2);
x_45 = lean_box_usize(x_44);
x_46 = l_EuclideanDisplay_rpc___lam__2___boxed__const__1;
x_47 = lean_alloc_closure((void*)(l_EuclideanDisplay_rpc___lam__1___boxed), 11, 6);
lean_closure_set(x_47, 0, x_1);
lean_closure_set(x_47, 1, x_2);
lean_closure_set(x_47, 2, x_45);
lean_closure_set(x_47, 3, x_46);
lean_closure_set(x_47, 4, x_43);
lean_closure_set(x_47, 5, x_3);
x_48 = l_Lean_Meta_withLCtx___at_____private_Lean_Meta_Basic_0__Lean_Meta_mkLevelErrorMessageCore_spec__2___redArg(x_34, x_14, x_47, x_4, x_5, x_6, x_7, x_11);
return x_48;
}
}
else
{
uint8_t x_49; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_49 = !lean_is_exclusive(x_9);
if (x_49 == 0)
{
return x_9;
}
else
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; 
x_50 = lean_ctor_get(x_9, 0);
x_51 = lean_ctor_get(x_9, 1);
lean_inc(x_51);
lean_inc(x_50);
lean_dec(x_9);
x_52 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_52, 0, x_50);
lean_ctor_set(x_52, 1, x_51);
return x_52;
}
}
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("details", 7, 7);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("open", 4, 4);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("summary", 7, 7);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("className", 9, 9);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("mv2 pointer", 11, 11);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__5;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__6;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__7;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__2;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Euclidean diagram", 17, 17);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__9;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__10;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__2;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__11;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__8;
x_3 = l_EuclideanDisplay_rpc___lam__3___closed__3;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("div", 3, 3);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__14() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ml1", 3, 3);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__14;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__15;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__16;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__2;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__12;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__18;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__20() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets.Demos.Euclidean", 28, 28);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__21() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("EuclideanDisplay.rpc", 20, 20);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__22() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("unreachable code has been reached", 33, 33);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__22;
x_2 = lean_unsigned_to_nat(38u);
x_3 = lean_unsigned_to_nat(142u);
x_4 = l_EuclideanDisplay_rpc___lam__3___closed__21;
x_5 = l_EuclideanDisplay_rpc___lam__3___closed__20;
x_6 = l_mkPanicMessageWithDecl(x_5, x_4, x_3, x_2, x_1);
return x_6;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__24() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__24;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(32u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__27() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__26;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__28() {
_start:
{
size_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_EuclideanDisplay_rpc___lam__3___closed__26;
x_4 = l_EuclideanDisplay_rpc___lam__3___closed__27;
x_5 = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set_usize(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__29() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(0);
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__28;
x_3 = l_EuclideanDisplay_rpc___lam__3___closed__25;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__30() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__31() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("No goals.", 9, 9);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__32() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__31;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__33() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__32;
x_2 = l_EuclideanDisplay_rpc___lam__0___closed__3;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___lam__3___closed__34() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__33;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__30;
x_3 = l_EuclideanDisplay_rpc___lam__0___closed__0;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__3(uint8_t x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; 
if (x_2 == 0)
{
lean_object* x_24; lean_object* x_25; uint8_t x_26; 
x_24 = lean_unsigned_to_nat(0u);
x_25 = lean_array_get_size(x_3);
x_26 = lean_nat_dec_lt(x_24, x_25);
lean_dec(x_25);
if (x_26 == 0)
{
lean_object* x_27; lean_object* x_28; 
lean_dec(x_4);
x_27 = l_EuclideanDisplay_rpc___lam__3___closed__23;
x_28 = l_panic___at___EuclideanDisplay_rpc_spec__0(x_27, x_5, x_6);
if (lean_obj_tag(x_28) == 0)
{
lean_object* x_29; lean_object* x_30; 
x_29 = lean_ctor_get(x_28, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_28, 1);
lean_inc(x_30);
lean_dec(x_28);
x_7 = x_29;
x_8 = x_30;
goto block_23;
}
else
{
return x_28;
}
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
lean_dec(x_5);
x_31 = lean_array_fget(x_3, x_24);
x_32 = lean_ctor_get(x_31, 0);
lean_inc(x_32);
x_33 = lean_ctor_get(x_32, 2);
lean_inc(x_33);
lean_dec(x_32);
x_34 = lean_ctor_get(x_31, 3);
lean_inc(x_34);
lean_dec(x_31);
x_35 = lean_ctor_get(x_33, 0);
lean_inc(x_35);
lean_dec(x_33);
x_36 = lean_alloc_closure((void*)(l_EuclideanDisplay_rpc___lam__2), 8, 3);
lean_closure_set(x_36, 0, x_34);
lean_closure_set(x_36, 1, x_4);
lean_closure_set(x_36, 2, x_24);
x_37 = l_EuclideanDisplay_rpc___lam__3___closed__29;
x_38 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_35, x_37, x_36, x_6);
if (lean_obj_tag(x_38) == 0)
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_38, 0);
lean_inc(x_39);
x_40 = lean_ctor_get(x_38, 1);
lean_inc(x_40);
lean_dec(x_38);
x_7 = x_39;
x_8 = x_40;
goto block_23;
}
else
{
uint8_t x_41; 
x_41 = !lean_is_exclusive(x_38);
if (x_41 == 0)
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_ctor_get(x_38, 0);
x_43 = l_Lean_Server_RequestError_ofIoError(x_42);
lean_ctor_set(x_38, 0, x_43);
return x_38;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; 
x_44 = lean_ctor_get(x_38, 0);
x_45 = lean_ctor_get(x_38, 1);
lean_inc(x_45);
lean_inc(x_44);
lean_dec(x_38);
x_46 = l_Lean_Server_RequestError_ofIoError(x_44);
x_47 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_47, 0, x_46);
lean_ctor_set(x_47, 1, x_45);
return x_47;
}
}
}
}
else
{
lean_object* x_48; 
lean_dec(x_5);
lean_dec(x_4);
x_48 = l_EuclideanDisplay_rpc___lam__3___closed__34;
x_7 = x_48;
x_8 = x_6;
goto block_23;
}
block_23:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_9 = l_EuclideanDisplay_rpc___lam__3___closed__0;
x_10 = l_EuclideanDisplay_rpc___lam__3___closed__1;
x_11 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_11, 0, x_1);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_10);
lean_ctor_set(x_12, 1, x_11);
x_13 = l_EuclideanDisplay_rpc___lam__3___closed__2;
x_14 = lean_array_push(x_13, x_12);
x_15 = l_EuclideanDisplay_rpc___lam__3___closed__13;
x_16 = l_EuclideanDisplay_rpc___lam__3___closed__17;
x_17 = lean_array_push(x_13, x_7);
x_18 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_18, 0, x_15);
lean_ctor_set(x_18, 1, x_16);
lean_ctor_set(x_18, 2, x_17);
x_19 = l_EuclideanDisplay_rpc___lam__3___closed__19;
x_20 = lean_array_push(x_19, x_18);
x_21 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_21, 0, x_9);
lean_ctor_set(x_21, 1, x_14);
lean_ctor_set(x_21, 2, x_20);
x_22 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_22, 1, x_8);
return x_22;
}
}
}
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; uint8_t x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_4 = lean_ctor_get(x_1, 1);
lean_inc(x_4);
x_5 = lean_ctor_get(x_1, 3);
lean_inc(x_5);
lean_dec(x_1);
x_6 = l_Array_isEmpty___redArg(x_4);
x_7 = lean_box(1);
x_8 = lean_box(x_6);
x_9 = lean_alloc_closure((void*)(l_EuclideanDisplay_rpc___lam__3___boxed), 6, 4);
lean_closure_set(x_9, 0, x_7);
lean_closure_set(x_9, 1, x_8);
lean_closure_set(x_9, 2, x_4);
lean_closure_set(x_9, 3, x_5);
x_10 = l_Lean_Server_RequestM_asTask___redArg(x_9, x_2, x_3);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; size_t x_8; lean_object* x_9; 
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_9 = l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1___redArg(x_1, x_2, x_7, x_8, x_5, x_6);
lean_dec(x_2);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
size_t x_13; size_t x_14; lean_object* x_15; 
x_13 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_14 = lean_unbox_usize(x_6);
lean_dec(x_6);
x_15 = l_Array_forIn_x27Unsafe_loop___at___EuclideanDisplay_rpc_spec__1(x_1, x_2, x_3, x_4, x_13, x_14, x_7, x_8, x_9, x_10, x_11, x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_15;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanDisplay_rpc_spec__2_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_7 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_8 = l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanDisplay_rpc_spec__2_spec__2(x_1, x_2, x_6, x_7, x_5);
lean_dec(x_2);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2(x_1, x_2, x_3, x_4);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_EuclideanDisplay_rpc___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_2);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
size_t x_12; size_t x_13; lean_object* x_14; 
x_12 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_13 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_14 = l_EuclideanDisplay_rpc___lam__1(x_1, x_2, x_12, x_13, x_5, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec(x_2);
lean_dec(x_1);
return x_14;
}
}
LEAN_EXPORT lean_object* l_EuclideanDisplay_rpc___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; uint8_t x_8; lean_object* x_9; 
x_7 = lean_unbox(x_1);
lean_dec(x_1);
x_8 = lean_unbox(x_2);
lean_dec(x_2);
x_9 = l_EuclideanDisplay_rpc___lam__3(x_7, x_8, x_3, x_4, x_5, x_6);
lean_dec(x_3);
return x_9;
}
}
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = lean_box(0);
x_3 = lean_unbox(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__1(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__2), 2, 1);
lean_closure_set(x_14, 0, x_13);
x_15 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(x_8, x_12);
x_16 = l_Prod_map___redArg(x_2, x_14, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_1 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__0;
x_2 = lean_box(9);
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
x_4 = lean_unbox(x_2);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_4);
return x_3;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, uint64_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
x_10 = l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_9, x_5);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_11 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__1;
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_st_ref_get(x_13, x_8);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_16 = lean_ctor_get(x_14, 0);
x_17 = lean_ctor_get(x_14, 1);
x_18 = lean_ctor_get(x_16, 0);
lean_inc(x_18);
lean_dec(x_16);
lean_inc(x_6);
x_19 = l_ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4_(x_6, x_18);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; uint8_t x_35; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
lean_dec(x_19);
x_21 = lean_box(3);
x_22 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__2;
x_23 = lean_box(1);
x_24 = lean_unbox(x_23);
x_25 = l_Lean_Name_toString(x_1, x_24, x_2);
x_26 = lean_string_append(x_22, x_25);
lean_dec(x_25);
x_27 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__3;
x_28 = lean_string_append(x_26, x_27);
x_29 = l_Lean_Json_compress(x_6);
x_30 = lean_string_append(x_28, x_29);
lean_dec(x_29);
x_31 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__4;
x_32 = lean_string_append(x_30, x_31);
x_33 = lean_string_append(x_32, x_20);
lean_dec(x_20);
x_34 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_34, 0, x_33);
x_35 = lean_unbox(x_21);
lean_ctor_set_uint8(x_34, sizeof(void*)*1, x_35);
lean_ctor_set_tag(x_14, 1);
lean_ctor_set(x_14, 0, x_34);
return x_14;
}
else
{
lean_object* x_36; lean_object* x_37; 
lean_free_object(x_14);
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_36 = lean_ctor_get(x_19, 0);
lean_inc(x_36);
lean_dec(x_19);
lean_inc(x_7);
x_37 = lean_apply_3(x_3, x_36, x_7, x_17);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
x_40 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_40, 0, x_13);
lean_closure_set(x_40, 1, x_4);
x_41 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_38, x_40, x_7, x_39);
return x_41;
}
else
{
uint8_t x_42; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_42 = !lean_is_exclusive(x_37);
if (x_42 == 0)
{
return x_37;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_43 = lean_ctor_get(x_37, 0);
x_44 = lean_ctor_get(x_37, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_37);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
return x_45;
}
}
}
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_46 = lean_ctor_get(x_14, 0);
x_47 = lean_ctor_get(x_14, 1);
lean_inc(x_47);
lean_inc(x_46);
lean_dec(x_14);
x_48 = lean_ctor_get(x_46, 0);
lean_inc(x_48);
lean_dec(x_46);
lean_inc(x_6);
x_49 = l_ProofWidgets_instRpcEncodablePanelWidgetProps_dec____x40_ProofWidgets_Component_Panel_Basic___hyg_4_(x_6, x_48);
if (lean_obj_tag(x_49) == 0)
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; uint8_t x_65; lean_object* x_66; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec(x_49);
x_51 = lean_box(3);
x_52 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__2;
x_53 = lean_box(1);
x_54 = lean_unbox(x_53);
x_55 = l_Lean_Name_toString(x_1, x_54, x_2);
x_56 = lean_string_append(x_52, x_55);
lean_dec(x_55);
x_57 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__3;
x_58 = lean_string_append(x_56, x_57);
x_59 = l_Lean_Json_compress(x_6);
x_60 = lean_string_append(x_58, x_59);
lean_dec(x_59);
x_61 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__4;
x_62 = lean_string_append(x_60, x_61);
x_63 = lean_string_append(x_62, x_50);
lean_dec(x_50);
x_64 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_64, 0, x_63);
x_65 = lean_unbox(x_51);
lean_ctor_set_uint8(x_64, sizeof(void*)*1, x_65);
x_66 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_66, 0, x_64);
lean_ctor_set(x_66, 1, x_47);
return x_66;
}
else
{
lean_object* x_67; lean_object* x_68; 
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_67 = lean_ctor_get(x_49, 0);
lean_inc(x_67);
lean_dec(x_49);
lean_inc(x_7);
x_68 = lean_apply_3(x_3, x_67, x_7, x_47);
if (lean_obj_tag(x_68) == 0)
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
x_69 = lean_ctor_get(x_68, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_68, 1);
lean_inc(x_70);
lean_dec(x_68);
x_71 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_71, 0, x_13);
lean_closure_set(x_71, 1, x_4);
x_72 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_69, x_71, x_7, x_70);
return x_72;
}
else
{
lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_73 = lean_ctor_get(x_68, 0);
lean_inc(x_73);
x_74 = lean_ctor_get(x_68, 1);
lean_inc(x_74);
if (lean_is_exclusive(x_68)) {
 lean_ctor_release(x_68, 0);
 lean_ctor_release(x_68, 1);
 x_75 = x_68;
} else {
 lean_dec_ref(x_68);
 x_75 = lean_box(0);
}
if (lean_is_scalar(x_75)) {
 x_76 = lean_alloc_ctor(1, 2, 0);
} else {
 x_76 = x_75;
}
lean_ctor_set(x_76, 0, x_73);
lean_ctor_set(x_76, 1, x_74);
return x_76;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__1___boxed), 1, 0);
x_5 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___boxed), 8, 4);
lean_closure_set(x_5, 0, x_1);
lean_closure_set(x_5, 1, x_3);
lean_closure_set(x_5, 2, x_2);
lean_closure_set(x_5, 3, x_4);
return x_5;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("EuclideanDisplay", 16, 16);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("rpc", 3, 3);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___rpc__wrapped___closed__1;
x_2 = l_EuclideanDisplay_rpc___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_EuclideanDisplay_rpc), 3, 0);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay_rpc___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___rpc__wrapped___closed__2;
x_2 = l_EuclideanDisplay_rpc___rpc__wrapped___closed__3;
x_3 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__1___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__1(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint64_t x_9; lean_object* x_10; 
x_9 = lean_unbox_uint64(x_5);
lean_dec(x_5);
x_10 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4(x_1, x_2, x_3, x_4, x_9, x_6, x_7, x_8);
return x_10;
}
}
static lean_object* _init_l_EuclideanDisplay___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as t,Fragment as n}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as a,EnvPosContext as o,useAsyncPersistent as c,mapRpcError as s,importWidgetModule as i}from\"@leanprover/infoview\";async function l(a,o,c){if(\"text\"in c)return t(n,{children:c.text});if(\"element\"in c){const[e,n,s]=c.element,i={};for(const[e,t]of n)i[e]=t;const u=await Promise.all(s.map((async e=>await l(a,o,e))));return\"hr\"===e\?t(\"hr\",{}):0===u.length\?r.createElement(e,i):r.createElement(e,i,u)}if(\"component\"in c){const[e,t,n,s]=c.component,u=await Promise.all(s.map((async e=>await l(a,o,e)))),m={...n,pos:o},f=await i(a,o,e);if(!(t in f))throw new Error(`Module '${e}' does not export '${t}'`);return 0===u.length\?r.createElement(f[t],m):r.createElement(f[t],m,u)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(c)]})}function u({html:i}){const u=a(),m=r.useContext(o),f=c((()=>l(u,m,i)),[u,m,i]);return\"resolved\"===f.state\?f.value:\"rejected\"===f.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",s(f.error).message]}):t(n,{})}const m=\"EuclideanDisplay.rpc\",f='false';var d=r.memo((e=>{const o=a(),i=r.useRef({fn:()=>{}}),l=c((async()=>{if(\"true\"===f){i.current.fn();const[t,n]=function(e,t,n){const r={fn:()=>{}};return[new Promise((async(a,o)=>{const c=await e.call(t,n),s=window.setInterval((async()=>{try{const t=await e.call(\"ProofWidgets.checkRequest\",c);if(\"running\"===t)return;window.clearInterval(s),a(t.done.result)}catch(e){window.clearInterval(s),o(e)}}),100);r.fn=()=>{e.call(\"ProofWidgets.cancelRequest\",c)}})),r]}(o,m,e);return i.current=n,t}return o.call(m,e)}),[o,e]);return r.useEffect((()=>()=>{i.current.fn()}),[]),\"rejected\"===l.state\?t(\"p\",{style:{color:\"red\"},children:s(l.error).message}):\"loading\"===l.state\?t(n,{children:\"Loading..\"}):t(u,{html:l.value})}));export{d as default};", 1880, 1880);
return x_1;
}
}
static uint64_t _init_l_EuclideanDisplay___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_EuclideanDisplay___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay___closed__2___boxed__const__1() {
_start:
{
uint64_t x_1; lean_object* x_2; 
x_1 = l_EuclideanDisplay___closed__1;
x_2 = lean_box_uint64(x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanDisplay___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay___closed__0;
x_2 = l_EuclideanDisplay___closed__2___boxed__const__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_EuclideanDisplay___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay___closed__3;
x_2 = l_EuclideanDisplay___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanDisplay() {
_start:
{
lean_object* x_1; 
x_1 = l_EuclideanDisplay___closed__4;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___constructLines_spec__0___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = l___private_ProofWidgets_Component_MakeEditLink_0__ProofWidgets_toJsonMakeEditLinkProps____x40_ProofWidgets_Component_MakeEditLink___hyg_298_(x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___constructLines_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___at___constructLines_spec__0___lam__0), 2, 1);
lean_closure_set(x_7, 0, x_2);
x_8 = lean_string_hash(x_6);
lean_inc(x_5);
x_9 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_7);
lean_ctor_set(x_9, 2, x_3);
lean_ctor_set_uint64(x_9, sizeof(void*)*3, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___constructLines_spec__1(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; uint8_t x_24; 
x_24 = lean_usize_dec_lt(x_3, x_2);
if (x_24 == 0)
{
lean_object* x_25; lean_object* x_26; 
lean_dec(x_6);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_4);
lean_ctor_set(x_25, 1, x_5);
x_26 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_26, 0, x_25);
lean_ctor_set(x_26, 1, x_10);
return x_26;
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_85; lean_object* x_94; 
x_27 = lean_ctor_get(x_4, 0);
lean_inc(x_27);
x_28 = lean_ctor_get(x_4, 1);
lean_inc(x_28);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 x_29 = x_4;
} else {
 lean_dec_ref(x_4);
 x_29 = lean_box(0);
}
x_30 = lean_array_uget(x_1, x_3);
x_94 = lean_ctor_get(x_30, 3);
lean_inc(x_94);
x_85 = x_94;
goto block_93;
block_84:
{
lean_object* x_38; 
x_38 = l_isCirclesInterPred_x3f(x_31);
lean_dec(x_31);
if (lean_obj_tag(x_38) == 0)
{
lean_dec(x_34);
lean_dec(x_30);
lean_dec(x_29);
x_18 = x_32;
x_19 = x_27;
x_20 = x_33;
x_21 = x_37;
goto block_23;
}
else
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_38, 0);
lean_inc(x_39);
lean_dec(x_38);
x_40 = lean_ctor_get(x_39, 0);
lean_inc(x_40);
if (lean_obj_tag(x_40) == 1)
{
uint8_t x_41; 
x_41 = !lean_is_exclusive(x_39);
if (x_41 == 0)
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_ctor_get(x_39, 1);
x_43 = lean_ctor_get(x_39, 0);
lean_dec(x_43);
if (lean_obj_tag(x_42) == 1)
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_ctor_get(x_40, 0);
lean_inc(x_44);
lean_dec(x_40);
x_45 = lean_ctor_get(x_42, 0);
lean_inc(x_45);
lean_dec(x_42);
lean_inc(x_34);
x_46 = l_Lean_FVarId_getDecl___redArg(x_44, x_34, x_35, x_36, x_37);
if (lean_obj_tag(x_46) == 0)
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_47 = lean_ctor_get(x_46, 0);
lean_inc(x_47);
x_48 = lean_ctor_get(x_46, 1);
lean_inc(x_48);
lean_dec(x_46);
x_49 = l_Lean_FVarId_getDecl___redArg(x_45, x_34, x_35, x_36, x_48);
if (lean_obj_tag(x_49) == 0)
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; 
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
x_51 = lean_ctor_get(x_49, 1);
lean_inc(x_51);
lean_dec(x_49);
lean_ctor_set(x_39, 1, x_50);
lean_ctor_set(x_39, 0, x_47);
x_52 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_52, 0, x_30);
lean_ctor_set(x_52, 1, x_39);
x_53 = lean_array_push(x_27, x_52);
if (lean_is_scalar(x_29)) {
 x_54 = lean_alloc_ctor(0, 2, 0);
} else {
 x_54 = x_29;
}
lean_ctor_set(x_54, 0, x_53);
lean_ctor_set(x_54, 1, x_32);
x_11 = x_54;
x_12 = x_33;
x_13 = x_51;
goto block_17;
}
else
{
uint8_t x_55; 
lean_dec(x_47);
lean_free_object(x_39);
lean_dec(x_33);
lean_dec(x_32);
lean_dec(x_30);
lean_dec(x_29);
lean_dec(x_27);
lean_dec(x_6);
x_55 = !lean_is_exclusive(x_49);
if (x_55 == 0)
{
return x_49;
}
else
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; 
x_56 = lean_ctor_get(x_49, 0);
x_57 = lean_ctor_get(x_49, 1);
lean_inc(x_57);
lean_inc(x_56);
lean_dec(x_49);
x_58 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_58, 0, x_56);
lean_ctor_set(x_58, 1, x_57);
return x_58;
}
}
}
else
{
uint8_t x_59; 
lean_dec(x_45);
lean_free_object(x_39);
lean_dec(x_34);
lean_dec(x_33);
lean_dec(x_32);
lean_dec(x_30);
lean_dec(x_29);
lean_dec(x_27);
lean_dec(x_6);
x_59 = !lean_is_exclusive(x_46);
if (x_59 == 0)
{
return x_46;
}
else
{
lean_object* x_60; lean_object* x_61; lean_object* x_62; 
x_60 = lean_ctor_get(x_46, 0);
x_61 = lean_ctor_get(x_46, 1);
lean_inc(x_61);
lean_inc(x_60);
lean_dec(x_46);
x_62 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_62, 0, x_60);
lean_ctor_set(x_62, 1, x_61);
return x_62;
}
}
}
else
{
lean_free_object(x_39);
lean_dec(x_42);
lean_dec(x_40);
lean_dec(x_34);
lean_dec(x_30);
lean_dec(x_29);
x_18 = x_32;
x_19 = x_27;
x_20 = x_33;
x_21 = x_37;
goto block_23;
}
}
else
{
lean_object* x_63; 
x_63 = lean_ctor_get(x_39, 1);
lean_inc(x_63);
lean_dec(x_39);
if (lean_obj_tag(x_63) == 1)
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; 
x_64 = lean_ctor_get(x_40, 0);
lean_inc(x_64);
lean_dec(x_40);
x_65 = lean_ctor_get(x_63, 0);
lean_inc(x_65);
lean_dec(x_63);
lean_inc(x_34);
x_66 = l_Lean_FVarId_getDecl___redArg(x_64, x_34, x_35, x_36, x_37);
if (lean_obj_tag(x_66) == 0)
{
lean_object* x_67; lean_object* x_68; lean_object* x_69; 
x_67 = lean_ctor_get(x_66, 0);
lean_inc(x_67);
x_68 = lean_ctor_get(x_66, 1);
lean_inc(x_68);
lean_dec(x_66);
x_69 = l_Lean_FVarId_getDecl___redArg(x_65, x_34, x_35, x_36, x_68);
if (lean_obj_tag(x_69) == 0)
{
lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; 
x_70 = lean_ctor_get(x_69, 0);
lean_inc(x_70);
x_71 = lean_ctor_get(x_69, 1);
lean_inc(x_71);
lean_dec(x_69);
x_72 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_72, 0, x_67);
lean_ctor_set(x_72, 1, x_70);
x_73 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_73, 0, x_30);
lean_ctor_set(x_73, 1, x_72);
x_74 = lean_array_push(x_27, x_73);
if (lean_is_scalar(x_29)) {
 x_75 = lean_alloc_ctor(0, 2, 0);
} else {
 x_75 = x_29;
}
lean_ctor_set(x_75, 0, x_74);
lean_ctor_set(x_75, 1, x_32);
x_11 = x_75;
x_12 = x_33;
x_13 = x_71;
goto block_17;
}
else
{
lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; 
lean_dec(x_67);
lean_dec(x_33);
lean_dec(x_32);
lean_dec(x_30);
lean_dec(x_29);
lean_dec(x_27);
lean_dec(x_6);
x_76 = lean_ctor_get(x_69, 0);
lean_inc(x_76);
x_77 = lean_ctor_get(x_69, 1);
lean_inc(x_77);
if (lean_is_exclusive(x_69)) {
 lean_ctor_release(x_69, 0);
 lean_ctor_release(x_69, 1);
 x_78 = x_69;
} else {
 lean_dec_ref(x_69);
 x_78 = lean_box(0);
}
if (lean_is_scalar(x_78)) {
 x_79 = lean_alloc_ctor(1, 2, 0);
} else {
 x_79 = x_78;
}
lean_ctor_set(x_79, 0, x_76);
lean_ctor_set(x_79, 1, x_77);
return x_79;
}
}
else
{
lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; 
lean_dec(x_65);
lean_dec(x_34);
lean_dec(x_33);
lean_dec(x_32);
lean_dec(x_30);
lean_dec(x_29);
lean_dec(x_27);
lean_dec(x_6);
x_80 = lean_ctor_get(x_66, 0);
lean_inc(x_80);
x_81 = lean_ctor_get(x_66, 1);
lean_inc(x_81);
if (lean_is_exclusive(x_66)) {
 lean_ctor_release(x_66, 0);
 lean_ctor_release(x_66, 1);
 x_82 = x_66;
} else {
 lean_dec_ref(x_66);
 x_82 = lean_box(0);
}
if (lean_is_scalar(x_82)) {
 x_83 = lean_alloc_ctor(1, 2, 0);
} else {
 x_83 = x_82;
}
lean_ctor_set(x_83, 0, x_80);
lean_ctor_set(x_83, 1, x_81);
return x_83;
}
}
else
{
lean_dec(x_63);
lean_dec(x_40);
lean_dec(x_34);
lean_dec(x_30);
lean_dec(x_29);
x_18 = x_32;
x_19 = x_27;
x_20 = x_33;
x_21 = x_37;
goto block_23;
}
}
}
else
{
lean_dec(x_40);
lean_dec(x_39);
lean_dec(x_34);
lean_dec(x_30);
lean_dec(x_29);
x_18 = x_32;
x_19 = x_27;
x_20 = x_33;
x_21 = x_37;
goto block_23;
}
}
}
block_93:
{
lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; uint8_t x_91; 
x_86 = l_Lean_instantiateMVars___at___addHypotheses_spec__0___redArg(x_85, x_5, x_7, x_10);
x_87 = lean_ctor_get(x_86, 0);
lean_inc(x_87);
x_88 = lean_ctor_get(x_86, 1);
lean_inc(x_88);
lean_dec(x_86);
x_89 = lean_ctor_get(x_87, 0);
lean_inc(x_89);
x_90 = lean_ctor_get(x_87, 1);
lean_inc(x_90);
lean_dec(x_87);
x_91 = l_isPoint_x3f(x_89);
if (x_91 == 0)
{
lean_inc(x_6);
x_31 = x_89;
x_32 = x_28;
x_33 = x_90;
x_34 = x_6;
x_35 = x_8;
x_36 = x_9;
x_37 = x_88;
goto block_84;
}
else
{
lean_object* x_92; 
lean_inc(x_30);
x_92 = lean_array_push(x_28, x_30);
lean_inc(x_6);
x_31 = x_89;
x_32 = x_92;
x_33 = x_90;
x_34 = x_6;
x_35 = x_8;
x_36 = x_9;
x_37 = x_88;
goto block_84;
}
}
}
block_17:
{
size_t x_14; size_t x_15; 
x_14 = 1;
x_15 = lean_usize_add(x_3, x_14);
x_3 = x_15;
x_4 = x_11;
x_5 = x_12;
x_10 = x_13;
goto _start;
}
block_23:
{
lean_object* x_22; 
x_22 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_22, 0, x_19);
lean_ctor_set(x_22, 1, x_18);
x_11 = x_22;
x_12 = x_20;
x_13 = x_21;
goto block_17;
}
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("let ⟨", 7, 5);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(", _, _⟩ := line_of_pts ", 25, 23);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" ", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("C", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(", _, _⟩ := circle_of_ne ", 26, 24);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" (by assumption)", 16, 16);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_15 = lean_ctor_get(x_6, 1);
x_16 = lean_ctor_get(x_6, 2);
x_17 = lean_nat_dec_lt(x_8, x_15);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; 
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_7);
lean_ctor_set(x_18, 1, x_9);
x_19 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_19, 0, x_18);
lean_ctor_set(x_19, 1, x_14);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; 
lean_dec(x_7);
x_20 = lean_array_fget(x_1, x_8);
x_21 = l_Lean_LocalDecl_toExpr(x_20);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_2);
x_22 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_2, x_21, x_9, x_10, x_11, x_12, x_13, x_14);
if (lean_obj_tag(x_22) == 0)
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_23 = lean_ctor_get(x_22, 0);
lean_inc(x_23);
x_24 = lean_ctor_get(x_22, 1);
lean_inc(x_24);
lean_dec(x_22);
x_25 = lean_ctor_get(x_23, 0);
lean_inc(x_25);
x_26 = lean_ctor_get(x_23, 1);
lean_inc(x_26);
lean_dec(x_23);
lean_inc(x_3);
x_27 = lean_string_append(x_3, x_25);
x_28 = l_isLine_x3f___closed__0;
x_29 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__0;
x_30 = lean_string_append(x_29, x_27);
x_31 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__1;
x_32 = lean_string_append(x_30, x_31);
x_33 = lean_string_append(x_32, x_3);
x_34 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__2;
x_35 = lean_string_append(x_33, x_34);
x_36 = lean_string_append(x_35, x_25);
lean_inc(x_4);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_27);
x_37 = lean_apply_9(x_4, x_27, x_28, x_36, x_26, x_10, x_11, x_12, x_13, x_24);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
x_40 = lean_ctor_get(x_38, 1);
lean_inc(x_40);
lean_dec(x_38);
x_41 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__7;
x_42 = lean_string_append(x_41, x_3);
x_43 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2;
x_44 = lean_string_append(x_42, x_43);
x_45 = lean_string_append(x_44, x_27);
x_46 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
x_47 = lean_string_append(x_45, x_46);
x_48 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_47, x_40, x_39);
x_49 = lean_ctor_get(x_48, 0);
lean_inc(x_49);
x_50 = lean_ctor_get(x_48, 1);
lean_inc(x_50);
lean_dec(x_48);
x_51 = lean_ctor_get(x_49, 1);
lean_inc(x_51);
lean_dec(x_49);
x_52 = lean_string_append(x_41, x_25);
x_53 = lean_string_append(x_52, x_43);
x_54 = lean_string_append(x_53, x_27);
lean_dec(x_27);
x_55 = lean_string_append(x_54, x_46);
x_56 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_55, x_51, x_50);
x_57 = lean_ctor_get(x_56, 0);
lean_inc(x_57);
x_58 = lean_ctor_get(x_56, 1);
lean_inc(x_58);
lean_dec(x_56);
x_59 = lean_ctor_get(x_57, 1);
lean_inc(x_59);
lean_dec(x_57);
x_60 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__3;
x_61 = lean_string_append(x_60, x_3);
x_62 = lean_string_append(x_61, x_25);
x_63 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0;
x_64 = lean_string_append(x_29, x_62);
x_65 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__4;
x_66 = lean_string_append(x_64, x_65);
x_67 = lean_string_append(x_66, x_3);
x_68 = lean_string_append(x_67, x_34);
x_69 = lean_string_append(x_68, x_25);
x_70 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__5;
x_71 = lean_string_append(x_69, x_70);
lean_inc(x_4);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_62);
x_72 = lean_apply_9(x_4, x_62, x_63, x_71, x_59, x_10, x_11, x_12, x_13, x_58);
if (lean_obj_tag(x_72) == 0)
{
lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; 
x_73 = lean_ctor_get(x_72, 0);
lean_inc(x_73);
x_74 = lean_ctor_get(x_72, 1);
lean_inc(x_74);
lean_dec(x_72);
x_75 = lean_ctor_get(x_73, 1);
lean_inc(x_75);
lean_dec(x_73);
x_76 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__4;
x_77 = lean_string_append(x_76, x_3);
x_78 = lean_string_append(x_77, x_43);
x_79 = lean_string_append(x_78, x_62);
x_80 = lean_string_append(x_79, x_46);
x_81 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_80, x_75, x_74);
x_82 = lean_ctor_get(x_81, 0);
lean_inc(x_82);
x_83 = lean_ctor_get(x_81, 1);
lean_inc(x_83);
lean_dec(x_81);
x_84 = lean_ctor_get(x_82, 1);
lean_inc(x_84);
lean_dec(x_82);
x_85 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__6;
x_86 = lean_string_append(x_85, x_25);
x_87 = lean_string_append(x_86, x_43);
x_88 = lean_string_append(x_87, x_62);
lean_dec(x_62);
x_89 = lean_string_append(x_88, x_46);
x_90 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_89, x_84, x_83);
x_91 = lean_ctor_get(x_90, 0);
lean_inc(x_91);
x_92 = lean_ctor_get(x_90, 1);
lean_inc(x_92);
lean_dec(x_90);
x_93 = lean_ctor_get(x_91, 1);
lean_inc(x_93);
lean_dec(x_91);
x_94 = lean_string_append(x_60, x_25);
x_95 = lean_string_append(x_94, x_3);
x_96 = lean_string_append(x_29, x_95);
x_97 = lean_string_append(x_96, x_65);
x_98 = lean_string_append(x_97, x_25);
x_99 = lean_string_append(x_98, x_34);
x_100 = lean_string_append(x_99, x_3);
x_101 = lean_string_append(x_100, x_70);
lean_inc(x_4);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_95);
x_102 = lean_apply_9(x_4, x_95, x_63, x_101, x_93, x_10, x_11, x_12, x_13, x_92);
if (lean_obj_tag(x_102) == 0)
{
lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; 
x_103 = lean_ctor_get(x_102, 0);
lean_inc(x_103);
x_104 = lean_ctor_get(x_102, 1);
lean_inc(x_104);
lean_dec(x_102);
x_105 = lean_ctor_get(x_103, 1);
lean_inc(x_105);
lean_dec(x_103);
x_106 = lean_string_append(x_76, x_25);
lean_dec(x_25);
x_107 = lean_string_append(x_106, x_43);
x_108 = lean_string_append(x_107, x_95);
x_109 = lean_string_append(x_108, x_46);
x_110 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_109, x_105, x_104);
x_111 = lean_ctor_get(x_110, 0);
lean_inc(x_111);
x_112 = lean_ctor_get(x_110, 1);
lean_inc(x_112);
lean_dec(x_110);
x_113 = lean_ctor_get(x_111, 1);
lean_inc(x_113);
lean_dec(x_111);
x_114 = lean_string_append(x_85, x_3);
x_115 = lean_string_append(x_114, x_43);
x_116 = lean_string_append(x_115, x_95);
lean_dec(x_95);
x_117 = lean_string_append(x_116, x_46);
x_118 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_117, x_113, x_112);
x_119 = lean_ctor_get(x_118, 0);
lean_inc(x_119);
x_120 = lean_ctor_get(x_118, 1);
lean_inc(x_120);
lean_dec(x_118);
x_121 = lean_ctor_get(x_119, 1);
lean_inc(x_121);
lean_dec(x_119);
x_122 = lean_nat_add(x_8, x_16);
lean_dec(x_8);
lean_inc(x_5);
{
lean_object* _tmp_6 = x_5;
lean_object* _tmp_7 = x_122;
lean_object* _tmp_8 = x_121;
lean_object* _tmp_13 = x_120;
x_7 = _tmp_6;
x_8 = _tmp_7;
x_9 = _tmp_8;
x_14 = _tmp_13;
}
goto _start;
}
else
{
lean_dec(x_95);
lean_dec(x_25);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_102;
}
}
else
{
lean_dec(x_62);
lean_dec(x_25);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_72;
}
}
else
{
lean_dec(x_27);
lean_dec(x_25);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_37;
}
}
else
{
uint8_t x_124; 
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_124 = !lean_is_exclusive(x_22);
if (x_124 == 0)
{
return x_22;
}
else
{
lean_object* x_125; lean_object* x_126; lean_object* x_127; 
x_125 = lean_ctor_get(x_22, 0);
x_126 = lean_ctor_get(x_22, 1);
lean_inc(x_126);
lean_inc(x_125);
lean_dec(x_22);
x_127 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_127, 0, x_125);
lean_ctor_set(x_127, 1, x_126);
return x_127;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
lean_object* x_17; 
x_17 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_11, x_12, x_13, x_14, x_15, x_16);
return x_17;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_15 = lean_ctor_get(x_6, 1);
x_16 = lean_ctor_get(x_6, 2);
x_17 = lean_nat_dec_lt(x_8, x_15);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; 
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_7);
lean_ctor_set(x_18, 1, x_9);
x_19 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_19, 0, x_18);
lean_ctor_set(x_19, 1, x_14);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
lean_dec(x_7);
x_20 = lean_array_fget(x_1, x_8);
x_21 = l_isPoint_x3f___closed__0;
x_22 = l_Lean_LocalDecl_toExpr(x_20);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
x_23 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_21, x_22, x_9, x_10, x_11, x_12, x_13, x_14);
if (lean_obj_tag(x_23) == 0)
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_24 = lean_ctor_get(x_23, 0);
lean_inc(x_24);
x_25 = lean_ctor_get(x_23, 1);
lean_inc(x_25);
lean_dec(x_23);
x_26 = lean_ctor_get(x_24, 0);
lean_inc(x_26);
x_27 = lean_ctor_get(x_24, 1);
lean_inc(x_27);
lean_dec(x_24);
x_28 = lean_nat_add(x_8, x_2);
lean_inc(x_2);
lean_inc(x_3);
lean_inc(x_28);
x_29 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_29, 0, x_28);
lean_ctor_set(x_29, 1, x_3);
lean_ctor_set(x_29, 2, x_2);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc_n(x_5, 2);
lean_inc(x_4);
x_30 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg(x_1, x_21, x_26, x_4, x_5, x_29, x_5, x_28, x_27, x_10, x_11, x_12, x_13, x_25);
lean_dec(x_29);
if (lean_obj_tag(x_30) == 0)
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; 
x_31 = lean_ctor_get(x_30, 0);
lean_inc(x_31);
x_32 = lean_ctor_get(x_30, 1);
lean_inc(x_32);
lean_dec(x_30);
x_33 = lean_ctor_get(x_31, 1);
lean_inc(x_33);
lean_dec(x_31);
x_34 = lean_nat_add(x_8, x_16);
lean_dec(x_8);
lean_inc(x_5);
{
lean_object* _tmp_6 = x_5;
lean_object* _tmp_7 = x_34;
lean_object* _tmp_8 = x_33;
lean_object* _tmp_13 = x_32;
x_7 = _tmp_6;
x_8 = _tmp_7;
x_9 = _tmp_8;
x_14 = _tmp_13;
}
goto _start;
}
else
{
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_30;
}
}
else
{
uint8_t x_36; 
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_36 = !lean_is_exclusive(x_23);
if (x_36 == 0)
{
return x_23;
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_37 = lean_ctor_get(x_23, 0);
x_38 = lean_ctor_get(x_23, 1);
lean_inc(x_38);
lean_inc(x_37);
lean_dec(x_23);
x_39 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_39, 0, x_37);
lean_ctor_set(x_39, 1, x_38);
return x_39;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
lean_object* x_17; 
x_17 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_11, x_12, x_13, x_14, x_15, x_16);
return x_17;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__3___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_15 = lean_ctor_get(x_6, 1);
x_16 = lean_ctor_get(x_6, 2);
x_17 = lean_nat_dec_lt(x_8, x_15);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; 
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_7);
lean_ctor_set(x_18, 1, x_9);
x_19 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_19, 0, x_18);
lean_ctor_set(x_19, 1, x_14);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
lean_dec(x_7);
x_20 = lean_array_fget(x_1, x_8);
x_21 = l_isPoint_x3f___closed__0;
x_22 = l_Lean_LocalDecl_toExpr(x_20);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
x_23 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_21, x_22, x_9, x_10, x_11, x_12, x_13, x_14);
if (lean_obj_tag(x_23) == 0)
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_24 = lean_ctor_get(x_23, 0);
lean_inc(x_24);
x_25 = lean_ctor_get(x_23, 1);
lean_inc(x_25);
lean_dec(x_23);
x_26 = lean_ctor_get(x_24, 0);
lean_inc(x_26);
x_27 = lean_ctor_get(x_24, 1);
lean_inc(x_27);
lean_dec(x_24);
x_28 = lean_nat_add(x_8, x_4);
lean_inc(x_4);
lean_inc(x_5);
lean_inc(x_28);
x_29 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_29, 0, x_28);
lean_ctor_set(x_29, 1, x_5);
lean_ctor_set(x_29, 2, x_4);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc_n(x_3, 2);
lean_inc(x_2);
x_30 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg(x_1, x_21, x_26, x_2, x_3, x_29, x_3, x_28, x_27, x_10, x_11, x_12, x_13, x_25);
lean_dec(x_29);
if (lean_obj_tag(x_30) == 0)
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_31 = lean_ctor_get(x_30, 0);
lean_inc(x_31);
x_32 = lean_ctor_get(x_30, 1);
lean_inc(x_32);
lean_dec(x_30);
x_33 = lean_ctor_get(x_31, 1);
lean_inc(x_33);
lean_dec(x_31);
x_34 = lean_nat_add(x_8, x_16);
lean_inc(x_3);
x_35 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3___redArg(x_1, x_4, x_5, x_2, x_3, x_6, x_3, x_34, x_33, x_10, x_11, x_12, x_13, x_32);
return x_35;
}
else
{
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_30;
}
}
else
{
uint8_t x_36; 
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_36 = !lean_is_exclusive(x_23);
if (x_36 == 0)
{
return x_23;
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_37 = lean_ctor_get(x_23, 0);
x_38 = lean_ctor_get(x_23, 1);
lean_inc(x_38);
lean_inc(x_37);
lean_dec(x_23);
x_39 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_39, 0, x_37);
lean_ctor_set(x_39, 1, x_38);
return x_39;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
lean_object* x_17; 
x_17 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__3___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_11, x_12, x_13, x_14, x_15, x_16);
return x_17;
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(", _, _, _, _, _⟩ := pts_of_circlesInter ", 42, 40);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("b", 1, 1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_14 = lean_ctor_get(x_5, 1);
x_15 = lean_ctor_get(x_5, 2);
x_16 = lean_nat_dec_lt(x_7, x_14);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; 
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_6);
lean_ctor_set(x_17, 1, x_8);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_13);
return x_18;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
lean_dec(x_6);
x_19 = lean_array_fget(x_1, x_7);
x_20 = lean_ctor_get(x_19, 1);
lean_inc(x_20);
x_21 = lean_ctor_get(x_19, 0);
lean_inc(x_21);
lean_dec(x_19);
x_22 = lean_ctor_get(x_20, 0);
lean_inc(x_22);
x_23 = lean_ctor_get(x_20, 1);
lean_inc(x_23);
lean_dec(x_20);
x_24 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0;
x_25 = l_Lean_LocalDecl_toExpr(x_22);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
x_26 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_24, x_25, x_8, x_9, x_10, x_11, x_12, x_13);
if (lean_obj_tag(x_26) == 0)
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_27 = lean_ctor_get(x_26, 0);
lean_inc(x_27);
x_28 = lean_ctor_get(x_26, 1);
lean_inc(x_28);
lean_dec(x_26);
x_29 = lean_ctor_get(x_27, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_27, 1);
lean_inc(x_30);
lean_dec(x_27);
x_31 = l_Lean_LocalDecl_toExpr(x_23);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
x_32 = l_ProofWidgets_Penrose_DiagramBuilderM_addExpr(x_24, x_31, x_30, x_9, x_10, x_11, x_12, x_28);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_97; 
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
x_34 = lean_ctor_get(x_32, 1);
lean_inc(x_34);
lean_dec(x_32);
x_35 = lean_ctor_get(x_33, 0);
lean_inc(x_35);
x_36 = lean_ctor_get(x_33, 1);
lean_inc(x_36);
lean_dec(x_33);
lean_inc(x_29);
x_37 = lean_string_append(x_29, x_35);
lean_inc(x_35);
x_38 = lean_string_append(x_35, x_29);
x_39 = l_isPoint_x3f___closed__0;
x_40 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__0;
x_41 = lean_string_append(x_40, x_37);
x_42 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2;
x_43 = lean_string_append(x_41, x_42);
x_44 = lean_string_append(x_43, x_38);
x_45 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__0;
x_46 = lean_string_append(x_44, x_45);
x_97 = lean_ctor_get(x_21, 2);
lean_inc(x_97);
lean_dec(x_21);
x_47 = x_97;
goto block_96;
block_96:
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; 
lean_inc(x_2);
x_48 = l_Lean_Name_toString(x_47, x_16, x_2);
x_49 = lean_string_append(x_46, x_48);
lean_dec(x_48);
lean_inc(x_3);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_37);
x_50 = lean_apply_9(x_3, x_37, x_39, x_49, x_36, x_9, x_10, x_11, x_12, x_34);
if (lean_obj_tag(x_50) == 0)
{
lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; 
x_51 = lean_ctor_get(x_50, 0);
lean_inc(x_51);
x_52 = lean_ctor_get(x_50, 1);
lean_inc(x_52);
lean_dec(x_50);
x_53 = lean_ctor_get(x_51, 1);
lean_inc(x_53);
lean_dec(x_51);
x_54 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__1;
x_55 = l_EuclideanDisplay_rpc___lam__3___closed__30;
lean_inc(x_38);
x_56 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_56, 0, x_38);
x_57 = l_EuclideanDisplay_rpc___lam__0___closed__3;
x_58 = lean_array_push(x_57, x_56);
x_59 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_59, 0, x_54);
lean_ctor_set(x_59, 1, x_55);
lean_ctor_set(x_59, 2, x_58);
lean_inc(x_38);
x_60 = l_ProofWidgets_Penrose_DiagramBuilderM_addEmbed___redArg(x_38, x_39, x_59, x_53, x_52);
x_61 = lean_ctor_get(x_60, 0);
lean_inc(x_61);
x_62 = lean_ctor_get(x_60, 1);
lean_inc(x_62);
lean_dec(x_60);
x_63 = lean_ctor_get(x_61, 1);
lean_inc(x_63);
lean_dec(x_61);
x_64 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__6;
x_65 = lean_string_append(x_64, x_38);
lean_dec(x_38);
x_66 = lean_string_append(x_65, x_42);
lean_inc(x_66);
x_67 = lean_string_append(x_66, x_29);
x_68 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
x_69 = lean_string_append(x_67, x_68);
x_70 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_69, x_63, x_62);
x_71 = lean_ctor_get(x_70, 0);
lean_inc(x_71);
x_72 = lean_ctor_get(x_70, 1);
lean_inc(x_72);
lean_dec(x_70);
x_73 = lean_ctor_get(x_71, 1);
lean_inc(x_73);
lean_dec(x_71);
x_74 = lean_string_append(x_64, x_37);
lean_dec(x_37);
x_75 = lean_string_append(x_74, x_42);
lean_inc(x_75);
x_76 = lean_string_append(x_75, x_35);
x_77 = lean_string_append(x_76, x_68);
x_78 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_77, x_73, x_72);
x_79 = lean_ctor_get(x_78, 0);
lean_inc(x_79);
x_80 = lean_ctor_get(x_78, 1);
lean_inc(x_80);
lean_dec(x_78);
x_81 = lean_ctor_get(x_79, 1);
lean_inc(x_81);
lean_dec(x_79);
x_82 = lean_string_append(x_75, x_29);
lean_dec(x_29);
x_83 = lean_string_append(x_82, x_68);
x_84 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_83, x_81, x_80);
x_85 = lean_ctor_get(x_84, 0);
lean_inc(x_85);
x_86 = lean_ctor_get(x_84, 1);
lean_inc(x_86);
lean_dec(x_84);
x_87 = lean_ctor_get(x_85, 1);
lean_inc(x_87);
lean_dec(x_85);
x_88 = lean_string_append(x_66, x_35);
lean_dec(x_35);
x_89 = lean_string_append(x_88, x_68);
x_90 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_89, x_87, x_86);
x_91 = lean_ctor_get(x_90, 0);
lean_inc(x_91);
x_92 = lean_ctor_get(x_90, 1);
lean_inc(x_92);
lean_dec(x_90);
x_93 = lean_ctor_get(x_91, 1);
lean_inc(x_93);
lean_dec(x_91);
x_94 = lean_nat_add(x_7, x_15);
lean_dec(x_7);
lean_inc(x_4);
{
lean_object* _tmp_5 = x_4;
lean_object* _tmp_6 = x_94;
lean_object* _tmp_7 = x_93;
lean_object* _tmp_12 = x_92;
x_6 = _tmp_5;
x_7 = _tmp_6;
x_8 = _tmp_7;
x_13 = _tmp_12;
}
goto _start;
}
else
{
lean_dec(x_38);
lean_dec(x_37);
lean_dec(x_35);
lean_dec(x_29);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_50;
}
}
}
else
{
uint8_t x_98; 
lean_dec(x_29);
lean_dec(x_21);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_98 = !lean_is_exclusive(x_32);
if (x_98 == 0)
{
return x_32;
}
else
{
lean_object* x_99; lean_object* x_100; lean_object* x_101; 
x_99 = lean_ctor_get(x_32, 0);
x_100 = lean_ctor_get(x_32, 1);
lean_inc(x_100);
lean_inc(x_99);
lean_dec(x_32);
x_101 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_101, 0, x_99);
lean_ctor_set(x_101, 1, x_100);
return x_101;
}
}
}
else
{
uint8_t x_102; 
lean_dec(x_23);
lean_dec(x_21);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_102 = !lean_is_exclusive(x_26);
if (x_102 == 0)
{
return x_26;
}
else
{
lean_object* x_103; lean_object* x_104; lean_object* x_105; 
x_103 = lean_ctor_get(x_26, 0);
x_104 = lean_ctor_get(x_26, 1);
lean_inc(x_104);
lean_inc(x_103);
lean_dec(x_26);
x_105 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_105, 0, x_103);
lean_ctor_set(x_105, 1, x_104);
return x_105;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
lean_object* x_16; 
x_16 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_10, x_11, x_12, x_13, x_14, x_15);
return x_16;
}
}
static lean_object* _init_l_constructLines___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" (", 2, 2);
return x_1;
}
}
static lean_object* _init_l_constructLines___lam__0___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_constructLines___lam__0___closed__0;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_constructLines___lam__0___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("insert", 6, 6);
return x_1;
}
}
static lean_object* _init_l_constructLines___lam__0___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_constructLines___lam__0___closed__2;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_constructLines___lam__0___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_constructLines___lam__0___closed__3;
x_2 = l_EuclideanDisplay_rpc___lam__0___closed__3;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_constructLines___lam__0___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")\n      ", 8, 8);
return x_1;
}
}
static lean_object* _init_l_constructLines___lam__0___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_constructLines___lam__0___closed__5;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_constructLines___lam__0___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_constructLines___lam__0___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Emphasize(", 10, 10);
return x_1;
}
}
LEAN_EXPORT lean_object* l_constructLines___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_12 = l_EuclideanDisplay_rpc___lam__0___closed__0;
x_13 = l_EuclideanDisplay_rpc___lam__3___closed__30;
x_14 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__1;
lean_inc(x_3);
x_15 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_15, 0, x_3);
x_16 = l_EuclideanDisplay_rpc___lam__0___closed__3;
x_17 = lean_array_push(x_16, x_15);
x_18 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_18, 0, x_14);
lean_ctor_set(x_18, 1, x_13);
lean_ctor_set(x_18, 2, x_17);
x_19 = l_constructLines___lam__0___closed__1;
x_20 = l_ProofWidgets_MakeEditLink;
lean_inc(x_1);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_1);
lean_ctor_set(x_21, 1, x_1);
x_22 = lean_box(0);
x_23 = l_ProofWidgets_MakeEditLinkProps_ofReplaceRange(x_2, x_21, x_5, x_22);
x_24 = l_constructLines___lam__0___closed__4;
x_25 = l_ProofWidgets_Html_ofComponent___at___constructLines_spec__0(x_20, x_23, x_24);
x_26 = l_constructLines___lam__0___closed__6;
x_27 = l_constructLines___lam__0___closed__7;
x_28 = lean_array_push(x_27, x_18);
x_29 = lean_array_push(x_28, x_19);
x_30 = lean_array_push(x_29, x_25);
x_31 = lean_array_push(x_30, x_26);
x_32 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_32, 0, x_12);
lean_ctor_set(x_32, 1, x_13);
lean_ctor_set(x_32, 2, x_31);
lean_inc(x_3);
x_33 = l_ProofWidgets_Penrose_DiagramBuilderM_addEmbed___redArg(x_3, x_4, x_32, x_6, x_11);
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_33, 1);
lean_inc(x_35);
lean_dec(x_33);
x_36 = lean_ctor_get(x_34, 1);
lean_inc(x_36);
lean_dec(x_34);
x_37 = l_constructLines___lam__0___closed__8;
x_38 = lean_string_append(x_37, x_3);
lean_dec(x_3);
x_39 = l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3;
x_40 = lean_string_append(x_38, x_39);
x_41 = l_ProofWidgets_Penrose_DiagramBuilderM_addInstruction___redArg(x_40, x_36, x_35);
return x_41;
}
}
static lean_object* _init_l_constructLines___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = l_Array_empty(lean_box(0));
return x_1;
}
}
static lean_object* _init_l_constructLines___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_constructLines___closed__0;
x_2 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
return x_2;
}
}
static lean_object* _init_l_constructLines___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_constructLines(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; size_t x_11; size_t x_12; lean_object* x_13; 
x_10 = l_constructLines___closed__1;
x_11 = lean_array_size(x_1);
x_12 = 0;
lean_inc(x_5);
x_13 = l_Array_forIn_x27Unsafe_loop___at___constructLines_spec__1(x_1, x_11, x_12, x_10, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_13) == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_14 = lean_ctor_get(x_13, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_16);
lean_dec(x_13);
x_17 = lean_ctor_get(x_14, 1);
lean_inc(x_17);
lean_dec(x_14);
x_18 = lean_ctor_get(x_15, 0);
lean_inc(x_18);
x_19 = lean_ctor_get(x_15, 1);
lean_inc(x_19);
lean_dec(x_15);
x_20 = lean_alloc_closure((void*)(l_constructLines___lam__0___boxed), 11, 2);
lean_closure_set(x_20, 0, x_3);
lean_closure_set(x_20, 1, x_2);
x_21 = lean_unsigned_to_nat(0u);
x_22 = lean_array_get_size(x_19);
x_23 = lean_unsigned_to_nat(1u);
lean_inc(x_22);
x_24 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_24, 0, x_21);
lean_ctor_set(x_24, 1, x_22);
lean_ctor_set(x_24, 2, x_23);
x_25 = lean_box(0);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_20);
x_26 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__3___redArg(x_19, x_20, x_25, x_23, x_22, x_24, x_25, x_21, x_17, x_5, x_6, x_7, x_8, x_16);
lean_dec(x_24);
lean_dec(x_19);
if (lean_obj_tag(x_26) == 0)
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; 
x_27 = lean_ctor_get(x_26, 0);
lean_inc(x_27);
x_28 = lean_ctor_get(x_26, 1);
lean_inc(x_28);
lean_dec(x_26);
x_29 = lean_ctor_get(x_27, 1);
lean_inc(x_29);
lean_dec(x_27);
x_30 = l_constructLines___closed__2;
x_31 = lean_array_get_size(x_18);
x_32 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_32, 0, x_21);
lean_ctor_set(x_32, 1, x_31);
lean_ctor_set(x_32, 2, x_23);
x_33 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg(x_18, x_30, x_20, x_25, x_32, x_25, x_21, x_29, x_5, x_6, x_7, x_8, x_28);
lean_dec(x_32);
lean_dec(x_18);
if (lean_obj_tag(x_33) == 0)
{
uint8_t x_34; 
x_34 = !lean_is_exclusive(x_33);
if (x_34 == 0)
{
lean_object* x_35; uint8_t x_36; 
x_35 = lean_ctor_get(x_33, 0);
x_36 = !lean_is_exclusive(x_35);
if (x_36 == 0)
{
lean_object* x_37; 
x_37 = lean_ctor_get(x_35, 0);
lean_dec(x_37);
lean_ctor_set(x_35, 0, x_25);
return x_33;
}
else
{
lean_object* x_38; lean_object* x_39; 
x_38 = lean_ctor_get(x_35, 1);
lean_inc(x_38);
lean_dec(x_35);
x_39 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_39, 0, x_25);
lean_ctor_set(x_39, 1, x_38);
lean_ctor_set(x_33, 0, x_39);
return x_33;
}
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_40 = lean_ctor_get(x_33, 0);
x_41 = lean_ctor_get(x_33, 1);
lean_inc(x_41);
lean_inc(x_40);
lean_dec(x_33);
x_42 = lean_ctor_get(x_40, 1);
lean_inc(x_42);
if (lean_is_exclusive(x_40)) {
 lean_ctor_release(x_40, 0);
 lean_ctor_release(x_40, 1);
 x_43 = x_40;
} else {
 lean_dec_ref(x_40);
 x_43 = lean_box(0);
}
if (lean_is_scalar(x_43)) {
 x_44 = lean_alloc_ctor(0, 2, 0);
} else {
 x_44 = x_43;
}
lean_ctor_set(x_44, 0, x_25);
lean_ctor_set(x_44, 1, x_42);
x_45 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_45, 0, x_44);
lean_ctor_set(x_45, 1, x_41);
return x_45;
}
}
else
{
return x_33;
}
}
else
{
lean_dec(x_20);
lean_dec(x_18);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
return x_26;
}
}
else
{
uint8_t x_46; 
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_3);
lean_dec(x_2);
x_46 = !lean_is_exclusive(x_13);
if (x_46 == 0)
{
return x_13;
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_47 = lean_ctor_get(x_13, 0);
x_48 = lean_ctor_get(x_13, 1);
lean_inc(x_48);
lean_inc(x_47);
lean_dec(x_13);
x_49 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_49, 0, x_47);
lean_ctor_set(x_49, 1, x_48);
return x_49;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___at___constructLines_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Html_ofComponent___at___constructLines_spec__0(x_1, x_2, x_3);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___constructLines_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
size_t x_11; size_t x_12; lean_object* x_13; 
x_11 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_12 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_13 = l_Array_forIn_x27Unsafe_loop___at___constructLines_spec__1(x_1, x_11, x_12, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_1);
return x_13;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; 
x_15 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_6);
lean_dec(x_1);
return x_15;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
lean_object* x_17; 
x_17 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__2(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16);
lean_dec(x_6);
lean_dec(x_1);
return x_17;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; 
x_15 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_6);
lean_dec(x_1);
return x_15;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
lean_object* x_17; 
x_17 = l_Std_Range_forIn_x27_loop___at___Std_Range_forIn_x27_loop___at___constructLines_spec__3_spec__3(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16);
lean_dec(x_6);
lean_dec(x_1);
return x_17;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__3___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; 
x_15 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__3___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_8);
lean_dec(x_6);
lean_dec(x_1);
return x_15;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
lean_object* x_17; 
x_17 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__3(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16);
lean_dec(x_8);
lean_dec(x_6);
lean_dec(x_1);
return x_17;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
lean_object* x_14; 
x_14 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13);
lean_dec(x_5);
lean_dec(x_1);
return x_14;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
lean_object* x_16; 
x_16 = l_Std_Range_forIn_x27_loop___at___constructLines_spec__5(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
lean_dec(x_5);
lean_dec(x_1);
return x_16;
}
}
LEAN_EXPORT lean_object* l_constructLines___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; 
x_12 = l_constructLines___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
return x_12;
}
}
LEAN_EXPORT lean_object* l_constructLines___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_constructLines(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0___redArg(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_16; lean_object* x_17; uint8_t x_20; 
x_20 = lean_usize_dec_eq(x_3, x_4);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_array_uget(x_2, x_3);
x_22 = lean_ctor_get(x_21, 1);
lean_inc(x_22);
switch (lean_obj_tag(x_22)) {
case 0:
{
lean_object* x_23; lean_object* x_24; uint8_t x_25; 
x_23 = lean_ctor_get(x_21, 0);
lean_inc(x_23);
lean_dec(x_21);
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec(x_22);
x_25 = lean_name_eq(x_23, x_1);
lean_dec(x_23);
if (x_25 == 0)
{
lean_dec(x_24);
x_10 = x_5;
x_11 = x_9;
goto block_15;
}
else
{
lean_object* x_26; 
lean_inc(x_6);
x_26 = l_Lean_FVarId_getDecl___redArg(x_24, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_26) == 0)
{
lean_object* x_27; lean_object* x_28; 
x_27 = lean_ctor_get(x_26, 0);
lean_inc(x_27);
x_28 = lean_ctor_get(x_26, 1);
lean_inc(x_28);
lean_dec(x_26);
x_16 = x_27;
x_17 = x_28;
goto block_19;
}
else
{
uint8_t x_29; 
lean_dec(x_6);
lean_dec(x_5);
x_29 = !lean_is_exclusive(x_26);
if (x_29 == 0)
{
return x_26;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_26, 0);
x_31 = lean_ctor_get(x_26, 1);
lean_inc(x_31);
lean_inc(x_30);
lean_dec(x_26);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
return x_32;
}
}
}
}
case 1:
{
lean_object* x_33; lean_object* x_34; uint8_t x_35; 
x_33 = lean_ctor_get(x_21, 0);
lean_inc(x_33);
lean_dec(x_21);
x_34 = lean_ctor_get(x_22, 0);
lean_inc(x_34);
lean_dec(x_22);
x_35 = lean_name_eq(x_33, x_1);
lean_dec(x_33);
if (x_35 == 0)
{
lean_dec(x_34);
x_10 = x_5;
x_11 = x_9;
goto block_15;
}
else
{
lean_object* x_36; 
lean_inc(x_6);
x_36 = l_Lean_FVarId_getDecl___redArg(x_34, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_36) == 0)
{
lean_object* x_37; lean_object* x_38; 
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec(x_36);
x_16 = x_37;
x_17 = x_38;
goto block_19;
}
else
{
uint8_t x_39; 
lean_dec(x_6);
lean_dec(x_5);
x_39 = !lean_is_exclusive(x_36);
if (x_39 == 0)
{
return x_36;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_40 = lean_ctor_get(x_36, 0);
x_41 = lean_ctor_get(x_36, 1);
lean_inc(x_41);
lean_inc(x_40);
lean_dec(x_36);
x_42 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_42, 0, x_40);
lean_ctor_set(x_42, 1, x_41);
return x_42;
}
}
}
}
default: 
{
lean_dec(x_22);
lean_dec(x_21);
x_10 = x_5;
x_11 = x_9;
goto block_15;
}
}
}
else
{
lean_object* x_43; 
lean_dec(x_6);
x_43 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_43, 0, x_5);
lean_ctor_set(x_43, 1, x_9);
return x_43;
}
block_15:
{
size_t x_12; size_t x_13; 
x_12 = 1;
x_13 = lean_usize_add(x_3, x_12);
x_3 = x_13;
x_5 = x_10;
x_9 = x_11;
goto _start;
}
block_19:
{
lean_object* x_18; 
x_18 = lean_array_push(x_5, x_16);
x_10 = x_18;
x_11 = x_17;
goto block_15;
}
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_8, x_9, x_10);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; uint8_t x_11; 
x_10 = l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___closed__0;
x_11 = lean_nat_dec_lt(x_3, x_4);
if (x_11 == 0)
{
lean_object* x_12; 
lean_dec(x_5);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_10);
lean_ctor_set(x_12, 1, x_9);
return x_12;
}
else
{
lean_object* x_13; uint8_t x_14; 
x_13 = lean_array_get_size(x_2);
x_14 = lean_nat_dec_le(x_4, x_13);
lean_dec(x_13);
if (x_14 == 0)
{
lean_object* x_15; 
lean_dec(x_5);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_10);
lean_ctor_set(x_15, 1, x_9);
return x_15;
}
else
{
size_t x_16; size_t x_17; lean_object* x_18; 
x_16 = lean_usize_of_nat(x_3);
x_17 = lean_usize_of_nat(x_4);
x_18 = l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0___redArg(x_1, x_2, x_16, x_17, x_10, x_5, x_7, x_8, x_9);
return x_18;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__2_spec__2(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; uint8_t x_10; 
x_10 = lean_usize_dec_eq(x_2, x_3);
if (x_10 == 0)
{
lean_object* x_11; 
x_11 = lean_array_uget(x_1, x_2);
if (lean_obj_tag(x_11) == 0)
{
x_5 = x_4;
goto block_9;
}
else
{
lean_object* x_12; lean_object* x_13; 
x_12 = lean_ctor_get(x_11, 0);
lean_inc(x_12);
lean_dec(x_11);
x_13 = lean_array_push(x_4, x_12);
x_5 = x_13;
goto block_9;
}
}
else
{
return x_4;
}
block_9:
{
size_t x_6; size_t x_7; 
x_6 = 1;
x_7 = lean_usize_add(x_2, x_6);
x_2 = x_7;
x_4 = x_5;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; uint8_t x_5; 
x_4 = l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___closed__0;
x_5 = lean_nat_dec_lt(x_2, x_3);
if (x_5 == 0)
{
return x_4;
}
else
{
lean_object* x_6; uint8_t x_7; 
x_6 = lean_array_get_size(x_1);
x_7 = lean_nat_dec_le(x_3, x_6);
lean_dec(x_6);
if (x_7 == 0)
{
return x_4;
}
else
{
size_t x_8; size_t x_9; lean_object* x_10; 
x_8 = lean_usize_of_nat(x_2);
x_9 = lean_usize_of_nat(x_3);
x_10 = l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__2_spec__2(x_1, x_8, x_9, x_4);
return x_10;
}
}
}
}
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; 
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
x_12 = l_addHypotheses(x_1, x_6, x_7, x_8, x_9, x_10, x_11);
if (lean_obj_tag(x_12) == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_13 = lean_ctor_get(x_12, 0);
lean_inc(x_13);
x_14 = lean_ctor_get(x_2, 0);
lean_inc(x_14);
lean_dec(x_2);
x_15 = lean_ctor_get(x_12, 1);
lean_inc(x_15);
lean_dec(x_12);
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_16);
lean_dec(x_13);
x_17 = lean_ctor_get(x_14, 0);
lean_inc(x_17);
lean_dec(x_14);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
x_18 = l_constructLines(x_3, x_17, x_4, x_16, x_7, x_8, x_9, x_10, x_15);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
x_20 = lean_ctor_get(x_18, 1);
lean_inc(x_20);
lean_dec(x_18);
x_21 = lean_ctor_get(x_19, 1);
lean_inc(x_21);
lean_dec(x_19);
x_22 = l_EuclideanDisplay_dsl___closed__0;
x_23 = l_EuclideanDisplay_sty___closed__0;
x_24 = lean_unsigned_to_nat(1500u);
x_25 = l_ProofWidgets_Penrose_DiagramBuilderM_buildDiagram(x_22, x_23, x_24, x_21, x_7, x_8, x_9, x_10, x_20);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
x_26 = lean_ctor_get(x_25, 0);
lean_inc(x_26);
x_27 = lean_ctor_get(x_26, 0);
lean_inc(x_27);
if (lean_obj_tag(x_27) == 0)
{
uint8_t x_28; 
x_28 = !lean_is_exclusive(x_25);
if (x_28 == 0)
{
lean_object* x_29; uint8_t x_30; 
x_29 = lean_ctor_get(x_25, 0);
lean_dec(x_29);
x_30 = !lean_is_exclusive(x_26);
if (x_30 == 0)
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_31 = lean_ctor_get(x_26, 0);
lean_dec(x_31);
x_32 = l_EuclideanDisplay_rpc___lam__0___closed__0;
x_33 = lean_mk_empty_array_with_capacity(x_5);
x_34 = l_EuclideanDisplay_rpc___lam__0___closed__4;
x_35 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_35, 0, x_32);
lean_ctor_set(x_35, 1, x_33);
lean_ctor_set(x_35, 2, x_34);
lean_ctor_set(x_26, 0, x_35);
return x_25;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_36 = lean_ctor_get(x_26, 1);
lean_inc(x_36);
lean_dec(x_26);
x_37 = l_EuclideanDisplay_rpc___lam__0___closed__0;
x_38 = lean_mk_empty_array_with_capacity(x_5);
x_39 = l_EuclideanDisplay_rpc___lam__0___closed__4;
x_40 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_40, 0, x_37);
lean_ctor_set(x_40, 1, x_38);
lean_ctor_set(x_40, 2, x_39);
x_41 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_41, 0, x_40);
lean_ctor_set(x_41, 1, x_36);
lean_ctor_set(x_25, 0, x_41);
return x_25;
}
}
else
{
lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; 
x_42 = lean_ctor_get(x_25, 1);
lean_inc(x_42);
lean_dec(x_25);
x_43 = lean_ctor_get(x_26, 1);
lean_inc(x_43);
if (lean_is_exclusive(x_26)) {
 lean_ctor_release(x_26, 0);
 lean_ctor_release(x_26, 1);
 x_44 = x_26;
} else {
 lean_dec_ref(x_26);
 x_44 = lean_box(0);
}
x_45 = l_EuclideanDisplay_rpc___lam__0___closed__0;
x_46 = lean_mk_empty_array_with_capacity(x_5);
x_47 = l_EuclideanDisplay_rpc___lam__0___closed__4;
x_48 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_48, 0, x_45);
lean_ctor_set(x_48, 1, x_46);
lean_ctor_set(x_48, 2, x_47);
if (lean_is_scalar(x_44)) {
 x_49 = lean_alloc_ctor(0, 2, 0);
} else {
 x_49 = x_44;
}
lean_ctor_set(x_49, 0, x_48);
lean_ctor_set(x_49, 1, x_43);
x_50 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_50, 0, x_49);
lean_ctor_set(x_50, 1, x_42);
return x_50;
}
}
else
{
uint8_t x_51; 
x_51 = !lean_is_exclusive(x_25);
if (x_51 == 0)
{
lean_object* x_52; uint8_t x_53; 
x_52 = lean_ctor_get(x_25, 0);
lean_dec(x_52);
x_53 = !lean_is_exclusive(x_26);
if (x_53 == 0)
{
lean_object* x_54; lean_object* x_55; 
x_54 = lean_ctor_get(x_26, 0);
lean_dec(x_54);
x_55 = lean_ctor_get(x_27, 0);
lean_inc(x_55);
lean_dec(x_27);
lean_ctor_set(x_26, 0, x_55);
return x_25;
}
else
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; 
x_56 = lean_ctor_get(x_26, 1);
lean_inc(x_56);
lean_dec(x_26);
x_57 = lean_ctor_get(x_27, 0);
lean_inc(x_57);
lean_dec(x_27);
x_58 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_58, 0, x_57);
lean_ctor_set(x_58, 1, x_56);
lean_ctor_set(x_25, 0, x_58);
return x_25;
}
}
else
{
lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; 
x_59 = lean_ctor_get(x_25, 1);
lean_inc(x_59);
lean_dec(x_25);
x_60 = lean_ctor_get(x_26, 1);
lean_inc(x_60);
if (lean_is_exclusive(x_26)) {
 lean_ctor_release(x_26, 0);
 lean_ctor_release(x_26, 1);
 x_61 = x_26;
} else {
 lean_dec_ref(x_26);
 x_61 = lean_box(0);
}
x_62 = lean_ctor_get(x_27, 0);
lean_inc(x_62);
lean_dec(x_27);
if (lean_is_scalar(x_61)) {
 x_63 = lean_alloc_ctor(0, 2, 0);
} else {
 x_63 = x_61;
}
lean_ctor_set(x_63, 0, x_62);
lean_ctor_set(x_63, 1, x_60);
x_64 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_64, 0, x_63);
lean_ctor_set(x_64, 1, x_59);
return x_64;
}
}
}
else
{
uint8_t x_65; 
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
x_65 = !lean_is_exclusive(x_18);
if (x_65 == 0)
{
return x_18;
}
else
{
lean_object* x_66; lean_object* x_67; lean_object* x_68; 
x_66 = lean_ctor_get(x_18, 0);
x_67 = lean_ctor_get(x_18, 1);
lean_inc(x_67);
lean_inc(x_66);
lean_dec(x_18);
x_68 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_68, 0, x_66);
lean_ctor_set(x_68, 1, x_67);
return x_68;
}
}
}
else
{
uint8_t x_69; 
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_2);
x_69 = !lean_is_exclusive(x_12);
if (x_69 == 0)
{
return x_12;
}
else
{
lean_object* x_70; lean_object* x_71; lean_object* x_72; 
x_70 = lean_ctor_get(x_12, 0);
x_71 = lean_ctor_get(x_12, 1);
lean_inc(x_71);
lean_inc(x_70);
lean_dec(x_12);
x_72 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_72, 0, x_70);
lean_ctor_set(x_72, 1, x_71);
return x_72;
}
}
}
}
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_array_get_size(x_1);
lean_inc(x_6);
x_12 = l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__0(x_2, x_1, x_3, x_11, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_11);
if (lean_obj_tag(x_12) == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_13 = lean_ctor_get(x_6, 2);
lean_inc(x_13);
x_14 = lean_ctor_get(x_12, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_12, 1);
lean_inc(x_15);
lean_dec(x_12);
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_16);
lean_dec(x_13);
x_17 = l_Lean_PersistentArray_toArray___redArg(x_16);
lean_dec(x_16);
x_18 = lean_array_get_size(x_17);
x_19 = l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__2(x_17, x_3, x_18);
lean_dec(x_18);
lean_dec(x_17);
x_20 = lean_alloc_closure((void*)(l_EuclideanConstructions_rpc___lam__0___boxed), 11, 5);
lean_closure_set(x_20, 0, x_19);
lean_closure_set(x_20, 1, x_4);
lean_closure_set(x_20, 2, x_14);
lean_closure_set(x_20, 3, x_5);
lean_closure_set(x_20, 4, x_3);
x_21 = l_ProofWidgets_Penrose_DiagramBuilderM_run___redArg(x_20, x_6, x_7, x_8, x_9, x_15);
return x_21;
}
else
{
uint8_t x_22; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
x_22 = !lean_is_exclusive(x_12);
if (x_22 == 0)
{
return x_12;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_23 = lean_ctor_get(x_12, 0);
x_24 = lean_ctor_get(x_12, 1);
lean_inc(x_24);
lean_inc(x_23);
lean_dec(x_12);
x_25 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_25, 0, x_23);
lean_ctor_set(x_25, 1, x_24);
return x_25;
}
}
}
}
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_MVarId_getDecl(x_1, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_8) == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_ctor_get(x_5, 2);
lean_inc(x_11);
x_12 = lean_ctor_get(x_9, 1);
lean_inc(x_12);
x_13 = lean_ctor_get(x_9, 4);
lean_inc(x_13);
lean_dec(x_9);
x_14 = lean_box(0);
x_15 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_15, 0, x_11);
lean_ctor_set(x_15, 1, x_14);
lean_ctor_set(x_15, 2, x_14);
x_16 = l_Lean_LocalContext_sanitizeNames(x_12, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
lean_dec(x_16);
x_18 = l_Lean_Meta_withLCtx___at_____private_Lean_Meta_Basic_0__Lean_Meta_mkLevelErrorMessageCore_spec__2___redArg(x_17, x_13, x_2, x_3, x_4, x_5, x_6, x_10);
return x_18;
}
else
{
uint8_t x_19; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_19 = !lean_is_exclusive(x_8);
if (x_19 == 0)
{
return x_8;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_20 = lean_ctor_get(x_8, 0);
x_21 = lean_ctor_get(x_8, 1);
lean_inc(x_21);
lean_inc(x_20);
lean_dec(x_8);
x_22 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_22, 0, x_20);
lean_ctor_set(x_22, 1, x_21);
return x_22;
}
}
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; 
x_1 = lean_box(1);
x_2 = lean_alloc_ctor(1, 0, 1);
x_3 = lean_unbox(x_1);
lean_ctor_set_uint8(x_2, 0, x_3);
return x_2;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanConstructions_rpc___lam__3___closed__0;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanConstructions_rpc___lam__3___closed__1;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__2;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Euclidean constructions", 23, 23);
return x_1;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_EuclideanConstructions_rpc___lam__3___closed__3;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanConstructions_rpc___lam__3___closed__4;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__2;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_EuclideanConstructions_rpc___lam__3___closed__5;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__8;
x_3 = l_EuclideanDisplay_rpc___lam__3___closed__3;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanConstructions_rpc___lam__3___closed__6;
x_2 = l_EuclideanDisplay_rpc___lam__3___closed__18;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("EuclideanConstructions.rpc", 26, 26);
return x_1;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___lam__3___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_EuclideanDisplay_rpc___lam__3___closed__22;
x_2 = lean_unsigned_to_nat(38u);
x_3 = lean_unsigned_to_nat(271u);
x_4 = l_EuclideanConstructions_rpc___lam__3___closed__8;
x_5 = l_EuclideanDisplay_rpc___lam__3___closed__20;
x_6 = l_mkPanicMessageWithDecl(x_5, x_4, x_3, x_2, x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; uint8_t x_11; lean_object* x_12; lean_object* x_13; 
x_4 = l_Lean_Server_RequestM_readDoc___at___Lean_Server_RequestM_withWaitFindSnapAtPos_spec__0(x_2, x_3);
x_5 = lean_ctor_get(x_4, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_4, 1);
lean_inc(x_6);
if (lean_is_exclusive(x_4)) {
 lean_ctor_release(x_4, 0);
 lean_ctor_release(x_4, 1);
 x_7 = x_4;
} else {
 lean_dec_ref(x_4);
 x_7 = lean_box(0);
}
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
x_9 = lean_ctor_get(x_1, 1);
lean_inc(x_9);
x_10 = lean_ctor_get(x_1, 3);
lean_inc(x_10);
lean_dec(x_1);
x_11 = l_Array_isEmpty___redArg(x_9);
if (x_11 == 0)
{
lean_object* x_26; lean_object* x_27; uint8_t x_28; 
x_26 = lean_unsigned_to_nat(0u);
x_27 = lean_array_get_size(x_9);
x_28 = lean_nat_dec_lt(x_26, x_27);
lean_dec(x_27);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; 
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_5);
x_29 = l_EuclideanConstructions_rpc___lam__3___closed__9;
x_30 = l_panic___at___EuclideanDisplay_rpc_spec__0(x_29, x_2, x_6);
if (lean_obj_tag(x_30) == 0)
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_ctor_get(x_30, 0);
lean_inc(x_31);
x_32 = lean_ctor_get(x_30, 1);
lean_inc(x_32);
lean_dec(x_30);
x_12 = x_31;
x_13 = x_32;
goto block_25;
}
else
{
lean_dec(x_7);
return x_30;
}
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
lean_dec(x_2);
x_33 = lean_array_fget(x_9, x_26);
lean_dec(x_9);
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_34, 2);
lean_inc(x_35);
lean_dec(x_34);
x_36 = lean_ctor_get(x_33, 3);
lean_inc(x_36);
lean_dec(x_33);
x_37 = lean_ctor_get(x_35, 0);
lean_inc(x_37);
lean_dec(x_35);
lean_inc(x_36);
x_38 = lean_alloc_closure((void*)(l_EuclideanConstructions_rpc___lam__1___boxed), 10, 5);
lean_closure_set(x_38, 0, x_10);
lean_closure_set(x_38, 1, x_36);
lean_closure_set(x_38, 2, x_26);
lean_closure_set(x_38, 3, x_5);
lean_closure_set(x_38, 4, x_8);
x_39 = lean_alloc_closure((void*)(l_EuclideanConstructions_rpc___lam__2), 7, 2);
lean_closure_set(x_39, 0, x_36);
lean_closure_set(x_39, 1, x_38);
x_40 = l_EuclideanDisplay_rpc___lam__3___closed__29;
x_41 = l_Lean_Elab_ContextInfo_runMetaM___redArg(x_37, x_40, x_39, x_6);
if (lean_obj_tag(x_41) == 0)
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_ctor_get(x_41, 0);
lean_inc(x_42);
x_43 = lean_ctor_get(x_41, 1);
lean_inc(x_43);
lean_dec(x_41);
x_12 = x_42;
x_13 = x_43;
goto block_25;
}
else
{
uint8_t x_44; 
lean_dec(x_7);
x_44 = !lean_is_exclusive(x_41);
if (x_44 == 0)
{
lean_object* x_45; lean_object* x_46; 
x_45 = lean_ctor_get(x_41, 0);
x_46 = l_Lean_Server_RequestError_ofIoError(x_45);
lean_ctor_set(x_41, 0, x_46);
return x_41;
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; 
x_47 = lean_ctor_get(x_41, 0);
x_48 = lean_ctor_get(x_41, 1);
lean_inc(x_48);
lean_inc(x_47);
lean_dec(x_41);
x_49 = l_Lean_Server_RequestError_ofIoError(x_47);
x_50 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_50, 0, x_49);
lean_ctor_set(x_50, 1, x_48);
return x_50;
}
}
}
}
else
{
lean_object* x_51; 
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_2);
x_51 = l_EuclideanDisplay_rpc___lam__3___closed__34;
x_12 = x_51;
x_13 = x_6;
goto block_25;
}
block_25:
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_14 = l_EuclideanDisplay_rpc___lam__3___closed__0;
x_15 = l_EuclideanDisplay_rpc___lam__3___closed__2;
x_16 = l_EuclideanConstructions_rpc___lam__3___closed__2;
x_17 = l_EuclideanDisplay_rpc___lam__3___closed__13;
x_18 = l_EuclideanDisplay_rpc___lam__3___closed__17;
x_19 = lean_array_push(x_15, x_12);
x_20 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_20, 0, x_17);
lean_ctor_set(x_20, 1, x_18);
lean_ctor_set(x_20, 2, x_19);
x_21 = l_EuclideanConstructions_rpc___lam__3___closed__7;
x_22 = lean_array_push(x_21, x_20);
x_23 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_23, 0, x_14);
lean_ctor_set(x_23, 1, x_16);
lean_ctor_set(x_23, 2, x_22);
if (lean_is_scalar(x_7)) {
 x_24 = lean_alloc_ctor(0, 2, 0);
} else {
 x_24 = x_7;
}
lean_ctor_set(x_24, 0, x_23);
lean_ctor_set(x_24, 1, x_13);
return x_24;
}
}
}
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; 
x_4 = lean_alloc_closure((void*)(l_EuclideanConstructions_rpc___lam__3), 3, 1);
lean_closure_set(x_4, 0, x_1);
x_5 = l_Lean_Server_RequestM_asTask___redArg(x_4, x_2, x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
size_t x_10; size_t x_11; lean_object* x_12; 
x_10 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_11 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_12 = l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0___redArg(x_1, x_2, x_10, x_11, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
return x_12;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
size_t x_11; size_t x_12; lean_object* x_13; 
x_11 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_12 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_13 = l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__0_spec__0(x_1, x_2, x_11, x_12, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
return x_13;
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__2_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_7 = l_Array_foldlMUnsafe_fold___at___Array_filterMapM___at___EuclideanConstructions_rpc_spec__2_spec__2(x_1, x_5, x_6, x_4);
lean_dec(x_1);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Array_filterMapM___at___EuclideanConstructions_rpc_spec__2(x_1, x_2, x_3);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; 
x_12 = l_EuclideanConstructions_rpc___lam__0(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec(x_5);
lean_dec(x_3);
lean_dec(x_1);
return x_12;
}
}
LEAN_EXPORT lean_object* l_EuclideanConstructions_rpc___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_EuclideanConstructions_rpc___lam__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_2);
lean_dec(x_1);
return x_11;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("EuclideanConstructions", 22, 22);
return x_1;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay_rpc___rpc__wrapped___closed__1;
x_2 = l_EuclideanConstructions_rpc___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_EuclideanConstructions_rpc), 3, 0);
return x_1;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanConstructions_rpc___rpc__wrapped___closed__2;
x_2 = l_EuclideanConstructions_rpc___rpc__wrapped___closed__1;
x_3 = l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanConstructions_rpc___rpc__wrapped() {
_start:
{
lean_object* x_1; 
x_1 = l_EuclideanConstructions_rpc___rpc__wrapped___closed__3;
return x_1;
}
}
static lean_object* _init_l_EuclideanConstructions___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as t,Fragment as n}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as a,EnvPosContext as o,useAsyncPersistent as c,mapRpcError as s,importWidgetModule as i}from\"@leanprover/infoview\";async function l(a,o,c){if(\"text\"in c)return t(n,{children:c.text});if(\"element\"in c){const[e,n,s]=c.element,i={};for(const[e,t]of n)i[e]=t;const u=await Promise.all(s.map((async e=>await l(a,o,e))));return\"hr\"===e\?t(\"hr\",{}):0===u.length\?r.createElement(e,i):r.createElement(e,i,u)}if(\"component\"in c){const[e,t,n,s]=c.component,u=await Promise.all(s.map((async e=>await l(a,o,e)))),m={...n,pos:o},f=await i(a,o,e);if(!(t in f))throw new Error(`Module '${e}' does not export '${t}'`);return 0===u.length\?r.createElement(f[t],m):r.createElement(f[t],m,u)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(c)]})}function u({html:i}){const u=a(),m=r.useContext(o),f=c((()=>l(u,m,i)),[u,m,i]);return\"resolved\"===f.state\?f.value:\"rejected\"===f.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",s(f.error).message]}):t(n,{})}const m=\"EuclideanConstructions.rpc\",f='false';var d=r.memo((e=>{const o=a(),i=r.useRef({fn:()=>{}}),l=c((async()=>{if(\"true\"===f){i.current.fn();const[t,n]=function(e,t,n){const r={fn:()=>{}};return[new Promise((async(a,o)=>{const c=await e.call(t,n),s=window.setInterval((async()=>{try{const t=await e.call(\"ProofWidgets.checkRequest\",c);if(\"running\"===t)return;window.clearInterval(s),a(t.done.result)}catch(e){window.clearInterval(s),o(e)}}),100);r.fn=()=>{e.call(\"ProofWidgets.cancelRequest\",c)}})),r]}(o,m,e);return i.current=n,t}return o.call(m,e)}),[o,e]);return r.useEffect((()=>()=>{i.current.fn()}),[]),\"rejected\"===l.state\?t(\"p\",{style:{color:\"red\"},children:s(l.error).message}):\"loading\"===l.state\?t(n,{children:\"Loading..\"}):t(u,{html:l.value})}));export{d as default};", 1886, 1886);
return x_1;
}
}
static uint64_t _init_l_EuclideanConstructions___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_EuclideanConstructions___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanConstructions___closed__2___boxed__const__1() {
_start:
{
uint64_t x_1; lean_object* x_2; 
x_1 = l_EuclideanConstructions___closed__1;
x_2 = lean_box_uint64(x_1);
return x_2;
}
}
static lean_object* _init_l_EuclideanConstructions___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanConstructions___closed__0;
x_2 = l_EuclideanConstructions___closed__2___boxed__const__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_EuclideanConstructions___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_EuclideanDisplay___closed__3;
x_2 = l_EuclideanConstructions___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_EuclideanConstructions() {
_start:
{
lean_object* x_1; 
x_1 = l_EuclideanConstructions___closed__3;
return x_1;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Elab_Tactic(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_PenroseDiagram(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_HtmlDisplay(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Panel_Basic(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_OfRpcMethod(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_MakeEditLink(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Demos_Euclidean(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Elab_Tactic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_PenroseDiagram(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_HtmlDisplay(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Panel_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_OfRpcMethod(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_MakeEditLink(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_isBetweenPred_x3f___closed__0 = _init_l_isBetweenPred_x3f___closed__0();
lean_mark_persistent(l_isBetweenPred_x3f___closed__0);
l_isBetweenPred_x3f___closed__1 = _init_l_isBetweenPred_x3f___closed__1();
lean_mark_persistent(l_isBetweenPred_x3f___closed__1);
l_isBetweenPred_x3f___closed__2 = _init_l_isBetweenPred_x3f___closed__2();
lean_mark_persistent(l_isBetweenPred_x3f___closed__2);
l_isOnLinePred_x3f___closed__0 = _init_l_isOnLinePred_x3f___closed__0();
lean_mark_persistent(l_isOnLinePred_x3f___closed__0);
l_isOnLinePred_x3f___closed__1 = _init_l_isOnLinePred_x3f___closed__1();
lean_mark_persistent(l_isOnLinePred_x3f___closed__1);
l_isOnCirclePred_x3f___closed__0 = _init_l_isOnCirclePred_x3f___closed__0();
lean_mark_persistent(l_isOnCirclePred_x3f___closed__0);
l_isOnCirclePred_x3f___closed__1 = _init_l_isOnCirclePred_x3f___closed__1();
lean_mark_persistent(l_isOnCirclePred_x3f___closed__1);
l_isInCirclePred_x3f___closed__0 = _init_l_isInCirclePred_x3f___closed__0();
lean_mark_persistent(l_isInCirclePred_x3f___closed__0);
l_isInCirclePred_x3f___closed__1 = _init_l_isInCirclePred_x3f___closed__1();
lean_mark_persistent(l_isInCirclePred_x3f___closed__1);
l_isCenterCirclePred_x3f___closed__0 = _init_l_isCenterCirclePred_x3f___closed__0();
lean_mark_persistent(l_isCenterCirclePred_x3f___closed__0);
l_isCenterCirclePred_x3f___closed__1 = _init_l_isCenterCirclePred_x3f___closed__1();
lean_mark_persistent(l_isCenterCirclePred_x3f___closed__1);
l_isCirclesInterPred_x3f___closed__0 = _init_l_isCirclesInterPred_x3f___closed__0();
lean_mark_persistent(l_isCirclesInterPred_x3f___closed__0);
l_isCirclesInterPred_x3f___closed__1 = _init_l_isCirclesInterPred_x3f___closed__1();
lean_mark_persistent(l_isCirclesInterPred_x3f___closed__1);
l_isPoint_x3f___closed__0 = _init_l_isPoint_x3f___closed__0();
lean_mark_persistent(l_isPoint_x3f___closed__0);
l_isPoint_x3f___closed__1 = _init_l_isPoint_x3f___closed__1();
lean_mark_persistent(l_isPoint_x3f___closed__1);
l_isLine_x3f___closed__0 = _init_l_isLine_x3f___closed__0();
lean_mark_persistent(l_isLine_x3f___closed__0);
l_isLine_x3f___closed__1 = _init_l_isLine_x3f___closed__1();
lean_mark_persistent(l_isLine_x3f___closed__1);
l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0 = _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__0);
l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__1 = _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__1();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__1);
l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2 = _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__2);
l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3 = _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__3);
l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__4 = _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__4();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__4);
l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__5 = _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__5();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__5);
l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__6 = _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__6();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__6);
l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__7 = _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__7();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__7);
l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__8 = _init_l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__8();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___addHypotheses_spec__1___closed__8);
l_EuclideanDisplay_dsl___closed__0 = _init_l_EuclideanDisplay_dsl___closed__0();
lean_mark_persistent(l_EuclideanDisplay_dsl___closed__0);
l_EuclideanDisplay_dsl = _init_l_EuclideanDisplay_dsl();
lean_mark_persistent(l_EuclideanDisplay_dsl);
l_EuclideanDisplay_sty___closed__0 = _init_l_EuclideanDisplay_sty___closed__0();
lean_mark_persistent(l_EuclideanDisplay_sty___closed__0);
l_EuclideanDisplay_sty = _init_l_EuclideanDisplay_sty();
lean_mark_persistent(l_EuclideanDisplay_sty);
l_panic___at___EuclideanDisplay_rpc_spec__0___closed__0 = _init_l_panic___at___EuclideanDisplay_rpc_spec__0___closed__0();
lean_mark_persistent(l_panic___at___EuclideanDisplay_rpc_spec__0___closed__0);
l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___closed__0 = _init_l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___closed__0();
lean_mark_persistent(l_Array_filterMapM___at___EuclideanDisplay_rpc_spec__2___closed__0);
l_EuclideanDisplay_rpc___lam__0___closed__0 = _init_l_EuclideanDisplay_rpc___lam__0___closed__0();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__0___closed__0);
l_EuclideanDisplay_rpc___lam__0___closed__1 = _init_l_EuclideanDisplay_rpc___lam__0___closed__1();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__0___closed__1);
l_EuclideanDisplay_rpc___lam__0___closed__2 = _init_l_EuclideanDisplay_rpc___lam__0___closed__2();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__0___closed__2);
l_EuclideanDisplay_rpc___lam__0___closed__3 = _init_l_EuclideanDisplay_rpc___lam__0___closed__3();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__0___closed__3);
l_EuclideanDisplay_rpc___lam__0___closed__4 = _init_l_EuclideanDisplay_rpc___lam__0___closed__4();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__0___closed__4);
l_EuclideanDisplay_rpc___lam__2___boxed__const__1 = _init_l_EuclideanDisplay_rpc___lam__2___boxed__const__1();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__2___boxed__const__1);
l_EuclideanDisplay_rpc___lam__3___closed__0 = _init_l_EuclideanDisplay_rpc___lam__3___closed__0();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__0);
l_EuclideanDisplay_rpc___lam__3___closed__1 = _init_l_EuclideanDisplay_rpc___lam__3___closed__1();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__1);
l_EuclideanDisplay_rpc___lam__3___closed__2 = _init_l_EuclideanDisplay_rpc___lam__3___closed__2();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__2);
l_EuclideanDisplay_rpc___lam__3___closed__3 = _init_l_EuclideanDisplay_rpc___lam__3___closed__3();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__3);
l_EuclideanDisplay_rpc___lam__3___closed__4 = _init_l_EuclideanDisplay_rpc___lam__3___closed__4();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__4);
l_EuclideanDisplay_rpc___lam__3___closed__5 = _init_l_EuclideanDisplay_rpc___lam__3___closed__5();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__5);
l_EuclideanDisplay_rpc___lam__3___closed__6 = _init_l_EuclideanDisplay_rpc___lam__3___closed__6();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__6);
l_EuclideanDisplay_rpc___lam__3___closed__7 = _init_l_EuclideanDisplay_rpc___lam__3___closed__7();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__7);
l_EuclideanDisplay_rpc___lam__3___closed__8 = _init_l_EuclideanDisplay_rpc___lam__3___closed__8();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__8);
l_EuclideanDisplay_rpc___lam__3___closed__9 = _init_l_EuclideanDisplay_rpc___lam__3___closed__9();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__9);
l_EuclideanDisplay_rpc___lam__3___closed__10 = _init_l_EuclideanDisplay_rpc___lam__3___closed__10();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__10);
l_EuclideanDisplay_rpc___lam__3___closed__11 = _init_l_EuclideanDisplay_rpc___lam__3___closed__11();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__11);
l_EuclideanDisplay_rpc___lam__3___closed__12 = _init_l_EuclideanDisplay_rpc___lam__3___closed__12();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__12);
l_EuclideanDisplay_rpc___lam__3___closed__13 = _init_l_EuclideanDisplay_rpc___lam__3___closed__13();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__13);
l_EuclideanDisplay_rpc___lam__3___closed__14 = _init_l_EuclideanDisplay_rpc___lam__3___closed__14();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__14);
l_EuclideanDisplay_rpc___lam__3___closed__15 = _init_l_EuclideanDisplay_rpc___lam__3___closed__15();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__15);
l_EuclideanDisplay_rpc___lam__3___closed__16 = _init_l_EuclideanDisplay_rpc___lam__3___closed__16();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__16);
l_EuclideanDisplay_rpc___lam__3___closed__17 = _init_l_EuclideanDisplay_rpc___lam__3___closed__17();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__17);
l_EuclideanDisplay_rpc___lam__3___closed__18 = _init_l_EuclideanDisplay_rpc___lam__3___closed__18();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__18);
l_EuclideanDisplay_rpc___lam__3___closed__19 = _init_l_EuclideanDisplay_rpc___lam__3___closed__19();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__19);
l_EuclideanDisplay_rpc___lam__3___closed__20 = _init_l_EuclideanDisplay_rpc___lam__3___closed__20();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__20);
l_EuclideanDisplay_rpc___lam__3___closed__21 = _init_l_EuclideanDisplay_rpc___lam__3___closed__21();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__21);
l_EuclideanDisplay_rpc___lam__3___closed__22 = _init_l_EuclideanDisplay_rpc___lam__3___closed__22();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__22);
l_EuclideanDisplay_rpc___lam__3___closed__23 = _init_l_EuclideanDisplay_rpc___lam__3___closed__23();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__23);
l_EuclideanDisplay_rpc___lam__3___closed__24 = _init_l_EuclideanDisplay_rpc___lam__3___closed__24();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__24);
l_EuclideanDisplay_rpc___lam__3___closed__25 = _init_l_EuclideanDisplay_rpc___lam__3___closed__25();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__25);
l_EuclideanDisplay_rpc___lam__3___closed__26 = _init_l_EuclideanDisplay_rpc___lam__3___closed__26();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__26);
l_EuclideanDisplay_rpc___lam__3___closed__27 = _init_l_EuclideanDisplay_rpc___lam__3___closed__27();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__27);
l_EuclideanDisplay_rpc___lam__3___closed__28 = _init_l_EuclideanDisplay_rpc___lam__3___closed__28();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__28);
l_EuclideanDisplay_rpc___lam__3___closed__29 = _init_l_EuclideanDisplay_rpc___lam__3___closed__29();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__29);
l_EuclideanDisplay_rpc___lam__3___closed__30 = _init_l_EuclideanDisplay_rpc___lam__3___closed__30();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__30);
l_EuclideanDisplay_rpc___lam__3___closed__31 = _init_l_EuclideanDisplay_rpc___lam__3___closed__31();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__31);
l_EuclideanDisplay_rpc___lam__3___closed__32 = _init_l_EuclideanDisplay_rpc___lam__3___closed__32();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__32);
l_EuclideanDisplay_rpc___lam__3___closed__33 = _init_l_EuclideanDisplay_rpc___lam__3___closed__33();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__33);
l_EuclideanDisplay_rpc___lam__3___closed__34 = _init_l_EuclideanDisplay_rpc___lam__3___closed__34();
lean_mark_persistent(l_EuclideanDisplay_rpc___lam__3___closed__34);
l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__0 = _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__0();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__0);
l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__1 = _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__1();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__1);
l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__2 = _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__2();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__2);
l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__3 = _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__3();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__3);
l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__4 = _init_l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__4();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___EuclideanDisplay_rpc___rpc__wrapped_spec__0___lam__4___closed__4);
l_EuclideanDisplay_rpc___rpc__wrapped___closed__0 = _init_l_EuclideanDisplay_rpc___rpc__wrapped___closed__0();
lean_mark_persistent(l_EuclideanDisplay_rpc___rpc__wrapped___closed__0);
l_EuclideanDisplay_rpc___rpc__wrapped___closed__1 = _init_l_EuclideanDisplay_rpc___rpc__wrapped___closed__1();
lean_mark_persistent(l_EuclideanDisplay_rpc___rpc__wrapped___closed__1);
l_EuclideanDisplay_rpc___rpc__wrapped___closed__2 = _init_l_EuclideanDisplay_rpc___rpc__wrapped___closed__2();
lean_mark_persistent(l_EuclideanDisplay_rpc___rpc__wrapped___closed__2);
l_EuclideanDisplay_rpc___rpc__wrapped___closed__3 = _init_l_EuclideanDisplay_rpc___rpc__wrapped___closed__3();
lean_mark_persistent(l_EuclideanDisplay_rpc___rpc__wrapped___closed__3);
l_EuclideanDisplay_rpc___rpc__wrapped = _init_l_EuclideanDisplay_rpc___rpc__wrapped();
lean_mark_persistent(l_EuclideanDisplay_rpc___rpc__wrapped);
l_EuclideanDisplay___closed__0 = _init_l_EuclideanDisplay___closed__0();
lean_mark_persistent(l_EuclideanDisplay___closed__0);
l_EuclideanDisplay___closed__1 = _init_l_EuclideanDisplay___closed__1();
l_EuclideanDisplay___closed__2___boxed__const__1 = _init_l_EuclideanDisplay___closed__2___boxed__const__1();
lean_mark_persistent(l_EuclideanDisplay___closed__2___boxed__const__1);
l_EuclideanDisplay___closed__2 = _init_l_EuclideanDisplay___closed__2();
lean_mark_persistent(l_EuclideanDisplay___closed__2);
l_EuclideanDisplay___closed__3 = _init_l_EuclideanDisplay___closed__3();
lean_mark_persistent(l_EuclideanDisplay___closed__3);
l_EuclideanDisplay___closed__4 = _init_l_EuclideanDisplay___closed__4();
lean_mark_persistent(l_EuclideanDisplay___closed__4);
l_EuclideanDisplay = _init_l_EuclideanDisplay();
lean_mark_persistent(l_EuclideanDisplay);
l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__0 = _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__0();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__0);
l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__1 = _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__1();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__1);
l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__2 = _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__2();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__2);
l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__3 = _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__3();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__3);
l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__4 = _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__4();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__4);
l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__5 = _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__5();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___constructLines_spec__2___redArg___closed__5);
l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__0 = _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__0();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__0);
l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__1 = _init_l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__1();
lean_mark_persistent(l_Std_Range_forIn_x27_loop___at___constructLines_spec__5___redArg___closed__1);
l_constructLines___lam__0___closed__0 = _init_l_constructLines___lam__0___closed__0();
lean_mark_persistent(l_constructLines___lam__0___closed__0);
l_constructLines___lam__0___closed__1 = _init_l_constructLines___lam__0___closed__1();
lean_mark_persistent(l_constructLines___lam__0___closed__1);
l_constructLines___lam__0___closed__2 = _init_l_constructLines___lam__0___closed__2();
lean_mark_persistent(l_constructLines___lam__0___closed__2);
l_constructLines___lam__0___closed__3 = _init_l_constructLines___lam__0___closed__3();
lean_mark_persistent(l_constructLines___lam__0___closed__3);
l_constructLines___lam__0___closed__4 = _init_l_constructLines___lam__0___closed__4();
lean_mark_persistent(l_constructLines___lam__0___closed__4);
l_constructLines___lam__0___closed__5 = _init_l_constructLines___lam__0___closed__5();
lean_mark_persistent(l_constructLines___lam__0___closed__5);
l_constructLines___lam__0___closed__6 = _init_l_constructLines___lam__0___closed__6();
lean_mark_persistent(l_constructLines___lam__0___closed__6);
l_constructLines___lam__0___closed__7 = _init_l_constructLines___lam__0___closed__7();
lean_mark_persistent(l_constructLines___lam__0___closed__7);
l_constructLines___lam__0___closed__8 = _init_l_constructLines___lam__0___closed__8();
lean_mark_persistent(l_constructLines___lam__0___closed__8);
l_constructLines___closed__0 = _init_l_constructLines___closed__0();
lean_mark_persistent(l_constructLines___closed__0);
l_constructLines___closed__1 = _init_l_constructLines___closed__1();
lean_mark_persistent(l_constructLines___closed__1);
l_constructLines___closed__2 = _init_l_constructLines___closed__2();
lean_mark_persistent(l_constructLines___closed__2);
l_EuclideanConstructions_rpc___lam__3___closed__0 = _init_l_EuclideanConstructions_rpc___lam__3___closed__0();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__0);
l_EuclideanConstructions_rpc___lam__3___closed__1 = _init_l_EuclideanConstructions_rpc___lam__3___closed__1();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__1);
l_EuclideanConstructions_rpc___lam__3___closed__2 = _init_l_EuclideanConstructions_rpc___lam__3___closed__2();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__2);
l_EuclideanConstructions_rpc___lam__3___closed__3 = _init_l_EuclideanConstructions_rpc___lam__3___closed__3();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__3);
l_EuclideanConstructions_rpc___lam__3___closed__4 = _init_l_EuclideanConstructions_rpc___lam__3___closed__4();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__4);
l_EuclideanConstructions_rpc___lam__3___closed__5 = _init_l_EuclideanConstructions_rpc___lam__3___closed__5();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__5);
l_EuclideanConstructions_rpc___lam__3___closed__6 = _init_l_EuclideanConstructions_rpc___lam__3___closed__6();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__6);
l_EuclideanConstructions_rpc___lam__3___closed__7 = _init_l_EuclideanConstructions_rpc___lam__3___closed__7();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__7);
l_EuclideanConstructions_rpc___lam__3___closed__8 = _init_l_EuclideanConstructions_rpc___lam__3___closed__8();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__8);
l_EuclideanConstructions_rpc___lam__3___closed__9 = _init_l_EuclideanConstructions_rpc___lam__3___closed__9();
lean_mark_persistent(l_EuclideanConstructions_rpc___lam__3___closed__9);
l_EuclideanConstructions_rpc___rpc__wrapped___closed__0 = _init_l_EuclideanConstructions_rpc___rpc__wrapped___closed__0();
lean_mark_persistent(l_EuclideanConstructions_rpc___rpc__wrapped___closed__0);
l_EuclideanConstructions_rpc___rpc__wrapped___closed__1 = _init_l_EuclideanConstructions_rpc___rpc__wrapped___closed__1();
lean_mark_persistent(l_EuclideanConstructions_rpc___rpc__wrapped___closed__1);
l_EuclideanConstructions_rpc___rpc__wrapped___closed__2 = _init_l_EuclideanConstructions_rpc___rpc__wrapped___closed__2();
lean_mark_persistent(l_EuclideanConstructions_rpc___rpc__wrapped___closed__2);
l_EuclideanConstructions_rpc___rpc__wrapped___closed__3 = _init_l_EuclideanConstructions_rpc___rpc__wrapped___closed__3();
lean_mark_persistent(l_EuclideanConstructions_rpc___rpc__wrapped___closed__3);
l_EuclideanConstructions_rpc___rpc__wrapped = _init_l_EuclideanConstructions_rpc___rpc__wrapped();
lean_mark_persistent(l_EuclideanConstructions_rpc___rpc__wrapped);
l_EuclideanConstructions___closed__0 = _init_l_EuclideanConstructions___closed__0();
lean_mark_persistent(l_EuclideanConstructions___closed__0);
l_EuclideanConstructions___closed__1 = _init_l_EuclideanConstructions___closed__1();
l_EuclideanConstructions___closed__2___boxed__const__1 = _init_l_EuclideanConstructions___closed__2___boxed__const__1();
lean_mark_persistent(l_EuclideanConstructions___closed__2___boxed__const__1);
l_EuclideanConstructions___closed__2 = _init_l_EuclideanConstructions___closed__2();
lean_mark_persistent(l_EuclideanConstructions___closed__2);
l_EuclideanConstructions___closed__3 = _init_l_EuclideanConstructions___closed__3();
lean_mark_persistent(l_EuclideanConstructions___closed__3);
l_EuclideanConstructions = _init_l_EuclideanConstructions();
lean_mark_persistent(l_EuclideanConstructions);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
