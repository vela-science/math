// Lean compiler output
// Module: ProofWidgets.Presentation.Expr
// Imports: Init ProofWidgets.Data.Html
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_enc____x40_ProofWidgets_Presentation_Expr___hyg_200____boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__1;
lean_object* l_Lean_Expr_const___override(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_exprPresenters;
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
lean_object* l_Lean_Name_fromJson_x3f(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_718_;
lean_object* l_Lean_Json_mkObj(lean_object*);
lean_object* l_Lean_PersistentEnvExtension_getState___redArg(lean_object*, lean_object*, lean_object*, uint8_t);
lean_object* l_Lean_ConstantInfo_type(lean_object*);
static lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_528_;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_234_(lean_object*);
static lean_object* l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData_dec____x40_ProofWidgets_Presentation_Expr___hyg_459____boxed(lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_352_;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_721_(lean_object*);
lean_object* l_Lean_Name_toString(lean_object*, uint8_t, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_718_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData_enc____x40_ProofWidgets_Presentation_Expr___hyg_459_(lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_;
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_42____boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps_enc____x40_ProofWidgets_Presentation_Expr___hyg_2068_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__1;
lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1927_;
uint64_t lean_string_hash(lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_;
lean_object* l_Lean_stringToMessageData(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Presentation_Expr___hyg_42_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1073_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_dec____x40_ProofWidgets_Presentation_Expr___hyg_200_(lean_object*, lean_object*);
lean_object* l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_784_;
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_evalExprPresenterUnsafe___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__0;
lean_object* l_Lean_Json_getStr_x3f(lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__3;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_ProofWidgets_instRpcEncodableExprPresentationData_enc___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_459_(lean_object*);
static lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__2;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__2;
static lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_993_;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1875_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Presentation_Expr___hyg_42_;
static lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__2;
lean_object* lean_st_ref_take(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_;
lean_object* l_Lean_Environment_evalConstCheck___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2102_(lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__1;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_;
lean_object* l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentations;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1111_;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2185_(lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableExprPresentations___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_internalError(lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0(size_t, size_t, lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__0;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0___redArg(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Presentation_Expr___hyg_42_;
lean_object* lean_st_ref_get(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationParams_dec____x40_ProofWidgets_Presentation_Expr___hyg_1688_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_evalExprPresenterUnsafe(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_993_(lean_object*);
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1111_;
static uint64_t l_ProofWidgets_ExprPresentation___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps_enc____x40_ProofWidgets_Presentation_Expr___hyg_2068____boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__1;
extern lean_object* l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_528_;
LEAN_EXPORT lean_object* l_ProofWidgets_ExprPresentation___closed__2___boxed__const__1;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__1___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData_dec____x40_ProofWidgets_Presentation_Expr___hyg_459_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ExprPresentation___closed__4;
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_314_;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__1;
lean_object* l_Lean_registerTagAttribute(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t, uint8_t, lean_object*);
lean_object* l_ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ExprPresentation___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1875_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Presentation_Expr___hyg_42_;
lean_object* l_Lean_MessageData_ofExpr(lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1076_(lean_object*);
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2182_;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_314_;
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations___rpc__wrapped;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ExprPresentation___closed__0;
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1073_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData_enc___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_459____boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_317_(lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_528_(lean_object*);
static lean_object* l_ProofWidgets_getExprPresentations___closed__1;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__2;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1740_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationParams_enc____x40_ProofWidgets_Presentation_Expr___hyg_1688_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1927_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2182_;
static lean_object* l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* l_Lean_Environment_getModuleIdx_x3f(lean_object*, lean_object*);
lean_object* l_Lean_Environment_allImportedModuleNames(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2220_;
static lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0;
static lean_object* l_ProofWidgets_instRpcEncodableExprPresentations___closed__0;
uint8_t l_Lean_Expr_isConstOf(lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_;
static lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData___closed__1;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_getExprPresentations___closed__0;
static lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationParams;
static lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData___closed__0;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Presentation_Expr___hyg_42_;
static lean_object* l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959____boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1878_(lean_object*);
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_784_;
static lean_object* l_ProofWidgets_ExprPresentation___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps_dec____x40_ProofWidgets_Presentation_Expr___hyg_2068_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_enc____x40_ProofWidgets_Presentation_Expr___hyg_200_(lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* l_Lean_RBNode_find___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget___hyg_204__spec__0___redArg(lean_object*, uint64_t);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_721____boxed(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959_(lean_object*, lean_object*);
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_array_size(lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0(size_t, size_t, lean_object*, lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableExprPresentations___closed__2;
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_throwUnknownIdentifierAt___at___Lean_throwUnknownConstantAt___at___Lean_filterFieldList___at___Lean_realizeGlobalConstCore_spec__0_spec__2_spec__2_spec__2_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_352_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__0(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
static lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__0;
lean_object* l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(lean_object*, lean_object*);
lean_object* l_Lean_PersistentEnvExtension_getModuleEntries___redArg(lean_object*, lean_object*, lean_object*, lean_object*, uint8_t);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__2;
static lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_;
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_42_(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_;
static lean_object* l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_;
lean_object* l_Lean_getConstInfo___at_____private_Lean_Compiler_InlineAttrs_0__Lean_Compiler_isValidMacroInline_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_;
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ExprPresentation;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Presentation_Expr___hyg_42_;
lean_object* l_Lean_instantiateMVars___at_____private_Lean_Meta_Basic_0__Lean_Meta_mkLevelErrorMessageCore_spec__1___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Presentation_Expr___hyg_42_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Presentation_Expr___hyg_42_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Presentation_Expr___hyg_42_;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2220_;
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ExprPresenter", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_2 = l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("type mismatch, expected ", 24, 24);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_3 = l_Lean_Expr_const___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_2 = l_Lean_MessageData_ofExpr(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_2 = l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" but got ", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_2 = l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("", 0, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_42_(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Lean_getConstInfo___at_____private_Lean_Compiler_InlineAttrs_0__Lean_Compiler_isValidMacroInline_spec__0(x_1, x_2, x_3, x_4);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_6; 
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; uint8_t x_11; 
x_7 = lean_ctor_get(x_5, 0);
x_8 = lean_ctor_get(x_5, 1);
x_9 = l_Lean_ConstantInfo_type(x_7);
lean_dec(x_7);
x_10 = l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_11 = l_Lean_Expr_isConstOf(x_9, x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
lean_free_object(x_5);
x_12 = l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_13 = l_Lean_MessageData_ofExpr(x_9);
x_14 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_14, 0, x_12);
lean_ctor_set(x_14, 1, x_13);
x_15 = l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_16 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_16, 0, x_14);
lean_ctor_set(x_16, 1, x_15);
x_17 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_throwUnknownIdentifierAt___at___Lean_throwUnknownConstantAt___at___Lean_filterFieldList___at___Lean_realizeGlobalConstCore_spec__0_spec__2_spec__2_spec__2_spec__2___redArg(x_16, x_2, x_3, x_8);
return x_17;
}
else
{
lean_object* x_18; 
lean_dec(x_9);
x_18 = lean_box(0);
lean_ctor_set(x_5, 0, x_18);
return x_5;
}
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; uint8_t x_23; 
x_19 = lean_ctor_get(x_5, 0);
x_20 = lean_ctor_get(x_5, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_5);
x_21 = l_Lean_ConstantInfo_type(x_19);
lean_dec(x_19);
x_22 = l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_23 = l_Lean_Expr_isConstOf(x_21, x_22);
if (x_23 == 0)
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_24 = l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_25 = l_Lean_MessageData_ofExpr(x_21);
x_26 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_26, 0, x_24);
lean_ctor_set(x_26, 1, x_25);
x_27 = l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_28 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_28, 0, x_26);
lean_ctor_set(x_28, 1, x_27);
x_29 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_throwUnknownIdentifierAt___at___Lean_throwUnknownConstantAt___at___Lean_filterFieldList___at___Lean_realizeGlobalConstCore_spec__0_spec__2_spec__2_spec__2_spec__2___redArg(x_28, x_2, x_3, x_20);
return x_29;
}
else
{
lean_object* x_30; lean_object* x_31; 
lean_dec(x_21);
x_30 = lean_box(0);
x_31 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_31, 0, x_30);
lean_ctor_set(x_31, 1, x_20);
return x_31;
}
}
}
else
{
uint8_t x_32; 
x_32 = !lean_is_exclusive(x_5);
if (x_32 == 0)
{
return x_5;
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_5, 0);
x_34 = lean_ctor_get(x_5, 1);
lean_inc(x_34);
lean_inc(x_33);
lean_dec(x_5);
x_35 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_35, 0, x_33);
lean_ctor_set(x_35, 1, x_34);
return x_35;
}
}
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expr_presenter", 14, 14);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Register an Expr presenter. It must have the type `ProofWidgets.ExprPresenter`.", 79, 79);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("exprPresenters", 14, 14);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_2 = l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Presentation_Expr___hyg_42_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint8_t x_8; uint8_t x_9; lean_object* x_10; 
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_42____boxed), 4, 0);
x_3 = l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_4 = l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_5 = l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_6 = lean_box(0);
x_7 = lean_box(2);
x_8 = lean_unbox(x_6);
x_9 = lean_unbox(x_7);
x_10 = l_Lean_registerTagAttribute(x_3, x_4, x_2, x_5, x_8, x_9, x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_42____boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_42_(x_1, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_5;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_evalExprPresenterUnsafe(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; 
x_4 = l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_5 = l_Lean_Environment_evalConstCheck___redArg(x_1, x_2, x_4, x_3);
return x_5;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_evalExprPresenterUnsafe___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_evalExprPresenterUnsafe(x_1, x_2, x_3);
lean_dec(x_2);
return x_4;
}
}
static lean_object* _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expr", 4, 4);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_234_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_;
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_314_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_234_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_314_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_314_;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_317_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_2 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_;
x_9 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_7, x_8);
x_10 = l_Lean_Json_mkObj(x_9);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_352_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_317_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_352_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_352_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_enc____x40_ProofWidgets_Presentation_Expr___hyg_200_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_4 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_3, x_1, x_2);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_317_(x_6);
lean_ctor_set(x_4, 0, x_7);
return x_4;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_4, 0);
x_9 = lean_ctor_get(x_4, 1);
lean_inc(x_9);
lean_inc(x_8);
lean_dec(x_4);
x_10 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_317_(x_8);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_9);
return x_11;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_enc____x40_ProofWidgets_Presentation_Expr___hyg_200____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_enc____x40_ProofWidgets_Presentation_Expr___hyg_200_(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_dec____x40_ProofWidgets_Presentation_Expr___hyg_200_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_234_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_6 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_5, x_4, x_2);
if (lean_obj_tag(x_6) == 0)
{
uint8_t x_7; 
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
return x_6;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
lean_inc(x_8);
lean_dec(x_6);
x_9 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_9, 0, x_8);
return x_9;
}
}
else
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_6);
if (x_10 == 0)
{
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_6, 0);
lean_inc(x_11);
lean_dec(x_6);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_enc____x40_ProofWidgets_Presentation_Expr___hyg_200____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_dec____x40_ProofWidgets_Presentation_Expr___hyg_200_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGetExprPresentationsParams() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__2;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("name", 4, 4);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_528_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("userName", 8, 8);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_528_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("html", 4, 4);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_528_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_2 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_;
lean_inc(x_1);
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_528_;
lean_inc(x_1);
x_6 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_5);
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
lean_dec(x_6);
x_8 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_528_;
x_9 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_8);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_12, 0, x_4);
lean_ctor_set(x_12, 1, x_7);
lean_ctor_set(x_12, 2, x_11);
lean_ctor_set(x_9, 0, x_12);
return x_9;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_13 = lean_ctor_get(x_9, 0);
lean_inc(x_13);
lean_dec(x_9);
x_14 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_14, 0, x_4);
lean_ctor_set(x_14, 1, x_7);
lean_ctor_set(x_14, 2, x_13);
x_15 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_15, 0, x_14);
return x_15;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_718_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_528_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_718_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_718_;
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_721_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_2 = lean_ctor_get(x_1, 0);
x_3 = lean_ctor_get(x_1, 1);
x_4 = lean_ctor_get(x_1, 2);
x_5 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_;
lean_inc(x_2);
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_2);
x_7 = lean_box(0);
x_8 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_8, 0, x_6);
lean_ctor_set(x_8, 1, x_7);
x_9 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_528_;
lean_inc(x_3);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_3);
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
x_12 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_528_;
lean_inc(x_4);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_4);
x_14 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_14, 1, x_7);
x_15 = lean_box(0);
x_16 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_16, 0, x_14);
lean_ctor_set(x_16, 1, x_15);
x_17 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_17, 0, x_11);
lean_ctor_set(x_17, 1, x_16);
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_8);
lean_ctor_set(x_18, 1, x_17);
x_19 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_;
x_20 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_18, x_19);
x_21 = l_Lean_Json_mkObj(x_20);
return x_21;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_721____boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_721_(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_784_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_721____boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_784_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_784_;
return x_1;
}
}
LEAN_EXPORT uint8_t l_ProofWidgets_instRpcEncodableExprPresentationData_enc___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_459_(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = lean_box(0);
x_3 = lean_unbox(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData_enc____x40_ProofWidgets_Presentation_Expr___hyg_459_(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_1);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint8_t x_8; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_1, 2);
x_7 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(x_6, x_2);
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_9 = lean_ctor_get(x_7, 0);
x_10 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentationData_enc___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_459____boxed), 1, 0);
x_11 = lean_box(1);
x_12 = lean_unbox(x_11);
x_13 = l_Lean_Name_toString(x_4, x_12, x_10);
x_14 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_14, 0, x_13);
x_15 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_15, 0, x_5);
lean_ctor_set(x_1, 2, x_9);
lean_ctor_set(x_1, 1, x_15);
lean_ctor_set(x_1, 0, x_14);
x_16 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_721_(x_1);
lean_dec(x_1);
lean_ctor_set(x_7, 0, x_16);
return x_7;
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_17 = lean_ctor_get(x_7, 0);
x_18 = lean_ctor_get(x_7, 1);
lean_inc(x_18);
lean_inc(x_17);
lean_dec(x_7);
x_19 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentationData_enc___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_459____boxed), 1, 0);
x_20 = lean_box(1);
x_21 = lean_unbox(x_20);
x_22 = l_Lean_Name_toString(x_4, x_21, x_19);
x_23 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_23, 0, x_22);
x_24 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_24, 0, x_5);
lean_ctor_set(x_1, 2, x_17);
lean_ctor_set(x_1, 1, x_24);
lean_ctor_set(x_1, 0, x_23);
x_25 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_721_(x_1);
lean_dec(x_1);
x_26 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_26, 0, x_25);
lean_ctor_set(x_26, 1, x_18);
return x_26;
}
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; uint8_t x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_27 = lean_ctor_get(x_1, 0);
x_28 = lean_ctor_get(x_1, 1);
x_29 = lean_ctor_get(x_1, 2);
lean_inc(x_29);
lean_inc(x_28);
lean_inc(x_27);
lean_dec(x_1);
x_30 = l_ProofWidgets_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(x_29, x_2);
x_31 = lean_ctor_get(x_30, 0);
lean_inc(x_31);
x_32 = lean_ctor_get(x_30, 1);
lean_inc(x_32);
if (lean_is_exclusive(x_30)) {
 lean_ctor_release(x_30, 0);
 lean_ctor_release(x_30, 1);
 x_33 = x_30;
} else {
 lean_dec_ref(x_30);
 x_33 = lean_box(0);
}
x_34 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentationData_enc___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_459____boxed), 1, 0);
x_35 = lean_box(1);
x_36 = lean_unbox(x_35);
x_37 = l_Lean_Name_toString(x_27, x_36, x_34);
x_38 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_38, 0, x_37);
x_39 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_39, 0, x_28);
x_40 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_40, 0, x_38);
lean_ctor_set(x_40, 1, x_39);
lean_ctor_set(x_40, 2, x_31);
x_41 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_721_(x_40);
lean_dec(x_40);
if (lean_is_scalar(x_33)) {
 x_42 = lean_alloc_ctor(0, 2, 0);
} else {
 x_42 = x_33;
}
lean_ctor_set(x_42, 0, x_41);
lean_ctor_set(x_42, 1, x_32);
return x_42;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData_enc___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_459____boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_ProofWidgets_instRpcEncodableExprPresentationData_enc___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_459_(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData_dec____x40_ProofWidgets_Presentation_Expr___hyg_459_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_528_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_ctor_get(x_4, 1);
x_8 = lean_ctor_get(x_4, 2);
x_9 = l_Lean_Name_fromJson_x3f(x_6);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_free_object(x_4);
lean_dec(x_8);
lean_dec(x_7);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
return x_9;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
else
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_9, 0);
lean_inc(x_13);
lean_dec(x_9);
x_14 = l_Lean_Json_getStr_x3f(x_7);
if (lean_obj_tag(x_14) == 0)
{
uint8_t x_15; 
lean_dec(x_13);
lean_free_object(x_4);
lean_dec(x_8);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
return x_14;
}
else
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_ctor_get(x_14, 0);
lean_inc(x_16);
lean_dec(x_14);
x_17 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_17, 0, x_16);
return x_17;
}
}
else
{
lean_object* x_18; lean_object* x_19; 
x_18 = lean_ctor_get(x_14, 0);
lean_inc(x_18);
lean_dec(x_14);
x_19 = l_ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5_(x_8, x_2);
if (lean_obj_tag(x_19) == 0)
{
uint8_t x_20; 
lean_dec(x_18);
lean_dec(x_13);
lean_free_object(x_4);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
return x_19;
}
else
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_ctor_get(x_19, 0);
lean_inc(x_21);
lean_dec(x_19);
x_22 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_22, 0, x_21);
return x_22;
}
}
else
{
uint8_t x_23; 
x_23 = !lean_is_exclusive(x_19);
if (x_23 == 0)
{
lean_object* x_24; 
x_24 = lean_ctor_get(x_19, 0);
lean_ctor_set(x_4, 2, x_24);
lean_ctor_set(x_4, 1, x_18);
lean_ctor_set(x_4, 0, x_13);
lean_ctor_set(x_19, 0, x_4);
return x_19;
}
else
{
lean_object* x_25; lean_object* x_26; 
x_25 = lean_ctor_get(x_19, 0);
lean_inc(x_25);
lean_dec(x_19);
lean_ctor_set(x_4, 2, x_25);
lean_ctor_set(x_4, 1, x_18);
lean_ctor_set(x_4, 0, x_13);
x_26 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_26, 0, x_4);
return x_26;
}
}
}
}
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_27 = lean_ctor_get(x_4, 0);
x_28 = lean_ctor_get(x_4, 1);
x_29 = lean_ctor_get(x_4, 2);
lean_inc(x_29);
lean_inc(x_28);
lean_inc(x_27);
lean_dec(x_4);
x_30 = l_Lean_Name_fromJson_x3f(x_27);
if (lean_obj_tag(x_30) == 0)
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; 
lean_dec(x_29);
lean_dec(x_28);
x_31 = lean_ctor_get(x_30, 0);
lean_inc(x_31);
if (lean_is_exclusive(x_30)) {
 lean_ctor_release(x_30, 0);
 x_32 = x_30;
} else {
 lean_dec_ref(x_30);
 x_32 = lean_box(0);
}
if (lean_is_scalar(x_32)) {
 x_33 = lean_alloc_ctor(0, 1, 0);
} else {
 x_33 = x_32;
}
lean_ctor_set(x_33, 0, x_31);
return x_33;
}
else
{
lean_object* x_34; lean_object* x_35; 
x_34 = lean_ctor_get(x_30, 0);
lean_inc(x_34);
lean_dec(x_30);
x_35 = l_Lean_Json_getStr_x3f(x_28);
if (lean_obj_tag(x_35) == 0)
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; 
lean_dec(x_34);
lean_dec(x_29);
x_36 = lean_ctor_get(x_35, 0);
lean_inc(x_36);
if (lean_is_exclusive(x_35)) {
 lean_ctor_release(x_35, 0);
 x_37 = x_35;
} else {
 lean_dec_ref(x_35);
 x_37 = lean_box(0);
}
if (lean_is_scalar(x_37)) {
 x_38 = lean_alloc_ctor(0, 1, 0);
} else {
 x_38 = x_37;
}
lean_ctor_set(x_38, 0, x_36);
return x_38;
}
else
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_35, 0);
lean_inc(x_39);
lean_dec(x_35);
x_40 = l_ProofWidgets_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5_(x_29, x_2);
if (lean_obj_tag(x_40) == 0)
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_39);
lean_dec(x_34);
x_41 = lean_ctor_get(x_40, 0);
lean_inc(x_41);
if (lean_is_exclusive(x_40)) {
 lean_ctor_release(x_40, 0);
 x_42 = x_40;
} else {
 lean_dec_ref(x_40);
 x_42 = lean_box(0);
}
if (lean_is_scalar(x_42)) {
 x_43 = lean_alloc_ctor(0, 1, 0);
} else {
 x_43 = x_42;
}
lean_ctor_set(x_43, 0, x_41);
return x_43;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; 
x_44 = lean_ctor_get(x_40, 0);
lean_inc(x_44);
if (lean_is_exclusive(x_40)) {
 lean_ctor_release(x_40, 0);
 x_45 = x_40;
} else {
 lean_dec_ref(x_40);
 x_45 = lean_box(0);
}
x_46 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_46, 0, x_34);
lean_ctor_set(x_46, 1, x_39);
lean_ctor_set(x_46, 2, x_44);
if (lean_is_scalar(x_45)) {
 x_47 = lean_alloc_ctor(1, 1, 0);
} else {
 x_47 = x_45;
}
lean_ctor_set(x_47, 0, x_46);
return x_47;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationData_dec____x40_ProofWidgets_Presentation_Expr___hyg_459____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableExprPresentationData_dec____x40_ProofWidgets_Presentation_Expr___hyg_459_(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentationData___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentationData_enc____x40_ProofWidgets_Presentation_Expr___hyg_459_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentationData___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentationData_dec____x40_ProofWidgets_Presentation_Expr___hyg_459____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentationData___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableExprPresentationData___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableExprPresentationData___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentationData() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableExprPresentationData___closed__2;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_993_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("presentations", 13, 13);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_993_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_993_;
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1073_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_993_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1073_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1073_;
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1076_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_2 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_993_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_;
x_9 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_7, x_8);
x_10 = l_Lean_Json_mkObj(x_9);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1111_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1076_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1111_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1111_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_lt(x_2, x_1);
if (x_5 == 0)
{
lean_object* x_6; 
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_3);
lean_ctor_set(x_6, 1, x_4);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; size_t x_13; size_t x_14; lean_object* x_15; 
x_7 = lean_array_uget(x_3, x_2);
x_8 = l_ProofWidgets_instRpcEncodableExprPresentationData_enc____x40_ProofWidgets_Presentation_Expr___hyg_459_(x_7, x_4);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_box(0);
x_12 = lean_array_uset(x_3, x_2, x_11);
x_13 = 1;
x_14 = lean_usize_add(x_2, x_13);
x_15 = lean_array_uset(x_12, x_2, x_9);
x_2 = x_14;
x_3 = x_15;
x_4 = x_10;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959_(lean_object* x_1, lean_object* x_2) {
_start:
{
size_t x_3; size_t x_4; lean_object* x_5; uint8_t x_6; 
x_3 = lean_array_size(x_1);
x_4 = 0;
x_5 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0(x_3, x_4, x_1, x_2);
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_7 = lean_ctor_get(x_5, 0);
x_8 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_7);
x_9 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1076_(x_8);
lean_ctor_set(x_5, 0, x_9);
return x_5;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_10 = lean_ctor_get(x_5, 0);
x_11 = lean_ctor_get(x_5, 1);
lean_inc(x_11);
lean_inc(x_10);
lean_dec(x_5);
x_12 = l_Array_toJson___at___Lean_Json_opt___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1586__spec__0_spec__0(x_10);
x_13 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1076_(x_12);
x_14 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_14, 1, x_11);
return x_14;
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0(x_5, x_6, x_3, x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_lt(x_2, x_1);
if (x_5 == 0)
{
lean_object* x_6; 
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_3);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; 
x_7 = lean_array_uget(x_3, x_2);
x_8 = l_ProofWidgets_instRpcEncodableExprPresentationData_dec____x40_ProofWidgets_Presentation_Expr___hyg_459_(x_7, x_4);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
lean_dec(x_3);
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
return x_8;
}
else
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_ctor_get(x_8, 0);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
return x_11;
}
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; size_t x_15; size_t x_16; lean_object* x_17; 
x_12 = lean_ctor_get(x_8, 0);
lean_inc(x_12);
lean_dec(x_8);
x_13 = lean_box(0);
x_14 = lean_array_uset(x_3, x_2, x_13);
x_15 = 1;
x_16 = lean_usize_add(x_2, x_15);
x_17 = lean_array_uset(x_14, x_2, x_12);
x_2 = x_16;
x_3 = x_17;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_993_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l_Array_fromJson_x3f___at___Option_fromJson_x3f___at___Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1642__spec__0_spec__0_spec__0(x_4);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_6; 
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; 
x_7 = lean_ctor_get(x_5, 0);
lean_inc(x_7);
lean_dec(x_5);
x_8 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_8, 0, x_7);
return x_8;
}
}
else
{
lean_object* x_9; size_t x_10; size_t x_11; lean_object* x_12; 
x_9 = lean_ctor_get(x_5, 0);
lean_inc(x_9);
lean_dec(x_5);
x_10 = lean_array_size(x_9);
x_11 = 0;
x_12 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0(x_10, x_11, x_9, x_2);
if (lean_obj_tag(x_12) == 0)
{
uint8_t x_13; 
x_13 = !lean_is_exclusive(x_12);
if (x_13 == 0)
{
return x_12;
}
else
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_12, 0);
lean_inc(x_14);
lean_dec(x_12);
x_15 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_15, 0, x_14);
return x_15;
}
}
else
{
uint8_t x_16; 
x_16 = !lean_is_exclusive(x_12);
if (x_16 == 0)
{
return x_12;
}
else
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_12, 0);
lean_inc(x_17);
lean_dec(x_12);
x_18 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_18, 0, x_17);
return x_18;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = l_Array_mapMUnsafe_map___at___ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959__spec__0(x_5, x_6, x_3, x_4);
lean_dec(x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959_(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentations___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentations___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentations_dec____x40_ProofWidgets_Presentation_Expr___hyg_959____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentations___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableExprPresentations___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableExprPresentations___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentations() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableExprPresentations___closed__2;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_8 = l_Lean_instantiateMVars___at_____private_Lean_Meta_Basic_0__Lean_Meta_mkLevelErrorMessageCore_spec__1___redArg(x_2, x_4, x_7);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_ctor_get(x_1, 1);
lean_inc(x_11);
lean_dec(x_1);
x_12 = lean_apply_6(x_11, x_9, x_3, x_4, x_5, x_6, x_10);
return x_12;
}
}
static lean_object* _init_l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentationData_enc___lam__0____x40_ProofWidgets_Presentation_Expr___hyg_459____boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Failed to evaluate Expr presenter '", 35, 35);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("': ", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; uint8_t x_6; 
x_5 = lean_ctor_get(x_1, 0);
lean_inc(x_5);
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_7 = lean_ctor_get(x_5, 0);
x_8 = lean_ctor_get(x_5, 1);
lean_dec(x_8);
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_7, 3);
lean_inc(x_10);
lean_dec(x_7);
lean_inc(x_2);
x_11 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_evalExprPresenterUnsafe(x_9, x_10, x_2);
lean_dec(x_10);
if (lean_obj_tag(x_11) == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
lean_dec(x_3);
lean_dec(x_1);
x_12 = lean_ctor_get(x_11, 0);
lean_inc(x_12);
lean_dec(x_11);
x_13 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0;
x_14 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__1;
x_15 = lean_box(1);
x_16 = lean_unbox(x_15);
x_17 = l_Lean_Name_toString(x_2, x_16, x_13);
x_18 = lean_string_append(x_14, x_17);
lean_dec(x_17);
x_19 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__2;
x_20 = lean_string_append(x_18, x_19);
x_21 = lean_string_append(x_20, x_12);
lean_dec(x_12);
x_22 = l_Lean_Server_RequestError_internalError(x_21);
lean_ctor_set_tag(x_5, 1);
lean_ctor_set(x_5, 1, x_4);
lean_ctor_set(x_5, 0, x_22);
return x_5;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; 
lean_free_object(x_5);
x_23 = lean_ctor_get(x_11, 0);
lean_inc(x_23);
lean_dec(x_11);
lean_inc(x_23);
x_24 = lean_alloc_closure((void*)(l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___lam__1), 7, 1);
lean_closure_set(x_24, 0, x_23);
x_25 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg(x_1, x_24, x_4);
if (lean_obj_tag(x_25) == 0)
{
uint8_t x_26; 
x_26 = !lean_is_exclusive(x_25);
if (x_26 == 0)
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_27 = lean_ctor_get(x_25, 0);
x_28 = lean_ctor_get(x_23, 0);
lean_inc(x_28);
lean_dec(x_23);
x_29 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_29, 0, x_2);
lean_ctor_set(x_29, 1, x_28);
lean_ctor_set(x_29, 2, x_27);
x_30 = lean_array_push(x_3, x_29);
lean_ctor_set(x_25, 0, x_30);
return x_25;
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_31 = lean_ctor_get(x_25, 0);
x_32 = lean_ctor_get(x_25, 1);
lean_inc(x_32);
lean_inc(x_31);
lean_dec(x_25);
x_33 = lean_ctor_get(x_23, 0);
lean_inc(x_33);
lean_dec(x_23);
x_34 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_34, 0, x_2);
lean_ctor_set(x_34, 1, x_33);
lean_ctor_set(x_34, 2, x_31);
x_35 = lean_array_push(x_3, x_34);
x_36 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_36, 0, x_35);
lean_ctor_set(x_36, 1, x_32);
return x_36;
}
}
else
{
uint8_t x_37; 
lean_dec(x_23);
lean_dec(x_2);
x_37 = !lean_is_exclusive(x_25);
if (x_37 == 0)
{
lean_object* x_38; 
x_38 = lean_ctor_get(x_25, 0);
lean_dec(x_38);
lean_ctor_set_tag(x_25, 0);
lean_ctor_set(x_25, 0, x_3);
return x_25;
}
else
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_25, 1);
lean_inc(x_39);
lean_dec(x_25);
x_40 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_40, 0, x_3);
lean_ctor_set(x_40, 1, x_39);
return x_40;
}
}
}
}
else
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_41 = lean_ctor_get(x_5, 0);
lean_inc(x_41);
lean_dec(x_5);
x_42 = lean_ctor_get(x_41, 0);
lean_inc(x_42);
x_43 = lean_ctor_get(x_41, 3);
lean_inc(x_43);
lean_dec(x_41);
lean_inc(x_2);
x_44 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_evalExprPresenterUnsafe(x_42, x_43, x_2);
lean_dec(x_43);
if (lean_obj_tag(x_44) == 0)
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; uint8_t x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
lean_dec(x_3);
lean_dec(x_1);
x_45 = lean_ctor_get(x_44, 0);
lean_inc(x_45);
lean_dec(x_44);
x_46 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0;
x_47 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__1;
x_48 = lean_box(1);
x_49 = lean_unbox(x_48);
x_50 = l_Lean_Name_toString(x_2, x_49, x_46);
x_51 = lean_string_append(x_47, x_50);
lean_dec(x_50);
x_52 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__2;
x_53 = lean_string_append(x_51, x_52);
x_54 = lean_string_append(x_53, x_45);
lean_dec(x_45);
x_55 = l_Lean_Server_RequestError_internalError(x_54);
x_56 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_56, 0, x_55);
lean_ctor_set(x_56, 1, x_4);
return x_56;
}
else
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_57 = lean_ctor_get(x_44, 0);
lean_inc(x_57);
lean_dec(x_44);
lean_inc(x_57);
x_58 = lean_alloc_closure((void*)(l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___lam__1), 7, 1);
lean_closure_set(x_58, 0, x_57);
x_59 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg(x_1, x_58, x_4);
if (lean_obj_tag(x_59) == 0)
{
lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; 
x_60 = lean_ctor_get(x_59, 0);
lean_inc(x_60);
x_61 = lean_ctor_get(x_59, 1);
lean_inc(x_61);
if (lean_is_exclusive(x_59)) {
 lean_ctor_release(x_59, 0);
 lean_ctor_release(x_59, 1);
 x_62 = x_59;
} else {
 lean_dec_ref(x_59);
 x_62 = lean_box(0);
}
x_63 = lean_ctor_get(x_57, 0);
lean_inc(x_63);
lean_dec(x_57);
x_64 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_64, 0, x_2);
lean_ctor_set(x_64, 1, x_63);
lean_ctor_set(x_64, 2, x_60);
x_65 = lean_array_push(x_3, x_64);
if (lean_is_scalar(x_62)) {
 x_66 = lean_alloc_ctor(0, 2, 0);
} else {
 x_66 = x_62;
}
lean_ctor_set(x_66, 0, x_65);
lean_ctor_set(x_66, 1, x_61);
return x_66;
}
else
{
lean_object* x_67; lean_object* x_68; lean_object* x_69; 
lean_dec(x_57);
lean_dec(x_2);
x_67 = lean_ctor_get(x_59, 1);
lean_inc(x_67);
if (lean_is_exclusive(x_59)) {
 lean_ctor_release(x_59, 0);
 lean_ctor_release(x_59, 1);
 x_68 = x_59;
} else {
 lean_dec_ref(x_59);
 x_68 = lean_box(0);
}
if (lean_is_scalar(x_68)) {
 x_69 = lean_alloc_ctor(0, 2, 0);
} else {
 x_69 = x_68;
 lean_ctor_set_tag(x_69, 0);
}
lean_ctor_set(x_69, 0, x_3);
lean_ctor_set(x_69, 1, x_67);
return x_69;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg(x_1, x_2, x_3, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0___redArg(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; 
x_7 = lean_usize_dec_lt(x_4, x_3);
if (x_7 == 0)
{
lean_object* x_8; 
lean_dec(x_1);
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_5);
lean_ctor_set(x_8, 1, x_6);
return x_8;
}
else
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_array_uget(x_2, x_4);
lean_inc(x_1);
x_10 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg(x_1, x_9, x_5, x_6);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; size_t x_13; size_t x_14; 
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = 1;
x_14 = lean_usize_add(x_4, x_13);
x_4 = x_14;
x_5 = x_11;
x_6 = x_12;
goto _start;
}
else
{
lean_dec(x_1);
return x_10;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0___redArg(x_1, x_2, x_3, x_4, x_5, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
lean_object* x_5; lean_object* x_6; 
lean_dec(x_1);
x_5 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_5, 0, x_3);
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_7 = lean_ctor_get(x_2, 0);
lean_inc(x_7);
x_8 = lean_ctor_get(x_2, 1);
lean_inc(x_8);
x_9 = lean_ctor_get(x_2, 3);
lean_inc(x_9);
lean_dec(x_2);
lean_inc(x_1);
x_10 = l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1___redArg(x_1, x_7, x_3, x_4);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; 
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
if (lean_obj_tag(x_11) == 0)
{
lean_dec(x_11);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_1);
return x_10;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_ctor_get(x_11, 0);
lean_inc(x_13);
lean_dec(x_11);
lean_inc(x_1);
x_14 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg(x_1, x_8, x_13, x_12);
if (lean_obj_tag(x_14) == 0)
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
x_16 = lean_ctor_get(x_14, 1);
lean_inc(x_16);
lean_dec(x_14);
x_2 = x_9;
x_3 = x_15;
x_4 = x_16;
goto _start;
}
else
{
uint8_t x_18; 
lean_dec(x_9);
lean_dec(x_1);
x_18 = !lean_is_exclusive(x_14);
if (x_18 == 0)
{
return x_14;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_14, 0);
x_20 = lean_ctor_get(x_14, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_14);
x_21 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_21, 0, x_19);
lean_ctor_set(x_21, 1, x_20);
return x_21;
}
}
}
}
else
{
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_1);
return x_10;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1___redArg(x_1, x_2, x_3, x_5);
return x_6;
}
}
static lean_object* _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("unknown module ", 15, 15);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, size_t x_7, size_t x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
uint8_t x_12; 
x_12 = lean_usize_dec_lt(x_8, x_7);
if (x_12 == 0)
{
lean_object* x_13; 
lean_dec(x_5);
lean_dec(x_3);
lean_dec(x_2);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_9);
lean_ctor_set(x_13, 1, x_11);
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_array_uget(x_6, x_8);
lean_inc(x_14);
x_15 = l_Lean_Environment_getModuleIdx_x3f(x_1, x_14);
if (lean_obj_tag(x_15) == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
lean_dec(x_9);
lean_dec(x_5);
lean_dec(x_3);
x_16 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2___closed__0;
x_17 = l_Lean_Name_toString(x_14, x_12, x_2);
x_18 = lean_string_append(x_16, x_17);
lean_dec(x_17);
x_19 = l_Lean_Server_RequestError_internalError(x_18);
x_20 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_20, 0, x_19);
lean_ctor_set(x_20, 1, x_11);
return x_20;
}
else
{
lean_object* x_21; lean_object* x_22; uint8_t x_23; lean_object* x_24; size_t x_25; size_t x_26; lean_object* x_27; 
lean_dec(x_14);
x_21 = lean_ctor_get(x_15, 0);
lean_inc(x_21);
lean_dec(x_15);
x_22 = lean_box(0);
x_23 = lean_unbox(x_22);
lean_inc(x_3);
x_24 = l_Lean_PersistentEnvExtension_getModuleEntries___redArg(x_3, x_4, x_1, x_21, x_23);
lean_dec(x_21);
x_25 = lean_array_size(x_24);
x_26 = 0;
lean_inc(x_5);
x_27 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0___redArg(x_5, x_24, x_25, x_26, x_9, x_11);
lean_dec(x_24);
if (lean_obj_tag(x_27) == 0)
{
lean_object* x_28; lean_object* x_29; size_t x_30; size_t x_31; 
x_28 = lean_ctor_get(x_27, 0);
lean_inc(x_28);
x_29 = lean_ctor_get(x_27, 1);
lean_inc(x_29);
lean_dec(x_27);
x_30 = 1;
x_31 = lean_usize_add(x_8, x_30);
x_8 = x_31;
x_9 = x_28;
x_11 = x_29;
goto _start;
}
else
{
lean_dec(x_5);
lean_dec(x_3);
lean_dec(x_2);
return x_27;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
lean_inc(x_1);
x_10 = l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1___redArg(x_1, x_2, x_3, x_9);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_27; 
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_27 = lean_ctor_get(x_11, 0);
lean_inc(x_27);
lean_dec(x_11);
x_13 = x_27;
goto block_26;
block_26:
{
lean_object* x_14; size_t x_15; size_t x_16; lean_object* x_17; 
x_14 = l_Lean_Environment_allImportedModuleNames(x_4);
x_15 = lean_array_size(x_14);
x_16 = 0;
x_17 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2(x_4, x_5, x_6, x_7, x_1, x_14, x_15, x_16, x_13, x_8, x_12);
lean_dec(x_14);
if (lean_obj_tag(x_17) == 0)
{
uint8_t x_18; 
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
return x_17;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_17, 0);
x_20 = lean_ctor_get(x_17, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_17);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_19);
lean_ctor_set(x_21, 1, x_20);
return x_21;
}
}
else
{
uint8_t x_22; 
x_22 = !lean_is_exclusive(x_17);
if (x_22 == 0)
{
return x_17;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_23 = lean_ctor_get(x_17, 0);
x_24 = lean_ctor_get(x_17, 1);
lean_inc(x_24);
lean_inc(x_23);
lean_dec(x_17);
x_25 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_25, 0, x_23);
lean_ctor_set(x_25, 1, x_24);
return x_25;
}
}
}
}
else
{
uint8_t x_28; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_1);
x_28 = !lean_is_exclusive(x_10);
if (x_28 == 0)
{
return x_10;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_29 = lean_ctor_get(x_10, 0);
x_30 = lean_ctor_get(x_10, 1);
lean_inc(x_30);
lean_inc(x_29);
lean_dec(x_10);
x_31 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_31, 0, x_29);
lean_ctor_set(x_31, 1, x_30);
return x_31;
}
}
}
}
static lean_object* _init_l_ProofWidgets_getExprPresentations___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_exprPresenters;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_getExprPresentations___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; uint8_t x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_4 = lean_ctor_get(x_1, 0);
lean_inc(x_4);
lean_dec(x_1);
x_5 = lean_ctor_get(x_4, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_5, 0);
lean_inc(x_6);
lean_dec(x_5);
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
lean_dec(x_6);
x_8 = l_ProofWidgets_getExprPresentations___closed__0;
x_9 = lean_ctor_get(x_8, 1);
lean_inc(x_9);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get_uint8(x_10, sizeof(void*)*3);
lean_dec(x_10);
x_12 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0;
x_13 = lean_box(0);
x_14 = l_ProofWidgets_getExprPresentations___closed__1;
lean_inc(x_7);
x_15 = l_Lean_PersistentEnvExtension_getState___redArg(x_13, x_9, x_7, x_11);
x_16 = lean_alloc_closure((void*)(l_ProofWidgets_getExprPresentations___lam__1___boxed), 9, 7);
lean_closure_set(x_16, 0, x_4);
lean_closure_set(x_16, 1, x_15);
lean_closure_set(x_16, 2, x_14);
lean_closure_set(x_16, 3, x_7);
lean_closure_set(x_16, 4, x_12);
lean_closure_set(x_16, 5, x_13);
lean_closure_set(x_16, 6, x_9);
x_17 = l_Lean_Server_RequestM_asTask___redArg(x_16, x_2, x_3);
return x_17;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; size_t x_8; lean_object* x_9; 
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_9 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0___redArg(x_1, x_2, x_7, x_8, x_5, x_6);
lean_dec(x_2);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
size_t x_8; size_t x_9; lean_object* x_10; 
x_8 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_9 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_10 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__0(x_1, x_2, x_8, x_9, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_RBNode_forIn_visit___at___ProofWidgets_getExprPresentations_spec__1(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
size_t x_12; size_t x_13; lean_object* x_14; 
x_12 = lean_unbox_usize(x_7);
lean_dec(x_7);
x_13 = lean_unbox_usize(x_8);
lean_dec(x_8);
x_14 = l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2(x_1, x_2, x_3, x_4, x_5, x_6, x_12, x_13, x_9, x_10, x_11);
lean_dec(x_10);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_1);
return x_14;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_getExprPresentations___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_ProofWidgets_getExprPresentations___lam__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_4);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__1(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__0), 2, 1);
lean_closure_set(x_14, 0, x_13);
x_15 = l_ProofWidgets_instRpcEncodableExprPresentations_enc____x40_ProofWidgets_Presentation_Expr___hyg_959_(x_8, x_12);
x_16 = l_Prod_map___redArg(x_2, x_14, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_1 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__0;
x_2 = lean_box(9);
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
x_4 = lean_unbox(x_2);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_4);
return x_3;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, uint64_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
x_10 = l_Lean_RBNode_find___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget___hyg_204__spec__0___redArg(x_9, x_5);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_11 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__1;
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_st_ref_get(x_13, x_8);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_16 = lean_ctor_get(x_14, 0);
x_17 = lean_ctor_get(x_14, 1);
x_18 = lean_ctor_get(x_16, 0);
lean_inc(x_18);
lean_dec(x_16);
lean_inc(x_6);
x_19 = l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_dec____x40_ProofWidgets_Presentation_Expr___hyg_200_(x_6, x_18);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; uint8_t x_35; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
lean_dec(x_19);
x_21 = lean_box(3);
x_22 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__2;
x_23 = lean_box(1);
x_24 = lean_unbox(x_23);
x_25 = l_Lean_Name_toString(x_1, x_24, x_2);
x_26 = lean_string_append(x_22, x_25);
lean_dec(x_25);
x_27 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__3;
x_28 = lean_string_append(x_26, x_27);
x_29 = l_Lean_Json_compress(x_6);
x_30 = lean_string_append(x_28, x_29);
lean_dec(x_29);
x_31 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__4;
x_32 = lean_string_append(x_30, x_31);
x_33 = lean_string_append(x_32, x_20);
lean_dec(x_20);
x_34 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_34, 0, x_33);
x_35 = lean_unbox(x_21);
lean_ctor_set_uint8(x_34, sizeof(void*)*1, x_35);
lean_ctor_set_tag(x_14, 1);
lean_ctor_set(x_14, 0, x_34);
return x_14;
}
else
{
lean_object* x_36; lean_object* x_37; 
lean_free_object(x_14);
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_36 = lean_ctor_get(x_19, 0);
lean_inc(x_36);
lean_dec(x_19);
lean_inc(x_7);
x_37 = lean_apply_3(x_3, x_36, x_7, x_17);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
x_40 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_40, 0, x_13);
lean_closure_set(x_40, 1, x_4);
x_41 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_38, x_40, x_7, x_39);
return x_41;
}
else
{
uint8_t x_42; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_42 = !lean_is_exclusive(x_37);
if (x_42 == 0)
{
return x_37;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_43 = lean_ctor_get(x_37, 0);
x_44 = lean_ctor_get(x_37, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_37);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
return x_45;
}
}
}
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_46 = lean_ctor_get(x_14, 0);
x_47 = lean_ctor_get(x_14, 1);
lean_inc(x_47);
lean_inc(x_46);
lean_dec(x_14);
x_48 = lean_ctor_get(x_46, 0);
lean_inc(x_48);
lean_dec(x_46);
lean_inc(x_6);
x_49 = l_ProofWidgets_instRpcEncodableGetExprPresentationsParams_dec____x40_ProofWidgets_Presentation_Expr___hyg_200_(x_6, x_48);
if (lean_obj_tag(x_49) == 0)
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; uint8_t x_65; lean_object* x_66; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec(x_49);
x_51 = lean_box(3);
x_52 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__2;
x_53 = lean_box(1);
x_54 = lean_unbox(x_53);
x_55 = l_Lean_Name_toString(x_1, x_54, x_2);
x_56 = lean_string_append(x_52, x_55);
lean_dec(x_55);
x_57 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__3;
x_58 = lean_string_append(x_56, x_57);
x_59 = l_Lean_Json_compress(x_6);
x_60 = lean_string_append(x_58, x_59);
lean_dec(x_59);
x_61 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__4;
x_62 = lean_string_append(x_60, x_61);
x_63 = lean_string_append(x_62, x_50);
lean_dec(x_50);
x_64 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_64, 0, x_63);
x_65 = lean_unbox(x_51);
lean_ctor_set_uint8(x_64, sizeof(void*)*1, x_65);
x_66 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_66, 0, x_64);
lean_ctor_set(x_66, 1, x_47);
return x_66;
}
else
{
lean_object* x_67; lean_object* x_68; 
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_67 = lean_ctor_get(x_49, 0);
lean_inc(x_67);
lean_dec(x_49);
lean_inc(x_7);
x_68 = lean_apply_3(x_3, x_67, x_7, x_47);
if (lean_obj_tag(x_68) == 0)
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
x_69 = lean_ctor_get(x_68, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_68, 1);
lean_inc(x_70);
lean_dec(x_68);
x_71 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__2___boxed), 5, 2);
lean_closure_set(x_71, 0, x_13);
lean_closure_set(x_71, 1, x_4);
x_72 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_69, x_71, x_7, x_70);
return x_72;
}
else
{
lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_73 = lean_ctor_get(x_68, 0);
lean_inc(x_73);
x_74 = lean_ctor_get(x_68, 1);
lean_inc(x_74);
if (lean_is_exclusive(x_68)) {
 lean_ctor_release(x_68, 0);
 lean_ctor_release(x_68, 1);
 x_75 = x_68;
} else {
 lean_dec_ref(x_68);
 x_75 = lean_box(0);
}
if (lean_is_scalar(x_75)) {
 x_76 = lean_alloc_ctor(1, 2, 0);
} else {
 x_76 = x_75;
}
lean_ctor_set(x_76, 0, x_73);
lean_ctor_set(x_76, 1, x_74);
return x_76;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0;
x_4 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__1___boxed), 1, 0);
x_5 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___boxed), 8, 4);
lean_closure_set(x_5, 0, x_1);
lean_closure_set(x_5, 1, x_3);
lean_closure_set(x_5, 2, x_2);
lean_closure_set(x_5, 3, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("getExprPresentations", 20, 20);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__0;
x_2 = l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_getExprPresentations), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_getExprPresentations___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__1;
x_2 = l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__2;
x_3 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__1___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__1(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint64_t x_9; lean_object* x_10; 
x_9 = lean_unbox_uint64(x_5);
lean_dec(x_5);
x_10 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_4, x_9, x_6, x_7, x_8);
return x_10;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1740_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_2 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_;
lean_inc(x_1);
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_;
x_6 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_5);
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_4);
lean_ctor_set(x_9, 1, x_8);
lean_ctor_set(x_6, 0, x_9);
return x_6;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_6, 0);
lean_inc(x_10);
lean_dec(x_6);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_4);
lean_ctor_set(x_11, 1, x_10);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1875_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1740_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1875_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1875_;
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1878_(lean_object* x_1) {
_start:
{
uint8_t x_2; 
x_2 = !lean_is_exclusive(x_1);
if (x_2 == 0)
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_3 = lean_ctor_get(x_1, 0);
x_4 = lean_ctor_get(x_1, 1);
x_5 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_;
lean_ctor_set(x_1, 1, x_3);
lean_ctor_set(x_1, 0, x_5);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_1);
lean_ctor_set(x_7, 1, x_6);
x_8 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_;
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_8);
lean_ctor_set(x_9, 1, x_4);
x_10 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_6);
x_11 = lean_box(0);
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_10);
lean_ctor_set(x_12, 1, x_11);
x_13 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_13, 0, x_7);
lean_ctor_set(x_13, 1, x_12);
x_14 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_;
x_15 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_13, x_14);
x_16 = l_Lean_Json_mkObj(x_15);
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_17 = lean_ctor_get(x_1, 0);
x_18 = lean_ctor_get(x_1, 1);
lean_inc(x_18);
lean_inc(x_17);
lean_dec(x_1);
x_19 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_;
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_19);
lean_ctor_set(x_20, 1, x_17);
x_21 = lean_box(0);
x_22 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_22, 0, x_20);
lean_ctor_set(x_22, 1, x_21);
x_23 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_;
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_23);
lean_ctor_set(x_24, 1, x_18);
x_25 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_25, 0, x_24);
lean_ctor_set(x_25, 1, x_21);
x_26 = lean_box(0);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_25);
lean_ctor_set(x_27, 1, x_26);
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_22);
lean_ctor_set(x_28, 1, x_27);
x_29 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_;
x_30 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_28, x_29);
x_31 = l_Lean_Json_mkObj(x_30);
return x_31;
}
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1927_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1878_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1927_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1927_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationParams_enc____x40_ProofWidgets_Presentation_Expr___hyg_1688_(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_1);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint8_t x_8; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_7 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_6, x_4, x_2);
lean_dec(x_4);
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_9 = lean_ctor_get(x_7, 0);
x_10 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0;
x_11 = lean_box(1);
x_12 = lean_unbox(x_11);
x_13 = l_Lean_Name_toString(x_5, x_12, x_10);
x_14 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_1, 1, x_14);
lean_ctor_set(x_1, 0, x_9);
x_15 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1878_(x_1);
lean_ctor_set(x_7, 0, x_15);
return x_7;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_16 = lean_ctor_get(x_7, 0);
x_17 = lean_ctor_get(x_7, 1);
lean_inc(x_17);
lean_inc(x_16);
lean_dec(x_7);
x_18 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0;
x_19 = lean_box(1);
x_20 = lean_unbox(x_19);
x_21 = l_Lean_Name_toString(x_5, x_20, x_18);
x_22 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_1, 1, x_22);
lean_ctor_set(x_1, 0, x_16);
x_23 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1878_(x_1);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_23);
lean_ctor_set(x_24, 1, x_17);
return x_24;
}
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; uint8_t x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_25 = lean_ctor_get(x_1, 0);
x_26 = lean_ctor_get(x_1, 1);
lean_inc(x_26);
lean_inc(x_25);
lean_dec(x_1);
x_27 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_28 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_27, x_25, x_2);
lean_dec(x_25);
x_29 = lean_ctor_get(x_28, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_28, 1);
lean_inc(x_30);
if (lean_is_exclusive(x_28)) {
 lean_ctor_release(x_28, 0);
 lean_ctor_release(x_28, 1);
 x_31 = x_28;
} else {
 lean_dec_ref(x_28);
 x_31 = lean_box(0);
}
x_32 = l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0;
x_33 = lean_box(1);
x_34 = lean_unbox(x_33);
x_35 = l_Lean_Name_toString(x_26, x_34, x_32);
x_36 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_36, 0, x_35);
x_37 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_37, 0, x_29);
lean_ctor_set(x_37, 1, x_36);
x_38 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1878_(x_37);
if (lean_is_scalar(x_31)) {
 x_39 = lean_alloc_ctor(0, 2, 0);
} else {
 x_39 = x_31;
}
lean_ctor_set(x_39, 0, x_38);
lean_ctor_set(x_39, 1, x_30);
return x_39;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableGetExprPresentationParams_dec____x40_ProofWidgets_Presentation_Expr___hyg_1688_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1740_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = lean_ctor_get(x_4, 1);
x_8 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_9 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_8, x_6, x_2);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_free_object(x_4);
lean_dec(x_7);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
return x_9;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
else
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_9, 0);
lean_inc(x_13);
lean_dec(x_9);
x_14 = l_Lean_Name_fromJson_x3f(x_7);
if (lean_obj_tag(x_14) == 0)
{
uint8_t x_15; 
lean_dec(x_13);
lean_free_object(x_4);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
return x_14;
}
else
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_ctor_get(x_14, 0);
lean_inc(x_16);
lean_dec(x_14);
x_17 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_17, 0, x_16);
return x_17;
}
}
else
{
uint8_t x_18; 
x_18 = !lean_is_exclusive(x_14);
if (x_18 == 0)
{
lean_object* x_19; 
x_19 = lean_ctor_get(x_14, 0);
lean_ctor_set(x_4, 1, x_19);
lean_ctor_set(x_4, 0, x_13);
lean_ctor_set(x_14, 0, x_4);
return x_14;
}
else
{
lean_object* x_20; lean_object* x_21; 
x_20 = lean_ctor_get(x_14, 0);
lean_inc(x_20);
lean_dec(x_14);
lean_ctor_set(x_4, 1, x_20);
lean_ctor_set(x_4, 0, x_13);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_4);
return x_21;
}
}
}
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_22 = lean_ctor_get(x_4, 0);
x_23 = lean_ctor_get(x_4, 1);
lean_inc(x_23);
lean_inc(x_22);
lean_dec(x_4);
x_24 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_25 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_24, x_22, x_2);
if (lean_obj_tag(x_25) == 0)
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
lean_dec(x_23);
x_26 = lean_ctor_get(x_25, 0);
lean_inc(x_26);
if (lean_is_exclusive(x_25)) {
 lean_ctor_release(x_25, 0);
 x_27 = x_25;
} else {
 lean_dec_ref(x_25);
 x_27 = lean_box(0);
}
if (lean_is_scalar(x_27)) {
 x_28 = lean_alloc_ctor(0, 1, 0);
} else {
 x_28 = x_27;
}
lean_ctor_set(x_28, 0, x_26);
return x_28;
}
else
{
lean_object* x_29; lean_object* x_30; 
x_29 = lean_ctor_get(x_25, 0);
lean_inc(x_29);
lean_dec(x_25);
x_30 = l_Lean_Name_fromJson_x3f(x_23);
if (lean_obj_tag(x_30) == 0)
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; 
lean_dec(x_29);
x_31 = lean_ctor_get(x_30, 0);
lean_inc(x_31);
if (lean_is_exclusive(x_30)) {
 lean_ctor_release(x_30, 0);
 x_32 = x_30;
} else {
 lean_dec_ref(x_30);
 x_32 = lean_box(0);
}
if (lean_is_scalar(x_32)) {
 x_33 = lean_alloc_ctor(0, 1, 0);
} else {
 x_33 = x_32;
}
lean_ctor_set(x_33, 0, x_31);
return x_33;
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_34 = lean_ctor_get(x_30, 0);
lean_inc(x_34);
if (lean_is_exclusive(x_30)) {
 lean_ctor_release(x_30, 0);
 x_35 = x_30;
} else {
 lean_dec_ref(x_30);
 x_35 = lean_box(0);
}
x_36 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_36, 0, x_29);
lean_ctor_set(x_36, 1, x_34);
if (lean_is_scalar(x_35)) {
 x_37 = lean_alloc_ctor(1, 1, 0);
} else {
 x_37 = x_35;
}
lean_ctor_set(x_37, 0, x_36);
return x_37;
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableGetExprPresentationParams_enc____x40_ProofWidgets_Presentation_Expr___hyg_1688_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableGetExprPresentationParams_dec____x40_ProofWidgets_Presentation_Expr___hyg_1688_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableGetExprPresentationParams() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__2;
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2102_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_;
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2182_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2102_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2182_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2182_;
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2185_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_2 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_;
x_9 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_7, x_8);
x_10 = l_Lean_Json_mkObj(x_9);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2220_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2185_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2220_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2220_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps_enc____x40_ProofWidgets_Presentation_Expr___hyg_2068_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_4 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_3, x_1, x_2);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2185_(x_6);
lean_ctor_set(x_4, 0, x_7);
return x_4;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_4, 0);
x_9 = lean_ctor_get(x_4, 1);
lean_inc(x_9);
lean_inc(x_8);
lean_dec(x_4);
x_10 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2185_(x_8);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_9);
return x_11;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps_enc____x40_ProofWidgets_Presentation_Expr___hyg_2068____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableExprPresentationProps_enc____x40_ProofWidgets_Presentation_Expr___hyg_2068_(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableExprPresentationProps_dec____x40_ProofWidgets_Presentation_Expr___hyg_2068_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2102_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_6 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_5, x_4, x_2);
if (lean_obj_tag(x_6) == 0)
{
uint8_t x_7; 
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
return x_6;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
lean_inc(x_8);
lean_dec(x_6);
x_9 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_9, 0, x_8);
return x_9;
}
}
else
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_6);
if (x_10 == 0)
{
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_6, 0);
lean_inc(x_11);
lean_dec(x_6);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentationProps_enc____x40_ProofWidgets_Presentation_Expr___hyg_2068____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableExprPresentationProps_dec____x40_ProofWidgets_Presentation_Expr___hyg_2068_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableExprPresentationProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ExprPresentation___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsxs as e,jsx as n,Fragment as t}from\"react/jsx-runtime\";import*as r from\"react\";import{useRpcSession as a,EnvPosContext as o,useAsyncPersistent as s,mapRpcError as l,importWidgetModule as i,InteractiveCode as m}from\"@leanprover/infoview\";async function c(a,o,s){if(\"text\"in s)return n(t,{children:s.text});if(\"element\"in s){const[e,t,l]=s.element,i={};for(const[e,n]of t)i[e]=n;const m=await Promise.all(l.map((async e=>await c(a,o,e))));return\"hr\"===e\?n(\"hr\",{}):0===m.length\?r.createElement(e,i):r.createElement(e,i,m)}if(\"component\"in s){const[e,n,t,l]=s.component,m=await Promise.all(l.map((async e=>await c(a,o,e)))),u={...t,pos:o},d=await i(a,o,e);if(!(n in d))throw new Error(`Module '${e}' does not export '${n}'`);return 0===m.length\?r.createElement(d[n],u):r.createElement(d[n],u,m)}return e(\"span\",{className:\"red\",children:[\"Unknown HTML variant: \",JSON.stringify(s)]})}function u({html:i}){const m=a(),u=r.useContext(o),d=s((()=>c(m,u,i)),[m,u,i]);return\"resolved\"===d.state\?d.value:\"rejected\"===d.state\?e(\"span\",{className:\"red\",children:[\"Error rendering HTML: \",l(d.error).message]}):n(t,{})}function d({expr:r}){const o=a(),i=s((()=>o.call(\"ProofWidgets.ppExprTagged\",{expr:r})),[r]);return\"resolved\"===i.state\?n(m,{fmt:i.value}):\"rejected\"===i.state\?e(t,{children:[\"Error: $\",l(i.error).message]}):n(t,{children:\"Loading..\"})}function p({expr:o}){const i=a(),[m,c]=r.useState({tag:\"auto\"}),p=s((async()=>{const e=await async function(e,n){return(await e.call(\"ProofWidgets.getExprPresentations\",{expr:n})).presentations}(i,o);return c((n=>\"manual\"!==n.tag||void 0===n.name||e.some((e=>e.name===n.name))\?n:{tag:\"auto\"})),new Map(e.map((e=>[e.name,e])))}),[i,o]);if(\"rejected\"===p.state)return e(t,{children:[\"Error: \",l(p.error).message]});if(\"resolved\"===p.state){let t=\"none\";return\"auto\"===m.tag&&0<p.value.size\?t=Array.from(p.value.values())[0].name:\"manual\"!==m.tag||\"none\"!==m.name&&!p.value.has(m.name)||(t=m.name),e(\"div\",{style:{display:\"flow-root\"},children:[\"none\"!==t&&n(u,{html:p.value.get(t).html}),\"none\"===t&&n(d,{expr:o}),e(\"select\",{className:\"fr\",value:t,onChange:e=>{c({tag:\"manual\",name:e.target.value})},children:[Array.from(p.value.values(),(e=>n(\"option\",{value:e.name,children:e.userName},e.name))),n(\"option\",{value:\"none\",children:\"Default\"},\"none\")]})]})}return n(d,{expr:o})}export{p as default};", 2357, 2357);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_ExprPresentation___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_ExprPresentation___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_ExprPresentation___closed__2___boxed__const__1() {
_start:
{
uint64_t x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_ExprPresentation___closed__1;
x_2 = lean_box_uint64(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_ExprPresentation___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_ExprPresentation___closed__0;
x_2 = l_ProofWidgets_ExprPresentation___closed__2___boxed__const__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_ExprPresentation___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ExprPresentation___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_ExprPresentation___closed__3;
x_2 = l_ProofWidgets_ExprPresentation___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_ExprPresentation() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_ExprPresentation___closed__4;
return x_1;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Data_Html(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Presentation_Expr(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Data_Html(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__5____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__6____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__7____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__8____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__9____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__10____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__11____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__12____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Presentation_Expr___hyg_42_);
l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_ = _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Presentation_Expr___hyg_42_);
res = l_ProofWidgets_initFn____x40_ProofWidgets_Presentation_Expr___hyg_42_(lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
l_ProofWidgets_exprPresenters = lean_io_result_get_value(res);
lean_mark_persistent(l_ProofWidgets_exprPresenters);
lean_dec_ref(res);
l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_ = _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_();
lean_mark_persistent(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_234_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_314_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_314_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_314_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_314_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_314_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_314_);
l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_ = _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_();
lean_mark_persistent(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_317_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_352_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_352_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_352_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_352_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_352_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_352_);
l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__0 = _init_l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__0);
l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__1 = _init_l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__1);
l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__2 = _init_l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGetExprPresentationsParams___closed__2);
l_ProofWidgets_instRpcEncodableGetExprPresentationsParams = _init_l_ProofWidgets_instRpcEncodableGetExprPresentationsParams();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGetExprPresentationsParams);
l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_ = _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_();
lean_mark_persistent(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_528_);
l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_528_ = _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_528_();
lean_mark_persistent(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Presentation_Expr___hyg_528_);
l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_528_ = _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_528_();
lean_mark_persistent(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Presentation_Expr___hyg_528_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_718_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_718_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_718_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_718_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_718_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_718_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_784_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_784_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_784_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_784_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_784_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_784_);
l_ProofWidgets_instRpcEncodableExprPresentationData___closed__0 = _init_l_ProofWidgets_instRpcEncodableExprPresentationData___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentationData___closed__0);
l_ProofWidgets_instRpcEncodableExprPresentationData___closed__1 = _init_l_ProofWidgets_instRpcEncodableExprPresentationData___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentationData___closed__1);
l_ProofWidgets_instRpcEncodableExprPresentationData___closed__2 = _init_l_ProofWidgets_instRpcEncodableExprPresentationData___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentationData___closed__2);
l_ProofWidgets_instRpcEncodableExprPresentationData = _init_l_ProofWidgets_instRpcEncodableExprPresentationData();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentationData);
l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_993_ = _init_l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_993_();
lean_mark_persistent(l___private_ProofWidgets_Presentation_Expr_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_993_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1073_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1073_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1073_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1073_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1073_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1073_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1111_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1111_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1111_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1111_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1111_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1111_);
l_ProofWidgets_instRpcEncodableExprPresentations___closed__0 = _init_l_ProofWidgets_instRpcEncodableExprPresentations___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentations___closed__0);
l_ProofWidgets_instRpcEncodableExprPresentations___closed__1 = _init_l_ProofWidgets_instRpcEncodableExprPresentations___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentations___closed__1);
l_ProofWidgets_instRpcEncodableExprPresentations___closed__2 = _init_l_ProofWidgets_instRpcEncodableExprPresentations___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentations___closed__2);
l_ProofWidgets_instRpcEncodableExprPresentations = _init_l_ProofWidgets_instRpcEncodableExprPresentations();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentations);
l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0 = _init_l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0();
lean_mark_persistent(l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__0);
l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__1 = _init_l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__1();
lean_mark_persistent(l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__1);
l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__2 = _init_l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__2();
lean_mark_persistent(l_ProofWidgets_getExprPresentations_addPresenterIfApplicable___redArg___closed__2);
l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2___closed__0 = _init_l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2___closed__0();
lean_mark_persistent(l_Array_forIn_x27Unsafe_loop___at___ProofWidgets_getExprPresentations_spec__2___closed__0);
l_ProofWidgets_getExprPresentations___closed__0 = _init_l_ProofWidgets_getExprPresentations___closed__0();
lean_mark_persistent(l_ProofWidgets_getExprPresentations___closed__0);
l_ProofWidgets_getExprPresentations___closed__1 = _init_l_ProofWidgets_getExprPresentations___closed__1();
lean_mark_persistent(l_ProofWidgets_getExprPresentations___closed__1);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__0 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__0();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__0);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__1 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__1();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__1);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__2 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__2();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__2);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__3 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__3();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__3);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__4 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__4();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_getExprPresentations___rpc__wrapped_spec__0___lam__3___closed__4);
l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__0 = _init_l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__0();
lean_mark_persistent(l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__0);
l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__1 = _init_l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__1();
lean_mark_persistent(l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__1);
l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__2 = _init_l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__2();
lean_mark_persistent(l_ProofWidgets_getExprPresentations___rpc__wrapped___closed__2);
l_ProofWidgets_getExprPresentations___rpc__wrapped = _init_l_ProofWidgets_getExprPresentations___rpc__wrapped();
lean_mark_persistent(l_ProofWidgets_getExprPresentations___rpc__wrapped);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1875_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1875_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1875_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1875_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1875_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1875_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1927_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1927_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_1927_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1927_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1927_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_1927_);
l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__0 = _init_l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__0);
l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__1 = _init_l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__1);
l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__2 = _init_l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGetExprPresentationParams___closed__2);
l_ProofWidgets_instRpcEncodableGetExprPresentationParams = _init_l_ProofWidgets_instRpcEncodableGetExprPresentationParams();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableGetExprPresentationParams);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2182_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2182_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2182_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2182_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2182_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2182_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2220_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2220_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Presentation_Expr___hyg_2220_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2220_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2220_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Presentation_Expr___hyg_2220_);
l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__0 = _init_l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__0);
l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__1 = _init_l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__1);
l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__2 = _init_l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentationProps___closed__2);
l_ProofWidgets_instRpcEncodableExprPresentationProps = _init_l_ProofWidgets_instRpcEncodableExprPresentationProps();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableExprPresentationProps);
l_ProofWidgets_ExprPresentation___closed__0 = _init_l_ProofWidgets_ExprPresentation___closed__0();
lean_mark_persistent(l_ProofWidgets_ExprPresentation___closed__0);
l_ProofWidgets_ExprPresentation___closed__1 = _init_l_ProofWidgets_ExprPresentation___closed__1();
l_ProofWidgets_ExprPresentation___closed__2___boxed__const__1 = _init_l_ProofWidgets_ExprPresentation___closed__2___boxed__const__1();
lean_mark_persistent(l_ProofWidgets_ExprPresentation___closed__2___boxed__const__1);
l_ProofWidgets_ExprPresentation___closed__2 = _init_l_ProofWidgets_ExprPresentation___closed__2();
lean_mark_persistent(l_ProofWidgets_ExprPresentation___closed__2);
l_ProofWidgets_ExprPresentation___closed__3 = _init_l_ProofWidgets_ExprPresentation___closed__3();
lean_mark_persistent(l_ProofWidgets_ExprPresentation___closed__3);
l_ProofWidgets_ExprPresentation___closed__4 = _init_l_ProofWidgets_ExprPresentation___closed__4();
lean_mark_persistent(l_ProofWidgets_ExprPresentation___closed__4);
l_ProofWidgets_ExprPresentation = _init_l_ProofWidgets_ExprPresentation();
lean_mark_persistent(l_ProofWidgets_ExprPresentation);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
