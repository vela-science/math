// Lean compiler output
// Module: ProofWidgets.Component.Basic
// Imports: Init Lean.Widget.InteractiveCode Lean.Widget.UserWidget ProofWidgets.Compat
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__1____x40_ProofWidgets_Component_Basic___hyg_962_;
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3;
lean_object* l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Window_0__fromJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_144__spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic___hyg_636_(lean_object*, lean_object*);
lean_object* l_Lean_Widget_ppExprTagged(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_788_;
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveCode;
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2;
static lean_object* l_ProofWidgets_InteractiveExpr___closed__3;
extern lean_object* l_Lean_instImpl____x40_Lean_Message___hyg_789_;
lean_object* l_Lean_Widget_instRpcEncodableSubexprInfo_enc____x40_Lean_Widget_InteractiveCode___hyg_292_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveMessage___closed__2___boxed__const__1;
static lean_object* l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0;
lean_object* l_Lean_Name_toString(lean_object*, uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_430_;
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__8____x40_ProofWidgets_Component_Basic___hyg_962_;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_468_;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_670_(lean_object*);
static uint64_t l_ProofWidgets_InteractiveMessage___closed__1;
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__11____x40_ProofWidgets_Component_Basic___hyg_962_;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_753_(lean_object*);
lean_object* l_ProofWidgets_ExprWithCtx_runMetaM___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_750_;
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped;
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_200_;
uint64_t lean_string_hash(lean_object*);
static lean_object* l_ProofWidgets_InteractiveExpr___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay___closed__2___boxed__const__1;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_433_(lean_object*);
static lean_object* l_ProofWidgets_InteractiveCode___closed__0;
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0;
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__7____x40_ProofWidgets_Component_Basic___hyg_962_;
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_350_;
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr3(lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__0;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_InteractiveCode___closed__2;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*);
lean_object* l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__7___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_162_;
lean_object* lean_st_ref_take(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2;
static uint64_t l_ProofWidgets_InteractiveCode___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay;
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__2____x40_ProofWidgets_Component_Basic___hyg_962_;
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1;
lean_object* l_Lean_MessageData_ofFormat(lean_object*);
static lean_object* l_ProofWidgets_MarkdownDisplay___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps;
lean_object* lean_st_ref_get(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_InteractiveCode___closed__4;
lean_object* l_Lean_Widget_WidgetInstance_ofHash(uint64_t, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_430_;
lean_object* l_Lean_PrettyPrinter_Delaborator_delab(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1;
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps;
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1;
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic___hyg_49_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps____x40_ProofWidgets_Component_Basic___hyg_962_(lean_object*);
lean_object* l___private_Lean_Widget_TaggedText_0__Lean_Widget_fromJsonTaggedText____x40_Lean_Widget_TaggedText___hyg_418____at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__4(lean_object*);
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__3____x40_ProofWidgets_Component_Basic___hyg_962_;
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0;
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__10____x40_ProofWidgets_Component_Basic___hyg_962_;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_468_;
static lean_object* l_ProofWidgets_ppExprTagged___lam__0___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_788_;
static lean_object* l_ProofWidgets_MarkdownDisplay___closed__2;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps____x40_ProofWidgets_Component_Basic___hyg_924_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_dec____x40_ProofWidgets_Component_Basic___hyg_636_(lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_962_;
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_;
static lean_object* l_ProofWidgets_InteractiveMessage___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_200_;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_165_(lean_object*);
static lean_object* l_ProofWidgets_InteractiveMessage___closed__2;
static lean_object* l_ProofWidgets_InteractiveExpr___closed__0;
static lean_object* l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps;
static lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1;
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__9____x40_ProofWidgets_Component_Basic___hyg_962_;
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveExpr___closed__2___boxed__const__1;
lean_object* l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_82_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__4;
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2;
lean_object* l_Lean_Widget_instRpcEncodableSubexprInfo_dec____x40_Lean_Widget_InteractiveCode___hyg_292_(lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_165_;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec____x40_ProofWidgets_Component_Basic___hyg_49_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_670_;
lean_object* l___private_Lean_Widget_TaggedText_0__Lean_Widget_toJsonTaggedText____x40_Lean_Widget_TaggedText___hyg_632____at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_enc____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__4(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic___hyg_636____boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent___lam__0(lean_object*);
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__5____x40_ProofWidgets_Component_Basic___hyg_962_;
static lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_350_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_MarkdownDisplay_instToJsonProps;
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1(lean_object*);
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1___boxed(lean_object*);
lean_object* l_Lean_RBNode_find___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget___hyg_204__spec__0___redArg(lean_object*, uint64_t);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__2;
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__4____x40_ProofWidgets_Component_Basic___hyg_962_;
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_162_;
lean_object* l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_enc____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__2___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_InteractiveCode___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveExpr;
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveCode___closed__2___boxed__const__1;
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__1(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_750_;
static lean_object* l_ProofWidgets_InteractiveMessage___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic___hyg_316_(lean_object*, lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic___hyg_316_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_InteractiveMessage;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__1;
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent___lam__0___boxed(lean_object*);
static lean_object* l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4(lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_82_;
static lean_object* l_ProofWidgets_MarkdownDisplay___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic___hyg_316____boxed(lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_924_;
static uint64_t l_ProofWidgets_InteractiveExpr___closed__1;
static uint64_t l_ProofWidgets_MarkdownDisplay___closed__1;
static lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__6____x40_ProofWidgets_Component_Basic___hyg_962_;
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_ctor_get(x_1, 0);
lean_inc(x_2);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_instToModuleComponent___lam__0___boxed), 1, 0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instToModuleComponent___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_instToModuleComponent___lam__0(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_82_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("fmt", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_82_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_82_;
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_162_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_82_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_162_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_162_;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_165_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_165_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_82_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_165_;
x_9 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_7, x_8);
x_10 = l_Lean_Json_mkObj(x_9);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_200_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_165_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_200_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_200_;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Widget_instRpcEncodableSubexprInfo_enc____x40_Lean_Widget_InteractiveCode___hyg_292_), 2, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic___hyg_49_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_;
x_4 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_enc____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__2___redArg(x_3, x_1, x_2);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = l___private_Lean_Widget_TaggedText_0__Lean_Widget_toJsonTaggedText____x40_Lean_Widget_TaggedText___hyg_632____at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_enc____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__4(x_6);
x_8 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_165_(x_7);
lean_ctor_set(x_4, 0, x_8);
return x_4;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_9 = lean_ctor_get(x_4, 0);
x_10 = lean_ctor_get(x_4, 1);
lean_inc(x_10);
lean_inc(x_9);
lean_dec(x_4);
x_11 = l___private_Lean_Widget_TaggedText_0__Lean_Widget_toJsonTaggedText____x40_Lean_Widget_TaggedText___hyg_632____at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_enc____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__4(x_9);
x_12 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_165_(x_11);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_10);
return x_13;
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Widget_instRpcEncodableSubexprInfo_dec____x40_Lean_Widget_InteractiveCode___hyg_292_), 2, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec____x40_ProofWidgets_Component_Basic___hyg_49_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_82_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l___private_Lean_Widget_TaggedText_0__Lean_Widget_fromJsonTaggedText____x40_Lean_Widget_TaggedText___hyg_418____at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__4(x_4);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_6; 
lean_dec(x_2);
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; 
x_7 = lean_ctor_get(x_5, 0);
lean_inc(x_7);
lean_dec(x_5);
x_8 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_8, 0, x_7);
return x_8;
}
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_9 = lean_ctor_get(x_5, 0);
lean_inc(x_9);
lean_dec(x_5);
x_10 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_;
x_11 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__7___redArg(x_10, x_9, x_2);
if (lean_obj_tag(x_11) == 0)
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
return x_11;
}
else
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_11, 0);
lean_inc(x_13);
lean_dec(x_11);
x_14 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_14, 0, x_13);
return x_14;
}
}
else
{
uint8_t x_15; 
x_15 = !lean_is_exclusive(x_11);
if (x_15 == 0)
{
return x_11;
}
else
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_ctor_get(x_11, 0);
lean_inc(x_16);
lean_dec(x_11);
x_17 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_17, 0, x_16);
return x_17;
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc____x40_ProofWidgets_Component_Basic___hyg_49_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec____x40_ProofWidgets_Component_Basic___hyg_49_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\n    import { InteractiveCode } from '@leanprover/infoview'\n    import * as React from 'react'\n    export default function(props) {\n      return React.createElement(InteractiveCode, props)\n    }", 194, 194);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_InteractiveCode___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_InteractiveCode___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode___closed__2___boxed__const__1() {
_start:
{
uint64_t x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_InteractiveCode___closed__1;
x_2 = lean_box_uint64(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__0;
x_2 = l_ProofWidgets_InteractiveCode___closed__2___boxed__const__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("default", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__3;
x_2 = l_ProofWidgets_InteractiveCode___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveCode() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_InteractiveCode___closed__4;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_350_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expr", 4, 4);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_350_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_350_;
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_430_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_350_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_430_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_430_;
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_433_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_350_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_165_;
x_9 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_7, x_8);
x_10 = l_Lean_Json_mkObj(x_9);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_468_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_433_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_468_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_468_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic___hyg_316_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_4 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_3, x_1, x_2);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_433_(x_6);
lean_ctor_set(x_4, 0, x_7);
return x_4;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_4, 0);
x_9 = lean_ctor_get(x_4, 1);
lean_inc(x_9);
lean_inc(x_8);
lean_dec(x_4);
x_10 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_433_(x_8);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_9);
return x_11;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic___hyg_316____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic___hyg_316_(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic___hyg_316_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_350_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l_ProofWidgets_instImpl____x40_ProofWidgets_Compat___hyg_54_;
x_6 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_5, x_4, x_2);
if (lean_obj_tag(x_6) == 0)
{
uint8_t x_7; 
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
return x_6;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
lean_inc(x_8);
lean_dec(x_6);
x_9 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_9, 0, x_8);
return x_9;
}
}
else
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_6);
if (x_10 == 0)
{
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_6, 0);
lean_inc(x_11);
lean_dec(x_6);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveExprProps_enc____x40_ProofWidgets_Component_Basic___hyg_316____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic___hyg_316_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delab), 7, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; 
x_7 = l_ProofWidgets_ppExprTagged___lam__0___closed__0;
x_8 = l_Lean_Widget_ppExprTagged(x_1, x_7, x_2, x_3, x_4, x_5, x_6);
return x_8;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_ExprWithCtx_runMetaM___redArg(x_1, x_2, x_4);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_6; 
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
return x_5;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_7 = lean_ctor_get(x_5, 0);
x_8 = lean_ctor_get(x_5, 1);
lean_inc(x_8);
lean_inc(x_7);
lean_dec(x_5);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
return x_9;
}
}
else
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_5);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_5, 0);
x_12 = l_Lean_Server_RequestError_ofIoError(x_11);
lean_ctor_set(x_5, 0, x_12);
return x_5;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_13 = lean_ctor_get(x_5, 0);
x_14 = lean_ctor_get(x_5, 1);
lean_inc(x_14);
lean_inc(x_13);
lean_dec(x_5);
x_15 = l_Lean_Server_RequestError_ofIoError(x_13);
x_16 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_14);
return x_16;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_4 = lean_ctor_get(x_1, 0);
lean_inc(x_4);
lean_dec(x_1);
x_5 = lean_alloc_closure((void*)(l_ProofWidgets_ppExprTagged___lam__0), 6, 0);
x_6 = lean_alloc_closure((void*)(l_ProofWidgets_ppExprTagged___lam__1___boxed), 4, 2);
lean_closure_set(x_6, 0, x_4);
lean_closure_set(x_6, 1, x_5);
x_7 = l_Lean_Server_RequestM_asTask___redArg(x_6, x_2, x_3);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ppExprTagged___lam__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_ppExprTagged___lam__1(x_1, x_2, x_3, x_4);
lean_dec(x_3);
return x_5;
}
}
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = lean_box(0);
x_3 = lean_unbox(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_;
x_15 = l_Lean_Widget_TaggedText_mapM___at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_enc____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__2___redArg(x_14, x_8, x_12);
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; 
x_17 = lean_ctor_get(x_15, 0);
x_18 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2), 2, 1);
lean_closure_set(x_18, 0, x_13);
x_19 = l___private_Lean_Widget_TaggedText_0__Lean_Widget_toJsonTaggedText____x40_Lean_Widget_TaggedText___hyg_632____at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_enc____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__4(x_17);
lean_ctor_set(x_15, 0, x_19);
x_20 = l_Prod_map___redArg(x_2, x_18, x_15);
x_21 = lean_ctor_get(x_20, 0);
lean_inc(x_21);
x_22 = lean_ctor_get(x_20, 1);
lean_inc(x_22);
lean_dec(x_20);
x_23 = lean_st_ref_set(x_1, x_22, x_11);
x_24 = !lean_is_exclusive(x_23);
if (x_24 == 0)
{
lean_object* x_25; 
x_25 = lean_ctor_get(x_23, 0);
lean_dec(x_25);
lean_ctor_set(x_23, 0, x_21);
return x_23;
}
else
{
lean_object* x_26; lean_object* x_27; 
x_26 = lean_ctor_get(x_23, 1);
lean_inc(x_26);
lean_dec(x_23);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_21);
lean_ctor_set(x_27, 1, x_26);
return x_27;
}
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_28 = lean_ctor_get(x_15, 0);
x_29 = lean_ctor_get(x_15, 1);
lean_inc(x_29);
lean_inc(x_28);
lean_dec(x_15);
x_30 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__2), 2, 1);
lean_closure_set(x_30, 0, x_13);
x_31 = l___private_Lean_Widget_TaggedText_0__Lean_Widget_toJsonTaggedText____x40_Lean_Widget_TaggedText___hyg_632____at___Lean_Widget_instRpcEncodableInteractiveHypothesisBundle_enc____x40_Lean_Widget_InteractiveGoal___hyg_5__spec__4(x_28);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_29);
x_33 = l_Prod_map___redArg(x_2, x_30, x_32);
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_33, 1);
lean_inc(x_35);
lean_dec(x_33);
x_36 = lean_st_ref_set(x_1, x_35, x_11);
x_37 = lean_ctor_get(x_36, 1);
lean_inc(x_37);
if (lean_is_exclusive(x_36)) {
 lean_ctor_release(x_36, 0);
 lean_ctor_release(x_36, 1);
 x_38 = x_36;
} else {
 lean_dec_ref(x_36);
 x_38 = lean_box(0);
}
if (lean_is_scalar(x_38)) {
 x_39 = lean_alloc_ctor(0, 2, 0);
} else {
 x_39 = x_38;
}
lean_ctor_set(x_39, 0, x_34);
lean_ctor_set(x_39, 1, x_37);
return x_39;
}
}
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_1 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__0;
x_2 = lean_box(9);
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
x_4 = lean_unbox(x_2);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_4);
return x_3;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, uint64_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
x_10 = l_Lean_RBNode_find___at___Lean_Widget_initFn____x40_Lean_Widget_UserWidget___hyg_204__spec__0___redArg(x_9, x_5);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_11 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__1;
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_st_ref_get(x_13, x_8);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_16 = lean_ctor_get(x_14, 0);
x_17 = lean_ctor_get(x_14, 1);
x_18 = lean_ctor_get(x_16, 0);
lean_inc(x_18);
lean_dec(x_16);
lean_inc(x_6);
x_19 = l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic___hyg_316_(x_6, x_18);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; uint8_t x_35; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
lean_dec(x_19);
x_21 = lean_box(3);
x_22 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__2;
x_23 = lean_box(1);
x_24 = lean_unbox(x_23);
x_25 = l_Lean_Name_toString(x_1, x_24, x_2);
x_26 = lean_string_append(x_22, x_25);
lean_dec(x_25);
x_27 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__3;
x_28 = lean_string_append(x_26, x_27);
x_29 = l_Lean_Json_compress(x_6);
x_30 = lean_string_append(x_28, x_29);
lean_dec(x_29);
x_31 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__4;
x_32 = lean_string_append(x_30, x_31);
x_33 = lean_string_append(x_32, x_20);
lean_dec(x_20);
x_34 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_34, 0, x_33);
x_35 = lean_unbox(x_21);
lean_ctor_set_uint8(x_34, sizeof(void*)*1, x_35);
lean_ctor_set_tag(x_14, 1);
lean_ctor_set(x_14, 0, x_34);
return x_14;
}
else
{
lean_object* x_36; lean_object* x_37; 
lean_free_object(x_14);
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_36 = lean_ctor_get(x_19, 0);
lean_inc(x_36);
lean_dec(x_19);
lean_inc(x_7);
x_37 = lean_apply_3(x_3, x_36, x_7, x_17);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
x_40 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_40, 0, x_13);
lean_closure_set(x_40, 1, x_4);
x_41 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_38, x_40, x_7, x_39);
return x_41;
}
else
{
uint8_t x_42; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_42 = !lean_is_exclusive(x_37);
if (x_42 == 0)
{
return x_37;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_43 = lean_ctor_get(x_37, 0);
x_44 = lean_ctor_get(x_37, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_37);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
return x_45;
}
}
}
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_46 = lean_ctor_get(x_14, 0);
x_47 = lean_ctor_get(x_14, 1);
lean_inc(x_47);
lean_inc(x_46);
lean_dec(x_14);
x_48 = lean_ctor_get(x_46, 0);
lean_inc(x_48);
lean_dec(x_46);
lean_inc(x_6);
x_49 = l_ProofWidgets_instRpcEncodableInteractiveExprProps_dec____x40_ProofWidgets_Component_Basic___hyg_316_(x_6, x_48);
if (lean_obj_tag(x_49) == 0)
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; uint8_t x_65; lean_object* x_66; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec(x_49);
x_51 = lean_box(3);
x_52 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__2;
x_53 = lean_box(1);
x_54 = lean_unbox(x_53);
x_55 = l_Lean_Name_toString(x_1, x_54, x_2);
x_56 = lean_string_append(x_52, x_55);
lean_dec(x_55);
x_57 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__3;
x_58 = lean_string_append(x_56, x_57);
x_59 = l_Lean_Json_compress(x_6);
x_60 = lean_string_append(x_58, x_59);
lean_dec(x_59);
x_61 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__4;
x_62 = lean_string_append(x_60, x_61);
x_63 = lean_string_append(x_62, x_50);
lean_dec(x_50);
x_64 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_64, 0, x_63);
x_65 = lean_unbox(x_51);
lean_ctor_set_uint8(x_64, sizeof(void*)*1, x_65);
x_66 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_66, 0, x_64);
lean_ctor_set(x_66, 1, x_47);
return x_66;
}
else
{
lean_object* x_67; lean_object* x_68; 
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_67 = lean_ctor_get(x_49, 0);
lean_inc(x_67);
lean_dec(x_49);
lean_inc(x_7);
x_68 = lean_apply_3(x_3, x_67, x_7, x_47);
if (lean_obj_tag(x_68) == 0)
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
x_69 = lean_ctor_get(x_68, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_68, 1);
lean_inc(x_70);
lean_dec(x_68);
x_71 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_71, 0, x_13);
lean_closure_set(x_71, 1, x_4);
x_72 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_69, x_71, x_7, x_70);
return x_72;
}
else
{
lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_73 = lean_ctor_get(x_68, 0);
lean_inc(x_73);
x_74 = lean_ctor_get(x_68, 1);
lean_inc(x_74);
if (lean_is_exclusive(x_68)) {
 lean_ctor_release(x_68, 0);
 lean_ctor_release(x_68, 1);
 x_75 = x_68;
} else {
 lean_dec_ref(x_68);
 x_75 = lean_box(0);
}
if (lean_is_scalar(x_75)) {
 x_76 = lean_alloc_ctor(1, 2, 0);
} else {
 x_76 = x_75;
}
lean_ctor_set(x_76, 0, x_73);
lean_ctor_set(x_76, 1, x_74);
return x_76;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1___boxed), 1, 0);
x_5 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___boxed), 8, 4);
lean_closure_set(x_5, 0, x_1);
lean_closure_set(x_5, 1, x_3);
lean_closure_set(x_5, 2, x_2);
lean_closure_set(x_5, 3, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ppExprTagged", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1;
x_2 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_ppExprTagged), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ppExprTagged___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2;
x_2 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3;
x_3 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__1(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint64_t x_9; lean_object* x_10; 
x_9 = lean_unbox_uint64(x_5);
lean_dec(x_5);
x_10 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4(x_1, x_2, x_3, x_4, x_9, x_6, x_7, x_8);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveExpr___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("window;import{jsx as e,jsxs as r,Fragment as o}from\"react/jsx-runtime\";import{useRpcSession as t,useAsyncPersistent as a,InteractiveCode as i,mapRpcError as n}from\"@leanprover/infoview\";function d({expr:d}){const p=t(),s=a((()=>p.call(\"ProofWidgets.ppExprTagged\",{expr:d})),[d]);return\"resolved\"===s.state\?e(i,{fmt:s.value}):\"rejected\"===s.state\?r(o,{children:[\"Error: $\",n(s.error).message]}):e(o,{children:\"Loading..\"})}export{d as default};", 443, 443);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_InteractiveExpr___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_InteractiveExpr___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveExpr___closed__2___boxed__const__1() {
_start:
{
uint64_t x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_InteractiveExpr___closed__1;
x_2 = lean_box_uint64(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveExpr___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveExpr___closed__0;
x_2 = l_ProofWidgets_InteractiveExpr___closed__2___boxed__const__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveExpr___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__3;
x_2 = l_ProofWidgets_InteractiveExpr___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveExpr() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_InteractiveExpr___closed__3;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_670_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("msg", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_670_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_670_;
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Extra_0__Lean_Lsp_fromJsonRpcCallParams____x40_Lean_Data_Lsp_Extra___hyg_3570__spec__1(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_750_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_670_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_750_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_750_;
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_753_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_670_;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
x_8 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_165_;
x_9 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_7, x_8);
x_10 = l_Lean_Json_mkObj(x_9);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_788_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_753_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_788_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_788_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic___hyg_636_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; uint8_t x_5; 
x_3 = l_Lean_instImpl____x40_Lean_Message___hyg_789_;
x_4 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcEncode___redArg(x_3, x_1, x_2);
x_5 = !lean_is_exclusive(x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_ctor_get(x_4, 0);
x_7 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_753_(x_6);
lean_ctor_set(x_4, 0, x_7);
return x_4;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_4, 0);
x_9 = lean_ctor_get(x_4, 1);
lean_inc(x_9);
lean_inc(x_8);
lean_dec(x_4);
x_10 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_753_(x_8);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_9);
return x_11;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic___hyg_636____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic___hyg_636_(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableInteractiveMessageProps_dec____x40_ProofWidgets_Component_Basic___hyg_636_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_670_(x_1);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
lean_dec(x_3);
x_5 = l_Lean_instImpl____x40_Lean_Message___hyg_789_;
x_6 = l_Lean_Server_instRpcEncodableWithRpcRefOfTypeName_rpcDecode___redArg(x_5, x_4, x_2);
if (lean_obj_tag(x_6) == 0)
{
uint8_t x_7; 
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
return x_6;
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_6, 0);
lean_inc(x_8);
lean_dec(x_6);
x_9 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_9, 0, x_8);
return x_9;
}
}
else
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_6);
if (x_10 == 0)
{
return x_6;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_6, 0);
lean_inc(x_11);
lean_dec(x_6);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveMessageProps_enc____x40_ProofWidgets_Component_Basic___hyg_636____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableInteractiveMessageProps_dec____x40_ProofWidgets_Component_Basic___hyg_636_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveMessage___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\n    import { InteractiveMessageData } from '@leanprover/infoview'\n    import * as React from 'react'\n    export default function(props) {\n      return React.createElement(InteractiveMessageData, props)\n    }\n  ", 211, 211);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_InteractiveMessage___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_InteractiveMessage___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveMessage___closed__2___boxed__const__1() {
_start:
{
uint64_t x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_InteractiveMessage___closed__1;
x_2 = lean_box_uint64(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveMessage___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveMessage___closed__0;
x_2 = l_ProofWidgets_InteractiveMessage___closed__2___boxed__const__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveMessage___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__3;
x_2 = l_ProofWidgets_InteractiveMessage___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_InteractiveMessage() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_InteractiveMessage___closed__3;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_924_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("contents", 8, 8);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps____x40_ProofWidgets_Component_Basic___hyg_924_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_924_;
x_3 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_3, 0, x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_2);
lean_ctor_set(x_4, 1, x_3);
x_5 = lean_box(0);
x_6 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_6, 0, x_4);
lean_ctor_set(x_6, 1, x_5);
x_7 = lean_box(0);
x_8 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_8, 0, x_6);
lean_ctor_set(x_8, 1, x_7);
x_9 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_165_;
x_10 = l_List_flatMapTR_go___at_____private_Lean_Data_Lsp_Window_0__toJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_250__spec__0(x_8, x_9);
x_11 = l_Lean_Json_mkObj(x_10);
return x_11;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps____x40_ProofWidgets_Component_Basic___hyg_924_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__1____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("MarkdownDisplay", 15, 15);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__2____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Props", 5, 5);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__3____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__2____x40_ProofWidgets_Component_Basic___hyg_962_;
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__1____x40_ProofWidgets_Component_Basic___hyg_962_;
x_3 = l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0;
x_4 = l_Lean_Name_mkStr3(x_3, x_2, x_1);
return x_4;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__4____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; lean_object* x_5; 
x_1 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_962_;
x_2 = lean_box(1);
x_3 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__3____x40_ProofWidgets_Component_Basic___hyg_962_;
x_4 = lean_unbox(x_2);
x_5 = l_Lean_Name_toString(x_3, x_4, x_1);
return x_5;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__5____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(".", 1, 1);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__6____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__5____x40_ProofWidgets_Component_Basic___hyg_962_;
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__4____x40_ProofWidgets_Component_Basic___hyg_962_;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__7____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_924_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__8____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; lean_object* x_5; 
x_1 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_962_;
x_2 = lean_box(1);
x_3 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__7____x40_ProofWidgets_Component_Basic___hyg_962_;
x_4 = lean_unbox(x_2);
x_5 = l_Lean_Name_toString(x_3, x_4, x_1);
return x_5;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__9____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__8____x40_ProofWidgets_Component_Basic___hyg_962_;
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__6____x40_ProofWidgets_Component_Basic___hyg_962_;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__10____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(": ", 2, 2);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__11____x40_ProofWidgets_Component_Basic___hyg_962_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__10____x40_ProofWidgets_Component_Basic___hyg_962_;
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__9____x40_ProofWidgets_Component_Basic___hyg_962_;
x_3 = lean_string_append(x_2, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps____x40_ProofWidgets_Component_Basic___hyg_962_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; 
x_2 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_924_;
x_3 = l_Lean_Json_getObjValAs_x3f___at_____private_Lean_Data_Lsp_Window_0__fromJsonShowMessageParams____x40_Lean_Data_Lsp_Window___hyg_144__spec__1(x_1, x_2);
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__11____x40_ProofWidgets_Component_Basic___hyg_962_;
x_7 = lean_string_append(x_6, x_5);
lean_dec(x_5);
lean_ctor_set(x_3, 0, x_7);
return x_3;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec(x_3);
x_9 = l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__11____x40_ProofWidgets_Component_Basic___hyg_962_;
x_10 = lean_string_append(x_9, x_8);
lean_dec(x_8);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
return x_11;
}
}
else
{
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_3);
if (x_12 == 0)
{
lean_ctor_set_tag(x_3, 0);
return x_3;
}
else
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_3, 0);
lean_inc(x_13);
lean_dec(x_3);
x_14 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_14, 0, x_13);
return x_14;
}
}
else
{
uint8_t x_15; 
x_15 = !lean_is_exclusive(x_3);
if (x_15 == 0)
{
return x_3;
}
else
{
lean_object* x_16; lean_object* x_17; 
x_16 = lean_ctor_get(x_3, 0);
lean_inc(x_16);
lean_dec(x_3);
x_17 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_17, 0, x_16);
return x_17;
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps____x40_ProofWidgets_Component_Basic___hyg_962_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("\n    import { Markdown } from '@leanprover/infoview'\n    import * as React from 'react'\n    export default (props) => React.createElement(Markdown, props)\n  ", 157, 157);
return x_1;
}
}
static uint64_t _init_l_ProofWidgets_MarkdownDisplay___closed__1() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_MarkdownDisplay___closed__0;
x_2 = lean_string_hash(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay___closed__2___boxed__const__1() {
_start:
{
uint64_t x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_MarkdownDisplay___closed__1;
x_2 = lean_box_uint64(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_MarkdownDisplay___closed__0;
x_2 = l_ProofWidgets_MarkdownDisplay___closed__2___boxed__const__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_InteractiveCode___closed__3;
x_2 = l_ProofWidgets_MarkdownDisplay___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_MarkdownDisplay() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_MarkdownDisplay___closed__3;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_8 = lean_ctor_get(x_2, 0);
lean_inc(x_8);
lean_dec(x_2);
x_9 = lean_ctor_get(x_8, 1);
lean_inc(x_9);
lean_dec(x_8);
x_10 = !lean_is_exclusive(x_1);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; uint64_t x_14; lean_object* x_15; 
x_11 = lean_ctor_get(x_1, 0);
x_12 = lean_ctor_get(x_1, 1);
lean_dec(x_12);
x_13 = lean_apply_1(x_11, x_3);
x_14 = lean_unbox_uint64(x_9);
lean_dec(x_9);
x_15 = l_Lean_Widget_WidgetInstance_ofHash(x_14, x_13, x_5, x_6, x_7);
if (lean_obj_tag(x_15) == 0)
{
uint8_t x_16; 
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_17 = lean_ctor_get(x_15, 0);
x_18 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_18, 0, x_4);
x_19 = l_Lean_MessageData_ofFormat(x_18);
lean_ctor_set_tag(x_1, 2);
lean_ctor_set(x_1, 1, x_19);
lean_ctor_set(x_1, 0, x_17);
lean_ctor_set(x_15, 0, x_1);
return x_15;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_20 = lean_ctor_get(x_15, 0);
x_21 = lean_ctor_get(x_15, 1);
lean_inc(x_21);
lean_inc(x_20);
lean_dec(x_15);
x_22 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_22, 0, x_4);
x_23 = l_Lean_MessageData_ofFormat(x_22);
lean_ctor_set_tag(x_1, 2);
lean_ctor_set(x_1, 1, x_23);
lean_ctor_set(x_1, 0, x_20);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_1);
lean_ctor_set(x_24, 1, x_21);
return x_24;
}
}
else
{
uint8_t x_25; 
lean_free_object(x_1);
lean_dec(x_4);
x_25 = !lean_is_exclusive(x_15);
if (x_25 == 0)
{
return x_15;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_15, 0);
x_27 = lean_ctor_get(x_15, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_15);
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_26);
lean_ctor_set(x_28, 1, x_27);
return x_28;
}
}
}
else
{
lean_object* x_29; lean_object* x_30; uint64_t x_31; lean_object* x_32; 
x_29 = lean_ctor_get(x_1, 0);
lean_inc(x_29);
lean_dec(x_1);
x_30 = lean_apply_1(x_29, x_3);
x_31 = lean_unbox_uint64(x_9);
lean_dec(x_9);
x_32 = l_Lean_Widget_WidgetInstance_ofHash(x_31, x_30, x_5, x_6, x_7);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
x_34 = lean_ctor_get(x_32, 1);
lean_inc(x_34);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 lean_ctor_release(x_32, 1);
 x_35 = x_32;
} else {
 lean_dec_ref(x_32);
 x_35 = lean_box(0);
}
x_36 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_36, 0, x_4);
x_37 = l_Lean_MessageData_ofFormat(x_36);
x_38 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_38, 0, x_33);
lean_ctor_set(x_38, 1, x_37);
if (lean_is_scalar(x_35)) {
 x_39 = lean_alloc_ctor(0, 2, 0);
} else {
 x_39 = x_35;
}
lean_ctor_set(x_39, 0, x_38);
lean_ctor_set(x_39, 1, x_34);
return x_39;
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_4);
x_40 = lean_ctor_get(x_32, 0);
lean_inc(x_40);
x_41 = lean_ctor_get(x_32, 1);
lean_inc(x_41);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 lean_ctor_release(x_32, 1);
 x_42 = x_32;
} else {
 lean_dec_ref(x_32);
 x_42 = lean_box(0);
}
if (lean_is_scalar(x_42)) {
 x_43 = lean_alloc_ctor(1, 2, 0);
} else {
 x_43 = x_42;
}
lean_ctor_set(x_43, 0, x_40);
lean_ctor_set(x_43, 1, x_41);
return x_43;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_MessageData_ofComponent___redArg(x_2, x_3, x_4, x_5, x_6, x_7, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Lean_MessageData_ofComponent___redArg(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Lean_MessageData_ofComponent___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_MessageData_ofComponent(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec(x_6);
return x_9;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Widget_InteractiveCode(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Widget_UserWidget(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Compat(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Component_Basic(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Widget_InteractiveCode(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Widget_UserWidget(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Compat(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_82_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_82_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_82_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_162_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_162_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_162_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_162_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_162_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_162_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_165_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_165_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_165_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_200_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_200_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_200_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_200_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_200_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_200_);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_ = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_enc___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_ = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps_dec___closed__0____x40_ProofWidgets_Component_Basic___hyg_49_);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0 = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__0);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1 = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__1);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2 = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps___closed__2);
l_ProofWidgets_instRpcEncodableInteractiveCodeProps = _init_l_ProofWidgets_instRpcEncodableInteractiveCodeProps();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveCodeProps);
l_ProofWidgets_InteractiveCode___closed__0 = _init_l_ProofWidgets_InteractiveCode___closed__0();
lean_mark_persistent(l_ProofWidgets_InteractiveCode___closed__0);
l_ProofWidgets_InteractiveCode___closed__1 = _init_l_ProofWidgets_InteractiveCode___closed__1();
l_ProofWidgets_InteractiveCode___closed__2___boxed__const__1 = _init_l_ProofWidgets_InteractiveCode___closed__2___boxed__const__1();
lean_mark_persistent(l_ProofWidgets_InteractiveCode___closed__2___boxed__const__1);
l_ProofWidgets_InteractiveCode___closed__2 = _init_l_ProofWidgets_InteractiveCode___closed__2();
lean_mark_persistent(l_ProofWidgets_InteractiveCode___closed__2);
l_ProofWidgets_InteractiveCode___closed__3 = _init_l_ProofWidgets_InteractiveCode___closed__3();
lean_mark_persistent(l_ProofWidgets_InteractiveCode___closed__3);
l_ProofWidgets_InteractiveCode___closed__4 = _init_l_ProofWidgets_InteractiveCode___closed__4();
lean_mark_persistent(l_ProofWidgets_InteractiveCode___closed__4);
l_ProofWidgets_InteractiveCode = _init_l_ProofWidgets_InteractiveCode();
lean_mark_persistent(l_ProofWidgets_InteractiveCode);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_350_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_350_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_350_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_430_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_430_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_430_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_430_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_430_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_430_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_468_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_468_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_468_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_468_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_468_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_468_);
l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0 = _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__0);
l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1 = _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__1);
l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2 = _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveExprProps___closed__2);
l_ProofWidgets_instRpcEncodableInteractiveExprProps = _init_l_ProofWidgets_instRpcEncodableInteractiveExprProps();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveExprProps);
l_ProofWidgets_ppExprTagged___lam__0___closed__0 = _init_l_ProofWidgets_ppExprTagged___lam__0___closed__0();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___lam__0___closed__0);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__0 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__0();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__0);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__1 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__1();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__1);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__2 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__2();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__2);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__3 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__3();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__3);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__4 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__4();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_ppExprTagged___rpc__wrapped_spec__0___lam__4___closed__4);
l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0 = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__0);
l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1 = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__1);
l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2 = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__2);
l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3 = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped___closed__3);
l_ProofWidgets_ppExprTagged___rpc__wrapped = _init_l_ProofWidgets_ppExprTagged___rpc__wrapped();
lean_mark_persistent(l_ProofWidgets_ppExprTagged___rpc__wrapped);
l_ProofWidgets_InteractiveExpr___closed__0 = _init_l_ProofWidgets_InteractiveExpr___closed__0();
lean_mark_persistent(l_ProofWidgets_InteractiveExpr___closed__0);
l_ProofWidgets_InteractiveExpr___closed__1 = _init_l_ProofWidgets_InteractiveExpr___closed__1();
l_ProofWidgets_InteractiveExpr___closed__2___boxed__const__1 = _init_l_ProofWidgets_InteractiveExpr___closed__2___boxed__const__1();
lean_mark_persistent(l_ProofWidgets_InteractiveExpr___closed__2___boxed__const__1);
l_ProofWidgets_InteractiveExpr___closed__2 = _init_l_ProofWidgets_InteractiveExpr___closed__2();
lean_mark_persistent(l_ProofWidgets_InteractiveExpr___closed__2);
l_ProofWidgets_InteractiveExpr___closed__3 = _init_l_ProofWidgets_InteractiveExpr___closed__3();
lean_mark_persistent(l_ProofWidgets_InteractiveExpr___closed__3);
l_ProofWidgets_InteractiveExpr = _init_l_ProofWidgets_InteractiveExpr();
lean_mark_persistent(l_ProofWidgets_InteractiveExpr);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_670_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_670_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_670_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_750_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_750_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_750_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_750_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_750_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_750_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_788_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_788_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Component_Basic___hyg_788_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_788_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_788_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Component_Basic___hyg_788_);
l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0 = _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__0);
l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1 = _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__1);
l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2 = _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveMessageProps___closed__2);
l_ProofWidgets_instRpcEncodableInteractiveMessageProps = _init_l_ProofWidgets_instRpcEncodableInteractiveMessageProps();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableInteractiveMessageProps);
l_ProofWidgets_InteractiveMessage___closed__0 = _init_l_ProofWidgets_InteractiveMessage___closed__0();
lean_mark_persistent(l_ProofWidgets_InteractiveMessage___closed__0);
l_ProofWidgets_InteractiveMessage___closed__1 = _init_l_ProofWidgets_InteractiveMessage___closed__1();
l_ProofWidgets_InteractiveMessage___closed__2___boxed__const__1 = _init_l_ProofWidgets_InteractiveMessage___closed__2___boxed__const__1();
lean_mark_persistent(l_ProofWidgets_InteractiveMessage___closed__2___boxed__const__1);
l_ProofWidgets_InteractiveMessage___closed__2 = _init_l_ProofWidgets_InteractiveMessage___closed__2();
lean_mark_persistent(l_ProofWidgets_InteractiveMessage___closed__2);
l_ProofWidgets_InteractiveMessage___closed__3 = _init_l_ProofWidgets_InteractiveMessage___closed__3();
lean_mark_persistent(l_ProofWidgets_InteractiveMessage___closed__3);
l_ProofWidgets_InteractiveMessage = _init_l_ProofWidgets_InteractiveMessage();
lean_mark_persistent(l_ProofWidgets_InteractiveMessage);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_924_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_924_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_toJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_924_);
l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0 = _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instToJsonProps___closed__0);
l_ProofWidgets_MarkdownDisplay_instToJsonProps = _init_l_ProofWidgets_MarkdownDisplay_instToJsonProps();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instToJsonProps);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__0____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__1____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__1____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__1____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__2____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__2____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__2____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__3____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__3____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__3____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__4____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__4____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__4____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__5____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__5____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__5____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__6____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__6____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__6____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__7____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__7____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__7____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__8____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__8____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__8____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__9____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__9____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__9____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__10____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__10____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__10____x40_ProofWidgets_Component_Basic___hyg_962_);
l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__11____x40_ProofWidgets_Component_Basic___hyg_962_ = _init_l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__11____x40_ProofWidgets_Component_Basic___hyg_962_();
lean_mark_persistent(l___private_ProofWidgets_Component_Basic_0__ProofWidgets_MarkdownDisplay_fromJsonProps___closed__11____x40_ProofWidgets_Component_Basic___hyg_962_);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0 = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps___closed__0);
l_ProofWidgets_MarkdownDisplay_instFromJsonProps = _init_l_ProofWidgets_MarkdownDisplay_instFromJsonProps();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay_instFromJsonProps);
l_ProofWidgets_MarkdownDisplay___closed__0 = _init_l_ProofWidgets_MarkdownDisplay___closed__0();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay___closed__0);
l_ProofWidgets_MarkdownDisplay___closed__1 = _init_l_ProofWidgets_MarkdownDisplay___closed__1();
l_ProofWidgets_MarkdownDisplay___closed__2___boxed__const__1 = _init_l_ProofWidgets_MarkdownDisplay___closed__2___boxed__const__1();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay___closed__2___boxed__const__1);
l_ProofWidgets_MarkdownDisplay___closed__2 = _init_l_ProofWidgets_MarkdownDisplay___closed__2();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay___closed__2);
l_ProofWidgets_MarkdownDisplay___closed__3 = _init_l_ProofWidgets_MarkdownDisplay___closed__3();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay___closed__3);
l_ProofWidgets_MarkdownDisplay = _init_l_ProofWidgets_MarkdownDisplay();
lean_mark_persistent(l_ProofWidgets_MarkdownDisplay);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
