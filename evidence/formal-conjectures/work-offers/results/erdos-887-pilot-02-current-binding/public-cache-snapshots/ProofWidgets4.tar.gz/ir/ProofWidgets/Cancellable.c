// Lean compiler output
// Module: ProofWidgets.Cancellable
// Imports: Init Lean.Data.Json.FromToJson Lean.Server.Rpc.RequestHandling Std.Data.HashMap ProofWidgets.Compat
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Expr_const___override(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable___hyg_966____boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__21____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* lean_io_cancel(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_384_;
lean_object* l_Lean_Json_compress(lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__3;
lean_object* l_Std_DHashMap_Internal_Raw_u2080_expand___redArg(lean_object*, lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_43_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_492_;
LEAN_EXPORT lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg___boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__25____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0(lean_object*, lean_object*);
lean_object* l_instBEqOfDecidableEq___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495____boxed(lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_966_;
size_t lean_uint64_to_usize(uint64_t);
lean_object* l_Lean_Name_toString(lean_object*, uint8_t, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* lean_array_push(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1____x40_ProofWidgets_Cancellable___hyg_384____boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable___hyg_966_(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
uint8_t lean_uint64_dec_lt(uint64_t, uint64_t);
lean_object* lean_mk_array(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_cancelRequest___lam__0___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__23____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable___hyg_343_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__24____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1;
lean_object* l_Lean_Server_ServerTask_mapCheap___redArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable___hyg_343_;
static lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
lean_object* l_Lean_stringToMessageData(lean_object*);
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_384_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__10____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable___hyg_343____boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2;
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_384_;
static lean_object* l_ProofWidgets_checkRequest___rpc__wrapped___closed__0;
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_384_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__19____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* l_Prod_map___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Std_DHashMap_Internal_AssocList_replace___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_384_;
static lean_object* l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__6____x40_ProofWidgets_Cancellable___hyg_966_;
size_t lean_usize_of_nat(lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable___hyg_966_(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable___hyg_966____boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_546_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__8____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_checkRequest___rpc__wrapped___closed__2;
lean_object* lean_st_ref_take(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_966_;
uint64_t lean_uint64_shift_right(uint64_t, uint64_t);
static lean_object* l_ProofWidgets_mkCancellable___redArg___closed__0;
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_384_;
lean_object* lean_nat_div(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0____x40_ProofWidgets_Cancellable___hyg_384_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable___hyg_966_(lean_object*);
static lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__15____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* l_instMonadEIO(lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__16____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_runningRequests;
static lean_object* l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_43_;
lean_object* lean_st_ref_get(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_43_;
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable___hyg_43_(lean_object*);
lean_object* l_Lean_Meta_mkAppM(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* lean_st_mk_ref(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__26____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* l_Lean_Name_num___override(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l_ProofWidgets_cancellableSuffix;
lean_object* l_Lean_Name_append(lean_object*, lean_object*);
lean_object* l_instHashableNat___lam__0___boxed(lean_object*);
static lean_object* l_ProofWidgets_mkCancellable___redArg___closed__1;
LEAN_EXPORT lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0(lean_object*, lean_object*, uint64_t);
lean_object* l_Lean_Server_RequestM_asTask___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_492_;
static lean_object* l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_495_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__7____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_cancellableSuffix___closed__0;
static lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0;
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__9____x40_ProofWidgets_Cancellable___hyg_966_;
uint8_t l_Std_DHashMap_Internal_AssocList_contains___at___Lean_Expr_CollectLooseBVars_main_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___rpc__wrapped;
lean_object* l_Except_orElseLazy___redArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* lean_task_get_own(lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_384_;
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__4;
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__1;
static lean_object* l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_checkRequest___lam__0___closed__0;
uint8_t l_Std_DHashMap_Internal_AssocList_contains___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc____x40_ProofWidgets_Cancellable___hyg_343_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_parseTagged(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Cancellable___hyg_384_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__20____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0___boxed(lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__28____x40_ProofWidgets_Cancellable___hyg_966_;
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_ReaderT_bind(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0(lean_object*);
static lean_object* l_ProofWidgets_cancellableSuffix___closed__1;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(lean_object*, uint64_t);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__12____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Cancellable___hyg_384_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__17____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse;
LEAN_EXPORT lean_object* l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_546_;
static lean_object* l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_43_;
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Cancellable___hyg_384_;
lean_object* lean_io_get_task_state(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint64_t lean_uint64_xor(uint64_t, uint64_t);
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__11____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* lean_nat_sub(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4(lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__1(lean_object*, lean_object*);
lean_object* l_Lean_Json_getNat_x3f(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1___boxed(lean_object*);
lean_object* l_Nat_nextPowerOfTwo(lean_object*);
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_384_;
lean_object* l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_object*, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__0;
static lean_object* l_ProofWidgets_checkRequest___rpc__wrapped___closed__1;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__13____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* l_Lean_registerBuiltinAttribute(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2;
lean_object* l_Lean_Server_RequestM_mapTaskCheap___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_uint64_dec_eq(uint64_t, uint64_t);
static lean_object* l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, uint64_t, lean_object*, lean_object*, lean_object*);
size_t lean_usize_sub(size_t, size_t);
static lean_object* l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__14____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* l_Std_DHashMap_Internal_AssocList_get_x3f___at___Int_Linear_Expr_applyPerm_go_spec__0___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_384_(lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable___hyg_966_;
lean_object* l_Lean_Server_registerRpcProcedure(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_384_;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg____x40_ProofWidgets_Cancellable___hyg_343_(lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__2;
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest(lean_object*, lean_object*, lean_object*);
lean_object* l_instDecidableEqNat___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0____x40_ProofWidgets_Cancellable___hyg_384____boxed(lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_throwUnknownIdentifierAt___at___Lean_throwUnknownConstantAt___at___Lean_filterFieldList___at___Lean_realizeGlobalConstCore_spec__0_spec__2_spec__2_spec__2_spec__2___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get_size(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0(lean_object*, lean_object*, lean_object*);
lean_object* lean_array_get(lean_object*, lean_object*, lean_object*);
lean_object* lean_infer_type(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
static uint64_t l_ProofWidgets_initFn___lam__1___closed__22____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1____x40_ProofWidgets_Cancellable___hyg_384_(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_addAndCompile(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_ofIoError(lean_object*);
static lean_object* l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_43_;
static lean_object* l_ProofWidgets_checkRequest___lam__0___closed__1;
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable___hyg_343_;
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0(lean_object*, lean_object*);
uint64_t l___private_Lean_Meta_Basic_0__Lean_Meta_Config_toKey(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__1___boxed(lean_object*, lean_object*);
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
static lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0;
static lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1;
static lean_object* l_ProofWidgets_initFn___lam__1___closed__27____x40_ProofWidgets_Cancellable___hyg_966_;
size_t lean_usize_land(size_t, size_t);
static lean_object* l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable___hyg_966_;
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg___boxed(lean_object*, lean_object*);
lean_object* l_Lean_Server_RequestError_invalidParams(lean_object*);
static lean_object* l_ProofWidgets_initFn___lam__1___closed__18____x40_ProofWidgets_Cancellable___hyg_966_;
static lean_object* l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_43_;
static lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0;
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable___hyg_343_(lean_object*, lean_object*);
static lean_object* _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_43_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_unsigned_to_nat(8u);
x_3 = lean_nat_mul(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_43_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_43_;
x_3 = lean_nat_div(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_43_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_43_;
x_2 = l_Nat_nextPowerOfTwo(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_43_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_43_;
x_3 = lean_mk_array(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_43_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_43_;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_43_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_43_;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable___hyg_43_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_43_;
x_3 = lean_st_mk_ref(x_2, x_1);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = lean_ctor_get(x_3, 1);
lean_inc(x_6);
lean_inc(x_5);
lean_dec(x_3);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
return x_7;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
uint8_t x_3; 
lean_dec(x_1);
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
return x_2;
}
else
{
lean_object* x_4; lean_object* x_5; 
x_4 = lean_ctor_get(x_2, 0);
lean_inc(x_4);
lean_dec(x_2);
x_5 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_5, 0, x_4);
return x_5;
}
}
else
{
lean_object* x_6; uint8_t x_7; 
x_6 = lean_ctor_get(x_1, 0);
lean_inc(x_6);
lean_dec(x_1);
x_7 = !lean_is_exclusive(x_2);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_2, 0);
x_9 = lean_apply_1(x_6, x_8);
lean_ctor_set(x_2, 0, x_9);
return x_2;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_2, 0);
lean_inc(x_10);
lean_dec(x_2);
x_11 = lean_apply_1(x_6, x_10);
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_11);
return x_12;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; uint8_t x_4; 
x_3 = lean_io_cancel(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = lean_ctor_get(x_3, 1);
lean_inc(x_6);
lean_inc(x_5);
lean_dec(x_3);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
return x_7;
}
}
}
static lean_object* _init_l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_runningRequests;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_alloc_closure((void*)(l_instDecidableEqNat___boxed), 2, 0);
x_2 = lean_alloc_closure((void*)(l_instBEqOfDecidableEq___redArg___lam__0___boxed), 3, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_6 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0;
x_7 = lean_st_ref_take(x_6, x_5);
x_8 = lean_ctor_get(x_7, 0);
lean_inc(x_8);
x_9 = lean_ctor_get(x_8, 1);
lean_inc(x_9);
x_10 = !lean_is_exclusive(x_7);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_11 = lean_ctor_get(x_7, 1);
x_12 = lean_ctor_get(x_7, 0);
lean_dec(x_12);
x_13 = lean_ctor_get(x_8, 0);
lean_inc(x_13);
if (lean_is_exclusive(x_8)) {
 lean_ctor_release(x_8, 0);
 lean_ctor_release(x_8, 1);
 x_14 = x_8;
} else {
 lean_dec_ref(x_8);
 x_14 = lean_box(0);
}
x_15 = !lean_is_exclusive(x_9);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_31; uint64_t x_32; uint64_t x_33; uint64_t x_34; uint64_t x_35; uint64_t x_36; uint64_t x_37; uint64_t x_38; size_t x_39; size_t x_40; size_t x_41; size_t x_42; size_t x_43; lean_object* x_44; uint8_t x_45; 
x_16 = lean_ctor_get(x_9, 0);
x_17 = lean_ctor_get(x_9, 1);
lean_inc(x_3);
x_18 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__1___boxed), 2, 1);
lean_closure_set(x_18, 0, x_3);
x_19 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1;
x_20 = l_Lean_Server_ServerTask_mapCheap___redArg(x_1, x_3);
x_21 = lean_unsigned_to_nat(1u);
x_22 = lean_nat_add(x_13, x_21);
lean_ctor_set(x_7, 1, x_18);
lean_ctor_set(x_7, 0, x_20);
x_31 = lean_array_get_size(x_17);
x_32 = lean_uint64_of_nat(x_13);
x_33 = 32;
x_34 = lean_uint64_shift_right(x_32, x_33);
x_35 = lean_uint64_xor(x_32, x_34);
x_36 = 16;
x_37 = lean_uint64_shift_right(x_35, x_36);
x_38 = lean_uint64_xor(x_35, x_37);
x_39 = lean_uint64_to_usize(x_38);
x_40 = lean_usize_of_nat(x_31);
lean_dec(x_31);
x_41 = 1;
x_42 = lean_usize_sub(x_40, x_41);
x_43 = lean_usize_land(x_39, x_42);
x_44 = lean_array_uget(x_17, x_43);
lean_inc(x_44);
lean_inc(x_13);
x_45 = l_Std_DHashMap_Internal_AssocList_contains___redArg(x_19, x_13, x_44);
if (x_45 == 0)
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; 
x_46 = lean_nat_add(x_16, x_21);
lean_dec(x_16);
lean_inc(x_13);
x_47 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_47, 0, x_13);
lean_ctor_set(x_47, 1, x_7);
lean_ctor_set(x_47, 2, x_44);
x_48 = lean_array_uset(x_17, x_43, x_47);
x_49 = lean_unsigned_to_nat(4u);
x_50 = lean_nat_mul(x_46, x_49);
x_51 = lean_unsigned_to_nat(3u);
x_52 = lean_nat_div(x_50, x_51);
lean_dec(x_50);
x_53 = lean_array_get_size(x_48);
x_54 = lean_nat_dec_le(x_52, x_53);
lean_dec(x_53);
lean_dec(x_52);
if (x_54 == 0)
{
lean_object* x_55; 
x_55 = l_Std_DHashMap_Internal_Raw_u2080_expand___redArg(x_2, x_48);
lean_ctor_set(x_9, 1, x_55);
lean_ctor_set(x_9, 0, x_46);
x_23 = x_9;
goto block_30;
}
else
{
lean_dec(x_2);
lean_ctor_set(x_9, 1, x_48);
lean_ctor_set(x_9, 0, x_46);
x_23 = x_9;
goto block_30;
}
}
else
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; 
lean_dec(x_2);
x_56 = lean_box(0);
x_57 = lean_array_uset(x_17, x_43, x_56);
lean_inc(x_13);
x_58 = l_Std_DHashMap_Internal_AssocList_replace___redArg(x_19, x_13, x_7, x_44);
x_59 = lean_array_uset(x_57, x_43, x_58);
lean_ctor_set(x_9, 1, x_59);
x_23 = x_9;
goto block_30;
}
block_30:
{
lean_object* x_24; lean_object* x_25; uint8_t x_26; 
if (lean_is_scalar(x_14)) {
 x_24 = lean_alloc_ctor(0, 2, 0);
} else {
 x_24 = x_14;
}
lean_ctor_set(x_24, 0, x_22);
lean_ctor_set(x_24, 1, x_23);
x_25 = lean_st_ref_set(x_6, x_24, x_11);
x_26 = !lean_is_exclusive(x_25);
if (x_26 == 0)
{
lean_object* x_27; 
x_27 = lean_ctor_get(x_25, 0);
lean_dec(x_27);
lean_ctor_set(x_25, 0, x_13);
return x_25;
}
else
{
lean_object* x_28; lean_object* x_29; 
x_28 = lean_ctor_get(x_25, 1);
lean_inc(x_28);
lean_dec(x_25);
x_29 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_29, 0, x_13);
lean_ctor_set(x_29, 1, x_28);
return x_29;
}
}
}
else
{
lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_74; uint64_t x_75; uint64_t x_76; uint64_t x_77; uint64_t x_78; uint64_t x_79; uint64_t x_80; uint64_t x_81; size_t x_82; size_t x_83; size_t x_84; size_t x_85; size_t x_86; lean_object* x_87; uint8_t x_88; 
x_60 = lean_ctor_get(x_9, 0);
x_61 = lean_ctor_get(x_9, 1);
lean_inc(x_61);
lean_inc(x_60);
lean_dec(x_9);
lean_inc(x_3);
x_62 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__1___boxed), 2, 1);
lean_closure_set(x_62, 0, x_3);
x_63 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1;
x_64 = l_Lean_Server_ServerTask_mapCheap___redArg(x_1, x_3);
x_65 = lean_unsigned_to_nat(1u);
x_66 = lean_nat_add(x_13, x_65);
lean_ctor_set(x_7, 1, x_62);
lean_ctor_set(x_7, 0, x_64);
x_74 = lean_array_get_size(x_61);
x_75 = lean_uint64_of_nat(x_13);
x_76 = 32;
x_77 = lean_uint64_shift_right(x_75, x_76);
x_78 = lean_uint64_xor(x_75, x_77);
x_79 = 16;
x_80 = lean_uint64_shift_right(x_78, x_79);
x_81 = lean_uint64_xor(x_78, x_80);
x_82 = lean_uint64_to_usize(x_81);
x_83 = lean_usize_of_nat(x_74);
lean_dec(x_74);
x_84 = 1;
x_85 = lean_usize_sub(x_83, x_84);
x_86 = lean_usize_land(x_82, x_85);
x_87 = lean_array_uget(x_61, x_86);
lean_inc(x_87);
lean_inc(x_13);
x_88 = l_Std_DHashMap_Internal_AssocList_contains___redArg(x_63, x_13, x_87);
if (x_88 == 0)
{
lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; uint8_t x_97; 
x_89 = lean_nat_add(x_60, x_65);
lean_dec(x_60);
lean_inc(x_13);
x_90 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_90, 0, x_13);
lean_ctor_set(x_90, 1, x_7);
lean_ctor_set(x_90, 2, x_87);
x_91 = lean_array_uset(x_61, x_86, x_90);
x_92 = lean_unsigned_to_nat(4u);
x_93 = lean_nat_mul(x_89, x_92);
x_94 = lean_unsigned_to_nat(3u);
x_95 = lean_nat_div(x_93, x_94);
lean_dec(x_93);
x_96 = lean_array_get_size(x_91);
x_97 = lean_nat_dec_le(x_95, x_96);
lean_dec(x_96);
lean_dec(x_95);
if (x_97 == 0)
{
lean_object* x_98; lean_object* x_99; 
x_98 = l_Std_DHashMap_Internal_Raw_u2080_expand___redArg(x_2, x_91);
x_99 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_99, 0, x_89);
lean_ctor_set(x_99, 1, x_98);
x_67 = x_99;
goto block_73;
}
else
{
lean_object* x_100; 
lean_dec(x_2);
x_100 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_100, 0, x_89);
lean_ctor_set(x_100, 1, x_91);
x_67 = x_100;
goto block_73;
}
}
else
{
lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; 
lean_dec(x_2);
x_101 = lean_box(0);
x_102 = lean_array_uset(x_61, x_86, x_101);
lean_inc(x_13);
x_103 = l_Std_DHashMap_Internal_AssocList_replace___redArg(x_63, x_13, x_7, x_87);
x_104 = lean_array_uset(x_102, x_86, x_103);
x_105 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_105, 0, x_60);
lean_ctor_set(x_105, 1, x_104);
x_67 = x_105;
goto block_73;
}
block_73:
{
lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
if (lean_is_scalar(x_14)) {
 x_68 = lean_alloc_ctor(0, 2, 0);
} else {
 x_68 = x_14;
}
lean_ctor_set(x_68, 0, x_66);
lean_ctor_set(x_68, 1, x_67);
x_69 = lean_st_ref_set(x_6, x_68, x_11);
x_70 = lean_ctor_get(x_69, 1);
lean_inc(x_70);
if (lean_is_exclusive(x_69)) {
 lean_ctor_release(x_69, 0);
 lean_ctor_release(x_69, 1);
 x_71 = x_69;
} else {
 lean_dec_ref(x_69);
 x_71 = lean_box(0);
}
if (lean_is_scalar(x_71)) {
 x_72 = lean_alloc_ctor(0, 2, 0);
} else {
 x_72 = x_71;
}
lean_ctor_set(x_72, 0, x_13);
lean_ctor_set(x_72, 1, x_70);
return x_72;
}
}
}
else
{
lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_124; lean_object* x_125; uint64_t x_126; uint64_t x_127; uint64_t x_128; uint64_t x_129; uint64_t x_130; uint64_t x_131; uint64_t x_132; size_t x_133; size_t x_134; size_t x_135; size_t x_136; size_t x_137; lean_object* x_138; uint8_t x_139; 
x_106 = lean_ctor_get(x_7, 1);
lean_inc(x_106);
lean_dec(x_7);
x_107 = lean_ctor_get(x_8, 0);
lean_inc(x_107);
if (lean_is_exclusive(x_8)) {
 lean_ctor_release(x_8, 0);
 lean_ctor_release(x_8, 1);
 x_108 = x_8;
} else {
 lean_dec_ref(x_8);
 x_108 = lean_box(0);
}
x_109 = lean_ctor_get(x_9, 0);
lean_inc(x_109);
x_110 = lean_ctor_get(x_9, 1);
lean_inc(x_110);
if (lean_is_exclusive(x_9)) {
 lean_ctor_release(x_9, 0);
 lean_ctor_release(x_9, 1);
 x_111 = x_9;
} else {
 lean_dec_ref(x_9);
 x_111 = lean_box(0);
}
lean_inc(x_3);
x_112 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__1___boxed), 2, 1);
lean_closure_set(x_112, 0, x_3);
x_113 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1;
x_114 = l_Lean_Server_ServerTask_mapCheap___redArg(x_1, x_3);
x_115 = lean_unsigned_to_nat(1u);
x_116 = lean_nat_add(x_107, x_115);
x_124 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_124, 0, x_114);
lean_ctor_set(x_124, 1, x_112);
x_125 = lean_array_get_size(x_110);
x_126 = lean_uint64_of_nat(x_107);
x_127 = 32;
x_128 = lean_uint64_shift_right(x_126, x_127);
x_129 = lean_uint64_xor(x_126, x_128);
x_130 = 16;
x_131 = lean_uint64_shift_right(x_129, x_130);
x_132 = lean_uint64_xor(x_129, x_131);
x_133 = lean_uint64_to_usize(x_132);
x_134 = lean_usize_of_nat(x_125);
lean_dec(x_125);
x_135 = 1;
x_136 = lean_usize_sub(x_134, x_135);
x_137 = lean_usize_land(x_133, x_136);
x_138 = lean_array_uget(x_110, x_137);
lean_inc(x_138);
lean_inc(x_107);
x_139 = l_Std_DHashMap_Internal_AssocList_contains___redArg(x_113, x_107, x_138);
if (x_139 == 0)
{
lean_object* x_140; lean_object* x_141; lean_object* x_142; lean_object* x_143; lean_object* x_144; lean_object* x_145; lean_object* x_146; lean_object* x_147; uint8_t x_148; 
x_140 = lean_nat_add(x_109, x_115);
lean_dec(x_109);
lean_inc(x_107);
x_141 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_141, 0, x_107);
lean_ctor_set(x_141, 1, x_124);
lean_ctor_set(x_141, 2, x_138);
x_142 = lean_array_uset(x_110, x_137, x_141);
x_143 = lean_unsigned_to_nat(4u);
x_144 = lean_nat_mul(x_140, x_143);
x_145 = lean_unsigned_to_nat(3u);
x_146 = lean_nat_div(x_144, x_145);
lean_dec(x_144);
x_147 = lean_array_get_size(x_142);
x_148 = lean_nat_dec_le(x_146, x_147);
lean_dec(x_147);
lean_dec(x_146);
if (x_148 == 0)
{
lean_object* x_149; lean_object* x_150; 
x_149 = l_Std_DHashMap_Internal_Raw_u2080_expand___redArg(x_2, x_142);
if (lean_is_scalar(x_111)) {
 x_150 = lean_alloc_ctor(0, 2, 0);
} else {
 x_150 = x_111;
}
lean_ctor_set(x_150, 0, x_140);
lean_ctor_set(x_150, 1, x_149);
x_117 = x_150;
goto block_123;
}
else
{
lean_object* x_151; 
lean_dec(x_2);
if (lean_is_scalar(x_111)) {
 x_151 = lean_alloc_ctor(0, 2, 0);
} else {
 x_151 = x_111;
}
lean_ctor_set(x_151, 0, x_140);
lean_ctor_set(x_151, 1, x_142);
x_117 = x_151;
goto block_123;
}
}
else
{
lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; 
lean_dec(x_2);
x_152 = lean_box(0);
x_153 = lean_array_uset(x_110, x_137, x_152);
lean_inc(x_107);
x_154 = l_Std_DHashMap_Internal_AssocList_replace___redArg(x_113, x_107, x_124, x_138);
x_155 = lean_array_uset(x_153, x_137, x_154);
if (lean_is_scalar(x_111)) {
 x_156 = lean_alloc_ctor(0, 2, 0);
} else {
 x_156 = x_111;
}
lean_ctor_set(x_156, 0, x_109);
lean_ctor_set(x_156, 1, x_155);
x_117 = x_156;
goto block_123;
}
block_123:
{
lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; 
if (lean_is_scalar(x_108)) {
 x_118 = lean_alloc_ctor(0, 2, 0);
} else {
 x_118 = x_108;
}
lean_ctor_set(x_118, 0, x_116);
lean_ctor_set(x_118, 1, x_117);
x_119 = lean_st_ref_set(x_6, x_118, x_106);
x_120 = lean_ctor_get(x_119, 1);
lean_inc(x_120);
if (lean_is_exclusive(x_119)) {
 lean_ctor_release(x_119, 0);
 lean_ctor_release(x_119, 1);
 x_121 = x_119;
} else {
 lean_dec_ref(x_119);
 x_121 = lean_box(0);
}
if (lean_is_scalar(x_121)) {
 x_122 = lean_alloc_ctor(0, 2, 0);
} else {
 x_122 = x_121;
}
lean_ctor_set(x_122, 0, x_107);
lean_ctor_set(x_122, 1, x_120);
return x_122;
}
}
}
}
static lean_object* _init_l_ProofWidgets_mkCancellable___redArg___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = l_instMonadEIO(lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_mkCancellable___redArg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_instHashableNat___lam__0___boxed), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_6 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__0), 2, 1);
lean_closure_set(x_6, 0, x_1);
x_7 = l_ProofWidgets_mkCancellable___redArg___closed__0;
x_8 = l_ProofWidgets_mkCancellable___redArg___closed__1;
x_9 = lean_alloc_closure((void*)(l_ProofWidgets_mkCancellable___redArg___lam__2___boxed), 5, 2);
lean_closure_set(x_9, 0, x_6);
lean_closure_set(x_9, 1, x_8);
x_10 = lean_apply_1(x_2, x_3);
x_11 = lean_alloc_closure((void*)(l_ReaderT_bind), 8, 7);
lean_closure_set(x_11, 0, lean_box(0));
lean_closure_set(x_11, 1, lean_box(0));
lean_closure_set(x_11, 2, x_7);
lean_closure_set(x_11, 3, lean_box(0));
lean_closure_set(x_11, 4, lean_box(0));
lean_closure_set(x_11, 5, x_10);
lean_closure_set(x_11, 6, x_9);
x_12 = l_Lean_Server_RequestM_asTask___redArg(x_11, x_4, x_5);
return x_12;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_ProofWidgets_mkCancellable___redArg(x_3, x_4, x_5, x_6, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_mkCancellable___redArg___lam__1(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_mkCancellable___redArg___lam__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_ProofWidgets_mkCancellable___redArg___lam__2(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
return x_2;
}
else
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_4 = lean_ctor_get(x_2, 0);
x_5 = lean_ctor_get(x_2, 1);
x_6 = lean_ctor_get(x_2, 2);
x_7 = lean_nat_dec_eq(x_4, x_1);
if (x_7 == 0)
{
lean_object* x_8; 
x_8 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_1, x_6);
lean_ctor_set(x_2, 2, x_8);
return x_2;
}
else
{
lean_free_object(x_2);
lean_dec(x_5);
lean_dec(x_4);
return x_6;
}
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_ctor_get(x_2, 0);
x_10 = lean_ctor_get(x_2, 1);
x_11 = lean_ctor_get(x_2, 2);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_dec(x_2);
x_12 = lean_nat_dec_eq(x_9, x_1);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; 
x_13 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_1, x_11);
x_14 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_14, 0, x_9);
lean_ctor_set(x_14, 1, x_10);
lean_ctor_set(x_14, 2, x_13);
return x_14;
}
else
{
lean_dec(x_10);
lean_dec(x_9);
return x_11;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ok", 2, 2);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; uint64_t x_18; uint64_t x_19; uint64_t x_20; uint64_t x_21; uint64_t x_22; uint64_t x_23; uint64_t x_24; size_t x_25; size_t x_26; size_t x_27; size_t x_28; size_t x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; uint8_t x_49; 
x_9 = lean_st_ref_take(x_1, x_4);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_10, 1);
lean_inc(x_11);
x_12 = lean_ctor_get(x_9, 1);
lean_inc(x_12);
lean_dec(x_9);
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
if (lean_is_exclusive(x_10)) {
 lean_ctor_release(x_10, 0);
 lean_ctor_release(x_10, 1);
 x_14 = x_10;
} else {
 lean_dec_ref(x_10);
 x_14 = lean_box(0);
}
x_15 = lean_ctor_get(x_11, 0);
lean_inc(x_15);
x_16 = lean_ctor_get(x_11, 1);
lean_inc(x_16);
x_17 = lean_array_get_size(x_16);
x_18 = lean_uint64_of_nat(x_2);
x_19 = 32;
x_20 = lean_uint64_shift_right(x_18, x_19);
x_21 = lean_uint64_xor(x_18, x_20);
x_22 = 16;
x_23 = lean_uint64_shift_right(x_21, x_22);
x_24 = lean_uint64_xor(x_21, x_23);
x_25 = lean_uint64_to_usize(x_24);
x_26 = lean_usize_of_nat(x_17);
lean_dec(x_17);
x_27 = 1;
x_28 = lean_usize_sub(x_26, x_27);
x_29 = lean_usize_land(x_25, x_28);
x_30 = lean_array_uget(x_16, x_29);
x_31 = l_Std_DHashMap_Internal_AssocList_get_x3f___at___Int_Linear_Expr_applyPerm_go_spec__0___redArg(x_2, x_30);
x_49 = l_Std_DHashMap_Internal_AssocList_contains___at___Lean_Expr_CollectLooseBVars_main_spec__0___redArg(x_2, x_30);
if (x_49 == 0)
{
lean_dec(x_30);
lean_dec(x_16);
lean_dec(x_15);
x_32 = x_11;
goto block_48;
}
else
{
uint8_t x_50; 
x_50 = !lean_is_exclusive(x_11);
if (x_50 == 0)
{
lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; 
x_51 = lean_ctor_get(x_11, 1);
lean_dec(x_51);
x_52 = lean_ctor_get(x_11, 0);
lean_dec(x_52);
x_53 = lean_box(0);
x_54 = lean_array_uset(x_16, x_29, x_53);
x_55 = lean_unsigned_to_nat(1u);
x_56 = lean_nat_sub(x_15, x_55);
lean_dec(x_15);
x_57 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_2, x_30);
x_58 = lean_array_uset(x_54, x_29, x_57);
lean_ctor_set(x_11, 1, x_58);
lean_ctor_set(x_11, 0, x_56);
x_32 = x_11;
goto block_48;
}
else
{
lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; 
lean_dec(x_11);
x_59 = lean_box(0);
x_60 = lean_array_uset(x_16, x_29, x_59);
x_61 = lean_unsigned_to_nat(1u);
x_62 = lean_nat_sub(x_15, x_61);
lean_dec(x_15);
x_63 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_2, x_30);
x_64 = lean_array_uset(x_60, x_29, x_63);
x_65 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_65, 0, x_62);
lean_ctor_set(x_65, 1, x_64);
x_32 = x_65;
goto block_48;
}
}
block_8:
{
lean_object* x_6; lean_object* x_7; 
x_6 = l_ProofWidgets_cancelRequest___lam__0___closed__0;
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
block_48:
{
lean_object* x_33; lean_object* x_34; 
if (lean_is_scalar(x_14)) {
 x_33 = lean_alloc_ctor(0, 2, 0);
} else {
 x_33 = x_14;
}
lean_ctor_set(x_33, 0, x_13);
lean_ctor_set(x_33, 1, x_32);
x_34 = lean_st_ref_set(x_1, x_33, x_12);
if (lean_obj_tag(x_31) == 0)
{
lean_object* x_35; 
x_35 = lean_ctor_get(x_34, 1);
lean_inc(x_35);
lean_dec(x_34);
x_5 = x_35;
goto block_8;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_36 = lean_ctor_get(x_31, 0);
lean_inc(x_36);
lean_dec(x_31);
x_37 = lean_ctor_get(x_34, 1);
lean_inc(x_37);
lean_dec(x_34);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec(x_36);
x_39 = lean_apply_1(x_38, x_37);
if (lean_obj_tag(x_39) == 0)
{
lean_object* x_40; 
x_40 = lean_ctor_get(x_39, 1);
lean_inc(x_40);
lean_dec(x_39);
x_5 = x_40;
goto block_8;
}
else
{
uint8_t x_41; 
x_41 = !lean_is_exclusive(x_39);
if (x_41 == 0)
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_ctor_get(x_39, 0);
x_43 = l_Lean_Server_RequestError_ofIoError(x_42);
lean_ctor_set(x_39, 0, x_43);
return x_39;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; 
x_44 = lean_ctor_get(x_39, 0);
x_45 = lean_ctor_get(x_39, 1);
lean_inc(x_45);
lean_inc(x_44);
lean_dec(x_39);
x_46 = l_Lean_Server_RequestError_ofIoError(x_44);
x_47 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_47, 0, x_46);
lean_ctor_set(x_47, 1, x_45);
return x_47;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_4 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0;
x_5 = lean_alloc_closure((void*)(l_ProofWidgets_cancelRequest___lam__0___boxed), 4, 2);
lean_closure_set(x_5, 0, x_4);
lean_closure_set(x_5, 1, x_1);
x_6 = l_Lean_Server_RequestM_asTask___redArg(x_5, x_2, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0(x_1, x_2, x_3);
lean_dec(x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_cancelRequest___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_cancelRequest___lam__0(x_1, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(lean_object* x_1, uint64_t x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; 
x_3 = lean_box(0);
return x_3;
}
else
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; uint8_t x_9; 
x_4 = lean_ctor_get(x_1, 0);
lean_inc(x_4);
x_5 = lean_ctor_get(x_1, 1);
lean_inc(x_5);
x_6 = lean_ctor_get(x_1, 2);
lean_inc(x_6);
x_7 = lean_ctor_get(x_1, 3);
lean_inc(x_7);
lean_dec(x_1);
x_8 = lean_unbox_uint64(x_5);
x_9 = lean_uint64_dec_lt(x_2, x_8);
if (x_9 == 0)
{
uint64_t x_10; uint8_t x_11; 
lean_dec(x_4);
x_10 = lean_unbox_uint64(x_5);
lean_dec(x_5);
x_11 = lean_uint64_dec_eq(x_2, x_10);
if (x_11 == 0)
{
lean_dec(x_6);
x_1 = x_7;
goto _start;
}
else
{
lean_object* x_13; 
lean_dec(x_7);
x_13 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_13, 0, x_6);
return x_13;
}
}
else
{
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
x_1 = x_4;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0(lean_object* x_1, lean_object* x_2, uint64_t x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_2, x_3);
return x_4;
}
}
LEAN_EXPORT uint8_t l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = lean_box(0);
x_3 = lean_unbox(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_3);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = !lean_is_exclusive(x_10);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_13 = lean_ctor_get(x_10, 0);
x_14 = lean_ctor_get(x_10, 1);
x_15 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2), 2, 1);
lean_closure_set(x_15, 0, x_14);
lean_ctor_set_tag(x_3, 3);
lean_ctor_set(x_10, 1, x_13);
lean_ctor_set(x_10, 0, x_3);
x_16 = l_Prod_map___redArg(x_2, x_15, x_10);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; 
x_24 = lean_ctor_get(x_10, 0);
x_25 = lean_ctor_get(x_10, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_10);
x_26 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2), 2, 1);
lean_closure_set(x_26, 0, x_25);
lean_ctor_set_tag(x_3, 3);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_3);
lean_ctor_set(x_27, 1, x_24);
x_28 = l_Prod_map___redArg(x_2, x_26, x_27);
x_29 = lean_ctor_get(x_28, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_28, 1);
lean_inc(x_30);
lean_dec(x_28);
x_31 = lean_st_ref_set(x_1, x_30, x_11);
x_32 = lean_ctor_get(x_31, 1);
lean_inc(x_32);
if (lean_is_exclusive(x_31)) {
 lean_ctor_release(x_31, 0);
 lean_ctor_release(x_31, 1);
 x_33 = x_31;
} else {
 lean_dec_ref(x_31);
 x_33 = lean_box(0);
}
if (lean_is_scalar(x_33)) {
 x_34 = lean_alloc_ctor(0, 2, 0);
} else {
 x_34 = x_33;
}
lean_ctor_set(x_34, 0, x_29);
lean_ctor_set(x_34, 1, x_32);
return x_34;
}
}
else
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
x_35 = lean_ctor_get(x_3, 0);
lean_inc(x_35);
lean_dec(x_3);
x_36 = lean_st_ref_take(x_1, x_5);
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec(x_36);
x_39 = lean_ctor_get(x_37, 0);
lean_inc(x_39);
x_40 = lean_ctor_get(x_37, 1);
lean_inc(x_40);
if (lean_is_exclusive(x_37)) {
 lean_ctor_release(x_37, 0);
 lean_ctor_release(x_37, 1);
 x_41 = x_37;
} else {
 lean_dec_ref(x_37);
 x_41 = lean_box(0);
}
x_42 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2), 2, 1);
lean_closure_set(x_42, 0, x_40);
x_43 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_43, 0, x_35);
if (lean_is_scalar(x_41)) {
 x_44 = lean_alloc_ctor(0, 2, 0);
} else {
 x_44 = x_41;
}
lean_ctor_set(x_44, 0, x_43);
lean_ctor_set(x_44, 1, x_39);
x_45 = l_Prod_map___redArg(x_2, x_42, x_44);
x_46 = lean_ctor_get(x_45, 0);
lean_inc(x_46);
x_47 = lean_ctor_get(x_45, 1);
lean_inc(x_47);
lean_dec(x_45);
x_48 = lean_st_ref_set(x_1, x_47, x_38);
x_49 = lean_ctor_get(x_48, 1);
lean_inc(x_49);
if (lean_is_exclusive(x_48)) {
 lean_ctor_release(x_48, 0);
 lean_ctor_release(x_48, 1);
 x_50 = x_48;
} else {
 lean_dec_ref(x_48);
 x_50 = lean_box(0);
}
if (lean_is_scalar(x_50)) {
 x_51 = lean_alloc_ctor(0, 2, 0);
} else {
 x_51 = x_50;
}
lean_ctor_set(x_51, 0, x_46);
lean_ctor_set(x_51, 1, x_49);
return x_51;
}
}
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Outdated RPC session", 20, 20);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_1 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__0;
x_2 = lean_box(9);
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
x_4 = lean_unbox(x_2);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_4);
return x_3;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cannot decode params in RPC call '", 34, 34);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")'\n", 3, 3);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, uint64_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
x_10 = l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_9, x_5);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_11 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__1;
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_st_ref_get(x_13, x_8);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_16 = lean_ctor_get(x_14, 1);
x_17 = lean_ctor_get(x_14, 0);
lean_dec(x_17);
lean_inc(x_6);
x_18 = l_Lean_Json_getNat_x3f(x_6);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; uint8_t x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; uint8_t x_34; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
lean_dec(x_18);
x_20 = lean_box(3);
x_21 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__2;
x_22 = lean_box(1);
x_23 = lean_unbox(x_22);
x_24 = l_Lean_Name_toString(x_1, x_23, x_2);
x_25 = lean_string_append(x_21, x_24);
lean_dec(x_24);
x_26 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__3;
x_27 = lean_string_append(x_25, x_26);
x_28 = l_Lean_Json_compress(x_6);
x_29 = lean_string_append(x_27, x_28);
lean_dec(x_28);
x_30 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__4;
x_31 = lean_string_append(x_29, x_30);
x_32 = lean_string_append(x_31, x_19);
lean_dec(x_19);
x_33 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_33, 0, x_32);
x_34 = lean_unbox(x_20);
lean_ctor_set_uint8(x_33, sizeof(void*)*1, x_34);
lean_ctor_set_tag(x_14, 1);
lean_ctor_set(x_14, 0, x_33);
return x_14;
}
else
{
lean_object* x_35; lean_object* x_36; 
lean_free_object(x_14);
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_35 = lean_ctor_get(x_18, 0);
lean_inc(x_35);
lean_dec(x_18);
lean_inc(x_7);
x_36 = lean_apply_3(x_3, x_35, x_7, x_16);
if (lean_obj_tag(x_36) == 0)
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; 
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec(x_36);
x_39 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_39, 0, x_13);
lean_closure_set(x_39, 1, x_4);
x_40 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_37, x_39, x_7, x_38);
return x_40;
}
else
{
uint8_t x_41; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_41 = !lean_is_exclusive(x_36);
if (x_41 == 0)
{
return x_36;
}
else
{
lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_42 = lean_ctor_get(x_36, 0);
x_43 = lean_ctor_get(x_36, 1);
lean_inc(x_43);
lean_inc(x_42);
lean_dec(x_36);
x_44 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_44, 0, x_42);
lean_ctor_set(x_44, 1, x_43);
return x_44;
}
}
}
}
else
{
lean_object* x_45; lean_object* x_46; 
x_45 = lean_ctor_get(x_14, 1);
lean_inc(x_45);
lean_dec(x_14);
lean_inc(x_6);
x_46 = l_Lean_Json_getNat_x3f(x_6);
if (lean_obj_tag(x_46) == 0)
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; uint8_t x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; uint8_t x_62; lean_object* x_63; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_47 = lean_ctor_get(x_46, 0);
lean_inc(x_47);
lean_dec(x_46);
x_48 = lean_box(3);
x_49 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__2;
x_50 = lean_box(1);
x_51 = lean_unbox(x_50);
x_52 = l_Lean_Name_toString(x_1, x_51, x_2);
x_53 = lean_string_append(x_49, x_52);
lean_dec(x_52);
x_54 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__3;
x_55 = lean_string_append(x_53, x_54);
x_56 = l_Lean_Json_compress(x_6);
x_57 = lean_string_append(x_55, x_56);
lean_dec(x_56);
x_58 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__4;
x_59 = lean_string_append(x_57, x_58);
x_60 = lean_string_append(x_59, x_47);
lean_dec(x_47);
x_61 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_61, 0, x_60);
x_62 = lean_unbox(x_48);
lean_ctor_set_uint8(x_61, sizeof(void*)*1, x_62);
x_63 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_63, 0, x_61);
lean_ctor_set(x_63, 1, x_45);
return x_63;
}
else
{
lean_object* x_64; lean_object* x_65; 
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_64 = lean_ctor_get(x_46, 0);
lean_inc(x_64);
lean_dec(x_46);
lean_inc(x_7);
x_65 = lean_apply_3(x_3, x_64, x_7, x_45);
if (lean_obj_tag(x_65) == 0)
{
lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; 
x_66 = lean_ctor_get(x_65, 0);
lean_inc(x_66);
x_67 = lean_ctor_get(x_65, 1);
lean_inc(x_67);
lean_dec(x_65);
x_68 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_68, 0, x_13);
lean_closure_set(x_68, 1, x_4);
x_69 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_66, x_68, x_7, x_67);
return x_69;
}
else
{
lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_70 = lean_ctor_get(x_65, 0);
lean_inc(x_70);
x_71 = lean_ctor_get(x_65, 1);
lean_inc(x_71);
if (lean_is_exclusive(x_65)) {
 lean_ctor_release(x_65, 0);
 lean_ctor_release(x_65, 1);
 x_72 = x_65;
} else {
 lean_dec_ref(x_65);
 x_72 = lean_box(0);
}
if (lean_is_scalar(x_72)) {
 x_73 = lean_alloc_ctor(1, 2, 0);
} else {
 x_73 = x_72;
}
lean_ctor_set(x_73, 0, x_70);
lean_ctor_set(x_73, 1, x_71);
return x_73;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1___boxed), 1, 0);
x_5 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___boxed), 8, 4);
lean_closure_set(x_5, 0, x_1);
lean_closure_set(x_5, 1, x_3);
lean_closure_set(x_5, 2, x_2);
lean_closure_set(x_5, 3, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("cancelRequest", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1;
x_2 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_cancelRequest), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_cancelRequest___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2;
x_2 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3;
x_3 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint64_t x_3; lean_object* x_4; 
x_3 = lean_unbox_uint64(x_2);
lean_dec(x_2);
x_4 = l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_1, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint64_t x_4; lean_object* x_5; 
x_4 = lean_unbox_uint64(x_3);
lean_dec(x_3);
x_5 = l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0(x_1, x_2, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint64_t x_9; lean_object* x_10; 
x_9 = lean_unbox_uint64(x_5);
lean_dec(x_5);
x_10 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4(x_1, x_2, x_3, x_4, x_9, x_6, x_7, x_8);
return x_10;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("no inductive constructor matched", 32, 32);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_384_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0____x40_ProofWidgets_Cancellable___hyg_384_(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_384_;
return x_2;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("done", 4, 4);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("result", 6, 6);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_384_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_384_;
x_2 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_384_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_384_;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1____x40_ProofWidgets_Cancellable___hyg_384_(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_6 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_384_;
x_7 = lean_unsigned_to_nat(1u);
x_8 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_384_;
x_9 = l_Lean_Json_parseTagged(x_1, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_dec(x_3);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; 
x_11 = l_Except_orElseLazy___redArg(x_9, x_2);
lean_dec(x_9);
return x_11;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_12 = lean_ctor_get(x_9, 0);
lean_inc(x_12);
lean_dec(x_9);
x_13 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_13, 0, x_12);
x_14 = l_Except_orElseLazy___redArg(x_13, x_2);
lean_dec(x_13);
return x_14;
}
}
else
{
uint8_t x_15; 
x_15 = !lean_is_exclusive(x_9);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_16 = lean_ctor_get(x_9, 0);
x_17 = lean_array_get(x_3, x_16, x_4);
lean_dec(x_16);
x_18 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_9, 0, x_18);
x_19 = l_Except_orElseLazy___redArg(x_9, x_2);
lean_dec(x_9);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_20 = lean_ctor_get(x_9, 0);
lean_inc(x_20);
lean_dec(x_9);
x_21 = lean_array_get(x_3, x_20, x_4);
lean_dec(x_20);
x_22 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_22, 0, x_21);
x_23 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_23, 0, x_22);
x_24 = l_Except_orElseLazy___redArg(x_23, x_2);
lean_dec(x_23);
return x_24;
}
}
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("running", 7, 7);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Cancellable___hyg_384_;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Cancellable___hyg_384_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_384_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = lean_alloc_closure((void*)(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0____x40_ProofWidgets_Cancellable___hyg_384____boxed), 1, 0);
x_3 = lean_box(0);
x_4 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_384_;
x_5 = lean_unsigned_to_nat(0u);
lean_inc(x_1);
x_6 = lean_alloc_closure((void*)(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1____x40_ProofWidgets_Cancellable___hyg_384____boxed), 5, 4);
lean_closure_set(x_6, 0, x_1);
lean_closure_set(x_6, 1, x_2);
lean_closure_set(x_6, 2, x_3);
lean_closure_set(x_6, 3, x_5);
x_7 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Cancellable___hyg_384_;
x_8 = l_Lean_Json_parseTagged(x_1, x_4, x_5, x_7);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; 
x_10 = l_Except_orElseLazy___redArg(x_8, x_6);
lean_dec(x_8);
return x_10;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_11 = lean_ctor_get(x_8, 0);
lean_inc(x_11);
lean_dec(x_8);
x_12 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_12, 0, x_11);
x_13 = l_Except_orElseLazy___redArg(x_12, x_6);
lean_dec(x_12);
return x_13;
}
}
else
{
lean_object* x_14; lean_object* x_15; 
lean_dec(x_8);
x_14 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Cancellable___hyg_384_;
x_15 = l_Except_orElseLazy___redArg(x_14, x_6);
return x_15;
}
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0____x40_ProofWidgets_Cancellable___hyg_384____boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0____x40_ProofWidgets_Cancellable___hyg_384_(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1____x40_ProofWidgets_Cancellable___hyg_384____boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1____x40_ProofWidgets_Cancellable___hyg_384_(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_5);
lean_dec(x_4);
return x_6;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_492_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_384_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_492_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_492_;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_495_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_384_;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495_(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_495_;
return x_2;
}
else
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_3 = lean_ctor_get(x_1, 0);
x_4 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_384_;
x_5 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_384_;
lean_inc(x_3);
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_3);
x_7 = lean_box(0);
x_8 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_8, 0, x_6);
lean_ctor_set(x_8, 1, x_7);
x_9 = l_Lean_Json_mkObj(x_8);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_4);
lean_ctor_set(x_10, 1, x_9);
x_11 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
x_12 = l_Lean_Json_mkObj(x_11);
return x_12;
}
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495____boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495_(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_546_() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495____boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_546_() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_546_;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable___hyg_343_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495_(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc____x40_ProofWidgets_Cancellable___hyg_343_(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable___hyg_343_;
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
else
{
uint8_t x_5; 
x_5 = !lean_is_exclusive(x_1);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; uint8_t x_8; 
x_6 = lean_ctor_get(x_1, 0);
x_7 = lean_apply_1(x_6, x_2);
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_ctor_set(x_1, 0, x_9);
x_10 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495_(x_1);
lean_dec(x_1);
lean_ctor_set(x_7, 0, x_10);
return x_7;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_11 = lean_ctor_get(x_7, 0);
x_12 = lean_ctor_get(x_7, 1);
lean_inc(x_12);
lean_inc(x_11);
lean_dec(x_7);
lean_ctor_set(x_1, 0, x_11);
x_13 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495_(x_1);
lean_dec(x_1);
x_14 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_14, 1, x_12);
return x_14;
}
}
else
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_15 = lean_ctor_get(x_1, 0);
lean_inc(x_15);
lean_dec(x_1);
x_16 = lean_apply_1(x_15, x_2);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
if (lean_is_exclusive(x_16)) {
 lean_ctor_release(x_16, 0);
 lean_ctor_release(x_16, 1);
 x_19 = x_16;
} else {
 lean_dec_ref(x_16);
 x_19 = lean_box(0);
}
x_20 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_20, 0, x_17);
x_21 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_495_(x_20);
lean_dec(x_20);
if (lean_is_scalar(x_19)) {
 x_22 = lean_alloc_ctor(0, 2, 0);
} else {
 x_22 = x_19;
}
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_22, 1, x_18);
return x_22;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable___hyg_343_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable___hyg_343_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg____x40_ProofWidgets_Cancellable___hyg_343_(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_384_(x_1);
if (lean_obj_tag(x_2) == 0)
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
return x_2;
}
else
{
lean_object* x_4; lean_object* x_5; 
x_4 = lean_ctor_get(x_2, 0);
lean_inc(x_4);
lean_dec(x_2);
x_5 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_5, 0, x_4);
return x_5;
}
}
else
{
uint8_t x_6; 
x_6 = !lean_is_exclusive(x_2);
if (x_6 == 0)
{
lean_object* x_7; 
x_7 = lean_ctor_get(x_2, 0);
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_8; 
lean_free_object(x_2);
x_8 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable___hyg_343_;
return x_8;
}
else
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_7);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_ctor_get(x_7, 0);
x_11 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable___hyg_343_), 2, 1);
lean_closure_set(x_11, 0, x_10);
lean_ctor_set(x_7, 0, x_11);
return x_2;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_12 = lean_ctor_get(x_7, 0);
lean_inc(x_12);
lean_dec(x_7);
x_13 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable___hyg_343_), 2, 1);
lean_closure_set(x_13, 0, x_12);
x_14 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_2, 0, x_14);
return x_2;
}
}
}
else
{
lean_object* x_15; 
x_15 = lean_ctor_get(x_2, 0);
lean_inc(x_15);
lean_dec(x_2);
if (lean_obj_tag(x_15) == 0)
{
lean_object* x_16; 
x_16 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable___hyg_343_;
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_17 = lean_ctor_get(x_15, 0);
lean_inc(x_17);
if (lean_is_exclusive(x_15)) {
 lean_ctor_release(x_15, 0);
 x_18 = x_15;
} else {
 lean_dec_ref(x_15);
 x_18 = lean_box(0);
}
x_19 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___lam__0____x40_ProofWidgets_Cancellable___hyg_343_), 2, 1);
lean_closure_set(x_19, 0, x_17);
if (lean_is_scalar(x_18)) {
 x_20 = lean_alloc_ctor(1, 1, 0);
} else {
 x_20 = x_18;
}
lean_ctor_set(x_20, 0, x_19);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_20);
return x_21;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable___hyg_343_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg____x40_ProofWidgets_Cancellable___hyg_343_(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable___hyg_343____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable___hyg_343_(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc____x40_ProofWidgets_Cancellable___hyg_343_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec____x40_ProofWidgets_Cancellable___hyg_343____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1;
x_2 = l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Request '", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___lam__0___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("' has already finished, or the ID is invalid.", 45, 45);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; uint8_t x_8; 
x_5 = lean_st_ref_get(x_1, x_4);
x_6 = lean_ctor_get(x_5, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_6, 1);
lean_inc(x_7);
lean_dec(x_6);
x_8 = !lean_is_exclusive(x_5);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint64_t x_13; uint64_t x_14; uint64_t x_15; uint64_t x_16; uint64_t x_17; uint64_t x_18; uint64_t x_19; size_t x_20; size_t x_21; size_t x_22; size_t x_23; size_t x_24; lean_object* x_25; lean_object* x_26; 
x_9 = lean_ctor_get(x_5, 1);
x_10 = lean_ctor_get(x_5, 0);
lean_dec(x_10);
x_11 = lean_ctor_get(x_7, 1);
lean_inc(x_11);
lean_dec(x_7);
x_12 = lean_array_get_size(x_11);
x_13 = lean_uint64_of_nat(x_2);
x_14 = 32;
x_15 = lean_uint64_shift_right(x_13, x_14);
x_16 = lean_uint64_xor(x_13, x_15);
x_17 = 16;
x_18 = lean_uint64_shift_right(x_16, x_17);
x_19 = lean_uint64_xor(x_16, x_18);
x_20 = lean_uint64_to_usize(x_19);
x_21 = lean_usize_of_nat(x_12);
lean_dec(x_12);
x_22 = 1;
x_23 = lean_usize_sub(x_21, x_22);
x_24 = lean_usize_land(x_20, x_23);
x_25 = lean_array_uget(x_11, x_24);
lean_dec(x_11);
x_26 = l_Std_DHashMap_Internal_AssocList_get_x3f___at___Int_Linear_Expr_applyPerm_go_spec__0___redArg(x_2, x_25);
lean_dec(x_25);
if (lean_obj_tag(x_26) == 0)
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_27 = l_ProofWidgets_checkRequest___lam__0___closed__0;
x_28 = l_Nat_reprFast(x_2);
x_29 = lean_string_append(x_27, x_28);
lean_dec(x_28);
x_30 = l_ProofWidgets_checkRequest___lam__0___closed__1;
x_31 = lean_string_append(x_29, x_30);
x_32 = l_Lean_Server_RequestError_invalidParams(x_31);
lean_ctor_set_tag(x_5, 1);
lean_ctor_set(x_5, 0, x_32);
return x_5;
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
lean_free_object(x_5);
x_33 = lean_ctor_get(x_26, 0);
lean_inc(x_33);
lean_dec(x_26);
x_34 = lean_ctor_get(x_33, 0);
lean_inc(x_34);
lean_dec(x_33);
x_35 = lean_io_get_task_state(x_34, x_9);
x_36 = lean_ctor_get(x_35, 0);
lean_inc(x_36);
if (lean_obj_tag(x_36) == 2)
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_63; lean_object* x_64; lean_object* x_65; size_t x_66; size_t x_67; size_t x_68; lean_object* x_69; uint8_t x_70; 
x_37 = lean_ctor_get(x_35, 1);
lean_inc(x_37);
lean_dec(x_35);
x_38 = lean_st_ref_take(x_1, x_37);
x_39 = lean_ctor_get(x_38, 0);
lean_inc(x_39);
x_40 = lean_ctor_get(x_38, 1);
lean_inc(x_40);
lean_dec(x_38);
x_41 = lean_ctor_get(x_39, 0);
lean_inc(x_41);
x_42 = lean_ctor_get(x_39, 1);
lean_inc(x_42);
if (lean_is_exclusive(x_39)) {
 lean_ctor_release(x_39, 0);
 lean_ctor_release(x_39, 1);
 x_43 = x_39;
} else {
 lean_dec_ref(x_39);
 x_43 = lean_box(0);
}
x_63 = lean_ctor_get(x_42, 0);
lean_inc(x_63);
x_64 = lean_ctor_get(x_42, 1);
lean_inc(x_64);
x_65 = lean_array_get_size(x_64);
x_66 = lean_usize_of_nat(x_65);
lean_dec(x_65);
x_67 = lean_usize_sub(x_66, x_22);
x_68 = lean_usize_land(x_20, x_67);
x_69 = lean_array_uget(x_64, x_68);
x_70 = l_Std_DHashMap_Internal_AssocList_contains___at___Lean_Expr_CollectLooseBVars_main_spec__0___redArg(x_2, x_69);
if (x_70 == 0)
{
lean_dec(x_69);
lean_dec(x_64);
lean_dec(x_63);
lean_dec(x_2);
x_44 = x_42;
goto block_62;
}
else
{
uint8_t x_71; 
x_71 = !lean_is_exclusive(x_42);
if (x_71 == 0)
{
lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; 
x_72 = lean_ctor_get(x_42, 1);
lean_dec(x_72);
x_73 = lean_ctor_get(x_42, 0);
lean_dec(x_73);
x_74 = lean_box(0);
x_75 = lean_array_uset(x_64, x_68, x_74);
x_76 = lean_unsigned_to_nat(1u);
x_77 = lean_nat_sub(x_63, x_76);
lean_dec(x_63);
x_78 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_2, x_69);
lean_dec(x_2);
x_79 = lean_array_uset(x_75, x_68, x_78);
lean_ctor_set(x_42, 1, x_79);
lean_ctor_set(x_42, 0, x_77);
x_44 = x_42;
goto block_62;
}
else
{
lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; 
lean_dec(x_42);
x_80 = lean_box(0);
x_81 = lean_array_uset(x_64, x_68, x_80);
x_82 = lean_unsigned_to_nat(1u);
x_83 = lean_nat_sub(x_63, x_82);
lean_dec(x_63);
x_84 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_2, x_69);
lean_dec(x_2);
x_85 = lean_array_uset(x_81, x_68, x_84);
x_86 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_86, 0, x_83);
lean_ctor_set(x_86, 1, x_85);
x_44 = x_86;
goto block_62;
}
}
block_62:
{
lean_object* x_45; lean_object* x_46; uint8_t x_47; 
if (lean_is_scalar(x_43)) {
 x_45 = lean_alloc_ctor(0, 2, 0);
} else {
 x_45 = x_43;
}
lean_ctor_set(x_45, 0, x_41);
lean_ctor_set(x_45, 1, x_44);
x_46 = lean_st_ref_set(x_1, x_45, x_40);
x_47 = !lean_is_exclusive(x_46);
if (x_47 == 0)
{
lean_object* x_48; lean_object* x_49; 
x_48 = lean_ctor_get(x_46, 0);
lean_dec(x_48);
x_49 = lean_task_get_own(x_34);
if (lean_obj_tag(x_49) == 0)
{
lean_object* x_50; 
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec(x_49);
lean_ctor_set_tag(x_46, 1);
lean_ctor_set(x_46, 0, x_50);
return x_46;
}
else
{
uint8_t x_51; 
x_51 = !lean_is_exclusive(x_49);
if (x_51 == 0)
{
lean_ctor_set(x_46, 0, x_49);
return x_46;
}
else
{
lean_object* x_52; lean_object* x_53; 
x_52 = lean_ctor_get(x_49, 0);
lean_inc(x_52);
lean_dec(x_49);
x_53 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_53, 0, x_52);
lean_ctor_set(x_46, 0, x_53);
return x_46;
}
}
}
else
{
lean_object* x_54; lean_object* x_55; 
x_54 = lean_ctor_get(x_46, 1);
lean_inc(x_54);
lean_dec(x_46);
x_55 = lean_task_get_own(x_34);
if (lean_obj_tag(x_55) == 0)
{
lean_object* x_56; lean_object* x_57; 
x_56 = lean_ctor_get(x_55, 0);
lean_inc(x_56);
lean_dec(x_55);
x_57 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set(x_57, 1, x_54);
return x_57;
}
else
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; 
x_58 = lean_ctor_get(x_55, 0);
lean_inc(x_58);
if (lean_is_exclusive(x_55)) {
 lean_ctor_release(x_55, 0);
 x_59 = x_55;
} else {
 lean_dec_ref(x_55);
 x_59 = lean_box(0);
}
if (lean_is_scalar(x_59)) {
 x_60 = lean_alloc_ctor(1, 1, 0);
} else {
 x_60 = x_59;
}
lean_ctor_set(x_60, 0, x_58);
x_61 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_61, 0, x_60);
lean_ctor_set(x_61, 1, x_54);
return x_61;
}
}
}
}
else
{
uint8_t x_87; 
lean_dec(x_36);
lean_dec(x_34);
lean_dec(x_2);
x_87 = !lean_is_exclusive(x_35);
if (x_87 == 0)
{
lean_object* x_88; lean_object* x_89; 
x_88 = lean_ctor_get(x_35, 0);
lean_dec(x_88);
x_89 = lean_box(0);
lean_ctor_set(x_35, 0, x_89);
return x_35;
}
else
{
lean_object* x_90; lean_object* x_91; lean_object* x_92; 
x_90 = lean_ctor_get(x_35, 1);
lean_inc(x_90);
lean_dec(x_35);
x_91 = lean_box(0);
x_92 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_92, 0, x_91);
lean_ctor_set(x_92, 1, x_90);
return x_92;
}
}
}
}
else
{
lean_object* x_93; lean_object* x_94; lean_object* x_95; uint64_t x_96; uint64_t x_97; uint64_t x_98; uint64_t x_99; uint64_t x_100; uint64_t x_101; uint64_t x_102; size_t x_103; size_t x_104; size_t x_105; size_t x_106; size_t x_107; lean_object* x_108; lean_object* x_109; 
x_93 = lean_ctor_get(x_5, 1);
lean_inc(x_93);
lean_dec(x_5);
x_94 = lean_ctor_get(x_7, 1);
lean_inc(x_94);
lean_dec(x_7);
x_95 = lean_array_get_size(x_94);
x_96 = lean_uint64_of_nat(x_2);
x_97 = 32;
x_98 = lean_uint64_shift_right(x_96, x_97);
x_99 = lean_uint64_xor(x_96, x_98);
x_100 = 16;
x_101 = lean_uint64_shift_right(x_99, x_100);
x_102 = lean_uint64_xor(x_99, x_101);
x_103 = lean_uint64_to_usize(x_102);
x_104 = lean_usize_of_nat(x_95);
lean_dec(x_95);
x_105 = 1;
x_106 = lean_usize_sub(x_104, x_105);
x_107 = lean_usize_land(x_103, x_106);
x_108 = lean_array_uget(x_94, x_107);
lean_dec(x_94);
x_109 = l_Std_DHashMap_Internal_AssocList_get_x3f___at___Int_Linear_Expr_applyPerm_go_spec__0___redArg(x_2, x_108);
lean_dec(x_108);
if (lean_obj_tag(x_109) == 0)
{
lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; 
x_110 = l_ProofWidgets_checkRequest___lam__0___closed__0;
x_111 = l_Nat_reprFast(x_2);
x_112 = lean_string_append(x_110, x_111);
lean_dec(x_111);
x_113 = l_ProofWidgets_checkRequest___lam__0___closed__1;
x_114 = lean_string_append(x_112, x_113);
x_115 = l_Lean_Server_RequestError_invalidParams(x_114);
x_116 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_116, 0, x_115);
lean_ctor_set(x_116, 1, x_93);
return x_116;
}
else
{
lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; 
x_117 = lean_ctor_get(x_109, 0);
lean_inc(x_117);
lean_dec(x_109);
x_118 = lean_ctor_get(x_117, 0);
lean_inc(x_118);
lean_dec(x_117);
x_119 = lean_io_get_task_state(x_118, x_93);
x_120 = lean_ctor_get(x_119, 0);
lean_inc(x_120);
if (lean_obj_tag(x_120) == 2)
{
lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_141; lean_object* x_142; lean_object* x_143; size_t x_144; size_t x_145; size_t x_146; lean_object* x_147; uint8_t x_148; 
x_121 = lean_ctor_get(x_119, 1);
lean_inc(x_121);
lean_dec(x_119);
x_122 = lean_st_ref_take(x_1, x_121);
x_123 = lean_ctor_get(x_122, 0);
lean_inc(x_123);
x_124 = lean_ctor_get(x_122, 1);
lean_inc(x_124);
lean_dec(x_122);
x_125 = lean_ctor_get(x_123, 0);
lean_inc(x_125);
x_126 = lean_ctor_get(x_123, 1);
lean_inc(x_126);
if (lean_is_exclusive(x_123)) {
 lean_ctor_release(x_123, 0);
 lean_ctor_release(x_123, 1);
 x_127 = x_123;
} else {
 lean_dec_ref(x_123);
 x_127 = lean_box(0);
}
x_141 = lean_ctor_get(x_126, 0);
lean_inc(x_141);
x_142 = lean_ctor_get(x_126, 1);
lean_inc(x_142);
x_143 = lean_array_get_size(x_142);
x_144 = lean_usize_of_nat(x_143);
lean_dec(x_143);
x_145 = lean_usize_sub(x_144, x_105);
x_146 = lean_usize_land(x_103, x_145);
x_147 = lean_array_uget(x_142, x_146);
x_148 = l_Std_DHashMap_Internal_AssocList_contains___at___Lean_Expr_CollectLooseBVars_main_spec__0___redArg(x_2, x_147);
if (x_148 == 0)
{
lean_dec(x_147);
lean_dec(x_142);
lean_dec(x_141);
lean_dec(x_2);
x_128 = x_126;
goto block_140;
}
else
{
lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; 
if (lean_is_exclusive(x_126)) {
 lean_ctor_release(x_126, 0);
 lean_ctor_release(x_126, 1);
 x_149 = x_126;
} else {
 lean_dec_ref(x_126);
 x_149 = lean_box(0);
}
x_150 = lean_box(0);
x_151 = lean_array_uset(x_142, x_146, x_150);
x_152 = lean_unsigned_to_nat(1u);
x_153 = lean_nat_sub(x_141, x_152);
lean_dec(x_141);
x_154 = l_Std_DHashMap_Internal_AssocList_erase___at___ProofWidgets_cancelRequest_spec__0___redArg(x_2, x_147);
lean_dec(x_2);
x_155 = lean_array_uset(x_151, x_146, x_154);
if (lean_is_scalar(x_149)) {
 x_156 = lean_alloc_ctor(0, 2, 0);
} else {
 x_156 = x_149;
}
lean_ctor_set(x_156, 0, x_153);
lean_ctor_set(x_156, 1, x_155);
x_128 = x_156;
goto block_140;
}
block_140:
{
lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; 
if (lean_is_scalar(x_127)) {
 x_129 = lean_alloc_ctor(0, 2, 0);
} else {
 x_129 = x_127;
}
lean_ctor_set(x_129, 0, x_125);
lean_ctor_set(x_129, 1, x_128);
x_130 = lean_st_ref_set(x_1, x_129, x_124);
x_131 = lean_ctor_get(x_130, 1);
lean_inc(x_131);
if (lean_is_exclusive(x_130)) {
 lean_ctor_release(x_130, 0);
 lean_ctor_release(x_130, 1);
 x_132 = x_130;
} else {
 lean_dec_ref(x_130);
 x_132 = lean_box(0);
}
x_133 = lean_task_get_own(x_118);
if (lean_obj_tag(x_133) == 0)
{
lean_object* x_134; lean_object* x_135; 
x_134 = lean_ctor_get(x_133, 0);
lean_inc(x_134);
lean_dec(x_133);
if (lean_is_scalar(x_132)) {
 x_135 = lean_alloc_ctor(1, 2, 0);
} else {
 x_135 = x_132;
 lean_ctor_set_tag(x_135, 1);
}
lean_ctor_set(x_135, 0, x_134);
lean_ctor_set(x_135, 1, x_131);
return x_135;
}
else
{
lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; 
x_136 = lean_ctor_get(x_133, 0);
lean_inc(x_136);
if (lean_is_exclusive(x_133)) {
 lean_ctor_release(x_133, 0);
 x_137 = x_133;
} else {
 lean_dec_ref(x_133);
 x_137 = lean_box(0);
}
if (lean_is_scalar(x_137)) {
 x_138 = lean_alloc_ctor(1, 1, 0);
} else {
 x_138 = x_137;
}
lean_ctor_set(x_138, 0, x_136);
if (lean_is_scalar(x_132)) {
 x_139 = lean_alloc_ctor(0, 2, 0);
} else {
 x_139 = x_132;
}
lean_ctor_set(x_139, 0, x_138);
lean_ctor_set(x_139, 1, x_131);
return x_139;
}
}
}
else
{
lean_object* x_157; lean_object* x_158; lean_object* x_159; lean_object* x_160; 
lean_dec(x_120);
lean_dec(x_118);
lean_dec(x_2);
x_157 = lean_ctor_get(x_119, 1);
lean_inc(x_157);
if (lean_is_exclusive(x_119)) {
 lean_ctor_release(x_119, 0);
 lean_ctor_release(x_119, 1);
 x_158 = x_119;
} else {
 lean_dec_ref(x_119);
 x_158 = lean_box(0);
}
x_159 = lean_box(0);
if (lean_is_scalar(x_158)) {
 x_160 = lean_alloc_ctor(0, 2, 0);
} else {
 x_160 = x_158;
}
lean_ctor_set(x_160, 0, x_159);
lean_ctor_set(x_160, 1, x_157);
return x_160;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_4 = l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0;
x_5 = lean_alloc_closure((void*)(l_ProofWidgets_checkRequest___lam__0___boxed), 4, 2);
lean_closure_set(x_5, 0, x_4);
lean_closure_set(x_5, 1, x_1);
x_6 = l_Lean_Server_RequestM_asTask___redArg(x_5, x_2, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_checkRequest___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_checkRequest___lam__0(x_1, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
x_6 = lean_ctor_get(x_3, 0);
lean_inc(x_6);
lean_dec(x_3);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_8 = lean_ctor_get(x_3, 0);
lean_inc(x_8);
lean_dec(x_3);
x_9 = lean_st_ref_take(x_1, x_5);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__2), 2, 1);
lean_closure_set(x_14, 0, x_13);
x_15 = l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc____x40_ProofWidgets_Cancellable___hyg_343_(x_8, x_12);
x_16 = l_Prod_map___redArg(x_2, x_14, x_15);
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec(x_16);
x_19 = lean_st_ref_set(x_1, x_18, x_11);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; 
x_21 = lean_ctor_get(x_19, 0);
lean_dec(x_21);
lean_ctor_set(x_19, 0, x_17);
return x_19;
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_dec(x_19);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_17);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, uint64_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_inc(x_9);
x_10 = l_Lean_RBNode_find___at___Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0_spec__0___redArg(x_9, x_5);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_11 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__1;
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_10, 0);
lean_inc(x_13);
lean_dec(x_10);
x_14 = lean_st_ref_get(x_13, x_8);
x_15 = !lean_is_exclusive(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_16 = lean_ctor_get(x_14, 1);
x_17 = lean_ctor_get(x_14, 0);
lean_dec(x_17);
lean_inc(x_6);
x_18 = l_Lean_Json_getNat_x3f(x_6);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; uint8_t x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; uint8_t x_34; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
lean_dec(x_18);
x_20 = lean_box(3);
x_21 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__2;
x_22 = lean_box(1);
x_23 = lean_unbox(x_22);
x_24 = l_Lean_Name_toString(x_1, x_23, x_2);
x_25 = lean_string_append(x_21, x_24);
lean_dec(x_24);
x_26 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__3;
x_27 = lean_string_append(x_25, x_26);
x_28 = l_Lean_Json_compress(x_6);
x_29 = lean_string_append(x_27, x_28);
lean_dec(x_28);
x_30 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__4;
x_31 = lean_string_append(x_29, x_30);
x_32 = lean_string_append(x_31, x_19);
lean_dec(x_19);
x_33 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_33, 0, x_32);
x_34 = lean_unbox(x_20);
lean_ctor_set_uint8(x_33, sizeof(void*)*1, x_34);
lean_ctor_set_tag(x_14, 1);
lean_ctor_set(x_14, 0, x_33);
return x_14;
}
else
{
lean_object* x_35; lean_object* x_36; 
lean_free_object(x_14);
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_35 = lean_ctor_get(x_18, 0);
lean_inc(x_35);
lean_dec(x_18);
lean_inc(x_7);
x_36 = lean_apply_3(x_3, x_35, x_7, x_16);
if (lean_obj_tag(x_36) == 0)
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; 
x_37 = lean_ctor_get(x_36, 0);
lean_inc(x_37);
x_38 = lean_ctor_get(x_36, 1);
lean_inc(x_38);
lean_dec(x_36);
x_39 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_39, 0, x_13);
lean_closure_set(x_39, 1, x_4);
x_40 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_37, x_39, x_7, x_38);
return x_40;
}
else
{
uint8_t x_41; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_41 = !lean_is_exclusive(x_36);
if (x_41 == 0)
{
return x_36;
}
else
{
lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_42 = lean_ctor_get(x_36, 0);
x_43 = lean_ctor_get(x_36, 1);
lean_inc(x_43);
lean_inc(x_42);
lean_dec(x_36);
x_44 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_44, 0, x_42);
lean_ctor_set(x_44, 1, x_43);
return x_44;
}
}
}
}
else
{
lean_object* x_45; lean_object* x_46; 
x_45 = lean_ctor_get(x_14, 1);
lean_inc(x_45);
lean_dec(x_14);
lean_inc(x_6);
x_46 = l_Lean_Json_getNat_x3f(x_6);
if (lean_obj_tag(x_46) == 0)
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; uint8_t x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; uint8_t x_62; lean_object* x_63; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_3);
x_47 = lean_ctor_get(x_46, 0);
lean_inc(x_47);
lean_dec(x_46);
x_48 = lean_box(3);
x_49 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__2;
x_50 = lean_box(1);
x_51 = lean_unbox(x_50);
x_52 = l_Lean_Name_toString(x_1, x_51, x_2);
x_53 = lean_string_append(x_49, x_52);
lean_dec(x_52);
x_54 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__3;
x_55 = lean_string_append(x_53, x_54);
x_56 = l_Lean_Json_compress(x_6);
x_57 = lean_string_append(x_55, x_56);
lean_dec(x_56);
x_58 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__4;
x_59 = lean_string_append(x_57, x_58);
x_60 = lean_string_append(x_59, x_47);
lean_dec(x_47);
x_61 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_61, 0, x_60);
x_62 = lean_unbox(x_48);
lean_ctor_set_uint8(x_61, sizeof(void*)*1, x_62);
x_63 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_63, 0, x_61);
lean_ctor_set(x_63, 1, x_45);
return x_63;
}
else
{
lean_object* x_64; lean_object* x_65; 
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
x_64 = lean_ctor_get(x_46, 0);
lean_inc(x_64);
lean_dec(x_46);
lean_inc(x_7);
x_65 = lean_apply_3(x_3, x_64, x_7, x_45);
if (lean_obj_tag(x_65) == 0)
{
lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; 
x_66 = lean_ctor_get(x_65, 0);
lean_inc(x_66);
x_67 = lean_ctor_get(x_65, 1);
lean_inc(x_67);
lean_dec(x_65);
x_68 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__3___boxed), 5, 2);
lean_closure_set(x_68, 0, x_13);
lean_closure_set(x_68, 1, x_4);
x_69 = l_Lean_Server_RequestM_mapTaskCheap___redArg(x_66, x_68, x_7, x_67);
return x_69;
}
else
{
lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
x_70 = lean_ctor_get(x_65, 0);
lean_inc(x_70);
x_71 = lean_ctor_get(x_65, 1);
lean_inc(x_71);
if (lean_is_exclusive(x_65)) {
 lean_ctor_release(x_65, 0);
 lean_ctor_release(x_65, 1);
 x_72 = x_65;
} else {
 lean_dec_ref(x_65);
 x_72 = lean_box(0);
}
if (lean_is_scalar(x_72)) {
 x_73 = lean_alloc_ctor(1, 2, 0);
} else {
 x_73 = x_72;
}
lean_ctor_set(x_73, 0, x_70);
lean_ctor_set(x_73, 1, x_71);
return x_73;
}
}
}
}
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__0___boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__1___boxed), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0;
x_4 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__1;
x_5 = lean_alloc_closure((void*)(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0___boxed), 8, 4);
lean_closure_set(x_5, 0, x_1);
lean_closure_set(x_5, 1, x_3);
lean_closure_set(x_5, 2, x_2);
lean_closure_set(x_5, 3, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("checkRequest", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_checkRequest___rpc__wrapped___closed__0;
x_2 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_3 = l_Lean_Name_mkStr2(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_checkRequest), 3, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_checkRequest___rpc__wrapped() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_checkRequest___rpc__wrapped___closed__1;
x_2 = l_ProofWidgets_checkRequest___rpc__wrapped___closed__2;
x_3 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__3(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint64_t x_9; lean_object* x_10; 
x_9 = lean_unbox_uint64(x_5);
lean_dec(x_5);
x_10 = l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___lam__0(x_1, x_2, x_3, x_4, x_9, x_6, x_7, x_8);
return x_10;
}
}
static lean_object* _init_l_ProofWidgets_cancellableSuffix___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("_cancellable", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_cancellableSuffix___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_cancellableSuffix___closed__0;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_cancellableSuffix() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_cancellableSuffix___closed__1;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("attribute cannot be erased", 26, 26);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_Lean_stringToMessageData(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable___hyg_966_(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; 
x_5 = l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_966_;
x_6 = l_Lean_throwError___at___Lean_throwErrorAt___at___Lean_throwUnknownIdentifierAt___at___Lean_throwUnknownConstantAt___at___Lean_filterFieldList___at___Lean_realizeGlobalConstCore_spec__0_spec__2_spec__2_spec__2_spec__2___redArg(x_5, x_2, x_3, x_4);
return x_6;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; 
x_1 = l_Lean_PersistentHashMap_mkEmptyEntriesArray(lean_box(0), lean_box(0));
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__6____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__7____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__6____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_ProofWidgets_initFn___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_ProofWidgets_initFn___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_966_;
x_4 = l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_966_;
x_5 = l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_966_;
x_6 = l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_966_;
x_7 = lean_unsigned_to_nat(0u);
x_8 = lean_alloc_ctor(0, 9, 0);
lean_ctor_set(x_8, 0, x_7);
lean_ctor_set(x_8, 1, x_7);
lean_ctor_set(x_8, 2, x_7);
lean_ctor_set(x_8, 3, x_6);
lean_ctor_set(x_8, 4, x_5);
lean_ctor_set(x_8, 5, x_4);
lean_ctor_set(x_8, 6, x_3);
lean_ctor_set(x_8, 7, x_2);
lean_ctor_set(x_8, 8, x_1);
return x_8;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__8____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__9____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__10____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__11____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__12____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__11____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_ProofWidgets_initFn___lam__1___closed__10____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_ProofWidgets_initFn___lam__1___closed__9____x40_ProofWidgets_Cancellable___hyg_966_;
x_4 = l_ProofWidgets_initFn___lam__1___closed__8____x40_ProofWidgets_Cancellable___hyg_966_;
x_5 = lean_alloc_ctor(0, 6, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_4);
lean_ctor_set(x_5, 4, x_1);
lean_ctor_set(x_5, 5, x_1);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__13____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(32u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__14____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__13____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__15____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
size_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_ProofWidgets_initFn___lam__1___closed__13____x40_ProofWidgets_Cancellable___hyg_966_;
x_4 = l_ProofWidgets_initFn___lam__1___closed__14____x40_ProofWidgets_Cancellable___hyg_966_;
x_5 = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set_usize(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__16____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__17____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__16____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_2);
lean_ctor_set(x_3, 2, x_2);
lean_ctor_set(x_3, 3, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__18____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__17____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_ProofWidgets_initFn___lam__1___closed__15____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = lean_box(0);
x_4 = l_ProofWidgets_initFn___lam__1___closed__12____x40_ProofWidgets_Cancellable___hyg_966_;
x_5 = l_ProofWidgets_initFn___lam__1___closed__7____x40_ProofWidgets_Cancellable___hyg_966_;
x_6 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_3);
lean_ctor_set(x_6, 3, x_2);
lean_ctor_set(x_6, 4, x_1);
return x_6;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__19____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("mkCancellable", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__20____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__21____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; uint8_t x_7; uint8_t x_8; uint8_t x_9; uint8_t x_10; uint8_t x_11; uint8_t x_12; uint8_t x_13; uint8_t x_14; uint8_t x_15; uint8_t x_16; uint8_t x_17; uint8_t x_18; uint8_t x_19; uint8_t x_20; uint8_t x_21; uint8_t x_22; uint8_t x_23; uint8_t x_24; uint8_t x_25; 
x_1 = lean_box(2);
x_2 = lean_box(0);
x_3 = lean_box(1);
x_4 = lean_box(1);
x_5 = lean_box(0);
x_6 = lean_alloc_ctor(0, 0, 19);
x_7 = lean_unbox(x_5);
lean_ctor_set_uint8(x_6, 0, x_7);
x_8 = lean_unbox(x_5);
lean_ctor_set_uint8(x_6, 1, x_8);
x_9 = lean_unbox(x_5);
lean_ctor_set_uint8(x_6, 2, x_9);
x_10 = lean_unbox(x_5);
lean_ctor_set_uint8(x_6, 3, x_10);
x_11 = lean_unbox(x_5);
lean_ctor_set_uint8(x_6, 4, x_11);
x_12 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 5, x_12);
x_13 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 6, x_13);
x_14 = lean_unbox(x_5);
lean_ctor_set_uint8(x_6, 7, x_14);
x_15 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 8, x_15);
x_16 = lean_unbox(x_3);
lean_ctor_set_uint8(x_6, 9, x_16);
x_17 = lean_unbox(x_2);
lean_ctor_set_uint8(x_6, 10, x_17);
x_18 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 11, x_18);
x_19 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 12, x_19);
x_20 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 13, x_20);
x_21 = lean_unbox(x_1);
lean_ctor_set_uint8(x_6, 14, x_21);
x_22 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 15, x_22);
x_23 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 16, x_23);
x_24 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 17, x_24);
x_25 = lean_unbox(x_4);
lean_ctor_set_uint8(x_6, 18, x_25);
return x_6;
}
}
static uint64_t _init_l_ProofWidgets_initFn___lam__1___closed__22____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; uint64_t x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__21____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l___private_Lean_Meta_Basic_0__Lean_Meta_Config_toKey(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__23____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__24____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___lam__1___closed__13____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__25____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
size_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = 5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_ProofWidgets_initFn___lam__1___closed__13____x40_ProofWidgets_Cancellable___hyg_966_;
x_4 = l_ProofWidgets_initFn___lam__1___closed__24____x40_ProofWidgets_Cancellable___hyg_966_;
x_5 = lean_alloc_ctor(0, 4, sizeof(size_t)*1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set_usize(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__26____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_initFn___lam__1___closed__25____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_ProofWidgets_initFn___lam__1___closed__23____x40_ProofWidgets_Cancellable___hyg_966_;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__27____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___lam__1___closed__28____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; lean_object* x_10; uint8_t x_11; uint8_t x_12; uint8_t x_13; 
x_1 = lean_box(0);
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_box(0);
x_4 = l_ProofWidgets_initFn___lam__1___closed__27____x40_ProofWidgets_Cancellable___hyg_966_;
x_5 = l_ProofWidgets_initFn___lam__1___closed__26____x40_ProofWidgets_Cancellable___hyg_966_;
x_6 = lean_box(0);
x_7 = lean_box(0);
x_8 = l_ProofWidgets_initFn___lam__1___closed__22____x40_ProofWidgets_Cancellable___hyg_966_;
x_9 = l_ProofWidgets_initFn___lam__1___closed__21____x40_ProofWidgets_Cancellable___hyg_966_;
x_10 = lean_alloc_ctor(0, 7, 11);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_6);
lean_ctor_set(x_10, 2, x_5);
lean_ctor_set(x_10, 3, x_4);
lean_ctor_set(x_10, 4, x_3);
lean_ctor_set(x_10, 5, x_2);
lean_ctor_set(x_10, 6, x_1);
lean_ctor_set_uint64(x_10, sizeof(void*)*7, x_8);
x_11 = lean_unbox(x_7);
lean_ctor_set_uint8(x_10, sizeof(void*)*7 + 8, x_11);
x_12 = lean_unbox(x_7);
lean_ctor_set_uint8(x_10, sizeof(void*)*7 + 9, x_12);
x_13 = lean_unbox(x_7);
lean_ctor_set_uint8(x_10, sizeof(void*)*7 + 10, x_13);
return x_10;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable___hyg_966_(lean_object* x_1, lean_object* x_2, lean_object* x_3, uint8_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_8 = l_ProofWidgets_initFn___lam__1___closed__18____x40_ProofWidgets_Cancellable___hyg_966_;
x_9 = lean_st_mk_ref(x_8, x_7);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = lean_ctor_get(x_9, 1);
x_22 = l_ProofWidgets_initFn___lam__1___closed__19____x40_ProofWidgets_Cancellable___hyg_966_;
x_23 = l_Lean_Name_mkStr2(x_1, x_22);
x_24 = lean_box(0);
lean_inc(x_2);
x_25 = l_Lean_Expr_const___override(x_2, x_24);
x_26 = l_ProofWidgets_initFn___lam__1___closed__20____x40_ProofWidgets_Cancellable___hyg_966_;
x_27 = lean_array_push(x_26, x_25);
x_28 = l_ProofWidgets_initFn___lam__1___closed__28____x40_ProofWidgets_Cancellable___hyg_966_;
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_11);
x_29 = l_Lean_Meta_mkAppM(x_23, x_27, x_28, x_11, x_5, x_6, x_12);
if (lean_obj_tag(x_29) == 0)
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_29, 0);
lean_inc(x_30);
x_31 = lean_ctor_get(x_29, 1);
lean_inc(x_31);
lean_dec(x_29);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_11);
lean_inc(x_30);
x_32 = lean_infer_type(x_30, x_28, x_11, x_5, x_6, x_31);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; uint8_t x_42; lean_object* x_43; lean_object* x_44; 
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
x_34 = lean_ctor_get(x_32, 1);
lean_inc(x_34);
lean_dec(x_32);
x_35 = l_ProofWidgets_cancellableSuffix;
x_36 = l_Lean_Name_append(x_2, x_35);
x_37 = lean_box(0);
lean_inc(x_36);
x_38 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_38, 0, x_36);
lean_ctor_set(x_38, 1, x_37);
lean_ctor_set(x_38, 2, x_33);
x_39 = lean_box(0);
x_40 = lean_box(1);
lean_inc(x_36);
lean_ctor_set_tag(x_9, 1);
lean_ctor_set(x_9, 1, x_37);
lean_ctor_set(x_9, 0, x_36);
x_41 = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(x_41, 0, x_38);
lean_ctor_set(x_41, 1, x_30);
lean_ctor_set(x_41, 2, x_39);
lean_ctor_set(x_41, 3, x_9);
x_42 = lean_unbox(x_40);
lean_ctor_set_uint8(x_41, sizeof(void*)*4, x_42);
x_43 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_43, 0, x_41);
lean_inc(x_6);
lean_inc(x_5);
x_44 = l_Lean_addAndCompile(x_43, x_5, x_6, x_34);
if (lean_obj_tag(x_44) == 0)
{
lean_object* x_45; lean_object* x_46; 
x_45 = lean_ctor_get(x_44, 1);
lean_inc(x_45);
lean_dec(x_44);
x_46 = l_Lean_Server_registerRpcProcedure(x_36, x_5, x_6, x_45);
x_13 = x_46;
goto block_21;
}
else
{
lean_dec(x_36);
lean_dec(x_6);
lean_dec(x_5);
x_13 = x_44;
goto block_21;
}
}
else
{
uint8_t x_47; 
lean_dec(x_30);
lean_free_object(x_9);
lean_dec(x_11);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_47 = !lean_is_exclusive(x_32);
if (x_47 == 0)
{
return x_32;
}
else
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; 
x_48 = lean_ctor_get(x_32, 0);
x_49 = lean_ctor_get(x_32, 1);
lean_inc(x_49);
lean_inc(x_48);
lean_dec(x_32);
x_50 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_50, 0, x_48);
lean_ctor_set(x_50, 1, x_49);
return x_50;
}
}
}
else
{
uint8_t x_51; 
lean_free_object(x_9);
lean_dec(x_11);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_51 = !lean_is_exclusive(x_29);
if (x_51 == 0)
{
return x_29;
}
else
{
lean_object* x_52; lean_object* x_53; lean_object* x_54; 
x_52 = lean_ctor_get(x_29, 0);
x_53 = lean_ctor_get(x_29, 1);
lean_inc(x_53);
lean_inc(x_52);
lean_dec(x_29);
x_54 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_54, 0, x_52);
lean_ctor_set(x_54, 1, x_53);
return x_54;
}
}
block_21:
{
if (lean_obj_tag(x_13) == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_14 = lean_ctor_get(x_13, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_13, 1);
lean_inc(x_15);
lean_dec(x_13);
x_16 = lean_st_ref_get(x_11, x_15);
lean_dec(x_11);
x_17 = !lean_is_exclusive(x_16);
if (x_17 == 0)
{
lean_object* x_18; 
x_18 = lean_ctor_get(x_16, 0);
lean_dec(x_18);
lean_ctor_set(x_16, 0, x_14);
return x_16;
}
else
{
lean_object* x_19; lean_object* x_20; 
x_19 = lean_ctor_get(x_16, 1);
lean_inc(x_19);
lean_dec(x_16);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_14);
lean_ctor_set(x_20, 1, x_19);
return x_20;
}
}
else
{
lean_dec(x_11);
return x_13;
}
}
}
else
{
lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
x_55 = lean_ctor_get(x_9, 0);
x_56 = lean_ctor_get(x_9, 1);
lean_inc(x_56);
lean_inc(x_55);
lean_dec(x_9);
x_65 = l_ProofWidgets_initFn___lam__1___closed__19____x40_ProofWidgets_Cancellable___hyg_966_;
x_66 = l_Lean_Name_mkStr2(x_1, x_65);
x_67 = lean_box(0);
lean_inc(x_2);
x_68 = l_Lean_Expr_const___override(x_2, x_67);
x_69 = l_ProofWidgets_initFn___lam__1___closed__20____x40_ProofWidgets_Cancellable___hyg_966_;
x_70 = lean_array_push(x_69, x_68);
x_71 = l_ProofWidgets_initFn___lam__1___closed__28____x40_ProofWidgets_Cancellable___hyg_966_;
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_55);
x_72 = l_Lean_Meta_mkAppM(x_66, x_70, x_71, x_55, x_5, x_6, x_56);
if (lean_obj_tag(x_72) == 0)
{
lean_object* x_73; lean_object* x_74; lean_object* x_75; 
x_73 = lean_ctor_get(x_72, 0);
lean_inc(x_73);
x_74 = lean_ctor_get(x_72, 1);
lean_inc(x_74);
lean_dec(x_72);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_55);
lean_inc(x_73);
x_75 = lean_infer_type(x_73, x_71, x_55, x_5, x_6, x_74);
if (lean_obj_tag(x_75) == 0)
{
lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; uint8_t x_86; lean_object* x_87; lean_object* x_88; 
x_76 = lean_ctor_get(x_75, 0);
lean_inc(x_76);
x_77 = lean_ctor_get(x_75, 1);
lean_inc(x_77);
lean_dec(x_75);
x_78 = l_ProofWidgets_cancellableSuffix;
x_79 = l_Lean_Name_append(x_2, x_78);
x_80 = lean_box(0);
lean_inc(x_79);
x_81 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_81, 0, x_79);
lean_ctor_set(x_81, 1, x_80);
lean_ctor_set(x_81, 2, x_76);
x_82 = lean_box(0);
x_83 = lean_box(1);
lean_inc(x_79);
x_84 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_84, 0, x_79);
lean_ctor_set(x_84, 1, x_80);
x_85 = lean_alloc_ctor(0, 4, 1);
lean_ctor_set(x_85, 0, x_81);
lean_ctor_set(x_85, 1, x_73);
lean_ctor_set(x_85, 2, x_82);
lean_ctor_set(x_85, 3, x_84);
x_86 = lean_unbox(x_83);
lean_ctor_set_uint8(x_85, sizeof(void*)*4, x_86);
x_87 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_87, 0, x_85);
lean_inc(x_6);
lean_inc(x_5);
x_88 = l_Lean_addAndCompile(x_87, x_5, x_6, x_77);
if (lean_obj_tag(x_88) == 0)
{
lean_object* x_89; lean_object* x_90; 
x_89 = lean_ctor_get(x_88, 1);
lean_inc(x_89);
lean_dec(x_88);
x_90 = l_Lean_Server_registerRpcProcedure(x_79, x_5, x_6, x_89);
x_57 = x_90;
goto block_64;
}
else
{
lean_dec(x_79);
lean_dec(x_6);
lean_dec(x_5);
x_57 = x_88;
goto block_64;
}
}
else
{
lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; 
lean_dec(x_73);
lean_dec(x_55);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_91 = lean_ctor_get(x_75, 0);
lean_inc(x_91);
x_92 = lean_ctor_get(x_75, 1);
lean_inc(x_92);
if (lean_is_exclusive(x_75)) {
 lean_ctor_release(x_75, 0);
 lean_ctor_release(x_75, 1);
 x_93 = x_75;
} else {
 lean_dec_ref(x_75);
 x_93 = lean_box(0);
}
if (lean_is_scalar(x_93)) {
 x_94 = lean_alloc_ctor(1, 2, 0);
} else {
 x_94 = x_93;
}
lean_ctor_set(x_94, 0, x_91);
lean_ctor_set(x_94, 1, x_92);
return x_94;
}
}
else
{
lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; 
lean_dec(x_55);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_95 = lean_ctor_get(x_72, 0);
lean_inc(x_95);
x_96 = lean_ctor_get(x_72, 1);
lean_inc(x_96);
if (lean_is_exclusive(x_72)) {
 lean_ctor_release(x_72, 0);
 lean_ctor_release(x_72, 1);
 x_97 = x_72;
} else {
 lean_dec_ref(x_72);
 x_97 = lean_box(0);
}
if (lean_is_scalar(x_97)) {
 x_98 = lean_alloc_ctor(1, 2, 0);
} else {
 x_98 = x_97;
}
lean_ctor_set(x_98, 0, x_95);
lean_ctor_set(x_98, 1, x_96);
return x_98;
}
block_64:
{
if (lean_obj_tag(x_57) == 0)
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; 
x_58 = lean_ctor_get(x_57, 0);
lean_inc(x_58);
x_59 = lean_ctor_get(x_57, 1);
lean_inc(x_59);
lean_dec(x_57);
x_60 = lean_st_ref_get(x_55, x_59);
lean_dec(x_55);
x_61 = lean_ctor_get(x_60, 1);
lean_inc(x_61);
if (lean_is_exclusive(x_60)) {
 lean_ctor_release(x_60, 0);
 lean_ctor_release(x_60, 1);
 x_62 = x_60;
} else {
 lean_dec_ref(x_60);
 x_62 = lean_box(0);
}
if (lean_is_scalar(x_62)) {
 x_63 = lean_alloc_ctor(0, 2, 0);
} else {
 x_63 = x_62;
}
lean_ctor_set(x_63, 0, x_58);
lean_ctor_set(x_63, 1, x_61);
return x_63;
}
else
{
lean_dec(x_55);
return x_57;
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_2 = lean_box(0);
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("initFn", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("_@", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_2 = l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cancellable", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("_hyg", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_Lean_Name_str___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(966u);
x_2 = l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_Lean_Name_num___override(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("server_rpc_method_cancellable", 29, 29);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable___hyg_966_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Like `server_rpc_method`, but requests for this method can be cancelled. The method should check for that using `IO.checkCanceled`. Cancellable methods are invoked differently from JavaScript: see `callCancellable` in `cancellable.ts`.", 235, 235);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable___hyg_966_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; uint8_t x_6; 
x_1 = lean_box(1);
x_2 = l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable___hyg_966_;
x_3 = l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable___hyg_966_;
x_4 = l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable___hyg_966_;
x_5 = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
x_6 = lean_unbox(x_1);
lean_ctor_set_uint8(x_5, sizeof(void*)*3, x_6);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable___hyg_966_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable___hyg_966____boxed), 4, 0);
x_3 = l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0;
x_4 = lean_alloc_closure((void*)(l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable___hyg_966____boxed), 7, 1);
lean_closure_set(x_4, 0, x_3);
x_5 = l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable___hyg_966_;
x_6 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_2);
x_7 = l_Lean_registerBuiltinAttribute(x_6, x_1);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable___hyg_966____boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_initFn___lam__0____x40_ProofWidgets_Cancellable___hyg_966_(x_1, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable___hyg_966____boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint8_t x_8; lean_object* x_9; 
x_8 = lean_unbox(x_4);
lean_dec(x_4);
x_9 = l_ProofWidgets_initFn___lam__1____x40_ProofWidgets_Cancellable___hyg_966_(x_1, x_2, x_3, x_8, x_5, x_6, x_7);
lean_dec(x_3);
return x_9;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Data_Json_FromToJson(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Server_Rpc_RequestHandling(uint8_t builtin, lean_object*);
lean_object* initialize_Std_Data_HashMap(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Compat(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Cancellable(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Data_Json_FromToJson(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Server_Rpc_RequestHandling(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Std_Data_HashMap(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Compat(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_43_ = _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_43_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_43_);
l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_43_ = _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_43_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_43_);
l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_43_ = _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_43_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_43_);
l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_43_ = _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_43_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_43_);
l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_43_ = _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_43_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_43_);
l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_43_ = _init_l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_43_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_43_);
res = l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable___hyg_43_(lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
l_ProofWidgets_runningRequests = lean_io_result_get_value(res);
lean_mark_persistent(l_ProofWidgets_runningRequests);
lean_dec_ref(res);
l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0 = _init_l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0();
lean_mark_persistent(l_ProofWidgets_mkCancellable___redArg___lam__2___closed__0);
l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1 = _init_l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1();
lean_mark_persistent(l_ProofWidgets_mkCancellable___redArg___lam__2___closed__1);
l_ProofWidgets_mkCancellable___redArg___closed__0 = _init_l_ProofWidgets_mkCancellable___redArg___closed__0();
lean_mark_persistent(l_ProofWidgets_mkCancellable___redArg___closed__0);
l_ProofWidgets_mkCancellable___redArg___closed__1 = _init_l_ProofWidgets_mkCancellable___redArg___closed__1();
lean_mark_persistent(l_ProofWidgets_mkCancellable___redArg___closed__1);
l_ProofWidgets_cancelRequest___lam__0___closed__0 = _init_l_ProofWidgets_cancelRequest___lam__0___closed__0();
lean_mark_persistent(l_ProofWidgets_cancelRequest___lam__0___closed__0);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__0 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__0();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__0);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__1 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__1();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__1);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__2 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__2();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__2);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__3 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__3();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__3);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__4 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__4();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_cancelRequest___rpc__wrapped_spec__0___lam__4___closed__4);
l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0 = _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped___closed__0);
l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1 = _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped___closed__1);
l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2 = _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped___closed__2);
l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3 = _init_l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped___closed__3);
l_ProofWidgets_cancelRequest___rpc__wrapped = _init_l_ProofWidgets_cancelRequest___rpc__wrapped();
lean_mark_persistent(l_ProofWidgets_cancelRequest___rpc__wrapped);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__1____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__2____x40_ProofWidgets_Cancellable___hyg_384_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Cancellable___hyg_384_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Cancellable___hyg_384_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_fromJsonRpcEncodablePacket___closed__3____x40_ProofWidgets_Cancellable___hyg_384_);
l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_492_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_492_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_492_);
l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_492_ = _init_l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_492_();
lean_mark_persistent(l_ProofWidgets_instFromJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_492_);
l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_495_ = _init_l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_495_();
lean_mark_persistent(l___private_ProofWidgets_Cancellable_0__ProofWidgets_toJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_495_);
l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_546_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_546_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket___closed__0____x40_ProofWidgets_Cancellable___hyg_546_);
l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_546_ = _init_l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_546_();
lean_mark_persistent(l_ProofWidgets_instToJsonRpcEncodablePacket____x40_ProofWidgets_Cancellable___hyg_546_);
l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable___hyg_343_ = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable___hyg_343_();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse_enc___closed__0____x40_ProofWidgets_Cancellable___hyg_343_);
l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable___hyg_343_ = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable___hyg_343_();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse_dec___redArg___closed__0____x40_ProofWidgets_Cancellable___hyg_343_);
l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0 = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__0);
l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1 = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__1);
l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2 = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse___closed__2);
l_ProofWidgets_instRpcEncodableCheckRequestResponse = _init_l_ProofWidgets_instRpcEncodableCheckRequestResponse();
lean_mark_persistent(l_ProofWidgets_instRpcEncodableCheckRequestResponse);
l_ProofWidgets_checkRequest___lam__0___closed__0 = _init_l_ProofWidgets_checkRequest___lam__0___closed__0();
lean_mark_persistent(l_ProofWidgets_checkRequest___lam__0___closed__0);
l_ProofWidgets_checkRequest___lam__0___closed__1 = _init_l_ProofWidgets_checkRequest___lam__0___closed__1();
lean_mark_persistent(l_ProofWidgets_checkRequest___lam__0___closed__1);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__0);
l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__1 = _init_l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__1();
lean_mark_persistent(l_Lean_Server_wrapRpcProcedure___at___ProofWidgets_checkRequest___rpc__wrapped_spec__0___closed__1);
l_ProofWidgets_checkRequest___rpc__wrapped___closed__0 = _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__0();
lean_mark_persistent(l_ProofWidgets_checkRequest___rpc__wrapped___closed__0);
l_ProofWidgets_checkRequest___rpc__wrapped___closed__1 = _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__1();
lean_mark_persistent(l_ProofWidgets_checkRequest___rpc__wrapped___closed__1);
l_ProofWidgets_checkRequest___rpc__wrapped___closed__2 = _init_l_ProofWidgets_checkRequest___rpc__wrapped___closed__2();
lean_mark_persistent(l_ProofWidgets_checkRequest___rpc__wrapped___closed__2);
l_ProofWidgets_checkRequest___rpc__wrapped = _init_l_ProofWidgets_checkRequest___rpc__wrapped();
lean_mark_persistent(l_ProofWidgets_checkRequest___rpc__wrapped);
l_ProofWidgets_cancellableSuffix___closed__0 = _init_l_ProofWidgets_cancellableSuffix___closed__0();
lean_mark_persistent(l_ProofWidgets_cancellableSuffix___closed__0);
l_ProofWidgets_cancellableSuffix___closed__1 = _init_l_ProofWidgets_cancellableSuffix___closed__1();
lean_mark_persistent(l_ProofWidgets_cancellableSuffix___closed__1);
l_ProofWidgets_cancellableSuffix = _init_l_ProofWidgets_cancellableSuffix();
lean_mark_persistent(l_ProofWidgets_cancellableSuffix);
l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__0____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__0___closed__1____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__0____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__1____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__2____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__3____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__4____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__5____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__6____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__6____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__6____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__7____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__7____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__7____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__8____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__8____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__8____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__9____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__9____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__9____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__10____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__10____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__10____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__11____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__11____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__11____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__12____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__12____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__12____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__13____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__13____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__13____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__14____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__14____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__14____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__15____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__15____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__15____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__16____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__16____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__16____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__17____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__17____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__17____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__18____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__18____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__18____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__19____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__19____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__19____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__20____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__20____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__20____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__21____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__21____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__21____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__22____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__22____x40_ProofWidgets_Cancellable___hyg_966_();
l_ProofWidgets_initFn___lam__1___closed__23____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__23____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__23____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__24____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__24____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__24____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__25____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__25____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__25____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__26____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__26____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__26____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__27____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__27____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__27____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___lam__1___closed__28____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___lam__1___closed__28____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___lam__1___closed__28____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__0____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__1____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__2____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__3____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__4____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__5____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__6____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__7____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__8____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__9____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__10____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__11____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__12____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__13____x40_ProofWidgets_Cancellable___hyg_966_);
l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable___hyg_966_ = _init_l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable___hyg_966_();
lean_mark_persistent(l_ProofWidgets_initFn___closed__14____x40_ProofWidgets_Cancellable___hyg_966_);
res = l_ProofWidgets_initFn____x40_ProofWidgets_Cancellable___hyg_966_(lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
